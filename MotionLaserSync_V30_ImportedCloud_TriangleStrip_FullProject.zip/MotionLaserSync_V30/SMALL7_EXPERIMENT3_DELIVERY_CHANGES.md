# 第三实验 Small7 修订：完整源码文件改动表

原始源码：`MotionLaserSync_H1_H3_TWO_STAGE_DYNAMIC_HOLDOUT_LINK_FIXED_FULL_SOURCE.zip`。原工程全部原有文件保留；新增独立实验3模块。历史SHA清单只代表其当时版本。

## 修改文件
- `CMakeLists.txt`
- `include/app/MainWindow.h`
- `include/core/ZmcController.h`
- `src/app/MainWindow.cpp`
- `src/app/MainWindowSphereExposure.cpp`
- `src/core/ZmcController.cpp`

## 新增文件
- `README_SMALL7_EXPERIMENT3_FIXED_ZH.md`
- `config/small7_verified_roi.example.json`
- `include/calibration/Small7HeightPlan.h`
- `src/app/MainWindowSmall7Experiment.cpp`
- `src/calibration/Small7HeightPlan.cpp`
- `tools/small7_experiment3_cli.cpp`
- `tools/verify_small7_experiment3_contract.py`

## 删除文件
无

**说明**：所有GUI运动/传感器路径仅实现并完成静态源码合同检查；在交付环境无法进行Windows x64 Qt/VTK/FCL厂商SDK编译或真实机床测试。不能把可移植CLI通过当成硬件部署验收。
