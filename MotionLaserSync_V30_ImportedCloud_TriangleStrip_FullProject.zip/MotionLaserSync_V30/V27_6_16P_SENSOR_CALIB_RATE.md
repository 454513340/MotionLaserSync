# V27.6.16P — Sensor Calibration Profile Rate / Full Measuring Field / Runtime Verification

## Scope

This release changes only the upper-PC sensor-calibration workflow. ECI3808 V32.9 BASIC, TABLE ABI, PWM0 hardware synchronization, ProfileIngress, GapForensics, TABLE B/C UI and the Physical17 coordinate contract are unchanged.

## 1. Sensor calibration timing now follows the scanCONTROL profile-rate model

The `系统标定 -> 传感标定` page now has an explicit **轮廓频率** control.

- Default: **25 Hz**.
- Official scanCONTROL 2950 family device hard ceiling represented in validation logic: **2000 profiles/s**.
- Because this page forces the full measuring-field preset (MEASURINGFIELD index 0), the UI is conservatively capped by the project's preset reference table for index 0 (currently 144 Hz).
- The reference ceiling is labelled as a **project reference**, not a live sensor-reported maximum.

The timing relation is:

```text
cycleUnits = ceil(100000 / requestedProfileRateHz)   // 10 us units
idleUnits  = max(0, cycleUnits - exposureUnits)
```

`Profile Rate` has priority over `Exposure`. If the selected exposure is longer than the selected period, the sensor-calibration exposure editor is clamped to the period. The formal scan parameter page is not modified.

Examples:

```text
25 Hz, Exposure=5.00 ms -> Idle=35.00 ms, period=40.00 ms
100 Hz, Exposure=5.00 ms -> Idle=5.00 ms, period=10.00 ms
```

## 2. Full measuring field naming is explicit

The calibration UI no longer describes index 0 simply as “Large/full range”. It now says:

```text
全测量场预设 / MEASURINGFIELD index=0
```

and explicitly states that the program does **not** define the Configuration Tools start/end row/column ROI on this page.

This avoids mixing the sensor's physical **measuring range** with the matrix **measuring field**.

## 3. Real-device runtime constraint verification

A new `LaserSensor::readTimingAndMeasuringField()` path reads back from the connected scanCONTROL device:

- `FEATURE_FUNCTION_MEASURINGFIELD`
- `FEATURE_FUNCTION_EXPOSURE_TIME`
- `FEATURE_FUNCTION_IDLE_TIME`

Before Video/profile calibration preview is allowed to run, V27.6.16P verifies:

1. The live device reports measuring-field index 0.
2. The live exposure equals the requested manual exposure.
3. The live Idle equals the auto-calculated Idle.
4. The realized rate from the live timing is not faster than the requested rate.
5. Auto exposure is not active in this calibration path.

If any live readback differs, calibration preview/test fails closed and shows the mismatch.

When entering calibration, the previous measuring-field index is now saved from the **actual device readback** when possible, not only from the UI combo. On exit, the previous field is restored and read back again for confirmation. This prevents calibration from silently leaving the device in full-field mode before a later Small(7)/200 Hz hardware-synchronization run.

## 4. Exposure sweep uses the same timing contract

The exposure auto-test:

- keeps the profile-rate control fixed during the sweep;
- rejects a sweep whose end exposure cannot fit in the requested period;
- recomputes Idle for every exposure value;
- reads back live measuring field / Exposure / Idle before starting each Video/Profile segment;
- saves both `TargetProfileRate` and `RealizedProfileRate` in CSV metadata.

## 5. Valid-reflection parameters remain write-only on this 2950 setup

Repeated attempts to read back valid-reflection width/intensity have not been reliable on the tested scanCONTROL 2950-50/BL + SDK/firmware combination. V27.6.16P therefore deliberately does **not** add another readback/retry loop.

The four parameters remain:

```text
Min width      2
Max width      256
Min intensity  0
Max intensity  1023
```

They are written when `写入传感器` is used and success/failure is judged from the write command return path. `从传感器读取` preserves the current UI values for these four fields and logs that they are write-only/unverified. They are not part of the runtime timing constraint gate.

## 6. Physical17 coordinate contract preserved

No calibration-coordinate source changes were made:

```text
Normal motion / Physical17 / RTCP:
  X/Y/Z = DPOS
  C/B   = software mechanical MPOS

Hardware-sync TABLE:
  X/Y/Z/C/B = REGIST(104) hardware-latched raw MPOS
```

The sensor-calibration XYZCB pose button continues to call the canonical 5D sample path, preserving the validated Physical17 model convention.

## 7. Formal hardware synchronization unchanged

The formal V32.9 path still uses:

```text
Small measuring-field preset (index 7 in the current machine configuration)
External Edge Rising
OUT14/PWM0 = 200 Hz
Exposure = 1 ms
Idle = 3 ms
```

V27.6.16P changes only static sensor calibration/debug timing. It does not move formal hardware acquisition to 25 Hz.
