# MotionLaserSync V27.6.34 — 双方法 XYZ 补偿表验证

## 目的

V27.6.33 将 X/Y 补偿表采集改为“每个方向只 PRIME 一次，然后单向连续 SWEEP”，但旧 A/B 验证仍然对每个验证点重新执行 ±preload 的点到点最终接近。对于存在摩擦、预紧、拖链力或机械 settling 的轴，两种运动历史并不等价。

V27.6.34 **不要求重新采集任何 XYZ 补偿表**。它只升级验证器，并同时兼容：

- **旧式表**：V27.6.30 等逐点 preload 采表，例如用户当前的 Z 表；
- **新式表**：V27.6.33+ PRIME-once + monotonic SWEEP 采表，例如用户当前的 X/Y 表。

## 自动选择验证方法

加载 `X/Y/Z_compensation_candidate.csv` 后，程序读取同目录 `axis_compensation_manifest.json`：

- manifest 声明 `monotonic` / `direction-prime-once` 采样策略：自动选择 `MONOTONIC_SWEEP`；
- 旧 manifest 未声明新策略：自动选择 `POINT_TO_POINT_PRELOAD`。

UI 同时允许手动覆盖自动选择，便于诊断或文件被移动后 manifest 不在同目录时使用。

## 方法 1：旧式逐点 preload 验证

用于旧 Z 表。

每个独立 off-grid 验证目标都执行：

1. coarse 到 `command ± preload`；
2. precision 最终接近 `command`；
3. IDLE + settle；
4. 分别做 RAW 与 COMPENSATED；
5. 奇偶循环交换 RAW/COMP 顺序。

这是 V27.6.31A 的原始验证运动学，保持兼容。

## 方法 2：新式单向 monotonic SWEEP 验证

用于 V27.6.33 X/Y 表。

验证目标仍取相邻表节点的中点，因此不直接复用建表节点。每个方向 / cycle / mode：

1. 计算整条 RAW 或 COMPENSATED off-grid 命令；
2. 只在第一个目标前做一次 coarse preload（`PRIME`）；
3. precision 到第一个验证点；
4. 后续所有验证点只沿相同方向连续运动（`SWEEP`），**不再逐点反向 preload**；
5. RAW 和 COMPENSATED 作为两条完整 sweep 分开执行；
6. Cycle 1: RAW→COMP；Cycle 2: COMP→RAW；Cycle 3: RAW→COMP，以减弱长时间热漂移顺序偏置。

这样验证和新采表在“方向历史”上保持一致。

## 输出增强

`axis_compensation_ab_validation.csv` 新增：

- `validation_method`
- `approach_mode`

其中：

- legacy：`POINT_TO_POINT_PRELOAD / POINT`
- new：`MONOTONIC_SWEEP / PRIME|SWEEP`

验证 manifest 升级为 version 2，并保存：

- `validation_method`
- `validation_method_auto_recommendation`
- `candidate_sampling_strategy_detected`
- `validation_motion_strategy`
- 候选表 motion profile（如果有）

## 当前 XYZ 建议

### Z

使用旧的、已经跨断电表现良好的 Z candidate 表。加载后自动模式应显示：

`旧式逐点预加载`

不需要重新采 Z。

### X / Y

使用 V27.6.33 重新生成的 X/Y candidate 表。加载后自动模式应显示：

`新式单向SWEEP`

也不需要重新采 X/Y。

建议第一次正式复验：

- 方向：正向 + 反向
- 独立验证点：36（想增强覆盖可用 48~72）
- 重复：3
- settle：2000 ms
- preload：让程序从 manifest 自动恢复（当前 X/Y 为 2 mm）
- 方法：自动

## 注意

- V27.6.34 仍然不会开启 runtime/global compensation；只做验证。
- Physical17、G-code、RTCP、Jog、普通定位均未接入补偿。
- 新式 sweep 验证如果只选较少验证点，点间距会大于原 0.5 mm 建表间距；它主要保证“单向、不逐点反向 preload”的机械历史一致。若要更逼近原采表步态，可增加验证点数。
