# V30 MSVC collision API compilation fix

## Scope

This revision targets the Windows Visual Studio errors reported in
`src/safety/MachineSafetyModel.cpp`, lines 166, 167, 173, and 261–262:
`C2039/E0135` for `CollisionEngine::setWorkpiece`, `clearWorkpiece`,
`minimumDistanceBelow`, followed by `C2737` and `C3536` for `d`.

## Root-cause assessment

The uploaded source ZIPs contain these methods in
`machine5x/collision_engine.h` and their implementations in
`machine5x/collision_engine.cpp`. The screenshot nevertheless shows an
unmatched `CollisionEngine` at compile time. This is consistent with a
stale/wrong header being used or a project tree containing mixed revisions.
The screenshot's Windows path starts with
`MotionLaserSync_V30_STEP_Collision_Motion_Timeout_Fix`, the previous
release directory, rather than `SITE_ACCEPTANCE_MSVC_FIX`.
A definite local MSVC preprocessor trace is not available; the exact cause
on the Windows workstation therefore remains to be confirmed.

## Changes

1. `include/safety/MachineSafetyModel.h`: use the exact bundled header
   `../../machine5x/collision_engine.h` instead of ambiguous include
   `collision_engine.h`, which could be resolved from another include folder.
2. `machine5x/collision_engine.h`: mark the STEP-workpiece API revision 2;
   retains the declarations for the three methods as well as `workpiece_`.
3. `src/safety/MachineSafetyModel.cpp`: add C++17 compile-time signature
   checks (`static_assert`) so mismatched signatures or stale declarations
   fail close to the cause instead of producing long downstream diagnostics.
4. `tests/safety/collision_engine_header_contract.cpp`: compile-time
   regression checks for the three methods and revision, runnable without
   Windows hardware, FCL, Qt, or OCCT via type-only mocks.
5. `CMakeLists.txt`: register the regression test in portable CLI mode.

No collision thresholds, real-machine authorization rules, controller motion
commands, or Step 4 site acceptance criteria were changed in this patch.

## Windows installation and clean rebuild

**Important: extract the COMPLETE archive into a NEW, EMPTY directory.**
Do not overwrite selected `.cpp` files in the old `STEP_Collision_Motion_Timeout_Fix`
directory: `MachineSafetyModel.cpp` and `machine5x/collision_engine.h/.cpp`
must be from the same revision.

1. Close Visual Studio. Extract the new ZIP into a new folder such as
   `E:\Projects\MotionLaserSync_V30_MSVC_API_FIX\MotionLaserSync_V30`.
2. Open `MotionLaserSync_V30/CMakeLists.txt` in Visual Studio, **not** the
   CMake project in the old `STEP_Collision_Motion_Timeout_Fix` folder.
3. Remove the CMake build cache for the *new working copy* if reusing a build
   folder (`out/build`, `CMakeCache.txt`, `CMakeFiles`, `.vs` as applicable).
   Never delete controller configuration, calibration data, or user AppData.
4. Select your already-configured Windows x64 Release dependencies and build.
   Before compiling, confirm the project has all three declarations inside
   `machine5x/collision_engine.h` and the exact relative include in
   `include/safety/MachineSafetyModel.h`.
5. If `C2039` still occurs, include the VS source path and compiler's
   `/showIncludes` output for `MachineSafetyModel.cpp`: it will reveal the
   actual `collision_engine.h` loaded by the compiler.

## Verification performed here

- Linux CMake portable CLI-only build: PASS.
- New C++17 collision header signature test: PASS.
- All portable CTest cases: 33/33 PASS.
- Confirmed that the ZIP includes both declaration and implementation for
  `setWorkpiece`, `clearWorkpiece`, and `minimumDistanceBelow`.
- **Not verified**: complete Windows/Visual Studio GUI binary, real Qt/FCL
  compilation or real-machine motion. These dependencies are absent here.

All packaged paths/names are ASCII only; document and UI text may contain
Chinese characters.
