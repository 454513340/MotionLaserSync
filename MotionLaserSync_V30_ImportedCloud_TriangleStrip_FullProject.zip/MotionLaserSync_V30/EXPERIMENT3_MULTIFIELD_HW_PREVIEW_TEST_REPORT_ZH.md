# 实验3多场模式与硬件同步轮廓显示：源码修订与离线测试报告

2026-10-13 | 完整工程源码修订 | **非现场实机验收报告**

## 用户反馈及改动

### A. 传感器标定的「启动轮廓显示」

- **正式软件/硬件同步采集已经运行**：增加只读显示附着。仅周期性读取 `LaserSensor::latestProfile()` 的最新解码帧，不改写传感器硬件触发、LLT Trigger Feature、OP14、ECI TABLE 或现有 SyncManager 任务。点击「停止轮廓显示」只解除UI显示，不停传感器同步传输。
- **防止旧帧充当实时画面**：绑定当前会话原始 `callbackOrdinal` 基线；仅显示新的callback编号。正式采集停止时自动解绑；运行中2.5秒没有新帧则显示等待/中断提示。有新帧后显示恢复提示。
- **未启动正式采集**：独立标定轮廓预览使用传感器 `SoftwareInternal`，不管界面下次正式采集选了软件或硬件。此时明确显示「独立软件内部触发，非硬件同步测量」。传感器已经被其他任务占用时，不擅自停流。
- **H1/H3区别**：H1依赖OP14真实外部触发；H3依赖传感器内部轮廓时钟与CMM链路。预览不产生任何触发事件，因此不能用UI动作代替真正的硬件同步源和时域校验。

### B. 实验3可选择测量场

- 将原专用Small7场号改为实际选择的 `measuringFieldIndex`，支持 `0=Large`、`2=Standard`、`7=Small` 及本工程Quick Reference提供的其他 `0..127` 场号（仅限Profile Measuring Field，**不包括Video或其他非Profile传输格式**）。
- 在规划核心、设备configure、曝光/Idle/场号回读、Profile采集、Session、各层结果文件中使用同一选择。选择时自动按照工程原有2950表收缩频率上限（例如Large=144Hz，Standard=192Hz，Small=552Hz）。
- 加入完整128项频率上限表的自动一致性检查：多场规划模块与 `LaserSensor` 项目SDK包装表逐项对照，防止运行时不同模块限速不一致。
- 每个场仍要求**独立实测**的X/Z范围、FlipX/FlipZ、verificationId和`verified=true`。新增3份示例配置全部是`verified=false`且范围为0，**绝不可直接用于启动机床**。
- 定位速度1～5mm/s、X扫描1mm/s，以及Physical17/MachineSafety保护保留不变。
- Session元数据使用 `Experiment3.MultiField.v2`，归档改为 `Experiment3/FieldN_<UTC>/`。为兼容旧解析工具，原始轮廓容器`S7P1/.s7raw`暂未更名；**必须通过Session读取真正的measuringFieldIndex**。
- 为避免误导，原来执行信息中的「Small7」提示已大部分改为「实验3/当前测量场」，结束记录为`Experiment3.MultiField.Completion.v2`。

## 当前环境已运行的测试

| 验证 | 结果 | 范围 |
|---|---|---|
| CMake portable `small7_experiment3_cli` + CTest | **通过**（1/1） | 测量场、已验证ROI、误配置拒绝、采样上限、Z规划、Physical17退化拒绝、1～5/1 mm/s运动约束 |
| 同一CLI的 ASan + UBSan | **通过**（1/1） | 可移植C++模块的内存/未定义行为检查 |
| Portable `sphere_exposure_cli` | **通过** | 原有圆弧、峰值等算法回归 |
| `verify_small7_experiment3_contract.py` | **52/52通过** | GUI/执行/互锁静态源码合同 |
| `verify_experiment3_hw_preview_multifield_contract.py` | **通过** | 只读绑定、停止不中断正式采集、任意索引、128项频率表一致性、示例配置默认不验证 |
| `verify_sphere_exposure_x_only_contract.py` | **15/15通过** | 旧球实验回归静态检查 |

## 未完成或不能外推的验证

- 当前容器没有Windows GUI的Qt/VTK/scanCONTROL LLT二进制依赖、ECI3808控制器和传感器，**因此没有在Windows上构建和运行完整GUI**；静态源码合同通过并不等于GUI已编译通过。
- 没有向真实控制器/传感器发射触发或移动五轴；硬件H1/H3轮廓画面、到位精度、实际帧率、归档吞吐、急停与断线恢复仍需实机验收。
- 对所有0..127场号的识别和配置逻辑进行了源码及规划验证，但**并非对128种真实光学FOV全部完成现场标定**。单独的已验证光学JSON是允许运动的先决条件。
- 高频子场可能高至2000Hz，规划参考表并不证明该频率下完整GUI圆弧拟合与RAW写盘有足够吞吐。首次现场测试应使用较低的、实际稳定出帧的频率，重点检查callback序号连续、保存速率和磁盘空间。
- 历史两阶段大规模质量回归曾在当前环境超时，未计入本报告通过项。

## 验收建议

1. Windows Release编译（匹配现场SDK和原工程Qt/VTK依赖），确保无编译或链接错误。
2. 传感器连接后，分别验证软件独立预览、H1正式采集附着显示、H3正式采集附着显示；点击停止轮廓显示不影响正式采集的frame计数/归档/OP14/CMM状态。
3. 依次加载Large0、Standard2、Small7各自的实测光学配置，核对field和采样率的设备实际回读；光学JSON不匹配及`verified=false`必须被拒绝。
4. 从机床静止、急停就绪状态开始，先空载/仿真，再以1mm/s扫描正式样件。确认位置回读、轴暂停、异常停轴和每层RAW完整性。

## 主要修改文件

`src/app/MainWindow.cpp`、`include/app/MainWindow.h`、`src/app/MainWindowSmall7Experiment.cpp`、`include/calibration/Small7HeightPlan.h`、`src/calibration/Small7HeightPlan.cpp`、`tools/small7_experiment3_cli.cpp`、`tools/verify_small7_experiment3_contract.py`、`tools/verify_experiment3_hw_preview_multifield_contract.py`、`config/experiment3_*_verified_roi.example.json`。

正式使用说明：`README_EXPERIMENT3_MULTIFIELD_AND_HARDWARE_PREVIEW_ZH.md`。本次交付为**完整源码 ZIP**，不是可直接连接生产机床的已验收安装包。
