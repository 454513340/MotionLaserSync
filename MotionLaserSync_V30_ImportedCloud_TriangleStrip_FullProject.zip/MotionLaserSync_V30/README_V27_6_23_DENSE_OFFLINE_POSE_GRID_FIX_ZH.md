# V27.6.23 — 阶段2离线密集姿态网格提前拒绝修复

## 现象

在阶段2离线生成姿态时，界面可能弹出：

`Candidate grid exceeds 200000 poses; increase angular/quality grid steps.`

例如以下参数：

- D = 86 .. 104 mm, step = 4 mm
- gamma = 0 .. 40 deg, step = 5 deg
- eta = -5.5 .. +5.5 deg, step = 1.5 deg
- B = -30 .. +30 deg, step = 5 deg
- C = -45 .. +45 deg, step = 5 deg
- 双激光平面侧

`inclusiveRange()` 会显式补入上界以及跨零时的 0，因此保守预计算为：

- D: 6
- gamma: 9
- eta: 10
- B: 13
- C: 19
- sides: 2

总计 266760，超过旧版硬编码 200000，因此规划器在任何 XYZ 可达性、光学 FOV、MachineSafety 检查前就直接失败。

## 根因

旧版把 200000 限制施加在“理论笛卡尔积”上，而不是“真正可行的候选姿态”上。
这会错误拒绝大量本来会被 XYZ、FOV 或 MachineSafety 立即剔除的组合。

## 修改

文件：`src/calibration/SingleSphere17Calibration.cpp`

1. 删除 D/gamma/eta/B/C 理论组合数 > 200000 的提前拒绝。
2. 保留 5000000 的原始组合防呆上限，仅用于阻止明显错误的极密网格。
3. 在计算 synthetic profile 和 17x17 information matrix 之前执行 `checks.poseAllowed`，让光学/静态 MachineSafety 先剪枝。
4. 200000 限制改为“通过 XYZ/FOV/static-safety 后的实际可行候选数”。
5. 已通过 poseAllowed 的候选不再在 D-optimal 选择阶段重复执行同一个静态姿态检查。

该修改不改变：

- Physical17 运动学模型；
- D-optimal 评分公式；
- transitionAllowed 路径安全检查；
- 48 个记录姿态目标数；
- V27.6.22 的 MPOS+DPOS CSV；
- V27.6.22 的阶段2独立五轴绝对定位。

## 回归测试

新增测试覆盖上述 266760 理论组合情形，并通过静态姿态门禁将其剪枝后正常生成姿态。

通过：

- `v27618_profile_block_tests`
- `v20_single_sphere14_tests`
- `v20_2_single_sphere17_tests`

其中 profile-block 数值一致性仍为：

- residual max difference = 8.52651e-14
- Jacobian max difference = 2.18557e-07

## 上电/离线验证建议

先在离线状态使用截图中的 D/gamma/eta/B/C 参数重新点击“生成阶段2姿态”。
此步骤不需要控制器连接，也不会触发运动。

生成成功后，再连接设备按 V27.6.22 的独立轴运动逻辑做低速首段验证。
