# H1/H3 ONLY — 源码测试与验收记录

本报告适用于 `MotionLaserSync_H1_H3_ONLY_FULL_PROJECT`，控制器程序 `ECI3808_V32_16_H1_H3_ONLY.bas`。原项目内 `V27_6_57_BUILD_TEST_REPORT.txt`、`VERSION_V27_6_57.txt`、历史 SHA256 manifest 均属于**原始版本历史记录**，不是本版本的当前测试结果。

| 检查 | 结果 | 范围 |
|---|---|---|
| `tools/verify_h1_h3_only_llt_basic_contract.py` | **PASS** | LLT CMM API 签名、H3 CMM 功能保留、仅 H1/H3 拓扑、BASIC 拒绝编号 2、`321058` 与 `1316` 标志、SDK 头文件存在 |
| `tests/h1_h3_only_contract_tests.cpp` (`g++ -std=c++17`) | **PASS** | H1 R0/104、H3 R1/114/115；H2 拒绝；旧 321057 拒绝；原有 FULL-MPOS TABLE 头兼容 |
| `tests/p0_unit_tests.cpp` (`g++ -std=c++17`) | **31/31 PASS** | 原工程移植性单元测试 |
| `tests/p0_core_mock_tests.cpp`（真实上位机核心 + Mock ZAux + 临时 Qt 兼容头文件） | **109/112 PASS** | H2 拒绝、旧 BASIC 拒绝、H3 CMM Probe/ACK 测试通过；仍有三项历史失败（下述） |

三项 Mock 失败与随包原工程报告 `V27_6_57_BUILD_TEST_REPORT.txt` 所列三项一致：

1. `AUDIT stale HOME restore rejects fake success on mask correction`
2. `V27635 reconnect revokes runtime enable`
3. `V32.13 stale XYZ bits are downgraded while C/B Home-session bits are preserved`

原工程报告中的 Mock 结果是 108/111，通过增加 H1/H3/旧 BASIC 检查后成为 109/112。本次没有声称修复这三项与 H2 移除无关的历史问题。

## 当前环境的验证边界

- 没有 Windows MSVC+Qt/VTK 完整 GUI 的编译条件；Mock 使用简化 Qt 测试替身，并不验证 Qt 事件循环或 Windows DLL 动态链接。
- 没有实际 ZDevelop/ECI3808 控制器，因此 BASIC **未经过目标控制器编译、下发、容量限制检查、实机运动及联锁测试**。
- 用户上传源包中 `third_party/scanCONTROL/lib/x64`、`bin/x64` 与 `third_party/zmc/lib/x64` 是空占位文件，不含真正的 `.lib`/`.dll`。需在现场补充兼容的厂商二进制 SDK 后才能编译完整 Windows 程序。
- 真正重新部署前，应在隔离、安全停止的设备状态下更新 **BASIC 和上位机**，重新回零，并验证 H1/H3、故障停机、锁存与 STOP-DRAIN。
