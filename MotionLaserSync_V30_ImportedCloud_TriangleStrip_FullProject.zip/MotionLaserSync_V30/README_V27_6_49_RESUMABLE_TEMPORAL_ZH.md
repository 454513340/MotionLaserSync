# MotionLaserSync V27.6.49 — 硬件时域标定断点续采 / 自动重试

## 为什么增加这一版

V27.6.48 已经做到每条自动扫描结束后把完整 RAW `.scan` 与 sidecar `.json` 保存到
`E:\Projects\CData\HardwareTemporalCalibration\HTRUN48-*`，并及时释放大点云内存。
但是自动路径流程仍有一个重要缺陷：任意一条路径失败后，流程停止；再次点击“开始标定路径采集”会新建 Session、重置全部 Plan 状态，从路径 1 重新开始。

对于 9 个速度 × 3 个正反 Pair（54 条标定）+ 18 条验证的长实验，这种行为不可接受。

V27.6.49 把自动时域标定改成 **checkpointed / resumable session**：

- 已成功路径是事务式提交，永远不会因为后续路径失败而自动作废；
- 每条成功后立即写 `session_manifest_v49.json`；
- 失败路径保持“未完成”，自动重试该路径，绝不回到路径 1；
- 自动重试耗尽后只是暂停，用户排除问题后点击“开始/继续”即可从失败路径继续；
- 应用重启后可用“恢复/继续已有Session”继续；
- “新建/重置本轮Session”成为显式操作，不再由“开始采集”隐式触发；
- 旧 V27.6.48 的 `.scan + .json` Session 可以恢复，已完成扫描无需重采。

## 本次日志中路径 40 的含义

路径 40 的停止收尾统计是：

- ControllerPublishedLatch = 1561
- Pose = 1561
- Profile = 1562
- Aligned = 1561
- Pending = 1

也就是传感器尾部多出 1 条 Profile，却没有同 ordinal 的硬件 REGIST 位姿。因此严格完整性门禁止接受该条扫描是正确的。V27.6.49 **没有降低这个安全门限**，而是把这种偶发 tail-closure 失败当作可重试的单条路径故障。

## V27.6.49 的失败策略

默认 `失败自动重试 = 2 次/路径`：

1. 第一次扫描失败；
2. 自动重新执行同一个 Plan；
3. 最多再重试 2 次；
4. 若仍失败，则流程暂停；
5. 前面已经成功并落盘的路径全部保留；
6. 再点击“开始/继续标定路径采集”从这个未完成 Plan 继续。

仅对硬件采集/闭环类瞬态错误自动重试，例如 Stop/Drain 闭环、Probe、同步意外停止等。碰撞、软硬限位、设备断开等安全类错误不会盲目自动重试。

## Session 检查点

V49 新建 Session 目录例如：

```
E:\Projects\CData\HardwareTemporalCalibration\HTRUN49-20261006-xxxxxxxxx\
```

其中增加：

```
session_manifest_v49.json
```

它保存：

- 参考球球心与半径；
- 扫描轨迹中点 XYZCB；
- 多速度实验模板；
- 每一个 Plan 的 start/end、Pair、方向、状态；
- attempt / failure 次数；
- 已成功 RAW/sidecar 路径；
- calibration observations；
- validation observations；
- 候选 τ 与验证状态；
- RAW 根目录、分析采样上限、自动重试设置。

每条成功扫描后台归档和球拟合都成功后，才把 Plan 标为 completed/accepted 并原子写检查点。

## 如何救回这次已经完成的前 39 条 V48 数据

你这次真正应该选择的旧 Session 是：

```
E:\Projects\CData\HardwareTemporalCalibration\HTRUN48-20261006-183603336
```

而不是失败后误启动的新目录 `HTRUN48-20261006-185409854`。

操作：

1. 启动 V27.6.49；
2. 正常连接控制器/传感器、XYZ DATUM、B/C 建立绝对坐标；
3. 导入并拟合这次实验使用的同一参考球点云 `sphere_calibration8.scan`；
4. 点击 **恢复/继续已有Session**；
5. 选择上面的 `HTRUN48-20261006-183603336`；
6. V49 会读取已有 `CAL_*.json / VAL_*.json`，恢复成功路径；
7. V49 会优先从旧 RAW `.scan` 自动推导原扫描轨迹中点，因此路径 40 会保持与路径 39 同一 Pair 的原始几何中心；
8. 标准模板情况下应看到“标定 39/54 条已恢复”；
9. 点击 **开始/继续标定路径采集**；
10. 应从路径 40（Pair020 的反向成员）开始，而不是路径 1。

恢复完成后，V49 会在旧 V48 Session 目录里补写 `session_manifest_v49.json`。之后即使再次暂停/重启，都可以按 V49 原生 Session 直接恢复。

## “开始/继续”与“新建/重置”的语义

- `开始/继续标定路径采集`：保留所有 accepted 数据，找第一个未完成 Plan 继续。
- `开始/继续验证路径采集`：同理，只执行未完成验证路径。
- `暂停当前流程`：停止当前自动流程但不清历史结果。
- `恢复/继续已有Session`：从磁盘 Manifest / V48 sidecar 恢复进度。
- `新建/重置本轮Session`：显式丢弃当前 UI 进度并开始新实验；旧 E 盘目录和 RAW 不删除。

## 硬件方案没有改变

V27.6.49 仍严格使用现场已经确认的 V32.9：

```
OP14/PWM0 -> scanCONTROL external trigger
OP14/PWM0 -> ECI IN0 -> REGIST(104) -> XYZ/C/B MPOS
```

没有修改控制器 BASIC，也没有放宽 Profile/Pose/Ordinal 完整性门。
