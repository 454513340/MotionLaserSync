# MotionLaserSync V28 — M0/M1/M2 清除功能 + M3 虚拟 scanCONTROL 2950-50/BL 扫描

## 交付状态

- 基础版本：`MotionLaserSync_V28_PROJECT_M2_MSVC_COMPILE_FIXED.zip`（用户已在 VS2022 运行）。
- 本版本保留全部项目源文件、原设备控制/标定/同步接口及 M0/M1/M2。
- 新增与离线数字孪生相关的“清除 CAD、清除支承面、清除 M2、清除 M3、一键清空”按钮。
- M3 实现独立 C++17 虚拟光学扫描核心及 Qt/VTK 显示接口，**未接入真实激光器/机床动作**。
- 本环境下 Debug 模式离线 8 项测试通过（其中包含新增的 H1 遮挡方向回归测试），包括真实 H1 提取的 100 帧 sensorToMachine 矩阵回放。**尚未在 Windows 10 + VS2022 + Qt6/VTK/OCCT 下完成 GUI 编译验证。**

## 在 VS2022 中使用

1. 打开 `MotionLaserSync_V28_PROJECT/CMakeLists.txt`；选择 GUI 主程序而非 `exposure_analysis_cli.exe`。
2. 保持原工程已经可工作的 Qt、VTK、FCL、ZMC、LLT 环境，不要覆盖 DLL/导入库。OCCT 默认前缀：`D:/dev/vcpkg/installed/x64-windows-release`。
3. 打开主界面的“路径规划”->“数字孪生 / STEP 工件放置…”按钮。
4. 导入你之前的 `传感器连接件.STEP`，或者点击“载入测试零件”；确认 MCS 的 X/Y/Z 和 Rx/Ry/Rz 设置。注意单位是毫米与角度，工件估计位姿与真值的划分不变。
5. 在 M2 区域选择 `6061_Alumina_Scan_H1.scan`，等待 CRC 校验与历史位姿加载完成。
6. 在 M3 设置“模拟相机 Y 偏置”，初始 **+75mm 是由 H1 单姿态数据约束的未标定等效值**。点击“运行 M3 虚拟扫描”。
7. 稍候查看状态：虚拟 1280 点/Profile 全部计算完成后，以橙红色独立图层显示；M2 实测回放仍为绿色。最多 25 万个可视点，导出 PLY 使用全部有效模拟点。
8. 点击“导出 M3 PLY + 完整 Profile…”同时输出 `*.ply`、`*.m3prof` 和 `*.m3.json`；以后可用于 M4 对比。
9. 各个清除按钮可独立移除加载的 CAD、支承面、M2、M3；“一键清空”仅清除离线数字孪生的内存图层，不删除磁盘文件，也不清空设备实时点云。后台运行时会请求取消。

## 虚拟光学几何模型——必须了解

- 模拟器是**未经真实光学标定的几何模型**。有效测量宽度为参考值：报告 Sensor-Z=70/95/120mm 时约 58/50/42mm（已采用参考 H1 的 FlipZ 约定）。
- 每条 Profile 固定模拟 1280 个索引。从虚拟激光投射中心朝激光扇形参考平面发射 1280 条射线，对 CAD 网格和可选支承面找第一个物理交点。
- 用可配置相机有效光心到交点的第二条光线进行遮挡检查，之后校验有效 Z/宽度并输出采样位置与状态。
- `laserOriginSensor=(0,0,251.25)`，`cameraOriginSensor=(0,+75,251.25)` 是**等效投影中心、数学近似参数**。`+75` 是根据 H1 单姿态沉孔可见侧修正的符号，不是厂家标定出来的真实机械/光学位置，不能据此验证 B/C 旋转后的真实补扫效果。
- M3 生成的 Profile 索引约定：`index=0` 对应 Sensor-X 的正侧，`index=1279` 对应 Sensor-X 的负侧，与 H1 实测索引—坐标斜率一致。
- 本轮 M3 默认通过 M2 的 SCAN v3 中 *逐帧曝光时刻的 `Frame5D.sensorToMachine`* 回放，每帧仅应用一次该矩阵。没有五轴路径生成/硬件指令。尚未实现 M4 的实测几何遮挡拟合、M5 CAD 覆盖率与 M6 NBV 自动补扫。
- 硬件发射/接收函数、反射强度/曝光噪声及 SDK 具体测量场配置需要以后独立标定；无需将这套虚拟模型用于测量精度声明。

## M3 状态与保存约定

采样状态（`VirtualSampleState`）：

| 数值 | 含义 |
|---|---|
| 0 | Valid（有效的双光路可测点） |
| 1 | LaserMiss（激光没有和场景交点） |
| 2 | CameraOccluded（接收相机视线被实体挡住） |
| 3 | OutsideField（超出当前测量场） |
| 4 | BadPose（无效曝光位姿） |
| 5 | Cancelled（预留，取消操作不会输出不完整结果） |

- 无效点坐标在内存中为 NaN；空腔不被填充 CAD 点；来自支承面回波保留，供以后与实测对比。
- `*.ply`：二进制 little-endian，全部有效模拟测量点，单位毫米，机器坐标。
- `*.m3.json`：模型参数/每类状态计数/源 SCAN 文件路径，标记光学中心尚未标定。
- `*.m3prof`：自定义 M3 仿真格式，不能改名为 `.scan`。8字节 ASCII 魔数 `M3VPROF1`；little-endian uint32 ProfileCount、uint32 SampleCount；每帧含 uint64 原始 ordinal、float64 仿真时间、16×float64 sensorToMachine，之后固定 SampleCount 个 `(uint8 status, float32 sensorX, float32 sensorZ)`，无效坐标为 NaN。此格式不具有真实 SCAN CRC/标定资格，仅用于离线 M4 分析。

## 构建和测试

离线 C++17 版本，不需要 Qt、VTK、设备 DLL、OCCT：

```powershell
cmake -S . -B build-twin -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build-twin --config Debug
ctest --test-dir build-twin -C Debug --output-on-failure
```

包含 8 项测试：坐标变换、CAD 几何、测试零件、球/平面视场、激光首交点、相机二次遮挡、BVH 与取消、合成 X 向扫描、真实 H1 100 帧离线曝光位姿回放。

生产 GUI 构建需要你的既有 Windows 10 + VS2022 项目依赖。按你在上一轮已经成功的工程配置重新配置构建。**本包在本环境中没有完成 Windows/MSVC GUI 实编译，不应把离线测试等同于它。**

## 本轮主要变更清单

- `include/twin/VirtualLaser2950.h`, `src/twin/VirtualLaser2950.cpp`：纯 C++ 光学模拟器及 BVH。
- `include/twin/TwinSimulationAdapter.h`, `src/twin/TwinSimulationAdapter.cpp`：SCAN v3 实测位姿→虚拟 Profile 与 PLY/Profile 导出桥接。
- `src/widgets/DigitalTwinScanWidget.cpp`, 对应头文件：M3 面板、后台任务/进度、取消、分层清理。
- `src/widgets/PointCloudWidget.cpp`, 对应头文件：独立橙红色 M3 Actor，与 M2/实时点云隔离。
- `CMakeLists.txt`：M3 模块、测试和独立 CLI 入口。
- `tests/twin/twin_virtual_laser_tests.cpp`、`tests/twin/data/h1_pose_subset.csv`、`tools/digital_twin_m3_cli.cpp`：离线回归。

## 建议下阶段：M4

将 M3 和 `6061_Alumina_Scan_H1.scan` 的采样索引有效性进行逐帧对比：上表面点、四个直径8mm阶梯孔台阶的半月形缺失，以及中心孔/弧槽区域，并优化等效光学中心。现阶段 M3 只能证明几何光路仿真正确，不能证明其参数已经复现真实扫描的 51.23% 台阶覆盖率。
