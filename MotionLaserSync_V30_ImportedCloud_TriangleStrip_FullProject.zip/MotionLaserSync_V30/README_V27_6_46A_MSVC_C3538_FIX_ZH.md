# MotionLaserSync V27.6.46A — MSVC C3538 编译修复

本 hotfix 仅修复 V27.6.46 在 MSVC 2022 下编译 `src/widgets/HardwareSyncCalibrationWidget.cpp` 时出现的 C3538：

```
error C3538: 在声明符列表中，“auto”必须始终推导为同一类型
```

## 原因

V27.6.46 第 233 行原代码：

```cpp
const auto aligned=m_sync->getHardwareAlignedPoints(),poses=m_sync->getHardwarePoseSamples();
```

两个函数的返回类型不同：

- `getHardwareAlignedPoints()` -> `QVector<AlignedPoint>`（Qt6 实现中诊断为 `QList<AlignedPoint>`）
- `getHardwarePoseSamples()` -> `QVector<SamplePoint>`（Qt6 实现中诊断为 `QList<SamplePoint>`）

C++ 的同一条 `auto` 多声明语句要求所有声明符推导为同一类型，因此 MSVC 正确报 C3538。

## 修复

拆分为两个独立的 `auto` 声明：

```cpp
const auto aligned=m_sync->getHardwareAlignedPoints();
const auto poses=m_sync->getHardwarePoseSamples();
```

此修改不改变：

- ECI3808 V32.9 SINGLE-OP14 硬件触发；
- IN0 -> `REGIST(104)` 五轴 MPOS 锁存；
- 硬件同步标定数学模型；
- 路径规划/自动采集；
- τ 求解、Hold-out 验证与运行时补偿；
- JSON schema；
- 控制器 BASIC。

因此 V27.6.46A 是 **编译兼容性 hotfix**，不是新的标定算法版本。

## 已执行检查

- V27.6.46 staged hardware temporal source contract: PASS
- V27.6.44 temporal runtime/archive compatibility contract: PASS
- V27.6.45 material exposure path compatibility contract: PASS
- hardware-temporal numerical tests: PASS
- HardwareSyncReport regression: 22/22 PASS
- Controller BASIC SHA-256 unchanged:
  `263d1f2a560120b006d25262e79fc364ebf35b4e6f2b3bf986f56013166b105a`

完整 Windows Qt/VTK GUI target 仍应在现场 Windows x64 + MSVC + Qt6 + VTK 环境重新执行 Release build，以捕获后续可能由 MSVC 暴露的编译问题。
