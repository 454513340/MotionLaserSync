# ECI3808 V32.10 ACTIVE

当前正式控制器程序：`controller/ECI3808_5Axis_Controller.bas`。

V32.10 在 V32.9 SINGLE-OP14 / FULL-MPOS / ColdPrime / synchronized-stop 拓扑上增加两项运行时协议：

- `TABLE[355]` 请求 PWM0 Hz，`TABLE[356]` BASIC ACK/实际 Hz；
- `TABLE[357]` XYZ 控制器上电会话回零 bitmask。

`TABLE[354]=321052` 是上位机识别 V32.10 能力的 magic。上位机 V27.6.52 会在硬件同步启动、XYZ 回零状态恢复/提交时检查该 magic；旧 BASIC 会被 fail-closed 拒绝。

BASIC 初始化会把 PWM 恢复到默认 200 Hz，并把 XYZ Home mask 清零。200 Hz 现在只是默认值，不再是固定运行频率。
