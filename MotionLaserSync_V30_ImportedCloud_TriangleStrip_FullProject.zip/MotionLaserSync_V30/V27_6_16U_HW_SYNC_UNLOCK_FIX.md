# MotionLaserSync V27.6.16U — Home-All 硬件同步解锁修复

## 现象

V27.6.16S 引入 XYZ 增量光栅 MPOS 回零基准以后，硬件同步自动预检要求：

- X/Y/Z 三轴均已通过正规 DATUM 建立 MPOS 机床零点；
- B/C 绝对机械坐标框架已建立；
- V32.9 TABLE 协议与 `TABLE[342]` 执行授权通过。

现场使用“全部回零”时会并行启动 X/Y/Z DATUM 与 C/B 到 0° 的绝对定位。S 版只在 **XYZ 回零完成事件**中重试硬件同步预检。

如果最后一个 XYZ 先于 C/B 停止，预检在 C/B 仍有运动任务时无法通过；随后 C/B 完成却不会再次触发预检，于是 `m_hardwareSyncPreflightPassed` 一直保持 false，界面的“硬件”同步模式持续灰色，直到重连或重建 B/C 绝对坐标。

## 修复

V27.6.16U 将授权逻辑改为“五轴状态收敛”：

1. 任一 X/Y/Z/C/B 回零开始前，立即清除旧的 `m_hardwareSyncPreflightPassed`，UI 自动退回软件同步，防止复用旧状态。
2. `runAutomaticHardwareSyncPreflight()` 在仍有轴 worker、五轴联动或 B/C 初始化任务时只做 **正常暂缓**，不把它当作协议故障。
3. 任一 X/Y/Z/C/B 回零成功完成后都会检查：
   - `m_axisWorkerCount == 0`；
   - `areLinearMposReferenced()`；
   - `isRotaryAbsoluteReady(AxisC/B)`。
4. 满足以上条件的**最后一个完成轴**自动重新执行 V32.9 TABLE 只读预检。最后完成的是 X/Y/Z/C/B 中哪一个都可以。
5. 回零结束无论是否已达到完整预检条件都会刷新传感器同步 UI。
6. 硬件同步单选框增加状态化 tooltip，可区分：控制器未连接、XYZ 未回零、B/C 框架未建立、TABLE 预检等待/失败、以及预检已通过但 Video/Profile/曝光任务正在运行。

## Home-All 期望时序

```text
开始全部回零
  -> 撤销旧硬件同步授权
  -> X/Y/Z/C/B 并行完成各自任务
  -> 每个完成事件只更新状态
  -> 最后一个轴完成，m_axisWorkerCount == 0
  -> XYZ MPOS referenced == true
  -> B/C absolute ready == true
  -> V32.9 TABLE preflight
  -> TABLE[342] == 1
  -> m_hardwareSyncPreflightPassed = true
  -> 硬件同步按钮解锁
```

## BASIC

本版本不修改任何 BASIC。现场的 XYZ：

```basic
ENCODER_RATIO(2,1) AXIS(1)
ENCODER_RATIO(2,1) AXIS(2)
ENCODER_RATIO(2,-1) AXIS(3)
```

保持不变。

## 验证

- V27.6.16U 专项源代码契约：16/16 PASS。
- 当前可执行 portable core / numerical / RTCP / parser 回归：20/20 PASS。
- V32.9 Full-MPOS 契约：9/9 PASS。
- 完整 Qt GUI 仍需在 Windows/MSVC + 项目自带厂商 SDK 环境最终编译和实机验证。
