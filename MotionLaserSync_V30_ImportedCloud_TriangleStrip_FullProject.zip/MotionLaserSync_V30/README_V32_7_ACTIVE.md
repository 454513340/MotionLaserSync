# V27.6.16I / ECI3808 V32.7 — SINGLE-OP14 FULL-MPOS + ColdPrime

本目录的活动硬件同步版本是 **V32.7**。

## 关键约束

- 现场只使用 **OP14**，不使用 OP0。
- BASIC 按最终 XYZ 光栅尺方案设计：X/Y/Z/C/B 均为 `ATYPE=4`。
- 硬件同步 TABLE 中的 `[X,Y,Z,C,B]` **全部来自 `REGIST(104)` 锁存 MPOS**。
- 当前 XYZ 光栅尺尚未接入时，X/Y/Z MPOS 可保持 0；这用于先验证 OP14、scanCONTROL、五轴 REGIST 计数以及 C/B 机械角链路。
- 上位机普通运动控制、轴状态和软件同步路径仍保持原设计：**XYZ 读取 DPOS；C/B 使用机械坐标 MPOS**。这与硬件同步 TABLE 的五轴 MPOS 是两套不同语义。
- C/B 机械绝对角仍为 `raw latched MPOS + 启动时冻结的 RS485 software-frame offset`。
- scanCONTROL 为 `EdgeRising`；ECI 为 `REGIST(104)` / R0 逻辑下降沿；依据现场已测极性，两者对应同一个 OP14 OFF 时刻。
- 冷启动仍先执行 `enable=3` ColdPrime，丢弃预热 Profile，再建立正式 session、清空并重新 Arm 五轴 REGIST FIFO。

## 活动 BASIC

`controller/ECI3808_5Axis_Controller.bas`

同内容独立文件：

`ECI3808_V32_7_SINGLE_OP14_FULL_MPOS_ColdPrime.bas`

## 预期协议头

ZDevelop：

```text
?*TABLE(330,22)
```

空闲时应为：

```text
96 0 0 0 0 0 0 270909 6 5 0 0 1 31 4 31 0 0 14 104 14 1
```

即：

- `343=31` 五轴反馈来源
- `344=4` HardwareLatched
- `345=31` 五轴硬件锁存
- `346=0` 硬件 TABLE 不含 DPOS command 源
- `348=14` 传感器触发输出 OP14
- `349=104` REGIST(104)
- `350=14` 锁存桥输出同为 OP14
- `351=1` ColdPrime capability

## 当前未接 XYZ 光栅尺时的测试含义

可以只转动 C/B。期望硬件 TABLE 中 X/Y/Z 为 0 或静态值，而 C/B 随运动变化。验收重点是：

`Profile == Pose == TABLE[336] == Aligned`、`Dropped=0`、五轴 REGIST FIFO 不分叉、无 Buffer-B 溢出。

此阶段 **不能用硬件同步 TABLE 的 XYZ=0 点云判断真实 XYZ 几何位置**。若要在未接光栅尺时进行带 XYZ 真实位置的测量，应使用上位机的软件同步/DPOS路径，而不是把硬件 TABLE 的 MPOS 改写成 DPOS。
