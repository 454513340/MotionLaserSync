# H1/H3 动态球心两阶段拟合 + Hold-out同点集 + LNK2019 链接修复

## 先解决你报告的两个无法解析的外部符号

缺失的符号是 `SphereTwoStageFit::fitImportedSphere(...)`、`SphereTwoStageFit::comparisonText(...)`。
这两个函数的定义都在 `src/calibration/SphereTwoStageFit.cpp` 中。`#include "calibration/SphereTwoStageFit.h"` **只提供声明，不会自动将实现 `.cpp` 链入 MotionLaserSync.exe**。

本版 `CMakeLists.txt` 在 `add_executable(MotionLaserSync ...)` 后通过独立的 `target_sources(MotionLaserSync PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src/calibration/SphereTwoStageFit.cpp")` 明确包含实现文件，并在配置时检查文件是否存在。

升级后在 Visual Studio **项目 → 删除缓存并重新配置**，再重新生成。应看到 `SphereTwoStageFit.cpp` 编译为对象文件。若仍报同样的两个 LNK2019：
1. 确认你编辑的 `CMakeLists.txt` 与 Visual Studio 顶端打开的 CMake 根目录是同一份；
2. 确认 `src/calibration/SphereTwoStageFit.cpp` 确实在该目录；
3. 删除对应构建目录内 `CMakeCache.txt`（或 VS 的“删除缓存并重新配置”），重新配置与编译；
4. 在生成输出中搜索 `SphereTwoStageFit.cpp`，如果从未编译，说明仍在构建旧目标。

**不要**在 `MainWindow.cpp` 里 `#include "SphereTwoStageFit.cpp"`，也不要复制函数定义到头文件来掩盖目标源文件配置错误。

## H1/H3 动态标定改变了什么

涉及 `HardwareSyncCalibrationWidget::startCaptureProcessing`：

- 每条硬件同步捕获先通过原有 Pose/Profile/Aligned/Fault 严格一致性检查；沿用双精度原始 X/Z + 同帧硬件锁存全 MPOS `Frame5D`。
- 对原始均匀抽样的三维点先计算**原全点 RANSAC**，用其估算球心并保留拟合直径/RMS/内点作对照。
- 用原始 Profile 的传感器 X/Z、保存的 Physical17 逐帧变换，将旧方法求得的候选球心投影到传感器 X/Z 作为 ROI 锚点，再按 `≥120°`、圆弧 RMS `≤0.010mm`、有效点 `≥80` 筛选 Profile。
- **只**将合格 Profile 中的机器 XYZ 分析点送入三维 RANSAC，使用 `0.020mm` 内点阈值。仍执行原自由有效半径的优化（不强行固定 9.525mm）。合格帧或点不足时拒绝形成新的 τ 观测，不静默回退到旧全点结果。
- 同样适用于 H1/R0 和 H3/R1：选择由现有硬件拓扑决定，没有复制或修改任何 ECI BASIC/TTL/CMM 时序代码。
- Hold-out RAW 与 Corrected 使用**完全相同**的 (Profile序号, 原始点索引) 集合：先判断插值是否有效；仅保留双方均能生成的点；再分别执行自由球拟合。不会用一组点算 RAW RMS、另一组点算 Corrected RMS。
- 每条成功的实验 `.json` sidecar 包含 `sphereFitComparison`、`arcTotalProfiles`、`arcQualifiedProfiles`、`arcQualifiedAnalysisPoints`、`holdoutIdenticalPointIndices` 和 `dynamicSphereFitContract`。

**这是一组研究/诊断阈值，不是计量合格证。** 新流程可以拒绝有效但可见圆弧较短的动态扫球数据；若发生这种情况请检查采集曝光、扫描路径/光学视场、Frame5D 几何与单帧圆弧结果，不能未经验证就放宽阈值。

## 旧 Session 数据保护

新版 `session_manifest_v49.json` 追加算法合同 `dynamicSphereFitContract`。含旧算法球心/验证观测的历史 Session 不能与新两阶段观测混合求解 τ；V48 原地恢复同样被拒绝。**原始磁盘 RAW、旧 Session 和原活动标定文件不删除、不自动重新计算。**

如要使用旧 RAW，必须将全部旧 CAL/VAL 扫描以同一版本的新算法统一离线重分析，再生成单独 Session。当前 GUI 修改的是*新捕获时*的归档分析流程，没有新增“直接导入旧 CAL/VAL RAW 批量重分析”按钮。

## 可复核的验证状态

已在无 Windows Qt/VTK/硬件 SDK 的可移植环境里执行：
- `sphere_two_stage_quality_cli`：圆弧覆盖/RMS/内点、球心投影、3D RANSAC 通过；
- `sphere_exposure_cli`：全标准球曝光圆弧/排序回归通过；
- `v27644_hardware_temporal_tests`、`h3_signed_temporal_tests`、`v27650_drift_radius_temporal_tests`：全部通过；
- `python tools/verify_h1h3_dynamic_two_stage_contract.py`：显式目标源文件、双方法拟合、H1/H3 路径、Hold-out 同点索引、Session 版本闸门静态检查通过；
- V32.16 控制器 BASIC SHA256 与上一版完全一致。

**未在 Windows+Qt+VTK 完整构建**，亦未经机床实测。本版标定结果未经独立验收前，不要直接写入活动 τ，不要自动开启 H1/H3 运行时补偿。首次测试宜使用新 Session 少量受控扫描，并保留 RAW，核对对比日志、合格帧数及 Hold-out 结果。
