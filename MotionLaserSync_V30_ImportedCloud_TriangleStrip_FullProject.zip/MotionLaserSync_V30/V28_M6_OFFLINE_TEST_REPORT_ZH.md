# V28.7 M6 离线测试记录

来源：M0–M5.2 Windows MSVC 修复版全量工程。新增核心 `TwinM6Continuous.*`，Qt 桥接 `TwinM6Adapter.*`，Qt/VTK 接口与 CMake 源文件登记。

## 可复现测试

- 纯 C++17 Release CMake 完整构建通过；共 17 项 CTest 测试通过（原有 16 + M6 一项）。
- 新测试在 reference STEP 代理 OBJ 上运行真实双光路 Profile，验证采集段 XYZ、C、B 均连续改变、限位/速度/加速度/jerk 约束、候选拒绝、安全标志恒假、磁盘 spool 字节数等于 `fullValidPoints * 3 * sizeof(float)`，以及各 CAD 特征新增面积之和等于新增总面积。
- 对用户导出的 247067 个 M5 CAD 表面单元和以前保存的真实 H1 参考曝光位姿进行独立压力烟雾测试：在示例参考 OBJ、约束行程、25 Hz 采样、B/C 搜索小幅度时，至少可以规划和模拟一条连续五轴补扫轨迹。此测试的输出不是通过硬件认证的路径，局部新增覆盖面积不能解释为工件全部已测量。
- 确保旧 H1/H3/设备控制源码没有被更改。

## VS2022 必须复验的部分

1. 数字孪生窗口 M6 控件是否出现、中文字符是否正常；
2. `V28.7 M6 continuous XYZCB: core + GUI + Physical17 bridge [OK]` CMake 消息出现，GUI 无 C2001/C3538/LNK2019；
3. M2、M5 原始数据和 M3 光学参数可输入 M6；
4. 多段规划完成后两处 VTK 视图有补扫点与轨迹，点击清除同步消失；
5. 取消或关闭窗口不会重新显示已清除任务；
6. JSON、XYZCB 轨迹 CSV 和所有有效模拟点的 PLY 可读，CSV 中禁止硬件执行标记为 0；
7. 各特征增量覆盖率与总面积一致，未达到目标必须仍显示缺失。

**未进行 Windows GUI 实际构建，不允许以 Linux 测试替代 Windows 的最终验收。**
