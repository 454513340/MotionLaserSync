# V27.6.10 calibration workflow optimization

This revision is based on `V27.6.9A_STAGE1_DEVICE_GATE_FIX` and targets the 2026-09-10 real-machine log.

## Stage 1

- Stage-1 result is now permanently visible on the **初步手眼标定** page: rank, RMS, max residual, condition number, solve time, 6-DoF hand-eye and the fixed machine-frame sphere center.
- Added **保存阶段1结果 JSON**. The file includes coordinate convention (`FlipX/FlipZ`, DPOS/MPOS feedback mask), diagnostics, hand-eye, sphere center, singular values and all Stage-1 captured XYZCB poses.
- Stage-1 success no longer forcibly switches tabs. The operator can inspect/save the result first, then manually enter **运动学标定**.
- Added a 16-pose Stage-1 candidate table. Eleven relative poses are taken from the first successful real-machine Stage-1 run in the supplied log; five extra candidates are safe interpolations between neighboring successful poses. Targets are anchored to the XYZCB pose at `①开始/重置阶段1`.
- Added **直接移动到选中候选姿态** and **跳过并选择下一候选**. One operator click creates one checked five-axis absolute move request. Existing controller soft limits and MainWindow motion checks are retained. Manual XYZ/B/C jog remains available for fine adjustment.
- Stage-1 capture automatically marks the active candidate as collected and selects the next pending candidate.

## Faster Stage-1 solve

Two bottlenecks were removed without changing the Stage-1 model (nominal machine geometry + hand-eye 6 DoF + fixed sphere center):

1. Ten fresh profiles at one static pose are highly correlated. The Stage-1 bootstrap now keeps at most 3 representative profiles per independent pose and at most 180 evenly spaced inlier points per representative profile. Pose diversity is preserved.
2. The core nominal hand-eye bootstrap previously performed an expensive 90-iteration numerical-Jacobian refinement for every one of 13 rotation starts. It now performs short coarse refinements for each start, ranks the basins, and performs the accurate refinement only once on the best basin.

The portable `v20_2_single_sphere17_tests` still passes after the core optimization. On this Linux test environment the complete test executable runtime decreased from about 5.77 s to 3.14 s; the real GUI Stage-1 solve should benefit further from the representative-profile reduction, but real-machine time must be measured on the Windows target.

## Stage 2

- Default D-optimal requested pose count increased from **30 to 48**; up to 160 can be requested.
- Before a final Physical-17 model exists, the first Stage-2 plan is constrained to the actually observed Stage-1 B/C envelope plus a small margin (B ±5°, C ±8°). This reduces risky extrapolation of the nominal-machine bootstrap into remote combined-rotation corners. After a successful Physical-17 solve, regenerated plans use the full user-selected B/C range.
- Increased allowed D-optimal records per B/C pair to 3 so the 48-pose default remains achievable under the conservative first-stage envelope.
- Replaced the old segmented visual transit with **直接移动到选中计划姿态**: one operator confirmation produces one full XYZCB target request. There is no repeated 3 mm / 5° UI stepping.
- After arrival, one sphere-fit check is performed. If no acceptable sphere is found, the row is marked **已跳过：无合格球拟合** and the next pending row is selected. The next physical move is **not** started automatically; the operator must click again.
- Added **跳过当前并选下一姿态** and a dedicated Stage-2 **停止五轴运动** button.
- A successful Stage-2/validation capture now selects the next pending row automatically.

## Diagnosis from the supplied log

The Stage-1 result itself was not obviously invalid: the log reports rank 9/9, RMS about 0.0627 mm, hand-eye translation `[33.5433, 12.5134, -291.8123] mm` and sphere center `[36.6511, 14.1246, -158.9131] mm`.

The first Stage-1 data covered approximately B=-15..+12 degrees and C=-29..+7 degrees. The old Stage-2 UI immediately requested B=-30..+30 and C=-45..+45. Several early Stage-2 points worked, but the failure appears when the old segmented path reaches the C≈-45°, B≈+10° combined-rotation area. That is outside the Stage-1 C coverage and therefore is consistent with bootstrap extrapolation / limited visibility, not by itself proof that Stage-1 calibration is wrong.

The repeated LLT debug message `设置分辨率失败，错误码 -1003` is also present around successful captures, so it is not treated as the root cause of those specific missing-sphere poses in this revision.

## Verification

- `git diff --check`: clean.
- Portable core target `single_sphere17_cli`: builds successfully.
- `v20_2_single_sphere17_tests`: passes.
- Full Windows GUI cannot be linked in the Linux verification environment because the project intentionally requires Windows x64 Qt/VTK and vendor SDKs. Reconfigure the actual Visual Studio x64-Release build from a clean CMake cache before field testing.
