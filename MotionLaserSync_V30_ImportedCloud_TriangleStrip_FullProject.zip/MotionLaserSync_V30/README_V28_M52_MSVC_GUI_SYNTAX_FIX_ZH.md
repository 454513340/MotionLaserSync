# MotionLaserSync V28.6.1 — M5.2 Windows / MSVC 编译修复

## 问题描述

VS2022 `x64-Release` 编译 `src/widgets/DigitalTwinScanWidget.cpp` 报错：

- C3538（约 1687、1689 行）：使用一条 `const auto` 声明两个不同模板类型的 `std::shared_ptr`，MSVC 要求同一声明的占位符推导类型一致。
- C2001 / C2143（约 1715～1742 行）：M5.2 Qt 中文摘要字符串包含未经转义的源文件换行，使字符串常量无法终止，后续出现连锁语法错误。

## 修改范围

1. `src/widgets/DigitalTwinScanWidget.cpp`
   - 拆开 `m_m52Cancel`、`m_m52Progress` 及 `m_replay`、`m_virtual` 的局部 `auto` 声明。
   - 将 Qt 提示信息中错误的多行字符串写为合法的相邻 C++ 字符串字面量，并使用 `\n` 表示换行。
   - 显式转换 M5.2 的计数为 `qulonglong`，避免 Qt/Windows 数字重载不一致。
2. `src/app/MainWindow.cpp`：显示版本改为 V28.6.1。
3. `CMakeLists.txt`：M5.2 注册消息改为 V28.6.1，便于确认清理缓存后的工程版本。

## 未修改范围

M0～M5.1 算法、M5.2 几何拟合算法、STEP 导入、机器运动控制与扫描仪 SDK、原始 `.scan` 数据格式均保持不变。Open CASCADE 的配置仍是 `D:/dev/vcpkg/installed/x64-windows-release`。

## 推荐的 VS2022 验证步骤

1. 解压完整 ZIP 至新的工程目录。
2. Visual Studio 2022 通过 **文件 → 打开 → 文件夹** 打开内层 `MotionLaserSync_V28_PROJECT`。
3. 选择 x64-Release，删除 CMake 缓存并重新配置。
4. 配置窗口确认打印：`V28.6.1 M5.2 geometric consistency + MSVC GUI syntax fix: core + GUI + JSON/CSV [OK]`。
5. 选择 `MotionLaserSync.exe` GUI 目标，执行 **全部重新生成**。
6. 启动程序并在数字孪生工作台运行 M5.2，检查输出摘要、逐角度热图、JSON/CSV 导出功能。

## 验证边界

Linux 便携式 C++17 核心离线编译/回归测试可在本环境运行；此环境缺少 Qt/VTK 与 MSVC 依赖，因此完整 Windows GUI 仍需要用户在 VS2022 本地进行最终编译和运行确认。
