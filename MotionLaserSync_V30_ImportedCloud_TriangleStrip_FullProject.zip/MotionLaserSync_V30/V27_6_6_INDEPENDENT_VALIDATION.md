# V27.6.6 — Independent hold-out validation

This revision closes a gap in V27.6.5: the documentation recommended independent validation, but the GUI had no dedicated hold-out data set, no validation-plan button and no frozen-model validation implementation.

Implemented:

- separate `m_validationRecords`; never added to the Physical17 solver;
- “生成独立验证姿态” using half-step-shifted B/C grids and different sensor-center targets;
- minimum validation-to-training B/C separation gate;
- “采集当前姿态为验证集”;
- “执行独立验证”;
- fixed-model raw sphere-surface residual evaluation;
- predicted-vs-measured sphere-center error statistics;
- positive/negative B/C validation coverage check;
- validation thresholds in the GUI;
- training-data changes invalidate old hold-out evidence;
- `scanCalibration()` refuses to release the model to scan/RTCP until validation passes;
- `*_validation.json` sidecar report;
- core numerical regression proving exact frozen models give zero hold-out residual and a perturbed model does not.

Build policy remains Release-only.
