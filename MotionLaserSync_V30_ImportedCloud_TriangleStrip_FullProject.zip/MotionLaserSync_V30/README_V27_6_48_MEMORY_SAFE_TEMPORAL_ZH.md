# MotionLaserSync V27.6.48 — 硬件时域标定内存安全/后台归档版

本版本基于 V27.6.47，专门解决 1.0~5.0 mm/s、0.5 mm/s 步长、每速度 3 个正反 Pair 的长时间自动硬件时域标定中出现的 UI 卡顿和内存持续升高问题。

## 1. 控制器硬件同步方案没有修改

仍然严格使用现场已确认的 ECI3808 V32.9 SINGLE-OP14 拓扑：

- OP14/PWM0 -> scanCONTROL 外部触发；
- 同一 OP14 -> ECI IN0 -> REGIST(104)；
- XYZ/C/B 均为硬件锁存 MPOS；
- 200 Hz，连续触发周期 5 ms。

控制器 BASIC 字节不变。

## 2. V27.6.47 卡顿/死机的主要原因

V27.6.47 的运动定位已经使用 QtConcurrent，scanCONTROL 解码和 ECI TABLE 读取也有各自线程；但硬件 Profile 与位姿配对后的逐点 Machine-frame 重建仍由 HardwareSyncStrategy 的 owner/GUI 定时器执行，而且自动时域标定期间还把完整 AlignedPoint 点云扇出到 PointCloudBuilder/3D GUI。

因此一条长扫描期间可能同时存在：

1. SyncManager::m_allAlignedPoints 完整点云；
2. PointCloudBuilder::m_alignmentLog 第二份 AlignedPoint；
3. PointCloudBuilder::m_points XYZ 点；
4. VTK/显示临时数据；
5. 扫描结束后的 RANSAC Vec3d、内点数组；
6. 验证阶段的 corrected 点云。

并且 QVector::clear() 通常只清元素、不保证立即释放峰值 capacity。54 条标定扫描 + 18 条验证扫描时，虽然逻辑上上一条观测没有永久保留完整点云，但反复的大块分配、显示副本和峰值 capacity 足以导致明显卡顿、内存压力和碎片化。

## 3. V27.6.48 的线程/数据生命周期

### 采集期间

自动硬件时域标定启动时：

- 禁止 alignedDataReady 向 PointCloudBuilder / VTK 实时扇出；
- 启用 Hardware Raw Profile Capture Mode；
- Profile<->REGIST ordinal 对齐仍在线完成；
- 但不在 GUI 线程为每个有效传感器点创建 AlignedPoint / Machine XYZ；
- 内存中只保留一次 decoded LaserProfile X/Z + 一次 REGIST pose 序列。

因此采集过程仍保留完整原始几何信息和硬件同步 provenance，但避免百万级 heavyweight AlignedPoint 的多份内存副本。

### Stop/Drain 后

每条扫描完成后：

1. 完成 Profile/Pose/Aligned-profile/Pending/Dropped/Fault 硬件闭环检查；
2. 通过 swap 把 RAW Profile + REGIST pose 所有权从 SyncManager 转移给后台 QtConcurrent worker，不做完整复制；
3. SyncManager 立即清空并释放该条扫描的内部大容量；
4. 后台线程先保存完整 `.scan`；
5. 后台仅从全部有效点中均匀抽取有界样本（默认最多 250000 点）做 RANSAC / 球心求解；
6. Hold-out 验证只对抽样 RANSAC 内点做 candidate tau 离线校正，不再构造整条 corrected 百万点云；
7. 保存 sidecar JSON；
8. worker 退出，RAW Profile / pose / 临时归档 / RANSAC 数组全部析构；
9. 只有轻量的球心、速度、RMS、Pair ID、文件路径等统计留在 RAM；
10. 然后才启动下一条规划路径。

因此不会同时后台处理上一条又继续采集下一条。

## 4. 默认磁盘目录

默认归档根目录：

`E:\Projects\CData`

每次“开始标定路径采集”建立独立 session：

`E:\Projects\CData\HardwareTemporalCalibration\HTRUN48-YYYYMMDD-HHMMSSmmm\`

每条路径产生：

- `CAL_..._PLUS.scan` / `CAL_..._MINUS.scan` 或 `VAL_...scan`：完整 RAW 硬件同步扫描；
- 同名 `.json`：路径、实际速度、球心、RMS、传感器时序、候选 tau 等 sidecar 元数据。

路径表最后一列显示对应 RAW 归档文件。

归档目录可以在 UI 中修改；“每条扫描自动保存完整RAW .scan”默认开启。

## 5. `.scan` 中保存什么

使用现有 CompactScan v3 五轴格式：

- 每个 Profile 的硬件同步 Frame5D / XYZCB provenance；
- 传感器有效 X/Z 点及 pointIndex；
- Profile index / sensor time / host estimate；
- Physical17 / source-mask / timing provenance。

它不是仅保存最终球心。因此后续仍可以离线重新重建、检查或开发新的时域算法。

## 6. RAM 中最终保留什么

一条扫描后台完成后，仅保留：

- calibration: actual Vxyz、sphere center、sphere RMS、free radius、inlier/profile count；
- validation: raw/corrected center、raw/corrected RMS、actual Vxyz；
- archive path / metadata path；
- 全局 tau / R2 / std / hold-out 统计。

不保留该条百万点完整点云。

## 7. 分析点数

新增 `RANSAC/验证最大分析点数`，默认 250000 点/条。

这是分析采样上限，不影响 RAW `.scan` 的完整保存。若机器内存较小，可降到 100000~150000；如果需要更高球心统计精度且内存足够，可以提高。

## 8. PointCloudBuilder 的峰值释放

`PointCloudBuilder::clear()` 改为 swap 空容器，而不是 clear-only，避免前一次大点云留下高峰 capacity。

SyncManager 的硬件 pose/aligned/raw profile 容器在新 session / clear 时同样强制释放峰值 capacity。

## 9. 推荐第一次使用

先不要直接跑 72 条：

1. 归档目录保持 `E:\Projects\CData`；
2. `每条扫描自动保存完整RAW .scan` 勾选；
3. 最大分析点数先用 150000~250000；
4. 先生成 1.0/3.0/5.0 mm/s、每档 1 Pair 的小实验验证 UI、内存和磁盘；
5. 确认每条完成后系统日志出现 `[内存] ... 已释放` 和 RAW 文件；
6. 再运行 1.0~5.0 / 0.5 step / 3 Pair 的完整实验。

