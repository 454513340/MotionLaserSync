# 导入点云后的三角网格显示（MotionLaserSync V30）

本改动只涉及**点云导入、拓扑重建和 VTK 可视化**；不改动控制器通讯、激光传感器采集、触发模式、同步流程、运动轨迹、标定、FCL 碰撞模型或 `.scan` 文件格式。

## UI 放置及使用

点击「文件 → 导入点云」，在「三维点云」页现有机床状态行下面会出现一条**仅导入时可见**的控制行：

- **导入点云**：`散点 / 三角网格 / 网格+边线`。对拓扑可靠的数据默认选择三角网格；构建过程中先保留散点画面。想检查原始点数据时可随时切回散点。
- **轮廓宽度**：`自动 / 1280 / 640`。对 `.scan`，使用文件头和每条轮廓的原始 sample index，选项锁定，绝不根据点数乱猜；对 `.ply/.csv`，尝试检测完整的 1280/640 列二维行列结构，亦可手动选择。
- **边长上限**：默认 `自动`（数值 0）。按照轮廓内部和相邻轮廓间的采样间距，各自计算过滤阈值；也可以设置手动边长上限（毫米）。断点、异常跨行距离、退化三角形都被过滤。
- **颜色**：`Z高度伪彩 / 单色`。高度伪彩使用每个顶点 Z 标量和现有 VTK LUT，并在三角形表面插值；保持原来的 Z(mm) 色标。单色使用原点云控件的默认颜色。可将网格边线叠加显示。
- **状态**：轮廓数、有效三角面数、条带数量、断边数量；超过网格预览上限时显示抽样倍数。阈值详情见鼠标悬停提示。

重新开始实时采集、清空点云，或者其他模块调用原有的 `setPoints()` 时，自动退出导入网格模式。**原实时采集每 200ms 一次的点云后台准备、VTK 点渲染路径不变。**

## 三角带的生成逻辑

对连续的轮廓 `r`、`r+1`，保持同一个传感器原始采样列号 `c`：

```
strip = [ P(r,c), P(r+1,c), P(r,c+1), P(r+1,c+1), ... ]
```

四个有效顶点形成两个三角形；用 VTK `vtkPolyData::SetStrips()` 保存真实的 `vtkTriangleStrip` 单元，而不是生成没有索引关系的散点或纯视觉填充。

- `.scan` v3 使用保存的 `ArchivePoint.index`，兼容不同轮廓的缺失采样点；v1/v2 则按原重建器相同的零值和有效 Z 过滤规则恢复原始列号。包括轮廓为空时，仍然保留正确的行边界。
- `.ply/.csv` **只保存 XYZ，不保证存在轮廓编号、原始 point index、无效点占位或采集方向**。只有完整 640/1280 列、点顺序未打乱、结构检测通过时才能自动组网；手动行宽也要求行长可整除，且有边长断开保护。若外部软件过滤或排序过 XYZ，请优先导入原 `.scan` 文件，不能凭点总数精确恢复丢失的列号。
- 顶点包含非有限 XYZ、列号不连续、边长突变或任一面几乎零面积时，中断当前三角带，以避免跨越测量空洞形成错误大面。默认的边长自动上限分别为`min(25 mm, max(0.05 mm, 5 × 轮廓内/轮廓间有效间距中位数))`；对角边另用方向组合阈值。实际数据如果出现过多断面，可以手动调整边长上限（单位为 mm）。
- 输入点数量保持完整，导入后的散点模式可以原样回看。为了防止特别大的数据集在 VTK 中因面片超量而分配无上限内存，**当理论三角形总数超过 1200 万时，只对三角网格预览进行有标注的行列步长抽样**。原始 XYZ 仍保留，不保存被抽样后的数据，也不改变采集档案。

## 多线程和生命周期

在 `QtConcurrent::run` 后台线程中，仅访问拷贝的 Qt 点向量/行列元数据以及与 Qt/VTK 无依赖的 C++17 网格算法。VTK actor、mapper、cell array 只在 GUI 线程更新。更换文件、切换行宽、修改阈值和清空数据都会取消旧任务，并使用 generation 检查阻止旧任务结果覆盖新文件。点模式保留原有 VTK vertex glyph actor；网格模式使用单独的 actor，两个 actor 共享 XYZ 坐标及高度标量，降低重复显存占用。

## 修改文件

- `include/geometry/OrganizedCloudMesher.h` — 可独立测试的有序轮廓网格连接、缺失点/异常边过滤、平坦 XYZ 自动识别。
- `include/utils/PointCloudLoader.h`, `src/utils/PointCloudLoader.cpp` — `.scan` 逐轮廓重建与原始采样索引恢复。
- `include/widgets/PointCloudWidget.h`, `src/widgets/PointCloudWidget.cpp` — 导入专用工具栏、异步构网、三种显示模式、高度伪彩/单色、生命周期保护。
- `src/app/MainWindow.cpp` — 文件导入时传递轮廓拓扑信息并切换到三维视图；硬件路径不变。
- `tests/organized_cloud_mesh_tests.cpp`, `CMakeLists.txt`, `tests/CMakeLists.txt` — 不依赖 Qt/VTK 的回归测试与构建入口。

## 构建及测试

**Windows GUI**：仍然使用当前项目 `CMakeSettings.json` 原有 Qt6/VTK/FCL/scanCONTROL/ZMC 的 MSVC Release 配置，在 Visual Studio 中重新配置、编译 `MotionLaserSync`。此交付未包含额外安装程序，也没有修改第三方依赖。请在正式工位上使用实际 `.scan/.ply/.csv` 进行显示验证，确认帧率、网格边长和轮廓顺序后再部署。该功能不发出任何硬件操作指令。

**纯 C++ 算法测试**（Linux 或 Windows/MSVC，无 Qt/VTK）：

```sh
cmake -S . -B build-mesh-test -DORGANIZED_CLOUD_MESH_TESTS_ONLY=ON
cmake --build build-mesh-test --config Release
ctest --test-dir build-mesh-test -C Release --output-on-failure
```

测试覆盖：640/1280 点完整轮廓、索引缺失、不跨缺失点连接、异常高度、非有限点、手动阈值、乱序索引、取消任务、三角数预览限制、拒绝无序随机 XYZ 自动识别。

**验证范围说明**：这份文件的独立 C++ 网格算法已在当前 Linux 环境完成 CMake 编译和 CTest；此环境未安装 Windows MSVC/Qt6/VTK 和相应硬件 SDK，无法运行 Windows GUI、测试实际 VTK OpenGL 渲染或者连接实体设备。这些项目需在原 Windows 开发机上验收。
