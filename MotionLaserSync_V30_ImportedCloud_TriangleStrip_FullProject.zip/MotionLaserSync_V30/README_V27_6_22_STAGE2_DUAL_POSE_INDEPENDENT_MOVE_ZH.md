# V27.6.22 Stage-2 双位姿记录 + 独立五轴姿态切换修改说明

本修改基于用户上传的 `MotionLaserSync_v27_6_21_SIMULATION_VIEW_SWITCH_FIX` 源码，目的只有两项：

1. Stage-2 / hold-out 静态采集时，同时保留 X/Y/Z/C/B 的 MPOS 与 DPOS，便于对同一批激光 profile 做严格 A/B 对比。
2. Stage-2 / hold-out 计划姿态之间的直接移动不再使用 `MoveAbs(5 axis)` 五轴插补，而改为对 X/Y/Z/C/B 分别下发 `Single_MoveAbs`。每个活动轴使用本轴 `SPEED/ACCEL/DECEL * speedScale`，允许各轴先后到达，全部轴停稳后才进入球拟合/采集。

## 1. CSV 变化

Stage-2 训练 CSV 新表头：

```text
profile_id,
x_mm,y_mm,z_mm,c_deg,b_deg,
mpos_x_mm,mpos_y_mm,mpos_z_mm,mpos_c_deg,mpos_b_deg,
dpos_x_mm,dpos_y_mm,dpos_z_mm,dpos_c_deg,dpos_b_deg,
sensor_x_mm,sensor_z_mm,weight
```

其中：

- `x_mm...b_deg` 继续保留，仍表示当前求解器实际使用的 MPOS，保证旧脚本/旧工作流兼容。
- `mpos_*` 是同一组 MPOS 的显式列。
- `dpos_*` 是同一静态采集周期中控制器 DPOS 的前/后稳定状态平均值。
- 当前 Physical17 求解器仍只使用 MPOS；加入 DPOS 仅用于诊断/A-B 对比，不改变现有求解模型。
- 旧 CSV 仍可导入。新解析器同时支持旧列和显式 `mpos_*`；如果两套 MPOS 列同时存在但数值不一致，会拒绝导入，避免误用。

hold-out validation CSV 也同步增加上述 MPOS/DPOS 列。

## 2. Stage-2 自动姿态移动变化

修改前：

```text
JointTrajectoryPlanner5Axis -> moveJointAbs5D -> ZAux_Direct_MoveAbs(..., 5 axes, ...)
```

五轴沿一条同步关节插补段运行，短行程轴速度会按多轴插补比例降低。

修改后（仅 Stage-2/hold-out 计划姿态直接移动）：

```text
requestIndependentJointMove
 -> ZmcController::moveJointAbs5DIndependent
 -> X/Y/Z/C/B 各自 SetSpeed/SetAccel/SetDecel
 -> X/Y/Z/C/B 各自 ZAux_Direct_Single_MoveAbs
 -> 等待五轴全部 Idle
 -> 球拟合 / fresh-profile 采集
```

每个活动轴：

```text
SPEED = 本轴配置 SPEED * speedScale
ACCEL = 本轴配置 ACCEL * speedScale
DECEL = 本轴配置 DECEL * speedScale
LSPEED = 0
SRAMP = 0
MERGE = 0
```

因此 Z 的短行程不再因为 X/Y/B/C 的长行程而按距离比例被拖慢。注意：如果 Z 行程本身短到不足以完成加速-匀速-减速，Z 仍可能只能走三角速度曲线，这是单轴加速度约束导致的正常现象，而不是五轴插补比例限速。

Stage-1、P4 手动五轴同步定位、连续扫描/G-code 等原有运动入口没有改为独立轴模式。

## 3. MachineSafety

独立轴运动的实际中间姿态与同步五轴直线插补不同。因此新增：

```cpp
MachineSafetyModel::checkIndependentTransition(...)
```

该检查按每个轴独立的梯形/三角速度轮廓重建时间轨迹，并沿该时间轨迹采样碰撞状态。MainWindow 在真正下发 `Single_MoveAbs` 前执行该检查；检查失败则拒绝运动。

计划生成阶段原有同步路径预检仍保留，因此可能比新的实际独立轨迹检查更保守；真正执行前的独立轨迹门禁不会被绕过。

## 4. 离线验证

在 Linux 离线环境完成：

- `v20_single_sphere14_tests`：PASS
- `v20_2_single_sphere17_tests`：PASS
- `v27618_profile_block_tests`：PASS
  - residual max diff = `8.52651e-14`
  - Jacobian max diff = `2.18557e-07`

并验证：

- 原始旧 Stage-2 CSV 可继续读取：480 profiles / 142059 points。
- 新双位姿 CSV 可读取，DPOS 可按 profile 保存。
- 带新表头但 DPOS 为空的旧数据重导出形式也可读取。

由于完整 GUI 依赖 Windows x64、Qt/VTK、ZMotion 厂商 SDK，本环境无法完成完整 Windows GUI/控制器链接构建。所以上电测试前仍需在你的正常 Windows x64 构建环境重新编译。

## 5. 首次上电建议

首次验证独立轴移动时建议：

1. 先备份当前可运行版本和控制器参数。
2. 使用较低 Stage-2 速度倍率、选择小位移姿态，确认 X/Y/Z/C/B 是分别执行 `Single_MoveAbs`，允许不同时间到达。
3. 验证停止按钮/急停能停止五轴独立运动。
4. 观察日志中 `Calibration independent five-axis move`。
5. 导出一次 Stage-2 CSV，确认同一 profile 同时具有 `mpos_*` 与 `dpos_*` 五轴列。
6. 重点计算每个姿态的 `MPOS-DPOS`，尤其比较 Z 在长/短行程组合下的差异，然后再重新进行完整 Stage-2 标定。
