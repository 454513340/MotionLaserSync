# MotionLaserSync V28.8 / M7 多视角融合与离线验收

## 版本与工程边界

基线：用户已运行的 V28.7.4 `MotionLaserSync_V28_PROJECT_M6_VISUALIZATION_COMPLETE.zip`。
保留 M0～M6、H1/H3 真实同步、ZMC/ECI3808 硬件链路以及现有 CompactScanIO `.scan` 存档逻辑。
仅新增离线 M7；**不会下发任何硬件运动或传感器采集指令**。
OCCT 前缀继续是 `D:/dev/vcpkg/installed/x64-windows-release`。

## 使用步骤

1. 导入 STEP，放置工件；导入真实的 M2 H1 `.scan`。
2. 按现有步骤运行 M3、M5（以及可选 M5.1、M5.2）。
3. 运行 M6 连续 XYZ/C/B 离线补扫并生成无损压缩 `.scan` 分卷。建议先**导出 M6** 的 SCAN 分卷和索引 JSON，留作完整数据来源。
4. 在工作台 **14. M7：M2 实测 + M6 连续多视角虚拟补扫 / 融合验收** 中设置显示体素分辨率、每来源最多显示体素数量、目标 CAD 覆盖率，点击“运行 M7”。
5. 在阶段 **13. 图层与复扫检视** 独立切换：
   - M7_FUSED：去重的 M2+M6 空间预览（实测点优先）
   - M7_REAL / M7_SIMULATED：分来源显示（真实 M2 / 虚拟 M6）
   - M7_OVERLAP：具有双来源的体素（仅用于空间差异诊断）
   - M7_NEW_CAD / M7_REMAINING_CAD：CAD 表面被 M6 首次覆盖 / 仍未覆盖的诊断标记，**不是扫描点云**
6. M7 的两个表格按 CAD 特征和连续扫描段显示模拟新增面积、原实测面积及未覆盖面积。验收低于目标时报告“仍需下一视角”，但**不会自动执行真实机床运动**。
7. 导出 `twin_m7_fusion_report.json` 时附带 `_features.csv`、`_segments.csv`、`_remaining_targets.csv` 和 `_fusion_preview.ply`。

## 数学口径和数据来源

- M7 **全分辨率面积覆盖**采用 M5 的原始 `realHits` 以及 M6 基于每条虚拟激光 Profile 的 `firstCoveredSegmentByCell`，每个 CAD 单元面积只计算一次。
- M5.1 重开的稀疏单元属于“需补充观测”的诊断目标。原本的 M2 回波没有被删除；只有 M6 获得足够模拟回波，才认为这个单元通过新的覆盖评价。
- 一段 M6 仅在原有 M6 使用的至少 `minNewHitsPerCell` 次虚拟命中条件下改变覆盖状态。
- M7 用 M5/M6 完整覆盖结果验证面积守恒：`M2 已满足面积 + M6 新增面积 + 未覆盖面积 = CAD 目标面积`，并和 M6 报告相互核对。
- M7 **点云预览**使用 M2 保存的真实点云预览以及 M6 的逐段虚拟激光回波预览进行空间体素抽样。达到容量上限时按空间哈希均匀抽样，不会只留第一段。
- 预览中双来源进入同一体素时**保留 M2 实测坐标**，不会用 M6 预测位置篡改真实测量。重叠误差仅作粗略空间诊断，不能作为尺寸检测精度。
- `_fusion_preview.ply` 是有来源字段（1=真实 M2，2=仅 M6 虚拟）的**显示预览**，不承诺等于所有原始的 1.8 亿多条模拟回波。
- **原始完整点**分别保留在实际 M2 `.scan` 和 M6 原有多个无损压缩 `.scan` 分卷；M7 不复制这些数百 MB 文件，不把 CAD 曲面采样成“测量点”。清除 M6 前务必保存完整 M6 分卷。M7 JSON 本身不是完整原始扫描归档。
- `_remaining_targets.csv` 包含每个还需评估补扫的 CAD 单元（CAD/机床坐标、法向、面积、真实命中数、M5.1 密度重开标记）。这些只是规划目标，不是虚构激光回波。

## 已知限制

1. 当前 M3 光学参数仍是通过固定姿态 H1 拟合的等效模型；M6 的 B/C 多姿态光学可见性**未经实际多角度验证**。
2. 目前没有完成工件夹具、传感器外壳及整个连续路径的真实碰撞认证。即使 FCL 加载了机床模型，也不能下发 M6/M7 轨迹。
3. M5.2 指出的真实/名义 CAD 系统残差未自动补偿到任何真实点；M7 融合刻意优先保留实测位置。
4. `.scan` 分卷需先在 M6 页单独导出；M7 的 JSON + PLY 是独立分析附件，不会重复打包大容量数据。
5. M7 目前是当前一次 M6 多段自适应模拟的融合与验收。低于覆盖目标时生成残余 CAD 单元 CSV 作为**下一轮** NBV 的输入依据；并不会绕过人工确认直接连续发起无限多轮 M6，也不会把虚拟补扫宣称为真实实测。

## 源码与验证

- `include/twin/TwinM7Fusion.h` / `src/twin/TwinM7Fusion.cpp`：纯 C++17 覆盖、来源标记、空间一致性和体素预览。
- `include/twin/TwinM7Adapter.h` / `src/twin/TwinM7Adapter.cpp`：Qt 数据桥、JSON / CSV / 二进制 PLY 导出。
- `DigitalTwinScanWidget.*`：M7 工作台、后台线程、取消、进度、独立图层、逐特征/扫描段表。
- `PointCloudWidget.*`：独立 M7 VTK Actor（源数据与 CAD 诊断分离）。
- `tests/twin/twin_m7_fusion_tests.cpp`：面积守恒、稀疏重开、非法分段、来源标记、均匀抽样；M6 回归测试额外接入 M7 计算。
- 便携 C++17 `DIGITAL_TWIN_CLI_ONLY` 的全套测试可以在当前 Linux 环境执行，**Windows 10 + VS2022 + Qt/VTK + OCCT 的主 GUI 仍需你本地编译实测**。

### 验收建议

在 VS2022 中清空 CMake 缓存、重新配置后确认出现：
`V28.8 M7 real/sim provenance fusion, CAD acceptance + GUI [OK]`。
运行 M7 后，CAD 总覆盖率应当和 M6 报告中的最终预测覆盖率一致（显示舍入误差除外）。同时分别切换 M7_FUSED、M7_REAL、M7_SIMULATED、M7_NEW_CAD、M7_REMAINING_CAD；确认关闭图层不会删除数据，清除 M6 会使 M7 结果失效并同步清理。
