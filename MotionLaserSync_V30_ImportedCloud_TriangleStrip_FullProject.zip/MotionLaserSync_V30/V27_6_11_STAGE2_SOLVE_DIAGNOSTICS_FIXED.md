# V27.6.11 — Stage-2 solve diagnostics / offline restore

本版针对现场“阶段2数据采完后点击最终求解没有任何反应”的问题修改。

## 根因

V27.6.10A 在真正启动 QtConcurrent 后台求解之前，先在 GUI 主线程执行完整的 `updateCalibrationReadiness()` / 数值可观测性 Jacobian。现场 CSV 包含 600 profiles、213468 个球面点，因此 UI 可以在进入后台任务前长时间阻塞；此时没有进度条、没有“已开始”日志，看起来就像按钮没有响应。

同时，旧版 CSV 导出把阶段1的 120 profiles 和阶段2的 480 profiles 混在一起。阶段2最终 Physical17 求解应只使用阶段2训练数据。

## 修复

- 阶段2最终求解进入 `QtConcurrent` 后台线程，GUI 保持响应。
- 增加阶段2进度条、当前阶段、实时耗时、详细输出和取消按钮。
- 核心 `SingleSphere17Calibrator::solve()` 增加 Qt-free progress callback 与 cancellation flag。
- 最终优化采用“每姿态最多3帧、每帧最多180点”的代表集；完成后用完整阶段2数据重新计算 RMS/max/rank/condition。
- 旧 V27.6.10A 混合 CSV 可通过阶段1 JSON 中保存的姿态自动剔除阶段1 profiles。
- 数值有限差分导致理论 gauge 奇异值偶尔越过阈值时，rank 判据从 `==14/17` 调整为 `>=14/17`；3D hand-eye translation 仍由阶段1固定为 gauge anchor。
- 增加“加载阶段2结果 JSON”。
- 增加“绑定已加载结果到当前实机坐标约定”：必须同时加载对应阶段1 JSON，并核对当前 FlipX/FlipZ、各轴 DPOS/MPOS 来源和 hand-eye translation gauge anchor，一致才恢复实机验证能力。
- 离线恢复后生成 hold-out 验证计划时，也会使用导入的阶段2 CSV 检查与训练 B/C 网格的间隔；不再只依赖内存中的 CaptureRecord。
- `scanCalibration()` 仍只在独立 hold-out 验证通过后向扫描/RTCP提供17参数；加载训练结果不会绕过验证门控。

## 本次现场数据离线复核

用户现场原 CSV：600 profiles，其中阶段1 120 profiles、阶段2 480 profiles。

阶段2净训练数据：48个机械姿态、480 profiles、174123个球面点。

V27.6.11代表集求解（144 profiles / 25920点）后冻结参数，再用全部阶段2点复核：

- full-data RMS: 0.0369248134 mm
- full-data max abs residual: 0.2081230711 mm
- physical rank: 14/17
- full-state rank: 17/20
- condition: 210597.33

另外做了一个离线交叉检查：按固定序号每6个姿态留1个，40姿态拟合、8姿态完全不参与拟合；80 hold-out profiles / 28378点得到 surface RMS 0.049346 mm、max 0.177936 mm。该检查支持模型具有一定泛化能力，但它不是现场重新采集的独立验证，不能替代软件中的最终 hold-out 验证流程。

## 离线恢复顺序

1. 打开“运动学标定”页，先点击“加载阶段1结果 JSON”，选择与本次数据对应的 `stage1_handeye_sphere_result.json`。
2. 点击“导入阶段2/旧版混合 CSV”。推荐使用已经剔除阶段1的 `single_sphere17_stage2_only_profiles_20260910.csv`；旧600-profile混合CSV也支持。
3. 点击“加载阶段2结果 JSON”，选择 `stage2_physical17_result_20260910.json`。这一步不重新求解。
4. 连接控制器和2950，确认五轴停止。
5. 点击“绑定已加载结果到当前实机坐标约定”。只有 Flip 与 DPOS/MPOS 约定和阶段1保存值一致才会成功。
6. 生成并采集独立 hold-out 验证姿态，执行独立验证。
7. 验证通过后，从“文件 -> 应用当前17参数标定到五轴扫描...”应用到扫描/RTCP。
