# MotionLaserSync V28.5 — M5.1 中心孔倒角细分与密度诊断

本工程基于 V28.4 / M5 完整工程增量开发；不触碰现场 ECI3808/ZMC 运动控制链、标定模式与采集 SDK。

## 本阶段与原 M5 的差别

M5 将整个 `Centre through-hole` 合并并以“每个细分 CAD 三角单元至少 2 点”判定覆盖。这导致原始数据 210°～300° 附近明显失点，但窄上倒角仍报告 100% 覆盖。

M5.1 **保留原 M5 不变**，增加专门针对 H1 (`30×95×10 mm`) 中心孔的独立分析模块：

- 解析导入模型的三角化曲面，独立确认上倒角、直孔壁、下倒角以及各自的 CAD face ID 和面积。
- 采用中心轴 `CAD(x,y)=(0,-38)mm`，孔口半径 3.25 mm、直孔半径 2.75 mm、上下倒角 0.5×45°。
- 上倒角与下倒角各使用 **72 个 5° 扇区 × 4 个径向/轴向层**；直孔壁使用 72×20 个扇区和深度层。
- 读取 M2 `.scan` 的**所有实际有效点**与五轴曝光位姿，独立重新投影到 CAD 局部几何。M3 如存在，使用它的 `Valid + Workpiece` 点；未返回采样原因保持 UNKNOWN。
- 默认在 0.30 mm 联合关联条件下计算角度密度，始终并列统计 0.15/0.30/0.65 mm 阈值（不是尺寸公差）。
- 以各层 75% 分位点密度作参考，标记低于参考比率 30% 的稀疏单元。下列结果都是**点密度诊断**而非遮挡成因判定。
- 提供中心孔三类曲面 CAD 解析面 ID、三角化面积、理论面积及 r+深度−3.25 名义圆锥方程探索性残差。残差包含 CAD 配准、光学模型与表面加工差异，禁止据此自动更改 STEP。
- 导出 JSON 汇总与 `_bins.csv` 全部 2016 个角度/层分箱，包含实际和模拟计数，以及稀疏标记。

## 使用步骤

1. 用 VS2022 打开 `MotionLaserSync_V28_PROJECT` 的完整工程并清除旧 CMake 缓存；`x64-Release` 对应 OCCT 路径已保留：`D:/dev/vcpkg/installed/x64-windows-release`。
2. 编译 `MotionLaserSync.exe`，打开 **路径规划 → 数字孪生 / STEP 工件放置**。
3. 导入对应 STEP，保持与原 M2 数据一致的工件位姿（估计位置）；导入 `6061_Alumina_Scan_H1.scan`。
4. 可选运行 M3（已修正的虚拟相机 Y = +75mm）获取 M3 模拟点云。
5. 找到 **“10. M5.1：中心孔倒角精细诊断（H1 离线）”**，选择关联阈值（推荐 0.30 mm）、稀疏比例（推荐 0.30），点击“运行 M5.1 中心孔分析”。
6. 在 4×72 热图中查看 M2 实测、M3 虚拟、以及相对差异，左右拖动水平滚动条查看完整 0–360° 扇区。鼠标停留显示角度、径向层与原始点数量。
7. 点击导出 JSON + 分箱 CSV；如需清除，使用“清除 M5.1 数据”，不会删除磁盘数据，也不会修改原 M5 热图。

## 重要限制

1. M5.1 的三个曲面分类为**当前 H1 STEP 模板**，不是任意 STEP 形状的通用圆孔探测器。其他尺寸/位置的 CAD 将通过尺寸与曲面检查拒绝运行。
2. `M2` 的 `.scan` 只有有效返回点，不包含每个缺失采样的真实物理原因，不能将零计数等同于相机遮挡。
3. 三种关联阈值属于**参数敏感性试验**。倒角宽度 0.5mm，0.65mm 容易跨邻接面，故另加独立的窄区域约束；即便如此，0.65mm 结果也不能当成有效计量数据。
4. 当前近似工件位姿可能在名义倒角方程上产生 0.1–0.3mm 量级的偏移，因此默认使用 0.30mm 诊断，0.15mm 用于更严格关联的灵敏度检查。**不能将差异直接归咎于 STEP 倒角加工尺寸**。
5. 对任何已存在的原始实际回波不做平滑、插值或 CAD 自动补点。M5.1 还没有 M6 五轴补扫规划与可达性判定。
6. 操作完全离线，既不启动激光也不向运动控制器下发指令。

## 新增/修改源码

新增：
- `include/twin/TwinM51Chamfer.h`, `src/twin/TwinM51Chamfer.cpp`：纯 C++17 圆孔曲面区域与角度密度统计。
- `include/twin/TwinM51Adapter.h`, `src/twin/TwinM51Adapter.cpp`：Qt M2/M3 原始回波接口、异步报告导出。
- `tests/twin/twin_m51_tests.cpp`：CAD 曲面、角度稀疏、阈值、面积、负例。
- `tests/twin/twin_m51_h1_real_tests.cpp`：真实 H1 的 100 帧原始样本回归。

修改：
- `CMakeLists.txt`：注册纯 C++ 核心、Qt GUI 与回归测试；加注册保护消息 `V28.5 M5.1 ... [OK]`。
- `include/widgets/DigitalTwinScanWidget.h`、`src/widgets/DigitalTwinScanWidget.cpp`：增加 M5.1 控件、后台运行、取消、清除、热图。
- `src/app/MainWindow.cpp`：窗口版本为 V28.5。

## 自动测试说明

便携构建（无需 Qt、OCCT、设备 SDK）：

```bash
cmake -S . -B build-m51 -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-m51 --parallel
ctest --test-dir build-m51 --output-on-failure
```

自动化测试只验证离线 C++17 核心及参考数据契约；Windows10/VS2022 的 Qt/VTK 图形目标需在目标机器上编译确认。若出现 MSVC/LNK 错误，请提供“输出 → 生成”的完整日志。
