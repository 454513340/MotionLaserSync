# G 代码驱动仿真增量补丁

此包用于**上一版** `MotionLaserSync_V29_多姿态动态仿真与点云对比_完整源码_仅离线.zip`。在原项目根目录合并相对路径覆盖同名源码（建议先备份或新分支）。

改动的核心是新增 NC 文本离线执行器，并将多姿态动画、M3 理想曝光、完整模拟 `.scan`/PLY 输出全部改为根据所解析的 NC 指令驱动。支持将导出 NC 文件重新导入、逐段比较和验证。

原有 M0–M8、GCodeExecutor 和 H1/H3 硬件实际控制逻辑没有更改；不解除 `OfflineOnly`。阅读 `README_MULTIPOSE_GCODE_DRIVEN_SIMULATION_ZH.md` 和根目录测试报告。Windows GUI 编译及实机验证尚未进行。
