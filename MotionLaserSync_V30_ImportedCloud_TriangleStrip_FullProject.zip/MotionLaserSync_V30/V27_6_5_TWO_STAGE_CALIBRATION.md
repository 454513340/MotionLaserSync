# V27.6.5 TWO_STAGE_CALIBRATION

本版本将单球17参数标定从“一阶段、先猜球心再规划”改为两阶段：

1. 名义机床固定：人工采集多姿态，自动求手眼6DoF + 固定球心3D（rank 9/9）；
2. 使用阶段1模型规划17参数 D-optimal 姿态，采集后做 Physical17 / rank14 最终求解。

核心改动：
- 右手传感器坐标 `Y_S = Z_S × X_S`，Flip X/Z 决定Y轴方向约定；
- 不再要求人工选择球心 ±Y；
- 不再要求人工输入 hand-eye Tx/Ty/Tz gauge anchor；
- 阶段1手眼平移自动成为阶段2最终求解的内部规范锚点；
- 阶段2选中姿态一次确认后自动分段移动，每步重拟合，丢球即暂停；
- 当前XYZ ATYPE=1时用DPOS、C/B ATYPE=4用MPOS；会话中途禁止数据源改变；
- Release-only 保持不变。

详见 `docs/V27_6_5_TWO_STAGE_SINGLE_SPHERE_CALIBRATION.md`。
