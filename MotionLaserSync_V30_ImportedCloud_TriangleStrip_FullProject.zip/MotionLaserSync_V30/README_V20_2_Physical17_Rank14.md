# V20.2 physical-17 / rank-14 single-sphere calibration

The active V20 calibration implementation is now the full 17-parameter physical model in `SingleSphere17Calibration.*`.

Key points:

- nominal chain remains `Trans(X,Y,Z)*Rz(-C)*Ry(-B)`;
- 17 physical quantities are retained: 11 machine geometry + 6DoF hand-eye;
- sphere center is unknown in machine coordinates;
- one unknown fixed sphere gives physical rank 14/17 and full-state rank 17/20;
- hand-eye translation is an explicit external/translation-gauge anchor;
- the raw joint residual is `||p_M-c_M||-R`; no sphere-side sign enters calibration;
- `+Y/-Y` is kept only for single-profile 3D center recovery used by finding/teaching/recentering;
- the calibrator automatically tries both sign branches when it needs a sphere-center initializer.

See `docs/V20_2_Physical17_Rank14_Review.md` for the complete derivation and simulation results.

Planning interface:

- `SingleSphere17Model::handEyeTransform()` returns the retained 4x4 `^E T_S`;
- `SingleSphere17Model::sensorToMachineTransform()` returns the calibrated 4x4 `^M T_S(q)`;
- `SingleSphere17QtAdapter::handEyeQMatrix()` / `sensorToMachineQMatrix()` expose the same transforms to Qt code.
