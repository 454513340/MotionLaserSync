# V27.6.1 — 标定日志统一到系统日志

基于 V27.6 稳定 Release/RelWithDebInfo 版本，仅调整标定日志 UI 与路由。

- 删除系统标定页面底部独立“标定日志”文本框。
- CalibrationWidget::appendLog() 统一写入 LogManager。
- 新增日志分类 Calibration。
- 主窗口底部“系统日志”的分类过滤器新增 Calibration。
- 单球17参、测量不确定度、运动学、手眼标定日志均进入底部系统日志。
- 保留标定状态标签与进度条。
- 未改动 ECI3808、PWM、REGIST、RTCP、TABLE 通信协议。
