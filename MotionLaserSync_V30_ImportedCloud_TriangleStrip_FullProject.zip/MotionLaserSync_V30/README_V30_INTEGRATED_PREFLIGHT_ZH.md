# MotionLaserSync V30 — G-code integrated machine preflight

2026-10-24 | Delivery: **source project**, not a prevalidated Windows binary.

## This change answers the requested workflow

The G-code toolbar retains **one** machine-readiness diagnosis entry, now labelled **实机状态诊断（含硬件试采）**. This is the original preflight position, not four new independent buttons. The old label `（只读）` was removed because the requested trial **actively starts hardware synchronization / sensor PWM/laser triggers**. The diagnosis never issues NC G00/G05 axis-motion commands.

Pressing that single entry performs the following sequentially without additional individual test buttons:

1. Parse the exact saved NC using `GCodeParser`, run `simulateMultiPoseNc` on the *same* text, and reject malformed G93/G05/M50/M51, missing simulated profiles, or mismatched H1/H3/rate. Read basic live machine readiness before actuating the sensor. Do not accept `RegistrationVerified` / `SimulationVerified` comment claims as evidence.
2. After an explicit **one-time active-test confirmation**, configure synchronization from the NC (`HardwareTopology`, frequency, H3 R1 edge). Reuse `MainWindow::onGCodeHardwareNcProbeRequested`, which calls `SyncManager::start()`, stops after the existing nominal three-second interval, drains data and runs the existing `analyzeHardwareSyncData()` plus the hardware evidence assessor. Reject empty capture, trigger readback error, missing pose/profile alignment, overruns/drops, timing mismatch, or interrupted stop; no five-axis NC motion.
3. If and only if hardware sampling passes, reuse `MainWindow::onGCodeFullNcGeometryAuditRequested` to asynchronously replay the *entire* NC through the existing Machine5X FCL transition checks and per-trigger STEP/SCAN/Physical17 optical coverage checks. Reject a missing scene, changed 17-parameter model, collision, or inadequate coverage. No NC movement.
4. Re-check live controller state and the **same installed independent site verifier** used at actual `GCodeExecutor::start()`: fresh NC bytes, active calibration numbers, matching H1/H3/Hz, measured synchronization, correct STEP scene, idle/homed axes, current controller TABLE and real physical safety/fixture/interlock reads. One consolidated JSON report is written under the application data directory `gcode_preflight/V30_integrated_preflight_*.json`.

The four stages **fail closed**. A new diagnosis clears previous successful proof material before beginning. An error or cancellation stops the workflow rather than falling through to the next stage. The progress dialog's **Cancel** safely requests an early trial stop or geometry-worker cancellation; there is no dedicated toolbar Stop Trial button.

## Execution and boundaries

`OfflineOnly: true` is a *candidate* tag, not an immutable refusal. The Start button becomes eligible for that NC only after this single integrated diagnosis has passed. The executor continues to re-check source bytes, sensor settings, current joint position / first G00 path, hardware readiness, and the independent site safety evidence **at the time of real Start**. Diagnosis does not start machining automatically.

The uploaded V29 project has **no commissioned PLC/guard/fixture/workpiece/physical-optics reader**, so the final stage returns a clear blocker unless the machine integrator supplies a real `MainWindow::installSiteSafetyReader()` implementation. Do not replace that input with a fixed true or an NC comment. On static H3 trials there may be no useful trigger window; zero profiles are not proof of synchronization health.

## Files changed in V30

- `src/widgets/GCodeWidget.cpp`, `include/widgets/GCodeWidget.h`: remove three independent testing buttons and handlers; add one sequenced asynchronous preflight, progress/cancel, file identity recheck, consolidated result and gated Start.
- `src/app/MainWindow.cpp`, `include/app/MainWindow.h`: connect cancellation and prior-proof invalidation; reuse actual `SyncManager`, `analyzeHardwareSyncData`, FCL and optics functions instead of duplicating them.
- `include/gcode/GCodeExecutor.h`, `src/gcode/GCodeExecutor.cpp`: expose a non-actuating call to the same on-site verifier used at Start; align preflight's G91/G92 first-motion checks with Start, update legacy guidance that mentioned standalone test buttons.
- `CMakeLists.txt`: project `MotionLaserSync_V30`, Windows executable `MotionLaserSync_V30.exe`; `src/app/main.cpp`: `V30.0.0`; MainWindow caption V30.
- `tests/gcode/*`: update historic expectations and add `test_v30_integrated_preflight_contract.py`.
- Two historical V29 Markdown documentation **filenames** containing Chinese characters were renamed to ASCII. The document contents may remain Chinese; all packaged file and directory names are ASCII.

## Verification performed and not performed

- Portable C++ digital twin configured and built with CMake `-DDIGITAL_TWIN_CLI_ONLY=ON`, all **30/30 CTest tests passed**. This build excludes Qt UI and hardware drivers.
- Python static/contract tests in `tests/gcode` passed, including **17 V30-specific checks** for the one-button orchestration, stage order, clean failure/cancel and ASCII filenames.
- **NOT verified:** Windows Qt6/MSVC/VTK/FCL full GUI compile, controller/sensor communications, actual H1/H3 data collection, physical FCL scene fidelity and independent site safety reader. These must be checked on the actual integration test bench before real axis actuation.

## Build outline (Windows developer machine)

Open project directory in Visual Studio with CMake, select the x64 Release profile and build `MotionLaserSync`. Its output is **`MotionLaserSync_V30.exe`** after the `OUTPUT_NAME` change. External Windows Qt6, VTK, FCL, OCCT, controller and scanCONTROL dependencies remain required as in V29; building the portable digital-twin CLI alone does **not** compile the GUI.

Use the diagnosis button only after original STEP/SCAN planning and NC export. No synthetic `.nc` test example is suitable for real axis movement.
