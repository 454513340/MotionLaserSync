# V27.6.16AA — Machine-Safety Digital Twin / FCL Swept Collision Gate

This release is based on V27.6.16Z and integrates the user-supplied `machine5x_vtk_fcl_outline_complete` model directly into MotionLaserSync.

## 1. One geometry source for visualization and collision

The package contains the original seven visual PLY meshes and seven FCL collision STL meshes under `models/machine5x/`. Their bytes are kept unchanged from the supplied project. Both display and collision use the same `linkDelta()` kinematic chain:

`BASE -> X -> Y -> Z -> C -> B -> END_SENSOR`

with commanded rotary signs:

- `RC = RotZ(-C)`
- `RB = RotY(-B)`

All zero-pose meshes are used directly at `XYZBC = [0,0,0,0,0]`. There is no additional visualization offset. After XYZ homing establishes grating MPOS and B/C absolute frames are ready, the point-cloud window is driven from actual XYZCB MPOS.

## 2. Point-cloud window digital twin

The existing VTK point-cloud scene now also renders:

- user visual PLY machine model;
- optional `FCL碰撞包络` wireframe using the exact collision STL triangles loaded by FCL;
- the fitted study sphere;
- an orange wireframe sphere showing the configured sphere safety clearance.

Collision links are highlighted in red. During normal operation the model is refreshed from measured MPOS. During hardware synchronization the already-latched five-axis MPOS sample is reused; no extra ECI query is inserted.

## 3. Fail-closed sphere-study path generation

Sphere-study path generation is disabled unless the Machine5X FCL model loads successfully.

Before RTCP/geometry generation, planning limits are shrunk by configurable margins (`models/machine5x/machine_config.json`):

- linear joint margin: 3 mm;
- rotary joint margin: 3 deg.

The existing Z-release gates remain active first: kinematic solution, joint limits, sphere/laser-plane intersection, actual scanCONTROL X/Z field, visible arc, and optical Probe.

After geometric generation every remaining pose is checked against the Machine5X collision model:

1. exact FCL self-collision excluding only configured normal mechanical neighbours;
2. static minimum clearance at the target pose;
3. the fitted RANSAC sphere, inflated by a configurable clearance, against all moving machine links;
4. the complete synchronous XYZCB transition from the previously accepted pose, sampled in joint space.

Default swept sampling is 0.5 mm for XYZ and 0.5 deg for B/C (max 4000 samples). If any sampled state collides, the destination pose is invalidated and cannot enter the autonomous queue.

The same target-pose and swept-transition gates are repeated immediately before:

- manual study moves;
- autonomous study moves;
- local Probe/reacquisition moves.

Thus a stale path cannot bypass collision checking after the machine position changes.

## 4. Arrival gate

A successful controller MOVEABS stop is not by itself sufficient to start measurement. The study now checks final measured MPOS against the checked target. Defaults:

- XYZ max MPOS target error <= 0.05 mm;
- B/C max MPOS target error <= 0.05 deg.

If the arrival window is missed, formal Profile acquisition is rejected.

## 5. Fitted sphere as a dynamic collision obstacle

After 3-D sphere RANSAC succeeds, its MCS center and the known standard-ball radius are installed into the FCL safety model. The collision obstacle is expanded by `study_sphere_clearance_mm` (default 2 mm). Importing a new cloud or a failed sphere fit clears the old obstacle so stale geometry cannot authorize a new path.

## 6. Build dependencies

The GUI keeps MotionLaserSync's existing Qt/VTK resolution unchanged. Only after Qt/VTK are found, the Machine5X dependency prefix is added:

`D:/m5x/vcpkg_installed/x64-windows-release`

and CMake finds:

- Eigen3
- FCL
- nlohmann_json

This avoids accidentally replacing the application's Qt-enabled VTK build with the separate Machine5X VTK installation. `CMakeSettings.json` exposes only `M5X_VCPKG_INSTALLED_ROOT=D:/m5x/vcpkg_installed`; it does not override the application's global vcpkg install tree.

The build copies `models/machine5x` next to the executable and uses `TARGET_RUNTIME_DLLS` for FCL's runtime dependency chain.

## 7. Important safety limitation

The supplied collision meshes are component-aware simplified outline meshes. Their own report explicitly notes that decimation is not a mathematically guaranteed outward conservative envelope. This release therefore adds engineering joint/clearance margins and repeated collision gates, but software simulation is not a substitute for the machine's hard limits, E-stop, guard interlocks, low-speed first-run validation, or operator supervision.

Collision protection covers the bodies represented by the supplied Machine5X collision model plus the dynamic study sphere. If a real sphere stem, holder, cable envelope, auxiliary fixture, probe, or other physical object is not represented by those meshes, it is not yet protected by FCL and should be added to the collision model before unattended motion.

## 8. BASIC

No controller BASIC file was modified. The active V32.9 file SHA-256 remains:

`263d1f2a560120b006d25262e79fc364ebf35b4e6f2b3bf986f56013166b105a`
