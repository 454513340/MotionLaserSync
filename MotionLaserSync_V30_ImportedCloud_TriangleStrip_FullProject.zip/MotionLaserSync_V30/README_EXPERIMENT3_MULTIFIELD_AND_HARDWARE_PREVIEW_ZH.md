# 实验3多测量场 + 传感器标定轮廓显示修订（源码）

## 这次改了什么

1. **传感标定→轮廓→启动**：正式软件/硬件同步采集运行时，可以启动只读轮廓显示，直接显示正在接收的真实 profile。该操作不改变 LLT 触发器、不停止或重启硬件传输、不修改 SyncManager/TABLE，不把显示数据重新送回正式采集队列。点击「停止轮廓显示」仅取消 UI 订阅，正式采集继续。硬件采集停止后预览自动解除。
2. **硬件模式已选、采集尚未启动时**：独立标定预览仍采用软件内部触发及校准全场（index0），状态栏和标签明确显示「非硬件同步测量」。这是供对焦/调整的独立显示，不会虚构硬件时戳；如要求显示真实硬件同步帧，先通过正式采集按钮启动授权的 H1/H3 硬件采集，再点击「轮廓启动」。硬件模式缺少新轮廓时将提示检查 H1 OP14/Probe 或 H3 内部轮廓时钟及 CMM 传输，不会强制切换触发方式。
3. **实验3测量场可选**：Large=0、Standard=2、Small=7，以及2950 Quick Reference 0～127的其他合法 Measuring Field 索引。下拉框显示各场的参考最高频率。实验3的采样率同步限幅，仍与1mm/s扫描及用户设置的最大帧距一起校验。
4. **每个场使用自己的光学验证配置**：绝不把Small(7)的 X/Z 报告坐标范围套到 Large(0)或Standard(2)。规划时要求 `verified=true`、非空 `verificationId`、`measuringFieldIndex` 与选择值严格一致，FlipX/FlipZ 与当前已验证Physical17约定一致。实际传感器配置后再次回读field、Exp、Idle，错误立即中止。
5. **归档**：目录为 `Experiment3/Field{索引}_{UTC时间}/`；`session.json` 及组 `*_summary.json` 均记录 field、频率和光学验证ID。为兼容已有解析程序，RAW仍采用原 `S7P1` 容器格式、`.s7raw` 扩展名；**`S7P1`只是旧容器版本标记，不再代表field=7**。读取时务必同时读取该Session中真正的 `measuringFieldIndex`，不允许从扩展名反推测量场。

## 多场光学配置示例

- Large(0)：拷贝 `config/experiment3_large_field_0_verified_roi.example.json` 为 `config/experiment3_field_0_verified_roi.json`；由现场实测填入xMin/xMax/zMin/zMax、FlipX/FlipZ、verificationId，并正式验收后更新verified。
- Standard(2)：同理使用 `config/experiment3_standard_field_2_verified_roi.example.json`，部署为 `config/experiment3_field_2_verified_roi.json`。
- Small(7)：保留上一版兼容路径 `config/small7_verified_roi.json`，示例为 `config/small7_verified_roi.example.json`。
- 其他索引N：复制任意示例并修改 `measuringFieldIndex=N`，用当前场实测的XY/Z信息填写，部署为 `config/experiment3_field_N_verified_roi.json`。

**示例默认全部 `verified=false`、上下限0，绝不包含臆造的硬件范围。**

## 现场操作与边界

- 轮廓显示不是触发源。H1/H3 必须由原有 SyncManager/ECI3808 先完成授权与安全预检；若 H1 没有 OP14 外部触发，或 H3 没有正常启动内部时钟/CMM传输，就没有可显示的新同步轮廓。硬件同步采集的数据有效性仍完全由原有硬件同步链路和质量门禁判断，显示不会替代它。
- 独立标定预览配置的是全场软件内部触发，**和正式硬件采集数据不是同一回事**。传感器正在正式采集时，请不要用独立预览改变它的时序；程序会自动切换为只读订阅。
- 不要将原单球Physical17全场标定的ROI当作任何新测量场的有效范围；每个场重新验证实际的X/Z光学边界与最大可见弧。
- 默认第三实验选择Small(7)，200Hz。切换到Large(0)时，采样率自动限制在其参考最大144Hz内。所有场都使用独立1～5mm/s定位和1mm/s扫球，并遵守MachineSafety/设备互锁。
- 没有 Windows/Qt/LLT/ECI3808 设备测试。本版仅提供可移植C++规划回归与代码结构核查；上线前必须通过真实传感器、控制器、轴运动和急停验收。

## 本地可执行测试

```sh
cmake -S . -B build-e3 -DSMALL7_EXPERIMENT3_CLI_ONLY=ON
cmake --build build-e3 --parallel
ctest --test-dir build-e3 --output-on-failure
python tools/verify_small7_experiment3_contract.py
python tools/verify_experiment3_hw_preview_multifield_contract.py
```
