# MotionLaserSync V27.6.44 — 当前 ECI3808 硬件触发方案的时域同步标定

## 1. 本版本定位

V27.6.44 在 V27.6.43 基础上新增第四类系统标定：**硬件同步时域标定**。

本版本**不修改控制器硬件触发方案，也不修改 BASIC**。现场拓扑仍保持：

```text
ECI3808 PWM0 / OP14
        ├──> scanCONTROL 外部 Trigger（EdgeRising）
        └──> ECI IN0 ──> REGIST(104) ──> XYZ/C/B 五轴 MPOS 锁存
```

控制器 V32.9 BASIC SHA-256 仍为：

```text
263d1f2a560120b006d25262e79fc364ebf35b4e6f2b3bf986f56013166b105a
```

新增标定只辨识这条已经建立好的一一对应链路中的**等效固定时间偏差**：

```text
τ = t_sensor,effective - t_ECI,latch
```

- `τ > 0`：传感器实际有效测量晚于同 ordinal 的 REGIST(104) 锁存；
- 运行时使用后一个 5 ms 锁存位姿进行 XYZ/C/B 插值，然后再进入 Physical17；
- `τ = 0`：保持 V27.6.43 原始行为；
- 当前拓扑只支持 `0 <= τ < 5 ms` 的标定补偿，超出范围直接拒绝应用。

## 2. UI 变化

“系统标定”现在按物理层次排列为：

1. 传感标定
2. 初步手眼标定
3. 运动学标定
4. **硬件同步标定**
5. 测量不确定度

新增页不会发送控制器运动命令，也不会改变 OP14、IN0、REGIST(104) 或触发边沿。操作者继续使用现有“控制/五轴运动学/采集”页面执行安全运动；本页只采入停止后的完整硬件同步扫描数据。

## 3. 推荐标定工况

固定 19.050 mm 标准球，保持正式测量用的传感器配置不变：

- hardware sync；
- V32.9 固定 5 ms / 200 Hz；
- scanCONTROL EdgeRising；
- 自动曝光关闭；
- resolution / exposure / idle 与未来正式测量一致；
- 已加载有效 Physical17；
- 时域补偿必须先禁用。

建议每轴至少两个不同绝对速度，并同时包含正、反方向，例如：

```text
X: -5, -3, +3, +5 mm/s
Y: -5, -3, +3, +5 mm/s
Z: -5, -3, +3, +5 mm/s
```

每一趟扫描停止后，在“硬件同步标定”页点击 **采入当前硬件扫描**。

## 4. 每一趟扫描如何得到一个观测

### 4.1 实际速度不用命令速度

程序从 `SyncManager::getHardwarePoseSamples()` 的 V32.9 `REGIST(104)` MPOS 计算相邻 5 ms 位姿差：

```text
v_k = (q[k+1] - q[k]) / 0.005
```

- ordinal 0 是正式 Probe；`0 -> 1` 不是正常 5 ms PWM 周期，因此自动排除；
- 自动判断 X/Y/Z 中的主运动轴；
- B/C 运动、明显交叉轴运动、加减速/速度离散过大的扫描会拒绝；
- 使用稳健中位数/MAD 得到本趟 `signedSpeedMmPerSec`。

### 4.2 标准球中心

程序直接使用当前扫描已经通过 Physical17 重建的 Machine-frame 点云：

1. 现有 `SphereDistanceAngleStudy::fitMachineSphereRansac()` 做自由半径 RANSAC；
2. 使用 RANSAC 内点；
3. 固定标准球半径 `R = D/2`，Huber 鲁棒 Gauss-Newton 再精化球心；
4. 本趟保存：轴、实际有符号速度、固定半径球心、RMS、自由拟合半径、内点数、Profile 数、sensor timing 配置。

## 5. τ 的求解模型

对 X 扫描：

```text
Cx(v) = bx - τx * v
```

Y/Z 同理。

因此每轴线性回归斜率：

```text
τaxis = -slope
```

这与正反扫描公式完全等价：

```text
C+ - C- = -2 * v * τ
τ = -(C+ - C-) / (2v)
```

软件同时求：

- `τX / τY / τZ`；
- 每轴 `R²`；
- 每轴统计标准差；
- X/Y/Z delay spread；
- 一个共享斜率、各轴独立截距的公共 `τ`。

公共模型为：

```text
center_axis = intercept_axis - τ * signed_speed
```

默认质量门限：

- X/Y/Z 三轴均有效；
- 每轴至少 4 个观测；
- 每轴必须有正、负方向；
- **每轴至少两个不同绝对速度等级**；
- `R² >= 0.40`；
- `max(τX,τY,τZ)-min(...) <= 300 us`；
- 公共 delay std `<= 250 us`；
- `0 <= τ < 0.95 * 5 ms`。

门限均可在 UI 调整；未通过时“应用并启用补偿”不可用。

## 6. 运行时如何代入

硬件帧对应关系不变：

```text
Profile[k] <-> Raw REGIST Pose[k]
```

若 `τ > 0`，设：

```text
alpha = τ / T,    T = 0.005 s
```

使用：

```text
q_corr[k] = q_raw[k] + alpha * (q_raw[k+1] - q_raw[k])
```

其中 `q = [X,Y,Z,C,B]`。

然后才执行现有 Physical17：

```text
T_sensor_to_machine = Physical17(q_corr[k])
P_machine = T_sensor_to_machine * P_sensor
```

注意：

- 先插值 XYZ/C/B，再调用 Physical17；
- 不直接对 4x4 变换矩阵做元素线性插值；
- C/B 使用控制器发布的连续机械坐标，不执行人为“最短角”回绕；
- Raw Pose 永远保留，补偿帧额外使用 `PoseTiming::HardwareTemporalInterpolated` 标识。

## 7. Probe 和最后一帧处理

当前方案使用“向下一条 latch look-ahead”。因此：

- Probe ordinal 0：与 ordinal 1 的间隔包含 Probe->continuous 握手，不可当成 5 ms，**只做配对、不重建点云**；
- 最后一条 Profile：没有 `Pose[k+1]`，**只做配对、不外推点云**；
- 这两条仍然计入 Profile/Pose/ordinal 完整性，不作为丢帧；
- `HardwareSyncReport` 单独显示 `temporalBoundarySkippedProfiles`。

因此启用时域补偿后，一个完整扫描最多比原始点云少 Probe + tail 两个轮廓，但不会用不可证明的时间间隔或外推污染计量数据。

## 8. 配置绑定和持久化

活动文件：

```text
<AppData>/calibration/active_hardware_temporal.json
```

JSON 保存：

- Calibration ID；
- topology；
- `delayDefinition`；
- 公共 delay/std/spread；
- 每轴结果；
- 原始观测；
- resolutionIndex；
- exposure/idle；
- trigger period；
- quality gates；
- runtimeEnabled。

正式启动硬件采集时，`SyncManager` 强制检查：

```text
resolutionIndex
exposureTime
idleTime
triggerPeriod == 5 ms
```

任一不一致时拒绝启动补偿扫描，要求重新标定或禁用时域补偿。

## 9. .scan 存档

`ScanArchive5D` payload 从 v4 升为 v5，增加：

- `temporalOffsetSec`；
- `temporalAlpha`；
- `temporalNextOrdinal`；
- `PoseTiming::HardwareTemporalInterpolated`。

解码器继续兼容旧 v4 文件。

## 10. 硬件同步报告

报告新增：

- 是否启用 temporal correction；
- Calibration ID；
- τ / std；
- Probe/tail boundary skip 数；
- 明确写出运行时的 XYZ/C/B 插值方法。

同时继续保留重要限制：动态球法标定的是整条测量链的**等效固定时延**。独立电气抖动、实际曝光相位最好仍通过示波器或 scanCONTROL CMM Trigger 验证。

## 11. 代码新增/修改位置

新增：

```text
include/calibration/HardwareTemporalCalibration.h
src/calibration/HardwareTemporalCalibration.cpp
include/runtime/HardwareTemporalCorrection.h
src/runtime/HardwareTemporalCorrection.cpp
include/widgets/HardwareSyncCalibrationWidget.h
src/widgets/HardwareSyncCalibrationWidget.cpp
tests/v27644_hardware_temporal_tests.cpp
tools/verify_v27644_hardware_temporal.py
```

核心修改：

```text
SyncManager            运行时 look-ahead、配置指纹、边界帧处理
Acquisition5D          新增 HardwareTemporalInterpolated provenance
ScanArchive5D          payload v5 + v4 backward read
HardwareSyncReport     新增时域标定/补偿报告
CalibrationWidget      新增“硬件同步标定”Tab
MainWindow             绑定 SyncManager、版本号升级
```

## 12. 验证结果

本交付环境无法构建依赖 Windows x64 + Qt6 + VTK + ZMotion/scanCONTROL SDK 的完整 GUI，但已经执行可移植真实核心测试：

```text
v27644_hardware_temporal_tests: PASS
p0_core_mock_tests:             85/85 PASS
v19_report_tests:               22/22 PASS
v21_runtime_tests:              47/47 PASS
verify_v27644_hardware_temporal.py: PASS
```

其中源契约还验证了两份 V32.9 ECI BASIC 的 SHA-256 与 V27.6.43 完全相同。

## 13. 上机前建议

1. 先在 Windows 正式构建环境完成 Release 编译；
2. 保留 V27.6.43 作为回退版本；
3. 首次只做低速 X 轴正反扫描，核对 τ 正负号；
4. 再做多速度 X/Y/Z；
5. 质量门限 PASS 后才启用补偿；
6. 补偿后用独立速度/轨迹做标准球 hold-out；
7. 最终使用示波器测 OP14 / IN0 / CMM Trigger，记录独立电气 jitter。
