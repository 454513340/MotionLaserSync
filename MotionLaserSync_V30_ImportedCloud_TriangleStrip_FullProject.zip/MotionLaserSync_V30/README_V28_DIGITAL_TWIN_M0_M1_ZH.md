> **注意：这是最初的 V28 M0/M1 文档。最新 M1 主界面同步修复及 M2 历史 SCAN 回放，见 `README_V28_M0_M1_FIXED_M2_ZH.md`。**

# MotionLaserSync_V28_PROJECT — 数字孪生 M0+M1 源码交付

## 0. 当前完成范围

本工程**以用户上传的 `MotionLaserSync_Experiment3_ZExposure_Revised_Source_20261013.zip` 为唯一代码基线**，保留已有实验3 Z/曝光、H1/H3、Physical17、Machine5X 与机床安全逻辑。

新增 V28 数字孪生功能：

1. C++17 **独立离线**核心库 `digital_twin_core`，不调用 Qt/VTK/ZMC/LLT；
2. STEP B-Rep 导入适配器（依赖 Open CASCADE，OCCT 未安装时可显式禁用）；
3. STEP 导入后按照 mm 单位和 CAD 原始坐标生成三角网格，保留本次导入中的 faceId；
4. `T_M_CAD`：CAD->机床坐标 MCS 的 XYZ/Rx/Ry/Rz 位置、旋转、包围盒计算；
5. 区分**仿真真值位姿**与**路径规划估计位姿**，为未来初扫配准预留接口；
6. 支承平面和基本射线首交点查询（M1 朴素逐三角形检查；M3 将升级为 BVH）；
7. 现有“路径规划”面板新增**“数字孪生 / STEP 工件放置…”**按钮，弹出独立 Qt/VTK 离线场景；
8. 工件三角网格 + 支承面在原有 VTK 机床坐标显示组件中可视化；可编辑全部六个放置参数、保存/加载 `*.twin.json`；
9. 内置来自用户 STEP 的**预三角化参考 OBJ 网格**，在没有 OCCT 时仍可测试摆放和射线接口；
10. 可选的离线 CMake CLI 和自动测试（不依赖设备 SDK）。

**本阶段没有实现**：真实 SCAN 回放、逐帧 2950 Profile、光学遮挡、NBV、五轴补扫、自动点云融合、运行中的碰撞验证。以上归属 M2～M8。界面不会向机床或激光传感器下发命令。

## 1. Windows 上运行 GUI

### 依赖

与原工程一致，使用 MSVC x64 Release、Qt6 Widgets/Concurrent/OpenGLWidgets、VTK (含 GUISupportQt)、Eigen3、FCL、nlohmann_json、ZMC SDK、scanCONTROL LLT SDK；另外 **STEP 导入需 Open CASCADE**。

OCCT 可以由现有 vcpkg 安装，例如（取决于您已有的 vcpkg 布局）：

```powershell
D:\dev\vcpkg\vcpkg.exe install opencascade:x64-windows
```

源项目 `CMakeSettings.json` 指定 `TWIN_OCCT_PREFIX=D:/dev/vcpkg/installed/x64-windows`。若安装在其他位置，请改这个路径，或显式设置 `OpenCASCADE_DIR` 指向包含 `OpenCASCADEConfig.cmake` 的目录。源码使用 `find_package(OpenCASCADE)` 检测并链接该依赖。Qt/VTK 优先使用原项目的发现流程，再加入额外 OCCT 前缀，避免改变已验证的图形组件来源。

**注意**：`CMakeLists.txt` 只有在实际找到 OCCT 时才定义 `MLS_TWIN_HAVE_OCCT`；若未找到，GUI 仍可构建（前提是已有原工程依赖齐全），但 STEP 按钮会提示安装 OCCT，OBJ 示例可工作。不能把预转换 OBJ 当作通用 STEP 读取。

原始 ZIP 并未包含现场官方二进制 SDK，尤其 `third_party/scanCONTROL/lib/x64/LLT.lib` 和 `third_party/zmc/lib/x64/zauxdll.lib` 缺失。原始 ZIP 还将 SDK 二进制目录以及 `models/machine5x/{visual,collision}` 打包成 0 字节占位文件。本 V28 包将**仅这些空占位文件**规范化为相应空目录，内置文字提示。应由您将合法的官方 SDK 库/DLL 和匹配的 PLY/STL 资源放进相应目录。没有这些文件，**原工程 Windows GUI 本身也不能完整编译/展示机床模型**。本交付不是编译好的 exe，也未在现场 Windows MSVC 环境进行编译验收。

### 使用步骤

1. 在 Visual Studio 中打开根目录（CMake 项目名 `MotionLaserSync_V28_PROJECT`；保留原 GUI 可执行文件名 `MotionLaserSync.exe` 以兼容原脚本）。
2. 确认依赖配置成功：CMake 中出现 `V28 STEP import: Open CASCADE enabled`。若出现 OCCT 缺失警告，请先配置 OCCT，才能导入任意 STEP。
3. 编译并启动 GUI，进入**路径规划 → 数字孪生 / STEP 工件放置…**。
4. 点击**导入 STEP…**选择 `.step/.stp`，或**载入测试零件**（优先实际 STEP；没有 OCCT 则使用随包 OBJ 网格）。
5. 在 **CAD → MCS 六自由度放置**调整 X/Y/Z/Rx/Ry/Rz，三维预览同步更新。可点击“使用实测参考位置”恢复上一轮从 `.scan` 初步配准的参考位置。
6. 配置或关闭支承面。可保存 `.twin.json`、再次载入并继续编辑。
7. 如果已将原 Machine5X 视觉模型实际安装，可以尝试“加载机床视觉模型”；否则仍可使用坐标系/零件/支承面预览，不影响 M1 算法。

**参考位姿** `X=44.3195, Y=10.2369, Z=-225.05, Rz=-89.2265°` 是之前基于真实扫描初步拟合的估计值，**不是六自由度高精度实机注册结果**。Rx/Ry 暂取零。完整准确性需后续 M2/M4 再验证。

### 坐标约定

- 几何单位 mm；角度度。
- 工件放置采用固定轴欧拉序列 `Rz(Rz) * Ry(Ry) * Rx(Rx)`：`p_MCS = T_MCS_CAD * p_CAD`。
- 这是**工件摆放**的旋转，不是设备 C/B 轴指令。原五轴 XYZ-C-B 运动学在本阶段未改变。
- `TwinScene::truePose()` 仅用于数字孪生物理场景；`estimatedPose()` 留给未来规划。正式 M5/M6 实现必须严格阻止规划代码读取场景真值。
- `TwinScene::firstHit()` 返回最近一个工件或支承面的射线命中，**不是激光/相机双光路测量模拟**。

## 2. 离线 CLI / CMake 检验

无需 Windows/Qt/VTK/vendor SDK，在 Linux/Windows 编译器运行：

```bash
cmake -S . -B build-twin -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build-twin --config Release
ctest --test-dir build-twin --output-on-failure -C Release
./build-twin/digital_twin_cli --obj examples/digital_twin/6061_reference_mesh.obj
```

若想测试真实 STEP 导入，将 `TWIN_ENABLE_OCCT=ON` 并提供有效的 OCCT CMake 安装；启用时会自动加入 STEP 导入测试。

## 3. 核心修改清单

修改原有：

- `CMakeLists.txt`：工程名称、`digital_twin_core`、CLI/测试、OCCT、GUI 绑定；
- `CMakeSettings.json`：新增 `TWIN_OCCT_PREFIX`；
- `include/widgets/PathPlanningWidget.h` / `src/widgets/PathPlanningWidget.cpp`：启动离线数字孪生工作台；
- `include/widgets/PointCloudWidget.h` / `src/widgets/PointCloudWidget.cpp`：新增工件网格与支承面的独立 VTK Actor；保留现有机器显示逻辑。

新增：

- `include/twin/` / `src/twin/`：几何、STEP 适配、位姿、射线、轨迹和会话；
- `include/widgets/DigitalTwinScanWidget.h` / `src/widgets/DigitalTwinScanWidget.cpp`：离线场景编辑器；
- `tools/digital_twin_cli.cpp`：独立导入和坐标报告；
- `tests/twin/`：坐标与几何回归测试；
- `examples/digital_twin/`：用户 STEP、预三角网格及参考摆放 JSON。

原 `ZmcController`、`SyncManager`、`Acquisition5D`、`ScanArchive5D`、`MachineKinematics5Axis`、BASIC 固件没有改动。

## 4. 测试范围与限制

Linux C++17 Release 的 `digital_twin_core`/CLI/CTest 已实际构建并通过 3 项回归（坐标变换、射线、参考网格）。还执行了 3 类原工程协议/路径安全静态合同检查，均通过。

由于当前构建环境没有用户的 Windows MSVC + Qt/VTK/OCCT/官方 SDK **完整依赖组合**，尚不能声称 Windows GUI 或直接 STEP B-Rep 导入分支已在该环境编译通过。首次部署请先验证 OCCT 导入、中文路径、界面按钮、Actor 变换、Qt/VTK 生命周期和官方 SDK 的 Debug/Release ABI 兼容性。物理硬件控制路径未更改，不意味着有实机安全验收。

下一阶段 M2 将复用现有 `CompactScanIO::load()` 回放 `6061_Alumina_Scan_H1.scan`；不将这份 33 MB 的原始扫描数据重复塞进源码 ZIP，请继续使用已上传的真实文件。
