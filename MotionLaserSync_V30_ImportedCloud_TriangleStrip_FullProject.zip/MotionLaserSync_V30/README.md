# MotionLaserSync V30 — Integrated NC Preflight

Current V30 entry point and change details: [README_V30_INTEGRATED_PREFLIGHT_ZH.md](README_V30_INTEGRATED_PREFLIGHT_ZH.md).
The G-code toolbar now provides one combined **实机状态诊断（含硬件试采）** procedure. Older V29/V28 sections below are historical technical records and do not override the V30 preflight workflow. The active synchronization trial is not read-only and will energize sensor/controller triggering. GUI/physical safety acceptance is not claimed.

---

## 多姿态实验导入标定与候选NC版本绑定（新增）

详见 [README_MULTIPOSE_IMPORTED_CALIBRATION_TRACEABILITY_ZH.md](README_MULTIPOSE_IMPORTED_CALIBRATION_TRACEABILITY_ZH.md)。本功能绑定 STEP/SCAN/Physical17 数值与 NC 原文哈希，**并不授权真实五轴运动**。

> 2026-10-24：H3/100 UI缓存、G代码只读准入误报及首G00动态检查修正：[操作与源码说明](README_GCODE_H3_100_UI_CACHE_AND_FIRST_G00_ZH.md)。

> **2026-10-23 当前默认多姿态矩阵（BC37）：** B、C 均取 `-10,-6,-2,2,6,10` 度，形成 36 组；另加 `P37: B=C=0`，共 **37 组**。已取代前一版默认45组设置，保留旧45组回归作为历史记录。新 SCAN 首帧标定的基础关节限位复核为37/37，**不包含完整FCL/光学/实机授权**。详见 [README_MULTIPOSE_BC37_EXPERIMENT_ZH.md](README_MULTIPOSE_BC37_EXPERIMENT_ZH.md)。

> **2026-10-23 多姿态 H3 轴限复现与扫描段修订：** 取消多姿态扫描中额外的 Z 进/退刀，保留扫码前后覆盖延伸；机床 X+→X−、激光关闭转场与 M50/M51 不变。新增真实 H3 P01/P41 超限数值诊断和 45 姿态失败列表。请先读 [README_MULTIPOSE_REAL_H3_AXIS_LIMIT_NO_RETRACT_ZH.md](README_MULTIPOSE_REAL_H3_AXIS_LIMIT_NO_RETRACT_ZH.md)。完整 NC 仍严格仅离线，**不准实机直接执行**。

> 2026-10-23 多姿态扫描更新：新增**由最终 G 代码文本驱动**的离线五轴数字孪生执行仿真。详见 [README_MULTIPOSE_GCODE_DRIVEN_SIMULATION_ZH.md](README_MULTIPOSE_GCODE_DRIVEN_SIMULATION_ZH.md)。所有输出保持 OfflineOnly。

> **2026-10-13 实验3多测量场与软/硬同步轮廓显示修订**：详见 `README_EXPERIMENT3_MULTIFIELD_AND_HARDWARE_PREVIEW_ZH.md` 和 `EXPERIMENT3_MULTIFIELD_HW_PREVIEW_TEST_REPORT_ZH.md`。实验3支持0～127场索引，必须使用每个场已验证的光学配置。正式硬件采集中的轮廓显示为只读订阅，绝不改写硬件触发。Windows GUI与实机运动仍需现场编译和验收。

> **2026-10-11 标准球全扫描 X单轴与路径预览修复**：详见 `README_SPHERE_EXPOSURE_X_ONLY_PATH_FIX_ZH.md`。先编译并空载安全验证；控制器 BASIC 未改。

# MotionLaserSync — H1/H3 ONLY 源码交付（ECI BASIC V32.16）

本版由用户提供的完整项目修改而成，**删除 H2（ECI PWM→Sensor CMM→IN1）拓扑**；保留 H1=1 和 H3=3 的 TABLE 数值 ID，不重新编号。原编号 `2` 属于已退役值，Host 和 BASIC 均明确拒绝。

- **唯一现场 BASIC**：`controller/ECI3808_V32_16_H1_H3_ONLY.bas`
- **Host 所要求的 V32.16 握手标志**：`TABLE[354]=321058`，`TABLE[362]=1316`。
- **H1**：OP14 同步外部 Profile/IN0，五轴 `REGIST(104)`，保留冷启动预热及正式 FIFO Probe、STOP-DRAIN。
- **H3**：scanCONTROL 内部 Profile 时钟，RS422 CMM→IN1，五轴 `REGIST(114/115)`；保留 LLT CMM 特殊启动/停止与连续窗口 Probe。
- **软件同步、机械模型、标定和历史技术档案保留**。历史 README、测试资料可能仍记录已经废弃的 H2，属于版本档案而非本版部署说明。
- 修改文件与验证范围见 `H2_REMOVAL_CHANGELOG.md`。现场下载指引见 `FIELD_BASIC_DEPLOYMENT_NOTICE.md`。

本交付包含完整 C++、头文件、controller BASIC、资源及随包第三方 SDK，**不是已完成编译的 Windows 程序，也不是已验证的控制器固件镜像**。

## 编译依赖与验收边界

本包保留了 C++ 源码、第三方接口头文件/封装源码及原有资源。**2026-10-23 完整性补包：已从上一版 9.6 MB 交付包原样恢复** `third_party/scanCONTROL/bin/x64/LLT.dll`、`third_party/zmc/bin/x64/zauxdll.dll`、`third_party/zmc/bin/x64/zmotion.dll`，以及两份 `examples/digital_twin/6061_*.obj` 网格；随包仍有 `LLT.lib` 和 `zauxdll.lib` 等导入库。此前“全部为 SDK 空占位、不含二进制依赖”的历史描述不适用于本补齐版。**但随包 DLL 的存在不代表与现场设备及 Windows/编译器版本完全兼容**；Qt、VTK、OCCT、FCL 等其他外部依赖仍需按工程配置提供，现场 SDK 版本及授权须自行核对。本包不是已编译或经现场验收的可执行程序。

可运行 `python tools/verify_h1_h3_only_llt_basic_contract.py` 做 H1/H3 源码静态合同检查；`tests/h1_h3_only_contract_tests.cpp` 可直接用 C++17 编译进行协议验证。详细验证结果及原项目继承的失败项，参见 `H1_H3_ONLY_TEST_REPORT.md`。

## V32.16 H3 专属有符号时域标定扩展

本包在 H1/H3 ONLY 工程上增加 H3 的独立 RAW 标定、正负延迟插值、独立 H3 JSON 和 R1/CMM 指纹。**控制器 BASIC 未修改**；仍使用 V32.16 H1/H3 协议，H2 不恢复。详细部署与安全约束：`H3_SIGNED_TEMPORAL_CALIBRATION_GUIDE_ZH.md`；测试及未验证条件：`H3_SIGNED_TEMPORAL_TEST_REPORT.md`。

## H3 路径界面排版与旧 Session 阻断（本次更新）

详见 `H3_PATH_UI_SESSION_DIAGNOSTICS_GUIDE_ZH.md`。在第2步按钮生成时写入
`[PATH-REQUEST]`、`[PATH-REJECT]`、`[PATH-OK]` 至系统日志；已加载的历史观测结果
同样禁止直接重建新 Plan ID。第3步的 6 个按钮改为两列，RAW 归档和结果表另作说明。


## 历史记录：2026-10-23 多姿态扫描范围与45姿态矩阵修订（已被当前37姿态预设取代）

默认 B=-20..20 每5°、C=-10..10 每5°，共45个姿态；按机床 X+→X− 扫描，默认前后各延伸5mm；按每一姿态的 M3 激光扇面投影进行范围及横向布带补偿，并以 NC 驱动的 M3 仿真检查 6×6 ROI/边界可见性（95% 门槛）。不满足条件禁止发布 NC 和模拟 SCAN。详情见 `README_MULTIPOSE_TILT_COVERAGE_BC45_ZH.md`。这仍是离线研究功能，绝不等同于实机执行许可。
