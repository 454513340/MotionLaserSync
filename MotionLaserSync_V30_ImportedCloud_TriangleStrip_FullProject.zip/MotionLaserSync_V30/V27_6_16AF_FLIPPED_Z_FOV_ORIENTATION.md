# V27.6.16AF — FlipZ-aware physical trapezoid FOV orientation

## Field symptom

In V27.6.16AE the scan optical digital twin correctly clipped the sphere/laser-plane section by a trapezoidal X-Z field and selected the sphere side facing the calibrated five-axis end-effector.  However, the trapezoid widths were still attached directly to the **numerical processed Sensor-Z endpoints** (`Z=70 -> 42 mm`, `Z=120 -> 58 mm`).  The project normally acquires profiles with `PROC_FLIP_DISTANCE / FlipZ=true`; therefore numerical Sensor-Z order is reversed relative to physical optical depth.  The rendered measuring field consequently appeared backwards: the large edge was on the sensor/end-effector side.

## AF correction

AF separates two concepts that must not be mixed:

1. **Physical optical depth**: the small edge is always nearest the sensor/head and the large edge is always farther away.
2. **Reported/calibrated Sensor-Z**: the ordering may be reversed by the saved FlipZ convention.

The path/simulation options now carry `sensorZCoordinateFlipped` and physical widths `sensorXSpanNearMm` / `sensorXSpanFarMm`.  The guarded field computes a physical depth fraction before interpolating width.  With the project's normal `FlipZ=true` convention:

- physical near/small edge -> reported `Sensor-Z = Zmax`;
- physical far/large edge -> reported `Sensor-Z = Zmin`.

With `FlipZ=false` the mapping is the normal order (`near=Zmin`, `far=Zmax`).  The code never infers physical near/far from the sign or magnitude of Sensor-Z alone.

## One geometry for rendering and clipping

`GuardedSensorField` is now the single source of truth for:

- the four trapezoid corners shown in the 3-D optical digital twin;
- the X bounds used to clip the sphere/laser-plane section;
- path-planning optical feasibility;
- offline accumulated synthetic acquisition points;
- the optical gate used before real acquisition/reacquisition.

Consequently the displayed trapezoid cannot be corrected independently while the simulated contour still uses the old reversed field.

The end-effector-side rule from AE remains unchanged: after trapezoid clipping, only points satisfying the calibrated end-effector-facing hemisphere test are eligible for the simulated scan contour.

## Offline coordinate convention source

Offline planning cannot query the disconnected sensor, so AF exposes the FlipX/FlipZ convention saved with the accepted/stage-1 calibration.  `MainWindow` passes the saved FlipZ value into both path generation and scan simulation.  A live sensor processing flag is only a fallback when no saved convention exists.

Study export schema is `SphereDistanceAngleStudy.v11` and records:

- `sensorZCoordinateFlipped`;
- the convention source;
- reported Z min/max;
- the reported-Z location of the physical near and far edges;
- physical near/mid/far X spans;
- the explicit trapezoid orientation rule.

## Regression coverage

`v27616af_flipped_z_fov_orientation_tests` verifies both branches:

- FlipZ=true: small/near edge at reported Zmax, large/far edge at reported Zmin;
- FlipZ=false: small/near edge at reported Zmin, large/far edge at reported Zmax;
- the small edge is geometrically closer to the calibrated end-effector in the constructed test case;
- every simulated visible point remains inside the FlipZ-aware trapezoid and on the end-effector-facing sphere side.

`verify_v27616af_flipped_z_fov_orientation.py` additionally checks the application wiring and export provenance.

## Files changed relative to AE

- `include/calibration/SphereDistanceAngleStudy.h`
- `src/calibration/SphereDistanceAngleStudy.cpp`
- `include/core/DataTypes.h`
- `include/widgets/SingleSphere14CalibrationWidget.h`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `include/app/MainWindow.h`
- `src/app/MainWindow.cpp`
- `tests/v27616af_flipped_z_fov_orientation_tests.cpp`
- `tests/CMakeLists.txt`
- `tools/verify_v27616af_flipped_z_fov_orientation.py`
- cumulative source-contract scripts / README

Machine5X PLY/STL geometry and the field V32.9 BASIC program are unchanged.
