# V29 多姿态：导入 Physical17 / STEP 位姿与连续 NC 的真实数据绑定

## 本次修的是数据链路，不是伪造现场验收

之前 `MultiPoseExperimentQtAdapter` 能使用从实测 SCAN v3 加载的 Physical17，但生成 NC 的 `PartPoseId`、`CalibrationId` 一直是 `UNVERIFIED`，无法检查后来应用到本机 `SyncManager` 的参数是不是同一套数值。现已将“有来源”和“已合格”分开。

## 改动

1. **PartPoseId**：根据 STEP 文件 SHA-256 和当前 CAD→MCS 16 元素矩阵，生成 `POSE_CANDIDATE_SHA256_<hash>`。改变 STEP 内容或位姿，ID 随之改变。`CANDIDATE` 代表粗/人工初始配准，并非已验收配准。
2. **CalibrationId**：根据实测 `.scan` 导入的完整 17 参数 IEEE754 数值，生成 `CAL17_IMPORTED_SHA256_<hash>`。不是“随便写的版本号”，也不能冒充已验收绝对计量标定。
3. **Physical17Sha256**：将同一 17 参数模型摘要写入每份姿态 NC 和 H1/H3 连续 NC；manifest 另外保存源 STEP、源 `.scan` 的文件哈希和原始 17 参数数值快照，方便重新验证。
4. **NC 解析/本机数值一致性**：`GCodeParser` 识别严格 64 位 `Physical17Sha256`。`SyncManager` 只读返回已应用到**软件和硬件采集策略**的 17 参数数值；执行前检查模型数值与 NC 匹配。不再用 `CalibrationId` “只要不等于 UNVERIFIED” 来假定可信。
5. **离线 NC 回放与保存**：继续使用原来的 G05/G93、M50/M51、37 姿态转场、NC 逐段校验、三维光学 ROI 覆盖；代码没有新增未经规划的五轴运动。
6. **首 G00**：保留之前改正的运行时 MPOS→首 G00 实际进场验证。没有回到“导入前必须手动位于起点”的错误假设。

## 现场使用方法

1. 在新版多姿态实验窗口重新加载 STEP 与 **真实** `.scan`，应用并复核 CAD 初始位姿，重新规划 37 姿态。原来已经导出的旧版 NC 不会凭空获得这些内容 ID，**必须重新导出**。
2. 观察规划日志里的 `PartPoseId`、`CalibrationId`、`Physical17Sha256`。生成 H1/H3 NC 和 `multi_pose_experiment_manifest.json`。
3. 在 **确实有同一模型** 的情况下，通过原有标定导入流程将同样的 17 参数应用到当前采集会话的 `SyncManager`。新实机准入报告会比较数值哈希；不一致时必须重新验证/规划，不能只改字符串。
4. 用 Python 3 在导出目录运行：

   ```shell
   python tools/check_multipose_provenance.py --nc MP_ALL_POSES_CONNECTED_OFFLINE_ONLY_H3.nc --manifest multi_pose_experiment_manifest.json --output candidate_audit.json
   ```

   如果源 STEP / `.scan` 路径仍指向同一台机器，还会校验它们的文件哈希。上述工具**不发送任何机床指令**。
5. H3 的配置须区分：参数页选择、`SyncManager` 当前缓存和实际上电气回读；H3 频率/锁存沿必须与 NC 真实一致。此项先前“参数页已改但检查还是 H1/200”的问题已由上一版修正，不能通过篡改 NC 文件头解决。

## 当前仍未被此代码证明的条件

- 粗配准只有初始位姿，**未有独立计量验收**。
- 虚拟激光 ROI 近似和离线控制器解释器不是经过真实机床验证的五轴动态安全/光学测量证据。
- 本机实际控制器的联锁、完整夹具碰撞、现场 H3 电气时序，以及**首 G00 实际进场**需要现场实际验证。
- 新版候选 NC **仍然写入** `OfflineOnly: true`、`RegistrationVerified: false`、`SimulationVerified: false`。只有可信的独立现场发布流程对最终 NC 的具体 SHA-256 完成验收后，才能生成、签署并运行实机任务。单纯把 `OfflineOnly=false` 或把校验回调写死成 `true` 不会生成可靠的运动授权。

## 开发与验证范围

- 本环境离线核心 C++ 构建成功；29 项已执行 CTest 均通过，排除一项原 M6 大型长时测试。
- Python 导入数据指纹静态合同、文件/标定篡改测试通过。
- Linux 环境没有项目 Qt6/VTK 与真实 ZMC/LLT 装置，未执行 Windows GUI 构建及本机运动试验。
- 这次补丁不触碰控制器 BASIC、运行时安全限位，也不设置 `OfflineOnly=false`。
