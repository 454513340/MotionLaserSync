# MotionLaserSync V27.6.52：运行时硬件同步频率 + 控制器上电会话回零状态

本版本只处理两个基础问题：

1. **硬件同步频率不再固定为 200 Hz / 5 ms**。频率由上位机统一设置，并在正式硬件同步启动前写入 ECI3808 的 PWM0；软件中所有与硬件同步周期相关的活动逻辑由频率 `f` 派生 `T=1/f`。
2. **XYZ 回零状态不再只保存在上位机进程内**。ECI3808 BASIC 在控制器 RAM 中维护 XYZ 回零位掩码；上位机异常退出/正常退出后，只要控制器和 BASIC 没有重启，下次连接会读取并验证该状态，不要求重复回零。

> 必须同时部署本版本上位机与 V32.10 BASIC。旧 V32.9 BASIC 不具备运行时 PWM / Home-mask 协议，上位机会按 fail-closed 方式拒绝相关操作。

## 1. 运行时硬件同步频率

### 1.1 上位机设置

“传感器参数”区域新增 **硬件频率** 设置。默认值仍为 200 Hz，但 200 Hz 只是默认值，不再是算法常量。

当前频率范围由两层约束共同决定：

- 控制器协议总范围：`25 .. 2000 Hz`；
- 当前 scanCONTROL Measuring Field 的项目 Quick Reference 最大频率。

当前界面预设对应的保守上限：

| Measuring Field | 索引 | 上限 |
|---|---:|---:|
| Large / 全测量场 | 0 | 144 Hz |
| Standard | 2 | 192 Hz |
| Small | 7 | 552 Hz |
| 快速1 | 32 | 241 Hz |
| 快速2 | 64 | 362 Hz |
| 快速3 | 96 | 552 Hz |
| 高速 | 122 | 2000 Hz |

实际完整 0..127 索引上限仍由 `LaserSensor::getMaxFrequencyForIndex()` 的 Quick Reference 表提供。界面切换 Measuring Field 时会立即重新设置硬件频率上限；如果当前值高于新区域上限，QSpinBox 会自动钳位。

正式硬件同步启动时 `SyncManager` 还会再次 fail-closed 校验，因此 UI 钳位不是唯一安全层。

### 1.2 Exposure / Idle 时序约束

硬件同步不再假定 `5 ms`，而使用精确周期：

```text
T_us = 1,000,000 / hardwareFrequencyHz
```

并要求：

```text
(Exposure + Idle) * 10 us < T_us
```

材料曝光方案在硬件同步模式下也会根据当前硬件频率重新计算 Idle，并保留 10 us 级保护余量。对于 144 Hz 这类周期不是整数个 10 us 的频率，计算使用精确频率后再向下取整并留一个 timing unit 的 guard。

### 1.3 ECI3808 运行时协议

V32.10 BASIC 使用以下 TABLE 单元：

| TABLE | 含义 |
|---:|---|
| 354 | `321052`，V32.10 runtime capability magic |
| 355 | 上位机请求的 PWM0 频率（Hz） |
| 356 | BASIC 已实际应用的 PWM0 频率（Hz） |
| 357 | XYZ 回零状态 bitmask |

BASIC 启动时：

```basic
TABLE(355)=DEFAULT_FREQ
TABLE(356)=DEFAULT_FREQ
PWM_FREQ(0)=DEFAULT_FREQ
```

空闲状态中 `ApplyRuntimeConfig()` 比较 355/356；只有新值合法且当前硬件同步未运行时才执行：

```basic
PWM_FREQ(0)=reqf
TABLE(356)=reqf
```

上位机写 TABLE[355] 后等待 TABLE[356] ACK，只有 ACK 与请求一致才允许继续启动采集。

旧 TABLE header 的 `[9]=5` **仅保留为历史 ABI/schema 标记**，活动运行时算法不再读取它作为 5 ms 周期。

### 1.4 Stop tail

BASIC 原来固定等待约一个 200 Hz 周期的逻辑已改为按当前频率派生：

```basic
stopdelay=1000/TABLE(356)+2
```

上位机的硬件同步 stop/drain 等待、时域补偿周期、时域标定速度估计、CompactScan 名义采样间隔、同步诊断报告也都使用当前运行频率/周期。

## 2. XYZ 回零状态跨上位机进程恢复

### 2.1 控制器 RAM Home mask

`TABLE(357)` 定义：

```text
bit0 = X 已正规回零并建立 MPOS 机床零点
bit1 = Y 已正规回零并建立 MPOS 机床零点
bit2 = Z 已正规回零并建立 MPOS 机床零点
```

XYZ 轴号是 1/2/3，所以位号使用：

```cpp
1 << (axis - AxisX)
```

不能直接使用 `1 << axis`。

### 2.2 安全提交顺序

开始某个 XYZ 轴回零之前：

1. 先清上位机本地 referenced 状态；
2. 关闭依赖该坐标基准的补偿；
3. **先清控制器 TABLE[357] 对应 bit**；
4. 然后才允许 DATUM 开始。

因此如果上位机在回零中途崩溃，控制器不会留下一个错误的“已回零”bit。

只有以下步骤全部成功后才重新置位：

```text
DATUM 成功
→ HOME_STATUS == 1
→ 光栅 MPOS 稳定
→ SetMpos(axis, 0)
→ DPOS/MPOS 零点验证
→ 原软限位恢复成功
→ TABLE[357] 对应 bit = 1
→ 上位机本地 referenced = true
```

### 2.3 上位机重新启动后的恢复

`connectTcp()` 建立控制器句柄后，会在同一生命周期 I/O 事务中读取 TABLE[354..357]。

对 TABLE[357] 中每一个置位的 XYZ：

- 再读 `HOME_STATUS`；
- 再读 MPOS 并检查有限值；
- 验证成功才恢复上位机 `m_linearMposReferenced[axis]`；
- 如果某 bit 已过期/不可信，会自动把控制器 mask 降级为实际验证通过的 mask。

因此：

```text
控制器持续上电 + BASIC持续运行
上位机退出
上位机重新启动
重新连接控制器
=> 已验证的 XYZ 回零状态自动恢复
```

### 2.4 何时自动清零

V32.10 BASIC 启动时执行：

```basic
TABLE(357)=0
```

所以以下情况都会安全地要求重新回零：

- 控制器掉电/重新上电；
- BASIC 被重新下载、停止后重新运行或其它导致程序初始化重新执行的情况。

这是故意的 fail-closed 设计：即使机械本体没有断电，只要控制器的坐标基准会话被重新初始化，就不继续相信旧的增量光栅零点。

B/C 不使用该 bitmask；B/C 继续沿用原有绝对编码器/RS485 机械坐标恢复路径。

## 3. 其它会撤销 XYZ 回零状态的情况

如果上位机修改 XYZ 的 `UNITS` 等会改变坐标解释的关键参数，会先清除对应 TABLE[357] bit，再撤销本地 referenced/补偿状态。这样不会在轴尺度已经变化后继续误用旧零点。

## 4. 部署文件

控制器请使用：

- `controller/ECI3808_5Axis_Controller.bas`（canonical）
- 或同内容的 `controller/ECI3808_V32_10_RUNTIME_PWM_HOME_STATE.bas`

上位机版本：`MotionLaserSync V27.6.52`。

## 5. 验证

新增/扩展回归覆盖：

- 运行时 PWM 请求/ACK，333 Hz 可切换，超出协议上限拒绝；
- 200 / 144 / 2000 Hz 的 Exposure/Idle 周期派生；
- 上位机断开/重连且控制器不重启时，XYZ Home mask 恢复；
- stale Home bit 在重连时被 HOME_STATUS/MPOS 验证并降级；
- 模拟 BASIC/控制器重启后 TABLE[357]=0，重新连接后要求重新回零；
- 回零失败/中止时对应 Home bit 保持清零。
