# V27.6.16R — Sensor Calibration Multi-Sample Capture

Scope: **sensor calibration/debug exposure sweep only**. Formal hardware-sync acquisition, SyncManager, HardwareSyncReport, Acquisition5D, LaserSensor decoding architecture, V32.9 BASIC/TABLE ABI and Physical17 coordinate contract are unchanged.

## Why this revision

V27.6.16Q used a fixed `采样等待` value and then saved only the latest Video frame and latest rich Profile. That had two limitations:

1. the UI value was expressed in 10-us units but the state machine applied a hard minimum 100 ms, so the displayed value did not directly describe the real waiting behavior;
2. one frame/Profile per exposure is too weak for exposure/reflectance/repeatability analysis, and a fixed time delay cannot prove that the sample is a genuinely new frame generated after the new Exposure/Idle setting.

V27.6.16R therefore makes acquisition **frame-driven**, not delay-driven.

## New user controls

The automatic exposure-test area now provides:

- `稳定丢弃`: 0–20 real new frames, default **3**. This is applied separately after starting Video and after starting Profile at every exposure setting.
- `轮廓数据 数量`: 1–200 Profiles per exposure, default **20**.
- `Video图像 数量`: 1–50 Video frames per exposure, default **3**.

The old `采样等待 (×10µs)` control is removed.

At the default 25 Hz, one nominal frame period is 40 ms. Therefore `稳定丢弃=3` corresponds to about 120 ms of real sensor frames before saving starts, without hard-coding a millisecond delay. If the user changes the calibration profile rate, stabilization automatically follows the new frame period.

## Exposure / Idle behavior

The existing timing rule is retained:

```text
cycleUnits = ceil(100000 / requestedRateHz)   // unit = 10 us
Idle       = max(0, cycleUnits - Exposure)
```

Thus at 25 Hz:

```text
Exposure=50  -> Idle=3950
Exposure=100 -> Idle=3900
Exposure=500 -> Idle=3500
```

`Exposure + Idle` remains approximately one 40 ms period. Each Video/Profile mode is configured and then verified by device readback before frame collection starts.

## How new-frame qualification works

### Video

`MainWindow::onVideoFrameReceived()` increments a monotonically increasing `m_videoFrameOrdinal` whenever the application actually receives a new Video frame. The exposure-test state machine records the ordinal at Video start, discards the requested number of subsequent real new frames, and only saves when the ordinal advances again. A cached frame is therefore not counted repeatedly.

### Profile

Sensor-calibration rich Profiles already carry `LaserProfile::callbackOrdinal`. V27.6.16R tracks this ordinal and only counts a Profile when the ordinal advances. The first N real new Profiles are discarded for stabilization; then the requested number of unique rich Profiles is saved.

A watchdog prevents a dead Video/Profile stream from leaving the exposure-test state machine waiting forever.

## Default save quantity per exposure

With both checkboxes enabled and defaults unchanged:

```text
stable discard: 3 Video frames + 3 Profile frames
saved Video:    3 frames
saved Profile:  20 profiles
```

The discarded frames are **not** written to disk.

For one exposure value, V27.6.16R saves:

```text
..._video_f001.png
..._video_f001_raw.csv
..._video_f002.png
..._video_f002_raw.csv
..._video_f003.png
..._video_f003_raw.csv

..._profile_f001.png
..._profile_f001.csv
..._profile_f001_meta.json
...
..._profile_f020.png
..._profile_f020.csv
..._profile_f020_meta.json
```

The experiment directory also contains one shared:

```text
sensor_calibration_session.json
```

## Video sample content

Each `*_video_fNNN.png` is the human-viewable grayscale frame.

Each matching `*_video_fNNN_raw.csv` contains the full `Row,Col,Value` grayscale matrix plus header metadata:

- Capture UTC
- sample index
- Video receive ordinal
- material / lighting / temperature
- full-measuring-field preset (index 0)
- Exposure and auto Idle
- requested Profile Rate
- derived rate from Exposure+Idle
- machine pose: XYZ=DPOS, C/B=software mechanical MPOS
- image width/height

## Rich Profile sample content

Each `*_profile_fNNN.csv` keeps the V27.6.16Q rich point schema:

```text
PointIndex,
X_mm,
Z_mm,
Width,
Maximum,
Threshold,
Moment0,
Moment1
```

Missing LLT auxiliary channels remain empty fields and are explicitly marked by the metadata flags rather than being faked as zero.

Each matching `*_profile_fNNN_meta.json` includes:

- sample index
- Profile index
- sensor open/close/exposure timestamps
- PC callback-entry and decode-done time
- callback ordinal
- raw bytes
- ingress depth
- callback/decode service timing
- ConvertProfile2Values flags
- per-channel availability
- Exposure / Idle / requested/derived rate
- XYZ DPOS + C/B mechanical MPOS

## Session-level information

`MotionLaserSync.SensorCalibrationSession.v3` records once per experiment:

- sensor identity where readable
- resolution
- full-field preset / previous field to restore
- target rate and Exposure sweep
- `samplingMode = frame-driven`
- stable-discard count
- Video/Profile counts per exposure
- material / lighting / temperature
- XYZ DPOS + C/B mechanical MPOS
- readable advanced sensor settings
- valid-reflection Width/Intensity limits as **configured/write-intent** values (not unreliable device readback)
- Reflection Selection and other readable settings
- file naming patterns

## Save-completion barrier

Multi-sample acquisition can queue many background disk writes, especially Video raw CSV files. V27.6.16R tracks every asynchronous save job and does not announce `完成` until the pending-save count reaches zero. Starting a new exposure test is blocked while save jobs from a previous stopped run are still finishing.

## Hardware-sync isolation

The following formal acquisition files remain byte-identical to V27.6.16Q:

- `src/core/SyncManager.cpp`
- `include/core/SyncManager.h`
- `src/core/HardwareSyncReport.cpp`
- `include/core/HardwareSyncReport.h`
- `src/runtime/Acquisition5D.cpp`
- `include/runtime/Acquisition5D.h`
- `src/core/LaserSensor.cpp`
- `include/core/LaserSensor.h`
- `ECI3808_V32_9_SINGLE_OP14_PWM_FULL_MPOS_StopFix_RAMCompact.bas`

Therefore formal HardwareSync remains:

```text
XYZ/C/B TABLE = REGIST(104) hardware-latched MPOS
OP14/PWM0 = 200 Hz continuous trigger
```

and ordinary control/calibration/RTCP remains:

```text
XYZ = DPOS
C/B = software mechanical MPOS
```
