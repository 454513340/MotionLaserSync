# V29 新增：用于 M3/M4 的独立多姿态线激光实验扫描（离线版）

## 1. 与原 M0–M8 的关系

这是 **新增的独立实验工作流**，不是替换原 M0–M8。原 M0–M8 以数字孪生、已有点云覆盖度诊断和自动补扫为主；新工作流把 **同一 CAD 区域（ROI）** 固定下来，针对实验员指定的 C/B 轴角度矩阵逐项扫描。目标是取得在不同姿态下的独立轮廓观测，以支撑 M3 光学仿真和 M4 实测–仿真对照、不同角度下的采集误差与几何可观测性研究。它**不会调用 M5/M6 的覆盖率最大化寻优结果作为实验姿态选择依据**。

这套模块可以复用已有的 STEP 网格加载、原生 SCAN-v3 回放、Physical17 五轴运动学、M3 虚拟轮廓追迹、可选 FCL 安全模型、M6 连续 XYZCB 路径表示及 G05/G93 NC 生成、H1/H3 同步声明、SCAN-v3 压缩保存。**所有生成的机床指令均是离线研究预览，不能直接实机执行。**

## 2. GUI 入口与操作

在主窗口右侧 **`路径规划`** 页面，原 **`数字孪生 / STEP 工件放置…`（M0–M8）** 按钮的上方新增 **`多姿态实验扫描 / 规划、仿真与离线 G代码…`** 按钮。点击后才创建一个独立可滚动的非模态窗口；关闭会隐藏，随后可再次打开并保留输入。主窗口启动不再创建多姿态实验控件。

1. 在 `1 研究数据与工件位置` 导入 `.STEP/.step` CAD；再导入同一零件的 **真实** `.scan`。该 SCAN 的 Profile 必须包含原始五轴关节记录与 Physical17，不接受已标识为 `PoseTiming::Simulated` 的 `.scan` 冒充标定观测。新建完整任务时，建议始终同时保留原始 STEP 和 SCAN 的 SHA256。
2. 录入 CAD 在机床坐标系中的 `X/Y/Z/Rx/Ry/Rz`。本界面也可从已有 M0–M8 `MotionLaserSync.DigitalTwinScene` v1 JSON 读取 `poseEstimate`；它只是**历史位姿初值**。**本次未新增可靠的自动 CAD–实测点云六自由度配准及独立验收模块**，不能把 M0 理想放置、旧 H1 文件位姿直接当作新 H3 工件准确定位。
3. 在 `2 多姿态实验矩阵` 编辑不同实验 `ID, C°, B°`，同一零件、同一 ROI 在所有指定姿态下重复实验。`C/B` 是机器**关节角**，不同于 CAD `Rx/Ry/Rz`。上限 16 个姿态，姿态 ID 必须是 ASCII 字母/数字/`_`/`-`。
4. 在 `3 单姿态轨迹配方` 填 CAD 局部坐标系的 ROI：`Xmin/Xmax/Ymin/Ymax`、参考顶面 Z、扫描方向、扫描速率 `v` (mm/s)、名义轮廓频率 `f` (Hz)、条带间距、光学参考焦点等。这一版针对**受控局部 ROI 的固定参考 Z 栅格实验**，不是自由曲面/孔洞逐点自动跟随轨迹；非平面 CAD 请核查真实激光视场、遮挡、间隙以及夹具碰撞。
5. 点击 **`规划 + 多姿态光学预览`**。后台运行逆运动学 (固定 C/B 下反求 XYZ)、运动学回代一致性、配置存在时的关节/部分 FCL 检查，并在各姿态下独立计算 M3 线激光虚拟轮廓。共享三维窗口可切换全部/某一姿态，分别开关实验 CAD、预扫真实点云、虚拟轮廓、实验扫描路径及非采集转场五种专属图层；**不会覆盖原 M1/M2/M6/M7 图层**。
6. 选择姿态及 H1/H3，点击 **`查看所选姿态 NC（只读）`**，在面板内查看 G05/G93 + M50/M51 指令。点击 **`导出 H1/H3 NC + 清单`**，生成 `MP_P01_OFFLINE_ONLY_H1.nc`、`MP_P01_OFFLINE_ONLY_H3.nc` 等，以及可追溯 JSON 清单；导出的所有程序均包含 `OfflineOnly: true`。
7. 需要仿真点云时再点击 **`输出模拟 SCAN→M3/M4`**；每个姿态导出独立的无损压缩 SCAN-v3，Profile 位姿明确为 `PoseTiming::Simulated`，不存在假冒真实 H1/H3 硬件锁存的时间戳/反馈证明。模拟 SCAN 可用于 M3 算法调试、研究理想观测与实测的误差分析，但**不能替代 M4 的独立真实采集数据**。

## 3. 新工作流的数据契约

| 层次 | 关键输入 | 关键输出与内容 |
|---|---|---|
| 工件与坐标 | STEP，历史或人工 `Pose6`（Rz×Ry×Rx） | `TwinScene` + 明确“registrationVerified=false” |
| 真实参考 | SCAN v3，逐 Profile XYZCB，Physical17，传感器到机床变换 | `ScanReplayData`，重放一致性检查，时间戳异常统计 |
| 实验配方 | `roiCad`，`surfaceZCadMm`，`[{id,C,B}]`，`v/f`，条带间距、视场焦点 | `ExperimentOptions` + `ExperimentPose` |
| 离线五轴规划 | 既有 `SingleSphere17Model` FK，CAD 放置，原 M6 joint bounds，任选 FCL | 每姿态 `ExperimentViewReport.path (t,XYZCB,role)`，`role=Scan/Transfer` |
| 光学仿真 | 每姿态曝光表，STEP 三角模型，M3 光学模型 | 虚拟轮廓、各姿态工件可见帧数、模拟 SCAN-v3 |
| NC / 记录 | 每姿态离线轨迹 + H1/H3 预提案 | G05/G93 五轴指令、M50/M51、H1/H3 元数据、SHA256、`OfflineOnly: true` |

基本采样关系在**匀速固定姿态**下近似为 `Δs = v/f`，例如 `10 mm/s / 200 Hz = 0.05 mm/Profile`。在五轴角度变化、加减速与真实触发时刻存在残差时，最终密度必须由实测锁存位姿与 Profile 时间序列重新计算，不能直接把这个名义值当实际采样间距。

每个视角是独立的 scan-group/记录；不因不同 C/B 获得新覆盖而自动添加/删除姿态。离线仿真不会输出真实硬件曝光证据。

## 4. 两种硬件同步的准确区分

- **H1**：控制器 ECI OP14/PWM 触发，IN0/R0 + `REGIST(104)`；预览 `HardwareTopology: H1`。
- **H3**：传感器自身采样时钟，CMM RS422→IN1/R1，`REGIST(114/115)`；预览 `HardwareTopology: H3`。
- **H2** 已退役，不生成或接受 H2 预览。

同一 XYZCB 轨迹可以导出 H1/H3 两种预览，以便对比**指令合同**；不同硬件拓扑的实时驱动、电气连线、锁存沿和触发间隔必须分别验收。NC 中 `ProgramFrame: MACHINE_JOINTS_XYZCB` 表示关节坐标，不应被 G43.4 当作 RTCP 任务空间 XYZ 再变换。

## 5. 安全与真实性状态

本版**不开放机床执行按钮**；离线生成器不调用控制器、设备运动、传感器采集或实时 SyncManager。原 G-code Executor 的离线程序安全闸门保持有效。

尤其需要现场独立核查：

- CAD 到 MCS 的 **真实六自由度配准**、标定版本、坐标轴方向及装夹基准；本版没有自动验收。
- 原始 SCAN 的历史第一条关节姿态**不是实机当前 MPOS**；自动将两者连成 G00 实机起始轨迹可能危险。
- 来自固定 B/C 数据的 Physical17 重放成功，不意味着大角度 B/C 下的位置、光轴、遮挡误差已得到实验验证。
- 如加载 FCL，检测依赖模型所包含的机器和障碍物，未必包含真实夹具/刀柄/传感器外壳；加速度、jerk、减速段、实时轮廓吞吐量需单独验证。
- 实测 M4 真值应是新的、独立的硬件 H1/H3 SCAN，而不是此工具合成的 `.scan`。

未来若做实机执行，必须新增独立的**配准验收→仿真认证→控制器当前 MPOS 连接及限位碰撞检查→硬件触发时序验收→操作员现场授权**步骤，而不是删除 `OfflineOnly` 注释。不要把此预览 NC 直接上传设备。

## 6. 测试与构建边界

在本次非 Windows 环境中，用现有 CMake `DIGITAL_TWIN_CLI_ONLY=ON` 构建 portable core 和 `twin_multi_pose_experiment_tests`，**24/24 个可构建的离线 CTest 已通过**。新测试覆盖：3 种指定 C/B、各组扫描/激光关闭转场、时间序列、五轴关节规划、M3 简化光学求交、H3 NC 五轴解释器回读，以及错误 ROI、频率、预算和姿态拒绝。附带 `examples/multi_pose_experiment/offline_example` 中 3 组×H1/H3 合成 NC 及位姿表，**仅供解析与接口测试**。

**没有**完成 Windows Qt/VTK 图形界面、Open CASCADE STEP 导入及控制器 SDK 的原生编译；不声称窗口已在真实设备上运行。源代码中的 `MultiPoseExperimentQtAdapter`、`MultiPoseExperimentWidget` 和 `PointCloudWidget` 的 GUI/VTK 改动需要在原 Windows 环境编译与人工交互验证。原仓库引用但未提供的 `sensor_calibration_timing_tests.cpp` 未计入通过的测试。

## 7. 源码入口

- Portable planner：`include/twin/MultiPoseExperiment.h`, `src/twin/MultiPoseExperiment.cpp`
- Qt/real SCAN/Physical17/M3/FCL bridge：`include/twin/MultiPoseExperimentQtAdapter.h`, `src/twin/MultiPoseExperimentQtAdapter.cpp`
- 独立 GUI：`include/widgets/MultiPoseExperimentWidget.h`, `src/widgets/MultiPoseExperimentWidget.cpp`
- 独立视口图层：`include/widgets/PointCloudWidget.h`, `src/widgets/PointCloudWidget.cpp`
- 主窗口注册：`src/app/MainWindow.cpp`, `include/app/MainWindow.h`
- 复用 M6 NC 并加实验编号：`src/twin/TwinM6NcPreview.cpp`, `include/twin/TwinM6NcPreview.h`
- 构建与测试：`CMakeLists.txt`, `tests/twin/twin_multi_pose_experiment_tests.cpp`


## 8. V29 启动闪退修复与 Windows GUI 自检

原多姿态面板初始化时，`buildUi()` 在创建 `m_btnExport`、`m_btnSim`、`m_btnPreviewNc`、`m_summary` 之前调用 `addOrientation()`，后者调用 `invalidate()` 解引用空控件指针，可导致程序在 `MainWindow::createUi()` 尚未完成时立即崩溃。这次修复将默认姿态添加移动到所有控件创建完毕以后，并在 `invalidate()` 中对 UI 指针实施保护。除此以外，主窗口仅在路径规划页面创建启动按钮；多姿态窗口使用按需初始化机制。

在有完整 Qt/VTK/OCCT 和 DLL 的 Windows 开发环境构建后，建议先做 GUI 快速自检。运行：

```powershell
# 用修改后的完整源码重新构建以后，替换为实际输出 exe 路径
powershell -ExecutionPolicy Bypass -File tools/RunGuiSmokeTest.ps1 -ExePath 'D:\your_build\Release\MotionLaserSync.exe'
```

脚本会运行 `MotionLaserSync.exe --smoke-ui`，依次检查主窗口出现、路径规划中的按钮存在、新窗口正常构建并显示约 450ms，然后自动退出；**不连接控制器，不运行扫描**。结果存放 `%TEMP%\MotionLaserSync_gui_smoke.txt`。若依然闪退，先读取该文件最后一条记录定位启动阶段，并提供 Windows 事件查看器中的异常模块信息。Linux `DIGITAL_TWIN_CLI_ONLY` 无法替代本 Windows GUI 自检。
