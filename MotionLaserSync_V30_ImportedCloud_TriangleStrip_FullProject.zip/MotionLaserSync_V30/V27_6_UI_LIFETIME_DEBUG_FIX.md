# V27.6 UI / lifetime / Debug diagnostic fixes

## 1. Right control panel clipping
- Right splitter pane minimum width: 560 px.
- Initial splitter ratio changed from roughly 900/300 to 1100/600.
- Horizontal scroll bars changed from AlwaysOff to AsNeeded on right-side scroll areas.
- Single-sphere UI changed from wide 4/6-column rows to compact two-column/grid rows.
- Long button rows are wrapped into multiple rows.
- Calibration inner tab bar uses scroll buttons and the single-sphere tab label is shortened.

## 2. Single-sphere 17-parameter calibration reuses the main 2D profile view
- Removed the embedded `Profile2DWidget` from `SingleSphere14CalibrationWidget`.
- Entering the single-sphere tab requests MainWindow to select the existing `二维轮廓` tab.
- Starting calibration preview also switches to that main 2D view.
- RANSAC/circle overlays are forwarded to the main `Profile2DWidget` by signals.

## 3. QObject lifetime crash fixed
The Debug exit crash at `disconnect(m_sensor, nullptr, this, nullptr)` was a real use-after-free risk.
`MainWindow` owns `LaserSensor/ZmcController/PointCloudBuilder` as `unique_ptr` members, while the
calibration widgets are QObject children destroyed later by the QMainWindow base destructor.

Fix:
- `SingleSphere14CalibrationWidget` uses `QPointer<>` for externally owned QObject objects.
- Its destructor no longer dereferences/disconnects a raw possibly-dead sender.
- `MainWindow::~MainWindow()` explicitly detaches calibration external references before member destruction.

## 4. VTK orientation marker warning fixed
V27.5 called `InteractiveOff()` before `SetEnabled()`, but VTK explicitly warns that the interactor and
Enabled state must be set before changing interaction.

V27.6 uses:
1. SetInteractor
2. SetEnabled
3. InteractiveOff

and repeats `InteractiveOff()` after later re-enabling the axes widget.

## 5. Qt Debug `qpixmap_win.cpp` assert
The project-side VTK/cursor paths have been reduced:
- QVTK widget uses a standard Arrow cursor.
- Input method is disabled on the pure graphics QVTK widget.
- Orientation marker is passive after enabling.

However, the supplied VS log shows a strong external clue: Sogou IME modules and its `systembeautify` component
are loaded immediately before the QPainter invalid-device warnings and the Qt Debug `QBitmap` assertion.
This is not proof by itself, but it should be tested by exiting Sogou / switching to Microsoft Pinyin or English
before launching the x64-Debug build.

RelWithDebInfo success does not prove the Debug invariant is fixed because Qt assertions are normally disabled
in release-class configurations.
