# V30 G93 first-G05 execution failure — dynamics audit and offline retiming

## Real-machine failure evidenced by the uploaded log

The four-stage site acceptance passed, but at 2026-10-24 16:20:37.748 the
real executor rejected the first G05 S1 motion on original NC line 32.
Earlier G00 reached the target and M50/H3 acquisition had started. This is
not the earlier G00 watchdog failure, nor an H3 missing-frame/physical FCL
collision event.

Original NC SHA256:
`7936e9ab0f21a40c4412deb983122f57f2d2653dfe19b3d328bca78659105478`

First scan displacement X: -0.9994187725 mm. G93 F=300.174469661 gives
60/F = 0.1998837545 s. Existing five-axis SP planner uses 5 mm/s X max
speed, 25 mm/s^2 acceleration/deceleration, and **exact stops at every G93
point**. This requires about 0.3998837376 s per 1 mm step.

The original NC has 8,103 G05 segments (4,088 exposed and 4,015 transfer).
All of them fail the currently implemented per-point zero-to-zero SP timing
requirement at the supplied limits. Ideal point interpolation and profile
timestamps in the old stage 1 did not include acceleration constraints.

## Source code changes

* `src/runtime/FiveAxis.cpp`: report failing segment number, demanded and
  minimum time, joint-space length, speed and acceleration. Do NOT silently
  stretch the NC inside the machine controller, change soft limits or hide errors.
* `src/core/ZmcController.cpp` and `include/core/ZmcController.h`: add a
  scheduler-protected **read-only** snapshot of the configured trajectory
  limits used by `prepareMergePath()`.
* `src/twin/NcG93MotionAudit.cpp` and its header: audit the exact parsed NC
  with the same physical planner as real `prepareMergePath()`. Each G05 group
  is validated separately with the current exact-stop G93 policy. The returned
  error identifies the original NC line, S1/S0 status and minimum time.
* `src/gcode/GCodeExecutor.cpp` and header: the existing read-only stage 1
  checks this NC against the configured machine SP limits, stopping before
  the H3 hardware test and 166-second FCL sweep on an impossible program.
  Execution calls the same guard against the exact disk file again **before
  the first G00** and preserves all prior safety permissions and checks.
* New `nc_g93_retime_candidate_cli`: OPTIONAL, offline-only, produces a NEW
  conservative NC by modifying per-point G93 F only, with 2% extra time and
  full 0-to-0 acceleration allowance. Original XYZCB and M50/M51/S0/S1 are
  preserved; provenance comments explicitly say the output is not authorized.
* New portable unit tests exercise rejection of F300, acceptance of feasible
  timings, unchanged geometry, on-site policy, and the candidate retimer.

## Example conservative NC for this exact uploaded input

File: `MP_G93_CONSERVATIVE_RETIMED_OFFLINE_ONLY.nc`

Original nominal motion: 1212.60 s (~20.2 min).
Conservative candidate: 3288.53 s (~54.8 min).
Points retimed: 8103 / 8103. 37 scanning groups, 166500 *nominal* 100 Hz
profiles in ideal NC replay. It passed the exact same offline G93 physical
SP planner limits. Example first F becomes about 147.10 (0.40788 sec).

**DO NOT LOAD THIS NC AND IMMEDIATELY START THE MACHINE.** The file is
labelled `OfflineOnly: true`. Its source SHA and physical timing changed.
The machine has not run this program: controller jerk/corner modes, following
error, fixture/STEP registration, first G00 travel, H3 timing and practical
scan quality are still **NOT VERIFIED**. Restore an engineer-reviewed NC only
after repeating all four software and on-site checks, inspecting the new scan
speed, and confirming physical controller limits, guarding and an independent
emergency stop. Never increase motion limits merely to make G93 pass.

To use the optional offline CLI (no controller needed):

```
cmake -S MotionLaserSync_V30 -B build_twin -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build_twin --config Release --target nc_g93_retime_candidate_cli
nc_g93_retime_candidate_cli input.nc NEW_OFFLINE_CANDIDATE.nc
```

The CLI uses bundled conservative limits X/Y/Z=5mm/s, C/B=2deg/s,
accel/decel cap=25 units/s^2. The integrated live read-only check uses the
configured controller trajectory limits instead. Differences reject rather
than automatically revising hardware motion. The offline proposal favors
safe feasibility rather than throughput. Real optimized scanning at the
original near-5mm/s requires independently verifying trajectory blending and
changing the NC generator to include acceleration-aware lead-in/lead-out,
not overriding the safety planner.

## Validation / limits

* Portable digital-twin sources compiled; all 34 CTest tests passed in the
  run after adding the new NC audit. The retiming functionality compiled and
  its four directly relevant CTests also passed afterward.
* The controller implementation including the new getter compiled using the
  bundled `p0_core_mock_tests` transport shims. 110/112 older P0 mock assertions
  passed; two legacy stale-home-state tests failed and do not involve modified
  motion/G93 code. The full GUI with actual Windows MSVC/Qt/FCL was NOT built
  in this Linux environment.
* NO motor movement / hardware timing / real-collision field acceptance has
  been conducted here. No usable motion authorizations are embedded.
