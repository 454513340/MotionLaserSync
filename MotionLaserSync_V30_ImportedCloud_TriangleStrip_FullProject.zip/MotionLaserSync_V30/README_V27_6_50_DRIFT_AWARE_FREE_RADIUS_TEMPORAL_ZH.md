# MotionLaserSync V27.6.50 — 漂移感知 + 动态自由有效半径的硬件时域标定

## 1. 本版解决的三个问题

V27.6.50 基于已经可断点续采的 V27.6.49，针对本轮实机数据和 Windows/MSVC 编译结果做三类修复。

### 1.1 修复 V27.6.49 的 MSVC 链接错误

V27.6.49 中以下三个成员函数在头文件中声明并在构造/工作流中调用，但 `.cpp` 中定义意外丢失：

- `HardwareSyncCalibrationWidget::refreshPathTable()`
- `HardwareSyncCalibrationWidget::refreshCaptureTable()`
- `HardwareSyncCalibrationWidget::refreshSpeedSummaryTable()`

因此 Windows 链接阶段产生 LNK2001/LNK1120。V27.6.50 已恢复三个函数的唯一 out-of-class 定义，并加入源码契约检查，防止再次遗漏。

### 1.2 默认实验增加 0.5 mm/s

默认标定速度现在为：

`0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0 mm/s`

每档默认 3 个正反 Pair，因此：

- 10 个速度等级；
- 30 个标定 Pair；
- 60 条标定扫描。

为了降低“实验时间/热漂移”与“速度”的混杂，模板不再按速度单调递增执行，而是默认低/高速度交错，例如：

`0.5, 5.0, 1.0, 4.5, 1.5, 4.0, 2.0, 3.5, 2.5, 3.0`

同一速度的 3 个 Pair 方向顺序默认交替：

- R1：`+ -> -`
- R2：`- -> +`
- R3：`+ -> -`

这不会改变 Pair 的数学定义，只用于减弱单调慢漂移始终以同一符号进入正反差分。

## 2. 为什么动态扫描不再强制使用标准球标称半径

标准球物理半径仍然为已知量，例如直径 19.050 mm：

`R_nominal = 9.525 mm`

但是在机床动态扫描中，点云经过：

- 传感器几何；
- 手眼变换；
- Physical17/机床运动学；
- 多轴实际反馈；
- 激光视场与采样分布；

如果仍存在残余的手眼误差、运动学误差或动态误差，重建得到的“球”可能不是一个严格的 9.525 mm 理想球。若每一趟动态扫描都强制固定 `R=9.525 mm`，这些几何形变可能被错误地转移到球心参数中，从而污染用于求时间偏差的球心差。

因此 V27.6.50 分开处理：

### 静态参考球

参考点云仍以已知物理标准球作为几何锚点：RANSAC 后使用固定物理半径精化参考球心。它主要用于：

- 建立参考位置；
- 防止动态扫描误拟合背景/球座；
- 记录物理尺寸基准。

### 动态正/反扫描

动态扫描改为鲁棒自由球拟合，同时估计：

`C_eff = [Cx, Cy, Cz]`

和：

`R_eff`

这里 `R_eff` 是当前扫描链路下的“有效拟合半径”，允许与 9.525 mm 有系统差异。

时间标定仍使用正反扫描的球心差。对于同一条空间路径、相同 B/C、相同 Sensor 配置，如果正扫和反扫受到近似相同的几何形变，则这部分共同球心偏差会在差分中抵消。

因此新的质量检查重点是：

`|R_eff,+ - R_eff,-|`

而不是：

`|R_eff - R_nominal|`

默认“最大 Pair 有效半径差”为 0.050 mm，可在 UI 调整。

`R_eff - R_nominal` 仍然显示和保存，但仅作为空间模型/动态几何误差诊断，不再直接判定硬件时延标定失败。

注意：正反形变“相同”是实验假设，不是无条件真理。若存在方向相关的反向间隙、伺服滞后、摩擦、采样覆盖差异等，正反形变可能不同；因此 Pair 有效半径差、球面 RMS 和三维 Pair 残差仍保留为质量门限。

## 3. 0.5 mm/s 为什么必须同时处理慢漂移

30 mm 扫描距离下，0.5 mm/s 单方向纯运动时间约为 60 s。正扫和反扫的采集时刻会相隔很长时间。

若球心/机床/传感器结构存在慢热漂移：

`C0(t) = C0 + g t`

则传统 Pair 公式：

`DeltaC = -tau DeltaV`

会把正反扫描之间的慢漂移误认为额外的时间延迟。低速越慢，正反间隔越长，偏置越明显。

V27.6.50 的主求解模型因此改为：

`C_i = C0 + g (t_i - t0) - tau V_i + epsilon_i`

一次联合求解：

- `C0`：三个方向的截距；
- `g=[gx,gy,gz]`：慢漂移速度；
- `tau`：唯一的硬件有效时延。

其中 `t_i` 使用扫描 RAW Profile 的 PC 接收时钟中点，只用于建立“扫描先后时间轴”并估计慢漂移；它绝不被当作 Sensor exposure 与 ECI latch 的绝对时间真值。真正的 `tau` 仍然来自动态几何与硬件锁存实际速度的关系。

如果旧 Session 没有 `captureMidPcUs`，V50 在 RAW `.scan` 存在时会尝试从归档 Profile 时间恢复；无法恢复时则安全回退到旧的正反 Pair 差分模型。

## 4. 求解模型

每条扫描保存实际 REGIST(104) 速度：

`V_i = [Vx, Vy, Vz]`

以及自由有效球心：

`C_i = [Cx, Cy, Cz]`

主模型：

`C_i = b + g t_i - tau V_i`

三个坐标共享同一个 `tau`，分别有自己的位置截距和漂移分量。

程序同时保留一个“不校正慢漂移的 naive Pair tau”，用于诊断：

`tau_naive = - sum(DeltaV_i dot DeltaC_i) / sum(||DeltaV_i||^2)`

UI 会同时显示：

- 漂移联合求解 `tau`；
- naive Pair `tau`；
- `gX/gY/gZ`，单位转换为 um/min；
- 模型 R²；
- 模型 RMS；
- 每速度 Pair 的 drift-corrected `tau_i`；
- 动态有效半径均值；
- 最大正反 Pair 有效半径差。

## 5. Hold-out 验证

XY/XZ/XYZ Hold-out 仍保持 RAW 硬件锁存采集。候选 `tau` 只在离线重建中应用：

`q_corr(k) = q(k) + tau/T * (q(k+1)-q(k))`

再通过现有 Physical17 重建点云。

验证阶段 raw 与 corrected 动态点云同样使用自由有效半径拟合，避免把“半径必须等于标准球”错误地当作时域补偿条件。

若 Hold-out 扫描均有有效扫描中点时间，验证中的 raw equivalent delay 和 corrected residual delay 也会使用慢漂移 nuisance model；否则回退 Pair 模型。

## 6. V49 断点机制保持不变

- 每条成功扫描 RAW 落盘；
- `session_manifest_v49.json` 文件名继续保留，用于兼容已采集的 V49/V48 Session；
- 新 V50 Session ID 使用 `HTRUN50-*`；
- 失败路径只重试/暂停该路径；
- 已成功数据不清空；
- 可读取 V49/V48 Session 结构用于断点/RAW追溯；但 V50 的动态球心语义已经改变，正式 V50 标定建议新建 Session，避免把旧 fixed-radius center 与新 free-effective-radius center 混入同一最终求解。

## 7. 运行时硬件方案没有改变

控制器仍为现场已经确认的：

`OP14/PWM0 -> scanCONTROL external trigger`

同时：

`OP14/PWM0 -> ECI IN0 -> REGIST(104) -> XYZ/C/B MPOS`

控制器 BASIC 未修改。

## 8. 标定 JSON 兼容性

V27.6.50 的最终硬件时域标定 JSON 使用 `schemaVersion=3`。

由于动态球拟合语义和求解模型已经从“固定半径 + Pair-only”改为“动态自由有效半径 + drift-aware”，旧的 V49/V48 `active_hardware_temporal.json` 不会被静默当成新的正式结果启用。

旧 RAW/Session 仍保留用于追溯和对照；由于旧扫描的已保存球心是在旧拟合语义下得到的，正式 V50 结果建议从新 Session 重新采集，或者后续使用专门的 V50 RAW 离线重分析工具后再合并。不要把旧 fixed-radius center 与新 free-effective-radius center 直接混合作为最终生产标定。

## 9. 已执行的离线验证

- V27.6.50 drift-aware/free-effective-radius numerical test：PASS；
- V27.6.47 multi-speed regression：PASS；
- V27.6.44 temporal runtime regression：PASS；
- HardwareSyncReport：22/22 PASS；
- P0 real-core mock/controller/sync：85/85 PASS；
- V27.6.50 source contract：PASS；
- commissioned controller BASIC SHA-256 保持不变。

当前容器没有 Windows x64 Qt6 + VTK + ZMotion SDK + scanCONTROL SDK 完整链接环境，因此最终 Windows GUI Release 链接仍需在现场 Visual Studio 环境执行。V49 截图中的三个 LNK2001 缺失定义已经在源码层恢复并由 source contract 检查。
