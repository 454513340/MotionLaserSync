# V27.6.16D / ECI3808 V32.2 HW-EXEC

## 1. 为什么 V32.1 只读预检通过后，硬件同步仍是灰色

V32.1 的日志 `V32.1 TABLE协议只读预检通过` 只证明 TABLE[330..349] 的协议结构、NoGrating/WithGrating 来源描述、REGIST(104) 元数据以及安全空闲状态与上位机一致。

V32.1 同时保留了两层显式执行锁：

1. UI 将“硬件同步”单选框永久 `setEnabled(false)`；
2. `SyncManager::start()` 在 `SyncMode::Hardware` 时直接返回失败。

此外 V32.1 BASIC 的 `TABLE[342]` 为 0，用作“物理硬件同步执行未授权”标记。因此用户日志中的：

```
hardwareExecutionAuthorization=0
```

不是协议预检失败，而是“协议匹配，但执行仍锁定”。

## 2. V32.2 的解锁范围

V32.2 只解锁 **Profile 面板中的手动“开始采集”硬件同步**，G-code 硬件同步仍保持关闭。

执行采用三重 fail-closed 门控：

- V32.2 HW-EXEC BASIC 启动时发布 `TABLE[342]=1`；
- UI 只有当前控制器 + 当前 B/C 软件机械坐标框架通过只读预检后才允许选择硬件同步；
- 点击“开始采集”后，MainWindow 和 SyncManager 都会再次做实时只读预检，随后 `ZmcController::hwTableSampleStart()` 还会再次检查 `TABLE[342]=1`，然后才允许写 TABLE[334] / TABLE[340]。

扫描期间如果 `TABLE[342]` 被改为 0，BASIC 与 PC 读取链都会 fail closed；BASIC 使用故障码 9 停止输出。

## 3. 硬件同步启动顺序

硬件模式固定使用下降沿，不允许 UI 手工改成其他边沿：

1. 上位机确认 V32.2 TABLE 协议、B/C 软件机械坐标 ready、`TABLE[342]=1`；
2. 传感器配置为 24 V 数字输入、外部下降沿触发，并先启动等待；
3. 等待 50 ms 让传感器进入可触发状态；
4. HardwareSyncStrategy 先开启 Profile ingress；
5. PC 请求新的 TABLE session，BASIC 在 `EN=0` 时 ACK 并清 ring/counter；
6. PC 写 `TABLE[334]=2`；
7. BASIC 先 Arm REGIST，再执行确定性的 `OUT14 ON -> DELAY(1 ms) -> OUT14 OFF`；
8. 同一个下降沿触发传感器和 REGIST(104)；
9. PC 必须看到 **恰好 1 Profile + 1 Pose**，并且 BASIC published/trigger 均为 1；
10. PC 写 `TABLE[334]=1`；BASIC 切换到 200 Hz、2% 硬件 PWM 连续采集；
11. 停止时 PC 先关闭 controller trigger，再等待 BASIC raw FIFO、Buffer-B、TABLE reader 和传感器队列全部收敛；未收敛则整段数据判无效。

## 4. NoGrating / WithGrating

### V32.2 NoGrating

当前未接 XYZ 光栅尺时使用：

- X/Y/Z = BASIC 检测到 C/B 锁存事件后读取的 DPOS 快照；
- C/B = REGIST(104) 锁存的控制器 raw MPOS；
- header: feedbackMask=24, commandMask=7, timing=1, latchMask=24。

因此 NoGrating 不是五轴严格同一硬件时刻锁存，XYZ 的时序语义是 ControllerSequential/Mixed。

### V32.2 WithGrating

XYZ 光栅尺接入并完成 ENCODER_RATIO / 方向标定后使用：

- X/Y/Z/C/B 全部使用 REGIST(104) 硬件锁存 MPOS；
- header: feedbackMask=31, commandMask=0, timing=4, latchMask=31。

## 5. B/C 增量编码器与 RS485 绝对坐标的处理

控制器中的 B/C `MPOS` 是增量编码器坐标，不能直接当作设备机械绝对角。

上位机启动/重同步时：

```
offsetC = C_RS485_absolute - C_controller_raw_MPOS
offsetB = B_RS485_absolute - B_controller_raw_MPOS
```

控制器 MPOS/DPOS 不写入、不清零。上位机机械坐标为：

```
C_machine = C_raw_MPOS + offsetC
B_machine = B_raw_MPOS + offsetB
```

硬件同步开始新 session 时，V32.2 会冻结当时的 `offsetC/offsetB` 到 `m_hwOffsets`；从 TABLE 读出的每条 `[seq,X,Y,Z,Craw,Braw]` 都通过 `decodeRecord()` 转换为：

```
C = Craw + offsetC
B = Braw + offsetB
```

所以硬件同步点云使用的 B/C 与普通 UI/软件同步采用同一个机械绝对坐标框架，而不是直接使用控制器 raw MPOS。

任何一次重新执行 B/C RS485 绝对位置同步都会使此前的硬件同步预检授权失效，必须重新点击“硬件同步只读预检”。

## 6. V32.2 BASIC 协议头

NoGrating：

```
TABLE[330..349]
96,0,0,0,0,0,0,270909,6,5,0,0,1,24,1,24,7,0,14,104
```

WithGrating：

```
96,0,0,0,0,0,0,270909,6,5,0,0,1,31,4,31,0,0,14,104
```

其中 TABLE[342]=1 是 V32.2 HW-EXEC 的显式物理执行授权标记。

## 7. 首次实机测试建议

首次 V32.2 硬件同步只在激光禁止出光或安全测试负载下进行。下载 V32.2 NoGrating BASIC 后：

1. ZDevelop 读取 `?*TABLE(330,20)`，确认 NoGrating 头和 `TABLE342=1`；
2. 上位机完成 B/C RS485 绝对坐标建立；
3. 点击“硬件同步只读预检”，日志应显示 `hardwareExecutionAuthorization=1`；
4. 硬件同步单选框应可选择；
5. 选择硬件同步，点击“开始采集”；
6. 日志应先出现启动前复核通过、冻结 C/B offset、单脉冲 Probe 对齐通过，再切 200 Hz；
7. 短时间采集后停止，检查 Trigger/Pose/Profile/Aligned 数量和尾部收敛结果。
