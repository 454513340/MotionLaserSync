# 2026-10-23 完整源码包遗漏文件恢复审计

此版本以 `MotionLaserSync_V29_多姿态_G代码驱动数字孪生_完整源码_仅离线.zip` 为基底，**仅恢复上一版中被误漏的五个文件，并修正 README 关于 SDK 的误导描述**，不改变任何 C++/BASIC/NC 逻辑。

- 前一版动态仿真完整源码：814 个文件 / 9,980,982 字节 ZIP。
- 最近一次 NC 驱动仿真交付：824 个文件 / 6,159,652 字节 ZIP。
- 两版共有 800 个相同文件；修改 9 个；新增 15 个；意外缺失 5 个。
- 五个缺失文件未压缩总大小：9,037,765 字节。
- 修复版保留 NC 解析/仿真新源码，补回这五个文件；`OfflineOnly` 闸门及实机控制逻辑不变。

| 补回路径 | 原始字节数 | SHA-256（来自上一版） |
|---|---:|---|
| `examples/digital_twin/6061_reference_mesh.obj` | 185,855 | `b43fb6c51c26c745c1a25c5b43a8ee745810f6b087398967dbbcce201b2e4da4` |
| `examples/digital_twin/6061_sensor_connector_NEW_2026.obj` | 371,142 | `8f88d3ce1967b2d1095b6a17d97129df317a6e1e8c63de7ddd1f9f6107ede9fe` |
| `third_party/scanCONTROL/bin/x64/LLT.dll` | 3,556,352 | `2f65313b8a277cedc6cfeb91bcc92b8d22fa449f29760c0e868453e101f8d551` |
| `third_party/zmc/bin/x64/zauxdll.dll` | 2,314,240 | `cbdb7c313e9ae52a1e4c2f94c75b4873c494daf4802ceb10159f3c9adeceb513` |
| `third_party/zmc/bin/x64/zmotion.dll` | 2,610,176 | `b506a9b8d46601e56074e7b0629c1000ae47e6eb1210688821f84ae46c23b8fd` |

> 这些 DLL 是原有交付包中的 Windows 动态库，不是本次新开发的替代 SDK。需现场核对版本及供应商许可。缺失测试 OBJ 会影响部分数字孪生和 CMake 测试。完整源码静态完整性 != Windows GUI 编译/启动通过 != 硬件安全验收通过。
