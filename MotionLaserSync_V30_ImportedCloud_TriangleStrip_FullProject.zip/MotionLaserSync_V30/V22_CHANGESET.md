# V22_CHANGESET — Physical17 RTCP + ECI3808 Hardware Latch

V22 在 V21 完整工程上继续修改，主要解决两个问题：扫描轨迹需要 RTCP；采集位姿需要真正利用 ECI3808 的位置锁存，同时彻底去掉 C/B DPOS 依赖。

## 新增

- `include/runtime/Rtcp17.h`
- `src/runtime/Rtcp17.cpp`
- `tests/v22_rtcp_tests.cpp`
- `tools/v22_rtcp_latch_sim.cpp`
- `tools/verify_v22.py`
- `examples/v22_rtcp_line_scan.nc`
- `examples/v22_rtcp_orientation_hold.nc`
- `docs/V22_RTCP_HardwareLatch_Review.md`
- `verification/v22_rtcp_latch/*`

## RTCP

- 使用与标定/点云相同的 Physical17 前向模型。
- 给定 C/B 时精确反解 X/Y/Z，逆解后正解自检。
- 支持可配置的传感器坐标系受控点。
- 任务空间线段按 Physical17 弦误差、C/B 步长、XYZ 步长自适应细分。
- G43.4 开启 RTCP，G49 关闭；G92 在 RTCP 中定义局部任务坐标锚点。
- 单球绝对平移 gauge 未锁定时，绝对 RTCP XYZ 必须由外部基准或 G92 锚定。
- G00/G01/G02/G03/G05 在 RTCP 模式下生成任务空间轨迹，然后转换成五轴 SP 关节段。
- 继续使用 ECI3808 `MoveAbsSp` 作为底层执行层，并保留每轴速度/加速度/减速度/软件限位检查。

## 硬件锁存采集

- BASIC 改为 ECI3808 IN0/Latch A + REGIST/REG_POS。
- 默认 `REGIST(4)`，对应官方脉冲轴示例中的 R0 24V→0V 锁存；实机必须确认实际有效边沿。
- 推荐 OUT14 高速 NPN 输出的同一实际电气沿同时触发传感器和 IN0。
- 每个采样周期先对 X/Y/Z/C/B 分别执行同一 REGIST，再触发 OUT14，等待五个 MARK，最后读取五个 REG_POS。
- TABLE 记录从 8 字段缩为 6 字段：`ordinal + REG_POS(X,Y,Z,C,B)`。
- 删除 BASIC 中 C/B DPOS 读取与传输。
- 协议 magic/元数据更新为 V22 hardware-latched schema。

## 上位机 C/B 位置语义

- 扫描、GCode 起点、RTCP、完成判定均用 XYZ DPOS + C/B MPOS。
- 实际 SDK 路径不再调用 `GetDpos(C)` / `GetDpos(B)`。
- 历史结构中的 `dpos.c/dpos.b` 仅为 MPOS 兼容别名，避免旧 UI 大规模 ABI 破坏。
- 归档增加 latchMask / commandMask / feedbackMask，能够区分五轴同沿与位置来源。

## 仿真与测试

- RTCP 直线最大采样误差：约 `7.324e-05 mm`；对应关节直线对照误差约 `17.987 mm`。
- 纯 C/B 变化且 TCP 固定：RTCP 最大漂移约 `7.325e-05 mm`；无补偿约 `66.317 mm`。
- 六字段 TABLE binary32 量化传播到 TCP 约 `1.734e-06 mm`。
- CTest：21/21。
- V22 source/latch/RTCP contracts：26/26。
- ASan/UBSan 选定可移植目标通过。

## 尚未宣称完成

- 尚未在目标 ZDevelop/RTSys 原生编译 BASIC。
- 尚未使用真实 ECI3808、OUT14/IN0 和 scanCONTROL 测量电气边沿、传播延迟、曝光延迟。
- 尚未完成 Windows Qt/VTK 全 GUI 最终链接/实机验收。
- 当前 RTCP 是 Physical17 软件 RTCP + ECI 五轴 SP 执行，不是依赖控制器内建某个固定机械手 FRAME 的 RTCP。
- 当前密集折线不是 NURBS/jerk-optimal 轨迹，后续轨迹研究可以继续替换上层任务规划器。
