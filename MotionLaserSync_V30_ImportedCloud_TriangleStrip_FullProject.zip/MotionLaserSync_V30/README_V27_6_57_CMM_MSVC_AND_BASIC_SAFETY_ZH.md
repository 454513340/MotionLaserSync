# V27.6.57 / ECI BASIC V32.15 修订说明（V27.6.56 的小范围修复）

## 唯一有效版本组合

- 上位机源码：MotionLaserSync V27.6.57（以用户先前收到的 V27.6.56 完整工程为基底）。
- 控制器正式下发文件：`controller/ECI3808_5Axis_Controller.bas`，内容与 `controller/ECI3808_V32_15_THREE_HARDWARE_TOPOLOGIES.bas` 完全一致。
- 运行时 capability `TABLE[354]=321057`；STOP-tail marker `TABLE[362]=1316`。
- 历史 V32.13 / V32.14 BASIC 原文件保留供对照，不得与新上位机混搭。
- BAS 下载/启动将重设 `TABLE[357]`，XYZCB 需重新确认回零/绝对机械坐标就绪。

## 1. Windows MSVC C2440 修复

发生于 `src/core/LaserSensor.cpp` 旧第 1686 行：

```cpp
// 错误：此版本厂商 C++ SDK 的函数返回 void，而不是 int
cmmRc = localLlt->Timestamp2CmmTriggerAndInCounter(...);
```

现在改为：

```cpp
localLlt->Timestamp2CmmTriggerAndInCounter(
    ts, &cmmEdgeCount, &cmmTrig, &cmmActive, &cmmCount);
cmmTimestampDecoded = true;
```

仅当获取完整时间戳，且本次 CMM 配置已启用，才将 `profile.cmmValid` 标为 `true`。**该标志代表“调用了解析器”，不能假设 SDK 提供了解析错误码。** 上位机在硬件 H2/H3 模式下另外要求 CMM `active` 标志；物理 IN1 边沿必须仍用示波器和实机五轴锁存验证。

同时在真实 `LaserSensor.cpp` 增加 SDK C++ 返回类型 `static_assert`，防止后续错误地把 `void` 当 `int`。未改任何厂商 DLL、LIB 和头文件，也未改 `CMakeLists.txt` / 原始资源路径。

## 2. V32.15 BASIC 变更

保留 H1=1 / H2=2 / H3=3 及原始位姿 FIFO / Buffer-B，保留 `REG_INPUTS=16,16,16,16,16` 和 `REGIST(he, ..., 129)` 五轴共享锁存：

- H1：`he=104`，同一 OP14 PWM 分叉至传感器触发和 ECI IN0；
- H2：`he=114` 或 `115`，OP14 PWM 触发传感器，scanCONTROL CMM→RS422-NPN→ECI IN1 锁存；
- H3：`he=114` 或 `115`，传感器内部时钟+CMM→ECI IN1，ECI 不产生扫描节拍。

新增三个 fail-closed 条件：

1. 只有 `gm=0` 或原本 `gm=3` 才能接收 `en=3` ColdPrime；禁止正式 Run/Probe 跳到 ColdPrime；
2. `en=1` 只能在 `gm=1/2` 状态使用，且首次 Probe→Run 前 H1/H2 必须已有**恰好 1**个五轴锁存，H3 必须至少 **8** 个。这防止直接 EN=1 跳过上位机 Probe，但不能取代上位机 Profile/CMM/pose 验证；
3. H3 停止，在初次 48ms raw FIFO drain 后，再等待至少约两帧的时间窗口，检查 ECI 锁存 head 是否仍增长。若增长，`TABLE[333]=13` 并 RAPIDSTOP/标记 tail 失败，拒绝错误地报告 `TABLE[363]=2`。

新增 Session 清理 `TABLE[364]=0`，防止旧 raw-head 诊断残留。

**必须注意**：H3 的静止窗口只是异常停机防护，不构成对 CMM 输出硬件已关闭的形式证明。正常路径仍应先由上位机 `StopTransmissionAndCmmTrigger()` 关闭 CMM，再让 BASIC 停止/排空；传感器、转换器、IN1 的电气边沿都需要实测。

## 3. 程序空间与构建限制

BASIC 源码文本长度由 V32.14 的约 5.9 KB 增加到约 6.4 KB，**文本大小不等于 ECI 的编译后程序大小**。本环境没有正运动 ZDevelop 编译器，无法确认实际 4 KB 程序空间是否满足要求，**在 ZDevelop 编译并查看内存占用前，不允许将本版视为现场合格版本**。若超限，应压缩 BASIC 控制流或让上位机承担更多验证，不应移除安全检查。

本环境不提供 Windows + MSVC/Qt/VTK 和实机 ECI3808/scanCONTROL 的完整 GUI 编译、DLL 实际运行、PWM 电气验证。用户应在 Windows 使用一个全新的 build 目录做 CMake Configure+Release 全编译。

## 4. 测试结果

- Windows SDK 函数签名：使用**原厂 `InterfaceLLT_2.h`** 和简化 Windows 类型桩，在 Linux `g++ -fsyntax-only` 验证 CMM 解码返回 `void`；但这不是 GUI 编译。
- C++ portable unit: **31/31 PASS**。
- 真实 ZmcController / SyncManager 与 Mock ZAux 联合测试：**108/111 PASS**。原 V27.6.56 报告亦为 108/111；3 项失败涉及 HOME/补偿状态恢复，不属于本次修改，但尚未解决。
- `tools/verify_v27657_llt_basic_contract.py`：静态 ABI / BASIC / 资源一致性检查通过。该测试不能替代 BASIC 编译或硬件验证。

## 5. 现场验收建议

1. 对当前可用版本及 Controller BASIC 做离线备份。检查所有五轴处于安全状态，先用 ZDevelop 编译并核对 V32.15 **实际程序空间 ≤ 4 KB**；若超限不要下载。
2. 下载 V32.15、连接 V27.6.57，核对 321057 / 1316，按现场 SOP 重建 XYZCB Home / B-C absolute-ready。
3. 分别测试 H1、H2、H3：200 Hz、低速无运动的 1:1 Profile/CMM/REGIST 计数；使用示波器确定 IN1 有效边沿和转换器延迟。
4. 测试中断窗口：未通过 Probe 时直接 EN=1 应锁定故障；运行时切 ColdPrime 应拒绝；H3 CMM 仍输出却只让 ECI 停止，应触发 tail 故障而非成功。
5. 低频、中频与不同 Measuring Field 的最大频率需独立验证；不得仅因传感器支持最高 2000 Hz 就认定 ECI FIFO / 网络读取链已通过。
