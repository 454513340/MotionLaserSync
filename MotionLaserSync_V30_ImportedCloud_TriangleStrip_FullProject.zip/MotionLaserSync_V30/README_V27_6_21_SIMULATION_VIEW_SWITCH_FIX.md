# V27.6.21 — 运动学标定仿真视图切换修复

基于 `V27.6.20 OFFLINE_KINEMATIC_PLANNING`。

## 问题

阶段2运动学标定姿态仿真在每个播放帧中都会更新二维预测圆弧。旧实现把“更新二维 overlay”和“切换到二维轮廓页”耦合：

- `showStage2SimulationPose()` 每帧发出 `requestProfileView()`；
- `MainWindow` 在收到 `singleSphereProfileOverlayRequested` 时也再次强制 `setCurrentWidget(m_profile2DView)`。

因此操作者即使手动切到“三维点云”，下一仿真帧也会把界面抢回“二维轮廓”。三维数字孪生实际仍在更新，只是无法持续观察。

## 修正

1. 二维 overlay 更新只负责数据更新，不再改变当前主视图 Tab。
2. 运动学标定仿真每帧不再发出 `requestProfileView()`。
3. 新增一次性的 `requestStage2SimulationView()`：仅在开始阶段2姿态仿真时自动切到“三维点云”。
4. 播放过程中二维轮廓和三维数字孪生继续同步更新，但用户可自由在：
   - 三维点云
   - 二维轮廓
   - 轮廓图像
   - 传感预览
   之间切换，后续仿真帧不会改变当前选择。
5. 主动执行“轮廓预览/当前轮廓球拟合”等原有操作时，仍保留显式 `requestProfileView()`，因此原来的二维工作流不受影响。

## 修改文件

- `include/widgets/SingleSphere14CalibrationWidget.h`
- `include/widgets/CalibrationWidget.h`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `src/widgets/CalibrationWidget.cpp`
- `src/app/MainWindow.cpp`

## 验证

已完成静态 UI 回归检查：

- 阶段2每帧函数继续发送二维 overlay；
- 阶段2每帧函数不再发送 `requestProfileView()`；
- overlay 的 MainWindow 接收槽不再调用 `setCurrentWidget()`；
- 开始阶段2仿真只发送一次三维视图请求；
- MainWindow 的三维视图请求只在启动时切到 `m_pointCloudView`。

同时 `SINGLE_SPHERE17_CLI_ONLY=ON` 在当前 Linux 环境 Release 编译通过，确认 Physical17 共享数值代码未受本次 GUI 修改影响。

完整 Qt/VTK GUI 需要在项目原有 Windows + VS2022 + Qt6 + VTK 环境重新生成验证。当前 Linux 环境缺少 Qt Widgets 开发头文件，因此未声称完成 Windows GUI 全量编译。

## 建议测试步骤

1. 离线加载阶段1/17参数；
2. 导入球点云并 RANSAC 求球心；
3. 生成阶段2 D-optimal 姿态；
4. 点击“仿真运行标定姿态”；
5. 确认程序自动进入“三维点云”；
6. 播放中手动切到“二维轮廓”，确认圆弧仍刷新；
7. 再手动切回“三维点云”，确认不会被下一帧抢回二维；
8. 检查数字孪生、激光梯形 FOV、理论截圆、有效圆弧和累计仿真点云持续更新。
