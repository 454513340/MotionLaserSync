# 历史版本 — V32.14 已由 V32.15 替代，禁止与 V27.6.57 上位机混用

# V32.14 BASIC 现场候选入口

唯一候选下发文件：`controller/ECI3808_5Axis_Controller.bas`。

此文件与同目录及根目录的 `ECI3808_V32_14_THREE_HARDWARE_TOPOLOGIES.bas` 逐字节相同。不要下载历史 V32.13。

现场必须使用 ZDevelop 验证 BASIC 编译后空间 ≤4KB、下载与回零流程，详情 `README_V27_6_56_H123_CMM_ZH.md`。
