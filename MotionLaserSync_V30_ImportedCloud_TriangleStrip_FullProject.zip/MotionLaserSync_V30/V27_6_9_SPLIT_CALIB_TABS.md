# V27.6.9 — 将单球17参数流程拆分到“初步手眼标定 / 运动学标定”两个Tab

本版本按标定物理含义重新组织系统标定UI，不改变两阶段数学模型。

## Tab顺序
1. 初步手眼标定
2. 运动学标定
3. 测量不确定度

原来的“手眼标定（Tsai-Lenz/Park/Horaud/Daniilidis/点云配准）”UI已移除。
原来的“运动学标定（指令XYZ/测量XYZ补偿表）”UI已移除。
原来的独立“单球17参(rank14)”Tab已移除。

## 初步手眼标定Tab
迁入原单球阶段1的完整内容：
- 坐标/Flip/DPOS-MPOS数据源锁定
- 2950轮廓预览和RANSAC球拟合
- XYZ/C/B人工小步找球
- fresh profile静态采集
- 人工多姿态数据集
- 名义机床模型下手眼6DoF + 固定球心3D，rank 9/9求解
- 阶段1失败诊断

## 运动学标定Tab
迁入原单球阶段2和阶段3：
- 基于阶段1手眼+球心的D-optimal规划
- 分段五轴运动 / XYZ闭环找球
- 阶段2训练集静态采集
- Physical17完整17参数 / 数据秩14联合求解
- 保存/加载结果与训练会话
- 独立hold-out验证姿态生成、验证采集、冻结模型验证

两个Tab背后仍由同一个 `SingleSphere14CalibrationWidget` 状态机对象管理。
因此阶段1求得的手眼和机床球心直接进入阶段2内存状态，不需要中间导出/导入，也不会产生两份互相不一致的数据。

阶段1成功后软件自动切换到“运动学标定”Tab。若阶段1尚未通过，运动学Tab顶部会明确显示锁定原因。

保持 Release-only；未改动 ECI3808 / PWM / REGIST / TABLE / RTCP。

## MSVC 编译修复（本修订包）

本修订只处理 V27.6.9 拆页后暴露出的两个 C++/Qt 编译问题，不改变标定数学、运动控制或Tab业务逻辑：

- `src/widgets/CalibrationWidget.cpp` 显式加入 `#include <QGroupBox>`，修复 MSVC `C2061`，并连带消除 `paramGroup/paramLayout/dataGroup/dataLayout` 的 `C3536` 级联错误。
- `src/widgets/SingleSphere14CalibrationWidget.cpp` 将同一 `setupUi()` 作用域中重复声明的 `actionGrid` 分别改名为 `stage1ActionGrid` / `stage2ActionGrid`，修复 `C2086/C2374/C2371`。
- 重新检查外层Tab顺序仍为：`初步手眼标定 -> 运动学标定 -> 测量不确定度`；阶段1和阶段2/验证仍由同一个 `SingleSphere14CalibrationWidget` 状态对象管理。
