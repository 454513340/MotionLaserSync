# V27.6.39：Stage2 数据自举手眼 + Physical17 Rank-14

## 目标

阶段2最终求解不再把“是否存在历史 Stage1 JSON”作为数值求解的硬前提。对于当前采集或直接导入的 **Stage2-only** 训练数据，软件先按阶段1同类的名义机床模型求一次 hand-eye 6DoF 与固定球心，再把这组结果作为 Physical17 的初值。

核心原则是：

- 11 项机床几何误差在自举阶段固定为名义值 0；
- 自举阶段只求 hand-eye `rx, ry, rz, tx, ty, tz` 与机床坐标固定球心 `Cx, Cy, Cz`，共 9 状态；
- 自举得到的 hand-eye 6DoF 进入 Physical17 初值；
- `handeye_tx/ty/tz` 在 Physical17 中作为 **3-D translation gauge anchor** 等式固定；
- Physical17 实际优化 11 项机床几何误差 + hand-eye 3 个旋转，即 14 个可辨识物理自由度；
- 球心 3D 仍作为 nuisance state 一起参与残差优化；
- 自举和 Physical17 使用同一训练集，因此它们不构成独立验证，最终仍必须做 hold-out。

## 新的最终求解链

```text
Stage2 训练数据（在线采集或 Stage2-only CSV）
        |
        v
名义机床 9-state bootstrap
  geometry11 = 0
  求 hand-eye 6DoF + sphere center 3D
        |
        +--> R_HE0
        +--> t_HE0 = [Tx0, Ty0, Tz0]
        +--> C0
        |
        v
构造 Physical17 初值
  geometry11 = 0
  hand-eye = bootstrap 6DoF
  sphere center = C0
        |
        v
Physical17 / rank-14
  固定 Tx=Tx0, Ty=Ty0, Tz=Tz0
  优化 geometry11 + hand-eye rotation3
        |
        v
代表集求解 -> 全 Stage2 数据精修
        |
        v
独立 hold-out validation
```

## 关键代码

### 1. 复用阶段1型 9 状态求解器

`SingleSphere17Calibrator` 新增：

```cpp
NominalHandEyeSphereResult solveNominalHandEyeBootstrap() const;
```

它把当前 calibrator 内部的 Stage2 observations 送入已有的 `NominalHandEyeSphereCalibrator`。因此 GUI、CLI 与后续离线工具可以复用同一套数据自举逻辑。

### 2. GUI Stage2 最终求解

`SingleSphere14CalibrationWidget::onSolve()` 现在先从每个不同 Stage2 姿态抽取 1 个代表 profile（每 profile 最多 180 点），用这一组覆盖全部姿态的自举集求 9 状态：

```cpp
auto bootstrapObservations = reducedStage2Observations(1, 180);
SingleSphere17Calibrator bootstrapCalibrator(options);
for (const auto& o : bootstrapObservations)
    bootstrapCalibrator.addObservation(o);

task.bootstrap = bootstrapCalibrator.solveNominalHandEyeBootstrap();
const auto initial = task.bootstrap.parameters;
const Vec3d initialCenter = task.bootstrap.sphereCenterMachineMm;

SingleSphere17Result result =
    reducedCalibrator.solve(initial, &initialCenter, ...);
```

这样手眼自举仍覆盖所有 Stage2 姿态，但计算量接近阶段1，不需要把几十万原始点在 13 个初始旋转分支上重复做 9 状态数值 Jacobian。

随后全量精修从代表集 Physical17 结果继续：

```cpp
result = fullCalibrator.solve(
    result.parameters,
    &result.sphereCenterMachineMm,
    ...);
```

底层 `SingleSphere17Calibrator::solve()` 的可优化索引本来就排除了 `HandEyeTx/Ty/Tz`，因此这三个平移分量从自举开始到代表集求解、全量精修都保持严格固定。

### 3. 直接导入 CSV

如果没有 Stage1 JSON，但已经导入 Stage2-only CSV，并且至少满足 8 个不同姿态、8 profiles、80 个有效点，则“阶段2最终求解”会直接解锁。

注意：旧 V27.6.10A 的 CSV 可能把 Stage1 与 Stage2 profiles 混在一个文件中，而旧 CSV 本身没有 stage flag。此类历史混合文件仍应先加载对应 Stage1 JSON，用记录的 Stage1 姿态把 Stage1 profiles 剔除；或者先转换为 Stage2-only CSV。

### 4. 结果 JSON 可追溯性

新结果可包含：

```json
"initialization_bootstrap": {
  "source": "stage2_training_data_nominal_machine_handeye",
  "state_rank": 9,
  "residual_rms_mm": 0.0,
  "condition_number": 0.0,
  "hand_eye": {
    "rx_rad": 0.0,
    "ry_rad": 0.0,
    "rz_rad": 0.0,
    "tx_mm": 0.0,
    "ty_mm": 0.0,
    "tz_mm": 0.0
  },
  "sphere_center_machine_mm": [0.0, 0.0, 0.0]
}
```

这里保存的是实际进入 Physical17 的自举来源，而不是重新从最终结果反推。旧 JSON 不含该字段时仍可按旧格式读取。

## CLI

`single_sphere17_cli calibrate` 默认启用当前输入 CSV 的自举：

```text
single_sphere17_cli calibrate stage2.csv result.json
```

如果明确要复现实验性的旧行为，可使用 `--no-auto-handeye-bootstrap`；如果提供 `--initial` / `--handeye-translation` / `--sphere-center`，则按人工 seed 路径执行。显式 `--auto-handeye-bootstrap` 与人工 seed 同时给出会报错，避免命令行顺序产生歧义。

## 在线流程与安全边界

“最终数值求解不依赖 Stage1 JSON”不等于“实机运动不需要 Stage1”。在线 D-optimal 姿态规划、真实移动、采集、扫描/RTCP 仍需要可核对的 FlipX/FlipZ、XYZCB DPOS/MPOS 来源以及设备安全门禁。Stage1/持久化标定仍承担这些坐标约定和在线导航职责。

## 验证

本版新增回归用例 `testStage2DataSelfBootstrapAnchorsTranslation()`，验证：

1. Stage2 数据自身可以达到 nominal bootstrap rank 9/9；
2. bootstrap 结果能直接驱动 Physical17；
3. Physical17 的 `Tx/Ty/Tz` 与 bootstrap 值逐位保持；
4. noiseless synthetic data 的 rank 仍为 14/17、完整状态 rank 为 17/20；
5. JSON 会写入 `initialization_bootstrap` provenance。

另保留 V27.6.38 的 Stage2 工作流源代码契约测试。
