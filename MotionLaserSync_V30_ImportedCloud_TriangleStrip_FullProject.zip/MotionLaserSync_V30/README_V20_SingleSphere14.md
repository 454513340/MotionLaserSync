# V20 单球 14 维联合标定扩展

本分支在 V19 基础上增加了一个不依赖 Qt/VTK/厂商 SDK 的便携标定核心，用于：

- 直径 19.05 mm 的单个固定标准球；
- 末端安装 LLT2950-50/BL；
- XYZ-C-B 多姿态静态轮廓；
- 14 个由数据唯一支持的规范化联合参数；
- D-optimal 姿态选择；
- 单轮廓球心拟合与小步 XYZ 闭环重居中；
- Schur 补后的 14/14 可观测性检查。

## 重要边界

在没有独立三维平移基准时，传统的 `11 PIGE + 6DoF hand-eye` 不能被唯一拆成 17 个
物理量。本扩展固定手眼平移规范，输出：

- 7 个机床角度型 PIGE；
- 4 个有效旋转轴位置项；
- 3 个手眼旋转项。

这些参数可以直接建立随 XYZCB 变化的传感器点复合变换，但四个有效位置项不能被当作
传统物理位置 PIGE 单独解释。

详细方法见：`docs/V20_SingleSphere14_Calibration.md`。

## 快速构建

```bash
cmake -S . -B build-ss14 -DSINGLE_SPHERE14_CLI_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-ss14 --config Release
```

## 生成姿态计划

```bash
single_sphere14_cli plan pose_plan.csv \
  --reference X0,Y0,Z0,0,0 \
  --sphere-center-s 0,3.81,95 \
  --diameter 19.05 --count 42 \
  --b-range "-50,50,15" --c-range "-70,70,20" \
  --xyz-limits "Xmin,Xmax,Ymin,Ymax,Zmin,Zmax"
```

## 标定

```bash
single_sphere14_cli calibrate captured_profiles.csv result.json \
  --diameter 19.05 --center-y-sign 1
```

输入 CSV：

```text
profile_id,x_mm,y_mm,z_mm,c_deg,b_deg,sensor_x_mm,sensor_z_mm,weight
```

## 测试

```bash
cmake -S . -B build-tests -DV19_TESTS_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

规划器给出的 XYZ 只用于找球初值，不能未经碰撞、限位和闭环检查直接发送给真实机床。

## V20.1 实机轮廓提取

GUI 版本不再把 ROI 内全部点直接拟合圆。现在使用已知 19.05 mm 球约束的圆 RANSAC，
随后对内点做几何圆精修，并检查内点比例、圆弧覆盖角和 RMS。只有 RANSAC 内点进入求解器。
单球标定预览固定为 `SoftwareInternal` + `Large/ROI1_PRESET=0` 全量程，且该量程切换不写入用户模式。
