# V27 Change Set — PWM + Five-Latch Double Buffer

## Controller BASIC

- XYZ remains `ATYPE=1` for current commissioning; C/B remains `ATYPE=4`.
- All five axes are armed with continuous `REGIST(104, table, 129)` on the same R0/IN0 event.
- OUT14/PWM0 is disabled at idle. PC `enable=2` starts a 20 Hz probe after all five latch FIFOs are armed; after one latch BASIC stops PWM. PC `enable=1` switches to 200 Hz.
- No timer interrupt is used.
- Two controller buffers are used:
  - raw latch FIFO: 128 samples per axis;
  - host-facing ring: 96 interleaved records `[ordinal,X,Y,Z,C,B]`.
- Host-facing ring still uses V22 header field positions 330..349. New magic is `270909`, capacity is 96, data begins at 370.
- `feedbackMask` / `commandMask` are derived from current ATYPE values. With `1,1,1,4,4`, masks are 24/7; after XYZ become ATYPE=4, masks become 31/0 without changing the PC ABI.
- All custom BASIC identifiers are at most 18 characters.

## Upper computer

- `Table5D` validates V27 schema and accepts either current 24/7 provenance or future 31/0 provenance, provided feedback/command masks are disjoint and cover XYZCB.
- Startup handshake remains strict: sensor receive is armed first, controller session resets with PWM off, `enable=2` creates exactly one low-rate PWM probe, and only after one Profile + one Pose does PC send `enable=1`.
- The TABLE reader continues to consume Buffer B at 10 ms cadence and acknowledges `readIndex` only after a complete batch has been read.
- The controller-reported feedback/latch/command masks are cached at session start and must not change during a scan.
- On stop, PC disables PWM first, drains remaining sensor/profile and Buffer-B records, then finalizes alignment.

## Offline verification

- `ctest`: 21/21 passed in the Linux portable/mock build.
- `tools/verify_v27.py`: 20/20 source contracts passed.
- This does not replace ZDevelop compilation or oscilloscope/electrical testing on ECI3808.

## V27.1 follow-up (MSVC + ECI3808 compact BASIC)

- Fixed Windows/MSVC `C2872 Arc ambiguous symbol` in `GCodeExecutor.cpp` by
  explicitly using `mls::runtime::Arc` and `mls::runtime::Plane` in both normal
  arc and RTCP arc paths. The C2065/C3536 errors shown after it were cascading
  parser/name-lookup errors.
- Replaced the packaged controller program with the compact ECI3808 BASIC that
  avoids parameterized SUBs and the observed 18-character identifier limit,
  while keeping the V27 host TABLE ABI.
- Updated `tools/verify_v27.py`; current result is 23/23 contracts passed.
- Portable/mock `ctest` result after the change: 21/21 passed.
