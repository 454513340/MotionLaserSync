# MotionLaserSync V29 37姿态连续NC：现场准入代码审查与修改结果

本版从 **BC37 无瞬移连续NC完整源码**继续修改，新增**只读现场资格诊断**，**未**提供可以绕开现场验收的自动启动程序。

## 源码和控制链路结论

- `src/gcode/GCodeExecutor.cpp` 已有 `startMotion` → `ZmcController::prepareMergePath`/`pumpMergeBuffer` 的真实五轴运动链路。普通 G 代码能运行与此一致。
- 同一个执行器显式拒绝 `OfflineOnly: true`；硬件 M50/M51 还有独立的触发配置预验证闸门。
- 给定的连续 H3 NC 是 37 组采集、36 次姿态间转场；首个 G00 之前没有验证从当前 MPOS 到起点的运动路径。
- 用户导出的 NC 和 manifest SHA-256 一致，但 manifest 自述 `hardwareAuthorized=false`、`registrationVerified=false`、`firstG00StartUnverified=true`、`opticsAcrossAnglesVerified=false`。

## 实际修改

| 文件 | 修改 |
| --- | --- |
| `include/gcode/GCodeExecutor.h` | 新增只读现场检查的报告结构与方法 |
| `src/gcode/GCodeExecutor.cpp` | 读取原始哈希、程序/同步声明、现场H3、五轴回零/MPOS/健康状态、首G00差值；**无运动/采集命令** |
| `include/widgets/GCodeWidget.h` | 新增 GUI 按钮与槽 |
| `src/widgets/GCodeWidget.cpp` | 工具栏只读检查 + 自动 JSON 归档 + 编辑器/磁盘一致性保护 |
| `tools/audit_multi_pose_nc_for_real_run.py` | NC+manifest 只读审计工具 |
| `tests/gcode/test_real_run_preflight_audit.py` | 伪哈希拒绝、状态检查未调用运动API、硬件闸门保留等测试 |
| `README_GCODE_READONLY_MACHINE_PREFLIGHT_ZH.md` | Windows 现场操作及验收边界 |

## 结果

- 输入连续 NC 的 SHA-256 为 `09f32d4b679c56d9f2c2f9f27e15d9593c820723192ef0a25c3c8493670e1cda`，与附件 manifest 一致。
- 在当前材料上有 12 条明确阻断（部分是同一个验收缺口的重复证据），完整机器预检需连接真实机器后获取。
- 离线相关 4 项 C++ 测试通过，新增 Python 静态/数据测试通过。
- Windows GUI 编译和真实硬件运行尚未完成；此版仍保留 `OfflineOnly` 和 H3 电气预验证保护。

可先在你的电脑运行“实机准入检查（只读）”，导出报告。真正允许执行要求完成**有资质的现场验收与签署**，并以可信方式在正式执行器中消费签署结果，不能仅在 NC 注释中将 false 改成 true。
