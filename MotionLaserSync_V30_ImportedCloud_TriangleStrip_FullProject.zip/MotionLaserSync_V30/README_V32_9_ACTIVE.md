# V32.9 active hardware-sync build

Active controller program: `controller/ECI3808_5Axis_Controller.bas`.

Key changes over V32.8B/J:

- Keeps the verified REGIST ring capacity fix (`128`, not `129`).
- Keeps SINGLE-OP14, PWM0 200 Hz, ColdPrime, one-shot probe and five-axis REGIST(104) MPOS records.
- On normal PWM stop, forces PWM0 to 100% for 6 ms and then to 0%. The final OFF edge is intentionally delayed until scanCONTROL is out of its exposure+idle busy interval, so the sensor and REGIST can both accept the same final edge instead of producing `Pose = Profile + 1`.
- Queues the post-stop Physical17 runtime re-injection until after `SyncManager::stop()` has fully unwound, so `m_stopping` no longer causes a false "采集中不能替换17参数/手眼模型" failure.
- Hardware-sync report wording now describes PWM0 instead of the obsolete TIMER trigger text.
- C/B control-panel refresh behavior is intentionally unchanged in this revision.

## V27.6.16S upper-PC coordinate integration

- XYZ incremental linear gratings are now the measured-position source after each axis completes DATUM and the host explicitly commits `MPOS=0` with `ZAux_Direct_SetMpos`.
- The host treats XYZ MPOS as invalid after connect/reconnect and after a failed/aborted re-home; five-axis calibration, RTCP, software acquisition and hardware-sync preflight stay gated until X/Y/Z all establish a fresh reference.
- Ordinary measured pose and software sampling are full five-axis MPOS (`31/0/0`); hardware TABLE remains full latched MPOS (`31/31/0`). XYZ DPOS remains demand/command state and a following-error diagnostic.
- Legacy accepted Physical17 models trained with XYZ DPOS + C/B MPOS (`feedback_mask=24`) remain usable as approximate runtime fallback and as sphere-center/path-planning seeds. Their saved provenance remains 24 even while the live machine is bound to mask 31; recalibration is recommended, not forced.
- The controller BASIC is intentionally unchanged by V27.6.16S. Keep the field-commissioned XYZ `ENCODER_RATIO` values on the machine.
