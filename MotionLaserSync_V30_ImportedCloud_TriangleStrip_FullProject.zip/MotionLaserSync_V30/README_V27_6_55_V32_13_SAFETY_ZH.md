# MotionLaserSync V27.6.55 + ECI3808 BASIC V32.13

## 版本基线与改动范围

以用户最新上传的 `68061e95-11b1-4c09-b601-2b00ef511e44.rar` 中 V27.6.54/V32.12 为唯一源代码基线；完整保留 V32.12 的 PWM 请求序号和 ACK 协议、StopPwmSync 尾沿收尾、双缓冲、五轴 REGIST(104) FULL-MPOS、ColdPrime、传感器和 XYZ/B/C 参数。

### 控制器 BASIC V32.13

1. `CONST RUNTIME_MAGIC=321055`。原 `321054` 不再被本版主机接受，防止旧新混用。
2. 保持 `TABLE[334]=0` 停止、旧采集 `StopPwmSync -> Pump -> gm=0`，之后才调用 `ApplyRuntimeConfig`，保证尾沿结束前不调新频率。
3. `TABLE[357] != 31` 时，若收到 `en=1` 连续采集、`en=2` Probe 或 `en=3` ColdPrime，则立即执行 `TABLE[333]=12` 和 `Bad()`，切断 OP14。运行中清除 Home 位也能触发同样故障；控制器与 PC 两侧独立联锁。
4. BASIC 初始化时清 `TABLE[357]=0`；不通过 BASIC 自动伪造任何 Home bit。**`TABLE` RAM 状态不能代替物理限位/编码器/伺服联锁**。
5. `ENCODER_RATIO`、软限位和输出线路不变，须现场核实方向、参数与实际硬件。

### 上位机 V27.6.55

1. C/B 回零和 XYZ 失效清位调用 `SetTable[357]` 后立即 `GetTable[357]` 回读，必须与目标整数完全相同；否则拒绝认定/继续动作。
2. 重连时若识别旧 XYZ Home 位，修正 mask 的写入失败、读回失败或不一致则清除本地主机五轴 Home 标志，并拒绝恢复。
3. 修改 XYZ `UNITS` 前，必须清除本地 Home 有效位，执行严格的 `TABLE[357]` 读-改-写-回读；任何一步失败拒绝修改 `UNITS`。旋转轴 `UNITS` 修改也使用相同的回零状态联锁。
4. 预检和正式采集分别验证 `areAllAxesHomed()`、控制器 mask 31、B/C absolute-ready、BASIC 状态/ACK；ColdPrime 在输出前增加本地五轴有效检查。
5. 对运行时表中版本、频率、mask、状态、序号、故障码采用有限数 + 精确整数 + 范围校验；不再依赖四舍五入来容忍无效 Home 状态。
6. ACK 提交、读回及真正 Idle 等待会拒绝非法、NaN/Inf 数据，不将故障数据强制转为整数；保持频率等待在 I/O 工作线程外执行，以便紧急停机请求有机会执行。
7. 主窗口、校准新建文件 metadata、报告中的当前版本标记同步到 V27.6.55/V32.13；**历史校准 JSON 仍按原 schema/REGIST(104) 拓扑标识兼容读取**，不能仅靠版本字符串认定它在新固件上通过了实机验证。

## 协议

| TABLE | 用途 |
|---:|---|
| 334 | EN：0 停止，1 正式采集，2 Probe，3 ColdPrime |
| 333 | BASIC 采集故障；新增 12=任一输出模式五轴 HomeMask 无效 |
| 354 | magic=321055 |
| 355 / 359 | PC 请求频率整数 Hz / 频率请求序号（最后写 359） |
| 356 / 360 | BASIC 已应用频率 Hz / 已 ACK 序号 |
| 357 | Home X=1 Y=2 Z=4 C=8 B=16；31=五轴完成 |
| 358 | BASIC 状态：0 IdleReady；1 Run；2 Probe；3 Prime；4 Stopping；5 ConfigError；6 Fault |
| 361 | 配置错误：0 无；10 非法频率；12 非法请求序号 |

## 验证命令（Linux 仅可移植 Qt shim + 模拟 ZAux，不是 GUI / BASIC 编译）

```shell
python3 tools/verify_v27655_pwm_home_safety.py
cmake -S . -B /tmp/mls-v55-build -DV21_TESTS_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build /tmp/mls-v55-build --target p0_core_mock_tests v27655_runtime_pwm_tests v27654_runtime_pwm_tests -j 2
ctest --test-dir /tmp/mls-v55-build --output-on-failure -R 'p0_real_core_mock_transport|v27655_runtime_pwm|v27654_runtime_pwm|v27655_pwm_home_safety_contract'
```

已将之前发现的 6 项 HOME 故障注入改为**永久回归测试**，并新增 BASIC 状态异常、序号错误和 ColdPrime 门禁测试。历史 v54 静态检查脚本不再注册为本版 active contract。可移植版源码和模拟 ZAux 的核心测试为 **107/107 通过**；全套 72 个 CTest 项为 39 通过、21 跳过、12 失败，12 个失败已在原 V27.6.54 基线复现，属于历史源代码静态合同检查的既有问题。详细证明与限制见 `RELEASE_AUDIT_V27_6_55_ZH.md`。

## 现场前置事项 / 当前限制

- **未经验证：Windows x64 Qt/MSVC 全工程 Release 编译；ZDevelop / 厂商 BASIC 语法；真实 ECI3808 上 PWM/OP14 触发边沿、REGIST FIFO、200~2000Hz 时序；真实驱动器绝对有效性、急停和软限位**。
- 本版只在本地模拟 SDK、静态检查和可移植构建层验证，不能据此宣称机床可安全运动。
- 保留现机正常运行固件完整备份；先用厂家软件校验 BASIC，再在禁激光、低速、可随时硬件急停的状态下验证五轴回零/重连/断电、故障清位、频率 ACK 超时和传感器时序；合格前不要替换在用生产固件。
- 修改固件会清空 `TABLE[357]`，必须重新回零 XYZ/C/B。若仅 C/B 驱动器独立掉电，但 BASIC 未重启，RAM Home 位可能保留；**这个风险需要结合伺服报警/电池/使能硬件信号现场设计额外失效监控**，当前源码不声称已经处理全部外部掉电情况。
