# V27.6.41：Stage2 渐进式姿态筛选（Progressive Trimmed LS）+ 重新自举 + Physical17 Rank-14

## 1. 为什么 V27.6.40 只筛掉了 1 个姿态

实机日志中第一轮统计为：

- 47 个独立姿态；
- pose RMS median = 0.05123451 mm；
- MAD = 0.02168023 mm；
- V27.6.40 RMS threshold = 0.1637354 mm；
- 最终只有 1 个姿态（RMS=0.200269 mm）超过门限；
- 删除后第二轮门限仍为 0.1517765 mm，因此不再删除；
- 最终训练 RMS = 0.062451776 mm。

V27.6.40 的主要问题是阈值写成：

```text
threshold = max(
    absolute_floor,
    relative_factor * median,
    median + 3.5 * 1.4826 * MAD)
```

当坏姿态不是“一个极端离群点”，而是形成一条较宽的高误差尾部时，MAD 本身会被这批姿态抬高。`max(...)` 又总是选择最宽松的门限，因此产生典型的 outlier masking：很多中等偏差姿态互相掩盖，只剩最差的一个被判为异常。

## 2. V27.6.41 的核心改动

V27.6.41 不再把“超过一个单独的异常值阈值”作为唯一删除条件，而改成 **rank-aware progressive trimmed least-squares**。

### 2.1 更严格的姿态质量门限

RMS 和 P95 门限改为：

```text
robust_gate   = median + 1.75 * 1.4826 * MAD
relative_gate = 1.30 * median
threshold     = max(absolute_floor, min(robust_gate, relative_gate))
```

默认：

```text
RMS absolute floor = 0.050 mm
P95 absolute floor = 0.080 mm
```

也就是说，不再让被污染的 MAD 把门限无限抬高。

按上一份实机日志的 RMS median/MAD 估算，V27.6.40 的 RMS 门限为约 0.1637 mm；V27.6.41 对相同统计量的门限约为 0.0666 mm，因此会把更多高误差尾部姿态送入候选集，而不是只看到 0.200 mm 那一个姿态。

### 2.2 渐进式 worst-tail trimming

如果：

- 当前保留数据的整体训练 RMS 仍高于 0.045 mm；
- 姿态间 RMS spread 足够大（robust sigma >= 0.010 mm）；

则即使经典异常值门限候选数太少，也会从最差尾部主动补充候选。

每轮默认：

```text
测试约当前姿态数的 12%
至少 3 个
最多 6 个
```

47 个姿态时，第一轮通常会测试约 6 个最差姿态，而不是固定只删 1 个。

### 2.3 删除不是“看到误差大就永久删除”

每一个候选删除批次都必须重新执行完整数值链：

```text
当前保留姿态
   ↓
重新求 9-state nominal hand-eye + sphere center
   ↓
重新建立 Tx/Ty/Tz translation gauge anchor
   ↓
重新求 representative Physical17 / rank-14
   ↓
在该批保留的全部 Stage2 点上短程联合精修（25 iter）
   ↓
检查 rank / condition / RMS
   ↓
决定是否真正接受该批删除
```

因此不会仅凭旧模型残差永久删除数据。

### 2.4 用“RMS + 删除比例惩罚”决定是否接受

为了避免为了降低训练 RMS 而无限删除数据，V27.6.41 使用：

```text
selection_objective = retained_RMS
                    + 0.020 mm * cumulative_rejected_fraction
```

只有新的 objective 至少改善 0.00025 mm，或者新的 RMS 已进入目标区间且确实下降，才接受该批删除。

例如 47 个姿态删除 6 个，删除比例约 12.8%，惩罚约 0.00255 mm。也就是说，仅仅因为少了数据导致 RMS 小幅下降还不够；下降必须足以抵消删除数据的代价。

### 2.5 批量删除过于激进时自动缩小

如果一次测试 6 个姿态没有改善目标，会自动尝试较小批次，例如：

```text
6 -> 4 -> 3 -> 1
```

而不是“一次删 6 个失败，就完全停止”。

### 2.6 最多 4 轮、累计最多 40%

默认：

```text
max screening rounds = 4
per-round rejection cap = 15%
cumulative rejection cap = 40%
minimum retained poses = 18
```

47 组姿态最多允许删除约 18 组，但实际是否删除到这么多由重拟合后的 objective、rank 和 coverage 决定。

## 3. 可观测性保护

V27.6.41 不会只追求低 RMS。每次删除必须同时满足：

- nominal 9-state bootstrap rank = 9/9；
- Physical17 physical rank >= 14；
- full-state rank >= 17；
- condition number 不超过绝对上限，并且不能相对当前解恶化过多；
- 至少保留 18 个姿态；
- X/Y/Z 运动跨度至少保留原数据的 55%；
- B/C 角度跨度至少保留原数据的 65%；
- 原数据若有足够 B+/B-/C+/C- 姿态，筛选后仍至少各保留 2 组。

因此极限 B/C 或 XYZ 姿态即使残差偏大，也不会在删除后破坏几何可辨识性时被盲目丢弃。

## 4. 每个姿态如何打分

每个完整 XYZBC 姿态组统计：

- RMS；
- mean absolute residual；
- |residual| P95；
- max |residual|；
- profile count；
- point count。

排序分数由 RMS/P95 相对门限以及相对 median/MAD 的 tail distance 共同组成。筛选单位始终是完整姿态组，不会把同一个姿态的某些点保留、某些点删除来人为降低结果。

## 5. 原始数据不删除

CSV / 采集缓存中的原始 profile 和点不会被修改或物理删除。筛选仅生成当前求解使用的 retained training subset。

结果 JSON 仍记录：

- 原始姿态数；
- 最终保留姿态数；
- 删除姿态数；
- 每个删除姿态的 XYZBC；
- RMS/P95/max；
- rejection score；
- 最终 hand-eye bootstrap 和 translation gauge anchor。

## 6. 关于目标 RMS

筛选内部目标设为 `0.045 mm`，这是为了给 GUI 最终 `0.050 mm` 训练门限留出一定余量，并不是把结果硬改成 0.045。若数据/模型本身不支持更低 RMS，算法会因为 selection objective 不再改善而停止，而不是继续删除直到剩很少的数据。

如果你之前所说的 “RMS=0.4” 实际是指 `0.04 mm`，这版算法就是按这一数量级附近进行渐进搜索；如果确实是 `0.4 mm`，那么当前 0.062 mm 本身已经小于 0.4 mm。

## 7. 主要修改文件

- `include/calibration/SingleSphere17Calibration.h`
- `src/calibration/SingleSphere17Calibration.cpp`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `tools/single_sphere17_cli.cpp`
- `tests/v20_2_single_sphere17_tests.cpp`
- `src/app/main.cpp`
- `src/app/MainWindow.cpp`

## 8. 回归测试

新增/扩展测试覆盖：

- 明显坏姿态整组剔除；
- 一批中等偏差姿态形成高误差尾部时，不再只选单个最差姿态；
- 每轮 trim 数量受限；
- 筛选后仍保留 rank/coverage 约束；
- 既有 Physical17 rank-14、自举、JSON 等回归测试继续通过。
