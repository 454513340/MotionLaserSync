# V27.3 Qt platform plugin runtime fix

Root cause of the V27.2 runtime regression:

- The user's previously working CMake explicitly copied the Qt Windows QPA plugin
  to `<exe>/platforms/qwindowsd.dll` (Debug) or `qwindows.dll` (Release).
- V27.2 replaced that with an optional `deploy_qt` target and left
  `AUTO_DEPLOY_QT=OFF` by default.
- Therefore a normal Visual Studio Debug build could launch with Qt6Core present
  but without a Windows platform plugin, producing:
  `This application failed to start because no Qt platform plugin could be initialized.`

V27.3 restores the previously proven POST_BUILD qwindows plugin copy while
retaining:
- MSVC `mls::runtime::Arc` qualification fix;
- guarded `WIN32_LEAN_AND_MEAN` in scanCONTROL stdafx;
- V27 PWM/latch/double-buffer host/runtime sources;
- controller/examples/config post-build copy.

After unpacking, delete `out` and `.vs` or use Visual Studio
`Delete Cache and Reconfigure`, then build x64-Debug.
After build, verify:
`out/build/x64-Debug/platforms/qwindowsd.dll`
exists next to `MotionLaserSync.exe`.
