# MotionLaserSync V27.6.16T — 球面距离 / 入射角研究

本版基于 V27.6.16S。V27.6.16S 的 XYZ 增量光栅 MPOS 回零、五轴实际姿态、旧 Physical17 标定兼容以及 ECI3808 V32.9 FULL-MPOS 同步协议保持不变；**三个 BASIC 文件均未修改**。

## 1. 研究目的

用于在正式的传感器标定/机床 Physical17 标定之前，用已知直径标定球研究：

- 传感器到球面的距离 D；
- 轮廓平面内的有符号入射角 alpha；
- 对有效轮廓率、轮廓圆弧拟合 RMS、重复球心稳定性以及机床坐标球面径向残差的影响。

最终目标是找到一块轮廓测量质量更稳定的 `D × alpha` 工作区，为后续标定的路径、距离和角度提供实验依据。

## 2. 首次球心建立：导入硬件同步点云

在 `系统标定 -> 传感标定 -> 球面距离 / 入射角研究` 中：

1. 先使用现有硬件同步扫描流程手动扫过标定球；
2. 保存/导出已经重建到机床坐标系的点云；
3. 点击“导入球面点云”，支持 `.scan/.ply/.csv/.txt`；
4. 点击“RANSAC拟合球心”。

`.scan` 文件通过现有 `PointCloudReconstructor` 按保存时的五轴 frame snapshot 重建到机床坐标。3-D RANSAC 使用已知球半径作为范围先验，自动抑制夹具、底座、背景等离群点，并在内点集上做鲁棒球面精修，输出：

- 球心 `C_M=[Xc,Yc,Zc]`；
- 自由拟合半径（用于诊断）；
- 内点数/比例；
- 球面残差 mean / mean-abs / RMS / max。

球路径与后续误差分析仍以界面中输入的**已知球直径**为几何真值。

## 3. D / alpha 的几何定义

设已知球半径为 `R`。

- `D`：传感器原点沿传感器 `+Z` 轴到选定球面命中点的距离；
- `alpha`：该命中点球面外法向相对视线方向的有符号入射角，限制在传感器 X-Z 轮廓平面内；
- 目标球心在传感器坐标系中的位置为：

```
C_S = [-R*sin(alpha), 0, D + R*cos(alpha)]
```

这样选择是为了把球面命中点保持在传感器轴线上 `[0,0,D]`，避免把“距离变化”与大幅横向平移混在一起。

实际到位后程序根据实际 XYZCB MPOS 和 Physical17 模型重新计算实际 D、实际 alpha 以及离轮廓平面的角度 beta，并保存这些实际量，而不是把规划目标值当成实测值。

## 4. 路径生成

路径生成需要：

- 已拟合的机床坐标球心；
- XYZ 已正规回零并建立光栅 MPOS 机床基准；
- B/C 机械绝对坐标已建立；
- 至少一套可作为几何初值的 Physical17/Stage-1 模型。

规划模型优先级：

1. 当前 Physical17 求解结果；
2. 上一套兼容/旧 Physical17 结果；
3. Stage-1 初步手眼 + 名义机床模型。

这一路径只用于**研究规划**，允许使用旧结果或尚未完成独立验证的近似结果。正式扫描和 RTCP 的授权逻辑没有降低，仍由原 `scanCalibration()` 的独立验证门禁控制。

为了把实验变量尽量限制在 D/alpha，本版固定“生成路径时的当前 C/B”，通过完整 Physical17 模型数值反解 XYZ。所有目标仍会经过 XYZ 软件限位和五轴 P2P 运动规划检查。

## 5. 每个位姿多组 Profile 采集

选中表格中的有效位姿后：

1. “移动到选定位姿”；
2. 到位后程序显示实际 D / alpha / beta；
3. “采集选定位姿多组Profile”；
4. 可配置每姿态组数、每组 Profile 数和每组开始时丢弃的稳定帧数。

每一组开始时重新读取实际 XYZCB MPOS，并把下面信息写入原始 CSV：

- 目标 D / alpha；
- 实际 D / alpha / beta；
- 实际 X/Y/Z 光栅 MPOS；
- 实际 C/B 机械 MPOS；
- 球心机床坐标；
- 本次路径所使用的 Physical17 初始模型来源；
- 每条 Profile 的原始 sensor X/Z 数据和时间信息。

研究采集使用独立的临时 `profileReceived` 连接，只在本研究采集期间存在；关闭程序、断开传感器或断开控制器时会自动解除。它不会改变正式硬件同步扫描链路。

## 6. 数据分析

每条 Profile 先根据初始模型预测球心在传感器坐标中的大致位置，建立 ROI，然后：

1. 对 X-Z 轮廓做 RANSAC 圆弧提取；
2. 计算圆弧有效内点率、覆盖角度、sensor-frame circle RMS；
3. 统计重复 Profile 拟合球心 X/Z 的标准差；
4. 把圆弧内点经 Physical17 映射回机床坐标，计算相对已知球心/半径的径向 mean / mean-abs / RMS / max。

**推荐距离/角度的主排序使用 sensor-frame 圆弧 RMS，其次使用重复球心稳定性。** 这两个指标主要反映传感器本身在该距离/角度下得到的轮廓质量，不会让当前仍可能不够准确的旧手眼/机床模型主导结论。机床坐标球面径向 RMS 作为第二类诊断指标同时保存和显示。

只有有效 Profile 比例达到 80% 且至少有 5 条有效 Profile 的位姿才进入自动推荐候选。

## 7. 导出文件

每次研究 session 可导出：

- `sphere_distance_angle_study.json`：球心 RANSAC、规划模型、D/alpha 网格、实际 MPOS、汇总结果；
- `distance_angle_summary.csv`：每个位姿的目标/实际 D/alpha、有效率、circle RMS、sphere RMS、重复性；
- `profile_metrics.csv`：每条 Profile 的详细圆弧与球面误差；
- `sphere_ransac_inliers.csv`：3-D RANSAC 提取出的球面机床坐标内点；
- `pose_.../group_..._profiles.csv`：每个位姿、每组的原始 Profile 数据。

## 8. BASIC 与 XYZ MPOS

V27.6.16T **没有修改任何 BASIC 文件**。现场已经设置的 XYZ：

```basic
ENCODER_RATIO(2,1) AXIS(1)
ENCODER_RATIO(2,1) AXIS(2)
ENCODER_RATIO(2,-1) AXIS(3)
```

请继续使用现场已确认版本，不要用工程中历史副本覆盖现场控制器。

所有研究位姿/实际几何计算要求 XYZ 已经通过正规回零建立 MPOS 机床坐标基准。

## 9. 验证

新增：

- `tests/v27616t_sphere_distance_angle_tests.cpp`
  - 完整球面 + 离群点 RANSAC；
  - 实际扫描更接近的局部球冠 + 离群点 RANSAC；
  - D/alpha 几何公式；
  - 固定 C/B、反解 XYZ 路径；
  - 实际 D/alpha 反算；
  - Profile 圆弧 RANSAC + 机床球面残差。
- `tools/verify_v27616t_sphere_distance_angle_study.py`
  - 检查 UI、规划模型兼容、MPOS 门禁、采集/分析/导出及 BASIC 未改动。

Linux 便携核心测试可以真实编译运行；完整 Qt GUI 仍需在项目既有 Windows/MSVC + 厂商 SDK 环境完成最终链接与实机验收。
