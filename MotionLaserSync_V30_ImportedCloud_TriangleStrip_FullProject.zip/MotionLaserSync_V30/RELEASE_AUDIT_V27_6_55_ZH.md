# MotionLaserSync V27.6.55 / ECI3808 BASIC V32.13 版本交付与验证报告

## 基线和范围

- **仅基于用户最近一次上传的 V27.6.54 + V32.12 工程**，不把以前生成的 V32.11 当作主分支；保留原厂 SDK、校准模型、机器参数、对时与 PWM 请求/确认逻辑。
- **目标版本：V27.6.55 / BASIC V32.13**。运行时协议魔数 `TABLE[354]=321055`；要求 PC 与固件配套升级，不能与原 `321054` 混用。
- **仅源码审计/可移植模拟验证，非真实控制器已通过验证的发布版本**。

## 解决的问题

| 问题 | 新版修复 | 关键文件 |
|---|---|---|
| `TABLE[357]` Home mask 写入 SDK 成功但实际不生效 | C/B 回零状态写入后回读核对目标值，失败即返回故障 | `src/core/ZmcController.cpp` |
| 重新连接时旧 XYZ Home 位清除失败被忽略 | 读、改、写、回读任一步失败就拒绝恢复本地五轴 Home | `src/core/ZmcController.cpp` |
| XYZ / 旋转轴 `UNITS` 修改时旧 Home 位没有可靠撤销 | 先撤销本地 Home，有可靠远端清位和回读才允许更改轴参数 | `src/core/ZmcController.cpp` |
| 预检/正式运行/ColdPrime 有绕开五轴 Home 的路径 | PC 双入口校验五轴状态和 mask31；BASIC 在 Run/Probe/ColdPrime 模式及运行过程中再次检查，Home 无效置采集错误12并安全关闭 OP14 | `src/core/ZmcController.cpp`、`controller/ECI3808_5Axis_Controller.bas` |
| 整数协议字段异常读数被隐式四舍五入/强制转换 | 频率、序号、Home mask、状态、故障码等读取均检查有限值、精确整数和边界；异常时拒绝启动/继续 | `include/runtime/Acquisition5D.h`、`src/core/ZmcController.cpp` |
| 旧文档版本/下载位置混淆 | 唯一正式 BASIC 下载位置指向控制器目录，旧版移到禁止下载归档区；主窗口/新生成标定元信息使用新版本 | `FIELD_BASIC_DEPLOYMENT_NOTICE.md`、`README_V32_13_ACTIVE.md`、相关 C++ |

### 保留的重要 V32.12 设计

- `TABLE[355]` 频率请求；`TABLE[359]` 提交序号；`TABLE[356]` 已应用频率；`TABLE[360]` 应答序号；`TABLE[358]` 状态；`TABLE[361]` 配置错误。
- BASIC 先完成旧 PWM 停止和尾沿收尾，再执行 `ApplyRuntimeConfig()`；同步停止延时按 BASIC 内部已应用频率 `gf` 计算。
- 五轴采样依然使用 REGIST(104) / FULL-MPOS / 单 OP14，XYZ/C/B 轴参数、编码器倍率、现场软限位不主动改动。

## 校验与测试（2026-10-08，本地 Linux 可移植工具链）

- CMake `-DV21_TESTS_ONLY=ON -DCMAKE_BUILD_TYPE=Release`：**全可移植目标编译成功**。这不是完整 Windows Qt/VTK/MSVC GUI Release 构建，也不是 ZDevelop BASIC 编译。
- `p0_core_mock_tests`：**107/107 通过**，包含六项持久化 Home 故障注入及新增非法状态、无效 ACK、ColdPrime Home 门禁等场景。
- 针对当前协议和历史运行时兼容性选择执行的重点 CTest：**9/9 通过**。
- 全部已注册 CTest 共 72 项：**39 通过，21 跳过，12 失败**。这 12 项为历史静态源代码合同断言，已在未修改的 V27.6.54 基线上逐项复现同样失败，不能表述为“全量通过”。历史脚本仍列入 suite，保留透明性。
- `python3 tools/verify_v27655_pwm_home_safety.py`：通过（检查 V32.13 三份 BASIC 相同、版本/协议、频率停止先后顺序和 Home 防护结构）。
- 以上测试不模拟 BASIC 编译器、物理回零真实度、断电后伺服状态、触发边沿和实际输送速率。新添的 BASIC 端联锁采用源码结构检查，**未上机动态验证**。

## 发布文件及版本隔离

- **正式 BASIC 候选**：`controller/ECI3808_5Axis_Controller.bas`。
- 便于核对的内容相同副本：`controller/ECI3808_V32_13_PWM_HANDSHAKE_FIVE_AXIS_HOME.bas`、根目录同名 BASIC。
- **历史不可下载**：`controller/ARCHIVE_NOT_FOR_FLASH/`；注意有历史 v32_9 文件名与其实际内容不完全匹配。
- `FILE_SHA256_MANIFEST_V27_6_55.tsv` 是新版工程逐文件校验清单；V27.6.54 的原清单在 `docs/HISTORICAL_MANIFESTS/`，不可当新版校验文件。
- `README_V27_6_55_V32_13_SAFETY_ZH.md` 说明表协议、现场步骤以及本版已知限制。

## 现场强制检查 / 不构成下载许可

1. 完整备份控制器中**当前实际能运行的固件**、轴参数、厂家配置和上位机原项目。不要只依赖项目里的旧版文件名。
2. 在目标 Windows Qt/VTK/MSVC 环境先完成 GUI/驱动程序全工程 Release 编译；在厂家 ZDevelop/ZBasic 编译并审查 BASIC 版本。
3. 核对每个轴真实正方向、光栅/电机编码器比例、限位和异常减速、急停硬接线；独立测试硬件联锁，不得用 `TABLE[357]` 软件状态代替安全回路。
4. 禁激光，空载/低速、可硬件急停条件下下载试运行，BASIC 启动会将 Home mask 清零，必须按现场流程重新回零 XYZCB；检查非法 mask、写入不生效、伺服报警、轴断电及重连。
5. 校验 355/359 与 356/360 ACK、358 Idle/Stop、361 故障响应、333 故障12；用示波器与完整 Profile/Pose 数据验证 OP14、scanCONTROL、IN0、REGIST FIFO 及采样计数。
6. 低频验证通过后再逐级测试频率与数据吞吐；**25..2000Hz 只是协议允许范围，不是设备实测合格带宽**。

**结论：这是一份待设备验证的 V27.6.55 / V32.13 源码候选，不是已确认安全可生产的固件。**
