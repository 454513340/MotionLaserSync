# V28.8 M7：VS2022 C3538 编译修复说明

## 原因与修改

`src/widgets/DigitalTwinScanWidget.cpp` 中 M7 启动函数的两条 `const auto a=x,b=y` 语句将不同 `std::shared_ptr` 类型放入同一声明，导致 MSVC C3538。

改为五条独立的 `const auto` 声明：

```cpp
const auto real = m_replay;
const auto m5 = m_m5Data;
const auto m6 = m_m6Data;
// ...
const auto cancel = m_m7Cancel;
const auto progress = m_m7Progress;
```

修复不会改变 QtConcurrent M7 融合计算、运动控制、M6 点云归档、Open CASCADE 设置或 CAD 覆盖算法。

## Windows 构建注意

用 VS2022 构建 `MotionLaserSync.exe`（不是 exposure_analysis_cli），选择 x64-Release，重新构建。如果错误列表中仍出现 `qrunnable.h` 的 E2422，请把筛选范围调整为"仅生成"，并发来 "输出→生成" 中的编译记录；该 Qt 头文件报错可能来自 IntelliSense，不能仅靠 E 编号断定编译失败。

完整 Windows GUI 的编译仍需在你的机器上验证；本包离线 C++17 核心的测试不包含 Windows Qt6/VTK/MSVC。

OCCT 路径：`D:/dev/vcpkg/installed/x64-windows-release`。
