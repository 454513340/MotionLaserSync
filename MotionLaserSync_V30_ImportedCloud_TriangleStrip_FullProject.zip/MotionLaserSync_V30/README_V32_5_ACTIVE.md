# Active hardware-sync build

Use `ECI3808_V32_5_WithGrating_ColdPrime_RAMCompact.bas` with this PC project.

This PC build accepts only the V32.5 WithGrating header. NoGrating BASIC images are intentionally rejected.

Before installing XYZ gratings, B/C-only motion may be used to commission the trigger/count pipeline. XYZ values are not physically meaningful until the gratings and `ENCODER_RATIO` settings are commissioned.
