# V27.6.16I / V32.7 变更说明

## 纠正 V32.6 的数据源理解

V32.6 把 XYZ DPOS 快照写入硬件 TABLE，这不符合“控制器程序完全按未来 XYZ 光栅尺接入后的最终结构设计”的要求。

V32.7 改为：

- BASIC：XYZ/C/B 全部 `ATYPE=4`；五轴全部 `REGIST(104)`；Buffer-B 中 `[seq,X,Y,Z,C,B]` 的五个坐标全部为 MPOS。
- 上位机硬件同步协议：`feedbackMask=31, timing=4, latchMask=31, commandMask=0`。
- 上位机普通运动控制/轴状态/软件同步：继续使用 XYZ DPOS，不因为 BASIC 改成全 MPOS 而改变。
- C/B 仍按 `machine = raw latched MPOS + frozen RS485 offset` 恢复机械绝对角。

因此：当前 XYZ 光栅尺未接时，硬件同步数据中的 X/Y/Z 预计为 0；这不影响用 C/B 验证触发、Profile、REGIST、TABLE ordinal 的一一对应。

## ColdPrime

保留 V32.6 的冷启动预热机制：正式 session 前使用同一 OP14 以 5 ms 触发 scanCONTROL，等待至少 8 个成功转换 Profile，全部丢弃；随后新 session 清空并重新 Arm 五轴 REGIST FIFO，再做正式单次 Probe。

## 验证

- V32.7 静态契约检查：9/9 PASS
- `p0_core_mock_tests`：62/62 PASS
- `v21_runtime_tests`：47/47 PASS
- `v19_report_tests`：20/20 PASS

这些为 portable/mock 测试；Windows + Qt + LLT.dll + ECI3808 的最终行为仍需现场编译与实机验证。
