# V27.6.27 — Z轴 DPOS/MPOS 过零与 SetMpos 自动诊断

## 目的

本版在 V27.6.26 的 DPOS/MPOS 手工/自动记录基础上，增加自动 Z 轴诊断计划，用于区分：

1. 上位机是否在普通过零运动时再次调用 `SetMpos`；
2. `MPOS` 坐标层是否在 DPOS=0 附近出现离散跳变；
3. 内部 `ENCODER` 与 MPOS 是否同时出现位移误差；
4. 误差是否只在回零/SetMpos 后出现；
5. 误差是“跨零效应”还是“零点附近物理位置效应”。

## 代码事实：SetMpos 调用位置

当前工程中 `ZAux_Direct_SetMpos` 只有 XYZ 正规回零成功后的 `homeAxis()` 一处生产代码调用。
普通 `moveAbs/moveRel`、DPOS 过零以及 Stage-2 运动都不会主动再次调用 SetMpos。

本版新增 `linearMposSetGeneration(axis)`：

- 每次当前连接会话由上位机成功提交一次 `SetMpos(home-zero)`，generation +1；
- 自动测试 CSV 在每一步保存 start/idle/settled generation；
- 普通过零时 generation 应保持不变。

## 新增 ENCODER 记录

通过 ZMotion SDK `ZAux_Direct_GetEncoder()` 读取“内部编码器值”，同时保存：

- start_encoder
- idle_encoder
- settled_encoder
- delta_encoder

用途：

- 如果 SetMpos generation 不变、ENCODER 位移正常但 MPOS 出现约 0.02 mm 跳变，重点检查控制器 MPOS 坐标/偏置映射；
- 如果 ENCODER 与 MPOS 同时少/多约 0.02 mm，重点检查光栅计数、反馈链、局部机械/电气问题。

## 控制页自动测试

控制页最下方“DPOS / MPOS 位移诊断”新增：

- 测试阶段：`POST_HOME` / `PRE_HOME`
- 自动计划
- 重复次数
- 开始自动测试 / 停止自动测试
- 进度条

### A. POST_HOME 三段 5 mm 对比（推荐）

必须先完成 Z 正规 DATUM 回零并建立 MPOS 零点。

三段全部为 5 mm，双向重复：

1. `-11.0 <-> -6.0 mm`：远离零点；
2. `-5.5 <-> -0.5 mm`：靠近零点但不跨 DPOS=0；
3. `-0.5 <-> +4.5 mm`：跨 DPOS=0。

解释：

- 只有第 3 段异常：高度怀疑“过零/坐标层”效应；
- 第 2、3 段都异常，第 1 段正常：更像零点附近物理位置局部问题；
- 三段都同比例异常：检查 ENCODER_RATIO/全局反馈比例；
- 正反方向符号/幅值明显不同：检查回差、摩擦、重力、伺服刚性。

默认重复 5 次，IDLE 后稳定等待默认 2000 ms。

### B. POST_HOME 零点 0.5 mm 细扫

范围：

`-2.0 -> +5.0 -> -2.0 mm`

步长：`0.5 mm`

用于寻找是否在 `DPOS=0`、DATUM 输入边沿或某个固定物理位置出现离散突变。
建议重复 2 次即可。

### C. PRE_HOME 上电未回零相对 ±5 mm

该模式只用于“SetMpos 前”对照。

- 不执行 DATUM；
- 不调用 SetMpos；
- 不使用绝对 Z 坐标；
- 从当前上电位置执行：`+5, -5, -5, +5 mm`，重复 N 次；
- 最大偏离当前起点为 5 mm。

**重要：未回零时绝对机床坐标无效。开始前必须人工确认 Z 当前机械位置正、负方向各至少 6 mm 安全余量，并有人监护急停。**

PRE_HOME 只能说明“未 SetMpos 时增量 5 mm 是否已经有 DPOS/MPOS/ENCODER 差异”。如果要与 POST_HOME 在完全相同物理区域比较，还需要用独立机械参考保证两次上电的起始物理位置一致。

## 推荐实验顺序

1. 上电、连接控制器，**不要回零**；在确认当前 Z 位置安全后运行 PRE_HOME 相对 ±5 mm，保存 CSV；
2. 正规回零 Z；确认日志出现 `host SetMpos(home-zero) committed; generation=1`；
3. 运行 POST_HOME 三段 5 mm 对比，保存 CSV；
4. 再运行 POST_HOME 0.5 mm 零点细扫，保存 CSV；
5. 可重新回零一次，再重复步骤 3，用于判断每次 homing/SetMpos 后异常位置是否稳定重复。

## CSV 新字段

除 V27.6.26 的 DPOS/MPOS/FE/DATUM/IDLE 后漂移外，新增：

- `phase`
- `plan`
- `role`
- `step_label`
- `cycle`
- `start/idle/settled_encoder`
- `start/idle/settled_linear_referenced`
- `start/idle/settled_setmpos_generation`
- `delta_encoder`
- `crosses_dpos_zero`
- `setmpos_generation_changed`

## 安全规则

- POST_HOME 计划启动前检查 Z 软限位；
- PRE_HOME 不依赖绝对坐标，必须由操作者确认局部机械余量；
- 自动运行期间禁用普通轴控件/Home/Zero，保留“停止自动测试”和机床急停；
- 软件停止不能替代硬件急停。
