# MotionLaserSync V28.7.2 — M6 进度、轨迹显示与点云输出修正

## 本次修复

基线：V28.7.1，保留 M0–M5.2 和连续 XYZ/C/B 仿真算法。

1. 新增 M6 阶段进度条：粗筛、精评和**当前扫描段**分别显示 0–100% 和耗时。完整扫描段数由贪心增益选择决定，故总运行耗时不是可预先精确估计的；单段百分比在下一段开始时会重新从零计算。进度条不伪装为全流程百分比，旧的候选/正式 Profile 数值仍可看到。
2. 更正黄色轨迹可视化：原版画传感器坐标原点 `sensorToMachine*(0,0,0)`，与测量位置相距约 95 mm，且用同一线段连通多个没有采集的转场。现在黄色线表示 `sensorToMachine*(0,0,focusSensorZmm)` 的**名义激光测量参考位置**，分段绘制，仅包含激光扫描段。真正的有效激光反射点仍须通过 M3 双光路求交，不以这条黄色示意线替代物理测量。所有转场关节与曝光轨迹仍完整记录在离线 CSV 中。
3. M6 工作台新增“PLY 每 N 个有效点保留 1 点”（1–32，默认 8）。覆盖率**仍处理所有**虚拟 Profile 和有效样本，不进行 CAD 点云插值；磁盘 PLY 和临时 XYZ float spool 只写每 N 个有效点中的一个。`N=1` 恢复旧版全分辨率。
4. 报告增加 `exportPointStride` 和 `exportedPlyPoints`，并单独保留 `virtualValidPoints`。默认 8 时文件名为 `*_simulated_sampled.ply`；选择 1 时为 `*_simulated_full.ply`。PLY 注释声明抽样率，不应作为全分辨率测量数据。
5. Open CASCADE 查找目录保持 `D:/dev/vcpkg/installed/x64-windows-release`。

## 基于用户 M6 报告的说明

先前 9 段、159503 条 Profile、89013414 个有效模拟点，按 float32 XYZ 的原始数据量为 89013414×12 = 1,068,160,968 bytes（约 1.07 GB）。取 N=8 可降低至约 134 MB（不含文件头与 CSV），但**不能**把 200Hz 光学射线追踪的运算量降低八倍。为减少计算时间，可在离线测试中把虚拟 Profile 频率调低到 50/100Hz，随后用 200Hz 重新验证；降低频率会改变采样覆盖结果。

## 重要安全边界

- 黄色线是示意的名义激光焦点轨迹，不是机床 TCP、激光器外壳边界或真正的光学首交点。
- M6 报告 `fullPhysical17Validated=true` 不等于五轴不同 B/C 实测已验证；H1 原始扫描中 B/C 未变化。
- 传感器外壳、工件及夹具完整路径碰撞尚未认证；所有 M6 轨迹均是 `NOT HARDWARE AUTHORIZED`。

## 编译测试

- 离线 `DIGITAL_TWIN_CLI_ONLY=ON` Release 构建及 17 项 CTest：通过。
- M6 专项增加验证：抽样流文件大小/点数、分段扫描路径落在 CAD 附近，以及分段进度计数。
- 当前环境无 Windows/MSVC/Qt/VTK/OCCT 全量依赖，新增 GUI 需在 VS2022 `x64-Release` 编译验证。

## Windows 使用顺序

1. 解压完整工程到新目录，清理 CMake 缓存后配置，确认输出包含 `V28.7.2 M6 focus-path + stage progress bar + configurable PLY subsampling [OK]`。
2. 编译 `MotionLaserSync.exe`（而非 exposure_analysis_cli.exe）。
3. 用原 STEP、H1.scan、M5 覆盖数据运行 M6。第一次可选最大扫描段 1，PLY 抽样 N=8，并观察进度条。
4. 完成后黄色线应贴近工件，而不是远离工件约 95mm。导出 JSON、轨迹 CSV 和抽样 PLY，对比报告中的 `virtualValidPoints` 与 `exportedPlyPoints`。
