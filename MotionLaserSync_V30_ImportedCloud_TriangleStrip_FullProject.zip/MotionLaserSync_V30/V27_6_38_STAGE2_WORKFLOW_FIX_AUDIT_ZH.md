# V27.6.38 Stage-2 实机日志 / 源码审计摘要

## 实机日志结论

- 27 个计划姿态进入 `接受静态采样`。
- 20 个姿态被 `当前与计划球心差异` 丢弃，旧日志中的 dY 为 4.971~14.980 mm，而多数 X/Z 偏差仅亚毫米。
- 姿态 18 的 Y 控制器目标为 -72.249828 mm，确实超出软限位 [-72, 96] mm；这是有效的运动拒绝。
- 姿态 18 之后被自动状态机重复尝试 68 次，属于明确的软件状态机 bug。

## 根因 1：速度参数修改误伤 reference

V27.6.37 `ZmcController::writeAxisParams()` 对 XYZ 任意参数写入都撤销 `m_linearMposReferenced`，对 B/C 任意参数写入都 reset rotary safety state。因此只改 SPEED 也会被视为坐标系变化。

V27.6.38 将运动 profile 参数与坐标定义参数分离；同时 Stage-2 使用内存中的临时速度倍率，不再要求为了标定速度去写全局轴配置。

## 根因 2：Y 门禁使用了不可观测的符号

轮廓是 XZ 二维截面；球半径与截面圆半径只能提供 `|Y_S|`。V27.6.37 的拟合 helper 固定选择 `+1` 支路，而计划目标包含正负 Y_S。直接比较 signed Y 会把负支路误判为大偏差。

修复：采集窗口只比较 `||Y_meas|-|Y_target||`。这不改变最终 Physical17 的点到球面联合优化方程。

## 根因 3：手动采集按钮 readiness 未刷新

PlanDirect 完成时 `m_moveInProgress` 从 true 改为 false，但 300 ms 延迟拟合路径原先只恢复 Move 按钮，没有统一调用 `updateCalibrationReadiness()`，因此 Capture 可能停留在运动期间的 disabled 状态。

修复：移动完成、延迟拟合完成以及移动失败路径均统一刷新 readiness。

## 根因 4：移动失败行重新进入 pending 选择

自动 continuation 的本地 pending 判定排除了“移动失败”，但 `selectNextPendingPlanRow()` 没排除，于是遍历一圈后又把同一失败行选回来。

修复：两个 pending 判定统一；移动失败本轮不重试，保留给人工后续处理。

## 求解最低数据量

硬下限：8 个差异姿态、>=8 observations、>=80 points；真正的合格条件还包括 physical rank >=14、full rank >=17、RMS <=0.050 mm、condition <=1e9。
