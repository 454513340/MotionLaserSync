# MotionLaserSync V29：多姿态启动闪退修复与入口调整

## 诊断结果（源代码可确定）

上次新增的 `src/widgets/MultiPoseExperimentWidget.cpp` 在 `buildUi()` 过程中先执行三次 `addOrientation(...)`，而 `addOrientation()` 会调用 `invalidate()`。此时 `m_btnExport`、`m_btnSim`、`m_btnPreviewNc`、`m_summary` 尚未被创建（头文件默认初始化为 `nullptr`），但 `invalidate()` 无条件访问它们，存在启动时确定的空指针解引用。原 `src/app/MainWindow.cpp` 又在 `createUi()` 中立即执行 `new MultiPoseExperimentWidget(...)`，从而导致**主窗口尚未显示就可能直接退出**。这些事实可由源文件和调用路径确认；未经本机 Windows 调试器捕获的崩溃栈不应被虚构为已取得。

## 本次具体修订

1. `src/widgets/MultiPoseExperimentWidget.cpp`：把初始三组姿态 P01/P02/P03 的插入移到整个 UI 构造结束后，并通过 `QSignalBlocker` 避免无意义的初始化期 itemChanged 事件。`invalidate()` 对 `m_btnExport`、`m_btnSim`、`m_btnPreviewNc`、`m_summary` 逐项做空指针保护；`log()` 对 `m_log` 做保护。
2. `src/app/MainWindow.cpp` / `include/app/MainWindow.h`：删除独立的顶部“多姿态实验扫描”标签和立即构造 `MultiPoseExperimentWidget` 的代码，保持原控制标签排列。
3. `src/widgets/PathPlanningWidget.cpp` / `include/widgets/PathPlanningWidget.h`：在 **路径规划** 页面、原“数字孪生 / STEP 工件放置…”按钮的**正上方**增加“多姿态实验扫描 / 规划、仿真与离线 G代码…”按钮。首次点击时，才生成包含 `MultiPoseExperimentWidget` 的非模态 `QDialog` 和 `QScrollArea`；关闭后会隐藏，后续点击会再次激活同一窗口，保留研究配方。
4. `src/app/main.cpp`：增加仅用于诊断的 `--smoke-ui` 模式，在 Windows 上测试主窗口显示、路径规划新按钮以及多姿态对话框显示，再自动退出。检查阶段写入 `%TEMP%\MotionLaserSync_gui_smoke.txt`。正常启动不会额外执行这些操作。
5. `tools/RunGuiSmokeTest.ps1`：添加 Windows 自检脚本；`tests/gui/test_multi_pose_startup_contract.py`：源码级回归检查启动顺序、懒加载和两个按钮的相对顺序。
6. `README_MULTI_POSE_M3_M4_EXPERIMENT_ZH.md`：更新 GUI 操作入口和验证说明。

## 复核结果（2026-10-23，本环境）

- Linux CMake + Ninja，`DIGITAL_TWIN_CLI_ONLY=ON`、`TWIN_ENABLE_OCCT=OFF`：portable core 和现有 CLI 测试二进制**构建成功**。
- 可快速完成的离线 CTest：**23/23 通过**，涵盖多姿态几何/光学/H1-H3 NC、M3/M4、GCode 预览等。
- 原 `V28_M6_CONTINUOUS_5AXIS_OFFLINE` 是另一个计算量大的完整五轴覆盖仿真：在 25 秒单独探测期限内**尚未完成**，此前全套运行也在等待该项时超时；本次不将它计入通过项，不宣称失败。
- `tests/gui/test_multi_pose_startup_contract.py` 源码级回归守卫 **PASS**。
- **未执行真实 Windows Qt/VTK GUI 启动测试**：当前运行环境没有 Qt6/VTK Windows GUI 和 ECI/LLT 设备环境。因此，必须在用户本机运行 `--smoke-ui` 后才能确认启动不再闪退。

## Windows 验证方法

使用完整修订源码重新生成/编译 **Windows x64** 程序，注意运行的是重新编译生成的 `MotionLaserSync.exe`，不是旧目录中的文件。PowerShell 示例：

```powershell
powershell -ExecutionPolicy Bypass -File tools/RunGuiSmokeTest.ps1 -ExePath 'D:\your_build\Release\MotionLaserSync.exe'
Get-Content "$env:TEMP\MotionLaserSync_gui_smoke.txt"
```

正常日志的末尾应是 `PASS: GUI smoke test complete (no hardware operations)`。然后手工正常启动，进入 **路径规划**，检查按钮顺序；点击“多姿态实验扫描”并确认窗口内容、关闭/再次打开以及原 M0–M8 界面均正常。

如果日志只写到 `BEGIN: construct MainWindow`，说明程序在主窗口创建期间仍有其他启动问题，建议提供 Windows 事件查看器异常模块、VS 调试堆栈及此日志；不能仅凭当前离线编译直接断言整个程序在现场已完全修复。

## 保留的安全边界

未改动 GCode Executor 的硬件安全门、H1/H3 同步拓扑或控制器执行接口。生成的实验扫描 NC 仍带有 `OfflineOnly: true`，不能直接在机床执行。原 M0–M8 数字孪生入口与现有算法继续保留；配准尚未独立验收、五轴非采集转场和真实碰撞/硬件触发需现场验证。
