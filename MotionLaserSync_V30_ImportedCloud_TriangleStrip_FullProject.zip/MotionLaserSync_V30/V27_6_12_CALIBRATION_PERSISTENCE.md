# V27.6.12 — 已验证标定自动持久化与恢复

本版本修复“已经完成机床误差 + 手眼标定，重新启动后仍被当成未标定”的状态管理问题。

## 目标状态机

- **从未完成标定**：`scanCalibration()` 始终不可用；必须完成阶段1、阶段2最终求解和独立 hold-out 验证。
- **本次新标定验证通过**：把最终 Physical17（11项机床几何误差 + 6DoF手眼）、球心、独立验证摘要和保存时的坐标约定原子保存为“默认有效标定”。
- **再次启动**：自动读取默认有效标定。控制器和 2950 可用后，自动核对 `FlipX/FlipZ` 与 XYZCB 的 `DPOS/MPOS` 来源；完全一致才把结果绑定为本次可用标定。
- **坐标约定不一致**：拒绝自动使用，保持 `scanCalibration()` 不可用；不会静默套用旧参数。
- **主动开始一轮新标定**：旧的默认有效标定立即失效，防止机械/传感器安装已经改变时重启又恢复旧参数。

## 持久化文件

使用 Qt `QStandardPaths::AppDataLocation`：

`calibration/active_single_sphere17.json`

使用 `QSaveFile` 原子提交。文件包含：

- `physical17_result`：最终 17 参数及求解质量；
- `coordinate_convention`：`flip_x`、`flip_z`、五轴 `feedback_mask`；
- `validation`：独立验证结果、训练 RMS、验证阈值和姿态数要求；
- `stage1_summary`：阶段1结果摘要，主要用于来源/界面信息。

读取时不会仅相信 JSON 中可编辑的 `expected_rank`；Physical17 固定要求至少 `rank 14/17`，完整状态至少 `17/20`。

## V27.6.11 已有结果迁移

旧版已经保存的结果可以一次迁移，不必重新做一遍 hold-out：

1. 先加载对应的阶段1 `stage1_handeye_sphere_result.json`；
2. 再加载阶段2 `single_sphere17_rank14_result.json`；
3. 程序自动查找同目录、同前缀的 `*_validation.json`；
4. 只有验证报告仍满足其保存阈值，并且 `training_surface_rms_mm` 与阶段2结果一致时，才恢复“验证通过”状态；
5. 连接设备并执行“绑定已加载结果到当前实机坐标约定”；通过 Flip/DPOS-MPOS/阶段1平移规范核对后，自动写成 V27.6.12 默认有效标定。以后启动自动恢复。

## 运行时闸门

最终向扫描/RTCP提供参数前，`scanCalibration()` 同时要求：

- 已有成功的 Physical17 结果；
- 独立验证通过；
- 已绑定当前设备坐标约定；
- 当前实时 Flip/DPOS-MPOS 复核仍一致。

因此“文件存在”本身不会解锁运行时使用。

## 验证

新增：`tools/verify_v27612_calibration_persistence.py`。

该源码契约覆盖启动恢复、原子保存、坐标约定核对、未标定闸门、旧版验证迁移、固定 rank 要求等 16 项检查。
