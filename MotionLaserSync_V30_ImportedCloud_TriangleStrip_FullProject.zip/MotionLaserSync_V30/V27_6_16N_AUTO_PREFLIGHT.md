# MotionLaserSync V27.6.16N / ECI3808 V32.9

本版建立在 V27.6.16M + V32.9 上。Profile ingress、GapForensics、TABLE-B/C UI、Physical17-DPOSXYZ、ColdPrime、128-slot REGIST wrap、PWM0 stop-tail 等逻辑保持不变。本版只调整硬件同步只读预检的使用流程。

## 1. 硬件同步只读预检改为自动执行

旧流程要求用户在每次启动并连接控制器后，手动点击“硬件同步只读预检”。V27.6.16N 删除该按钮。

控制器连接后，上位机会先完成既有的五轴参数读取和 B/C RS485 绝对机械坐标建立。只有在 B/C software mechanical frame 成功建立之后，才自动调用 `ZmcController::hwTableCommissioningPreflight()`。这是预检能够同时绑定“当前控制器会话 + 当前 B/C 软件机械坐标框架”的最早安全时点。

自动预检仍是只读操作：只读取 ECI3808 TABLE 协议头并验证 V32.9 SINGLE-OP14 / FULL-MPOS-LATCH / ColdPrime / TABLE[342] 授权，不写 TABLE、不产生 OP14 触发、不运动轴。

## 2. 成功静默，失败才弹窗

自动预检成功时：

- 不弹出 QMessageBox；
- 日志记录完整 V32.9 协议摘要；
- 状态栏短暂显示“硬件同步自动只读预检通过，硬件模式已解锁”；
- `m_hardwareSyncPreflightPassed=true`，传感器可用且系统空闲时硬件同步单选框自动可选。

自动预检失败时：

- fail-closed，继续保持软件同步选择；
- 硬件同步模式保持不可选；
- 日志记录失败原因；
- 弹出一次“硬件同步自动预检未通过”对话框。

如果现场在预检失败后重新下载/运行 BASIC，重新连接控制器或执行一次 B/C 绝对坐标重同步即可触发新的自动预检，不再提供单独的手动预检按钮。

## 3. 启动采集前仍保留二次只读复核

UI 自动预检不是唯一安全门。真正点击“开始采集”且选择 Hardware 时，原有的启动前 `hwTableCommissioningPreflight()` 仍保留，用来防止：

- BASIC 在 UI 预检后被更换；
- TABLE 会话状态变化；
- TABLE[342] 授权撤销；
- B/C software frame 被重新建立后复用旧授权。

因此流程为：

`控制器连接 → B/C绝对机械坐标建立 → 自动只读预检（成功静默/失败弹窗） → 用户选择Hardware → 开始采集前再次只读复核 → ColdPrime → Probe → 200Hz PWM0正式采集`。

## 4. Physical17 坐标约定不变

本版不修改机床标定数据源：

- 普通上位机 / Physical17 标定 / RTCP：XYZ = DPOS，C/B = software mechanical MPOS；
- Hardware TABLE：XYZ/C/B = REGIST(104) hardware-latched raw MPOS；
- C/B hardware session：machine = rawMPOS + frozen software-frame offset。

因此删除手动预检按钮不会改变或重新定义现有 Physical17 标定模型。

## 5. 控制器

继续使用 `ECI3808_V32_9_SINGLE_OP14_PWM_FULL_MPOS_StopFix_RAMCompact.bas`，TABLE ABI 不变。
