# ECI3808 V32.12 ACTIVE

正式使用 `controller/ECI3808_5Axis_Controller.bas`，内容与 `controller/ECI3808_V32_12_PWM_HANDSHAKE_FIVE_AXIS_HOME.bas` 相同。不要使用历史 V32.9/V32.10/V32.11。

升级 V32.11 的部分：

- TABLE 354 magic 由 321053 改为 321054；上位机必须升级 V27.6.54。
- TABLE 355 写频率，TABLE 359 最后提交 request sequence；BASIC 空闲、Stop tail 完成后应用，TABLE 356 反馈 Hz，TABLE 360 反馈 ACK seq。
- TABLE 358 表示真实控制器运行/停止状态，TABLE 361 是配置错误。
- 运行中私自更改 355/359 将使当前采集停止，标记 TABLE333=11 fault；非法空闲配置不会重复 RAPIDSTOP。
- TABLE 357 保留完整 XYZCB Home mask 31；B/C 绝对编码器必须按原上位机流程独立确认 ready。
- stopdelay 从控制器内部 `gf` 计算，不能靠外部 TABLE356 改变。

请阅读 `README_V27_6_54_PWM_HANDSHAKE_SAFETY_ZH.md` 了解状态机和验证清单。
