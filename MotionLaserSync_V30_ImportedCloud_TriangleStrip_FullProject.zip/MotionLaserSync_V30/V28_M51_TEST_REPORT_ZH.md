# V28.5 M5.1 构建/回归测试说明

- 基线：`MotionLaserSync_V28_PROJECT_M5_COMPLETE.zip`（V28.4/M5）。
- 代码注册：M5.1 核心 `TwinM51Chamfer.cpp` 进入 `digital_twin_core`；Qt M5.1 桥接 `TwinM51Adapter.cpp` 进入 `MotionLaserSync.exe`，避免出现之前 M4 类似的 LNK2019。
- CMake CLI-only（Release）：共 14 项测试通过，包含 M0～M5 原有 12 项与新增 M5.1 两项。
- Debug + AddressSanitizer + UndefinedBehaviorSanitizer：14 项通过（LeakSanitizer 在隔离环境下关闭；ASan/UBSan 开启）。
- M5.1 专项：已测试中心孔上/下倒角与直孔壁的独立区域，360° 扇区（72×5°）、4/20/4 层单元，合成稀疏扇区，面积和拒绝无中心孔假几何，关联距离严格度单调性。
- M5.1 H1 实测子集：使用工程中经 CRC/归档提取的真实 `h1_real_100_profiles.bin` 及曝光位姿，完成 M2/M3 回波关联测试。
- 额外的完整 H1 中心 ROI（104,568 点）离线诊断：0.30mm 阈值下上倒角有效关联约 5,773 点；210°～300° 存在方向性低密度；近似工件配准带有明显残差，不应自动改 STEP。

**尚未在 Windows10 + VS2022 + Qt6/VTK + OCCT 完整 GUI 构建中实际运行。**
请在 VS2022 重新配置 CMake 并编译 `MotionLaserSync.exe`，确认配置输出：
`V28.5 M5.1 H1 center chamfer: core + GUI bridge registered [OK]`。

如果出现 MSVC 编译/链接问题，优先提供 **输出 → 生成** 的第一条错误（不是后续连锁错误）。
