# 多姿态 M3/M4 实验矩阵更新：B/C 各 ±10°、步长 4°，加 0/0 参考姿态

**版本：2026-10-23，继承 V29「真实 H3 轴限复现与无进退刀」完整源码。仅用于离线研究。**

## 1. 标准姿态矩阵

B 轴角度：`-10, -6, -2, +2, +6, +10` 度。

C 轴角度：`-10, -6, -2, +2, +6, +10` 度。

每个 B 都搭配 6 个 C，产生 `6×6=36` 组。由于从 `-10` 开始按 `+4` 递增不包含零度，按用户要求**另外新增** `B=0,C=0` 参考姿态，合计 37 组。

- `P01–P36`：B 为外循环、C 为内循环，顺序固定；`P01=(-10,-10)`，`P36=(+10,+10)`（元组为 B,C）。
- `P37`：`B=0,C=0`，是独立的实验组，不替换任何网格点。
- GUI 原「恢复标准 B/C 45组」现在为「恢复 B/C 37组」，窗口初次打开即加载此矩阵。手工编辑矩阵不会在加载历史 SCAN 时被强制覆盖。
- 旧 45 姿态文档、测试记录是历史档案，不再是新建实验的默认设置。

## 2. 规划与控制语义未改变

- 扫描仍按机床 `X+→X−`；扫描前后各有 **5 mm 激光采集覆盖延伸**，不附加独立的 Z 进退刀。
- 扫描段 `M50` 开、扫描结束 `M51` 关；下一条带转场保持激光关闭。独立姿态之间**没有**自动假定已经验证的转场路径。
- 保留 Physical17、FCL 检查入口、G05/G93 逐段 NC 仿真、SCAN/PLY 导出链路及 H1/H3 同步合同。
- NC 始终 `OfflineOnly: true`，未经真实零件配准精度、完整碰撞及控制器时序验收不得实机执行。

## 3. 新 `.scan` 的可重复基础轴限诊断

使用 `6061_Alumina_Scan_H2_New_01.scan` 首帧解出的 Physical17、sensorToMachine、历史 XYZCB **数值快照**，参考 OBJ 网格（与 STEP 的几何测试网格），及先前拟合的粗位姿 `X=-9.769,Y=7.347,Z=-217.681,Rz=-90°`。

复现配方：扫描速度 10 mm/s、频率 200 Hz、名义传感器参考深度 95 mm、前后各延伸 5 mm、ROI 为参考网格完整 XY 包围盒顶面。软件安全规划区间（X/Y/Z）为 `[-147,114] / [-116,134] / [-32,53]` mm。**这些是离线配置值，不代表已确认的现场轴限。**

通过 `twin_newscan_bc37_axis_bounds` 得到：

| 检查项 | 结果 |
|---|---:|
| 姿态组合 | 37（P01–P37，含独立零位） |
| 仅 Physical17 运动学与软件关节限位通过 | **37/37** |
| 累计名义 Profile 计划数 | **81,509** |
| 当前预算 | 160,000 |
| 全轨迹 X 需求范围 | **[-141.3888, 43.7754] mm** |
| 全轨迹 Y 需求范围 | **[-14.8302, 7.6778] mm** |
| 全轨迹 Z 需求范围 | **[-18.1445, -7.7929] mm** |

本结果 **不包括** 完整 FCL 碰撞、旋转轴动态限制、逐姿态完整光学有效覆盖、实际机床起始位置/进场，亦未把粗配准升级成已验证配准。尤其最小 X 到安全下限只剩约 5.61 mm 数值余量，不能简单作为实际安全保证。

`tools/diagnose_newscan_bc37_bounds.cpp` 会按 P01–P37 分别输出完整的 XYZ 轴范围、名义 profile 数，并再次调用整组规划器检验总预算。

## 4. 修改文件与回归

- `src/twin/MultiPoseExperiment.cpp`：更新默认 37 姿态生成器、预设相关提示。
- `include/twin/MultiPoseExperiment.h`：更新矩阵契约描述。
- `src/widgets/MultiPoseExperimentWidget.cpp`：更新矩阵恢复按钮、初始化及日志信息。
- `tests/twin/twin_multi_pose_experiment_tests.cpp`：校验 36 组笛卡尔积 + 独立 0/0、P01–P37 ID 唯一、NC 重解析和光学样例。
- `tools/diagnose_real_h3_bounds.cpp`：**保留旧 H3 45 组历史回归**，不再随默认矩阵改变而改变历史结论。
- `tools/diagnose_newscan_bc37_bounds.cpp` + `CMakeLists.txt`：新增当前新 SCAN 37 姿态基线检查。
- `tests/gui/test_multi_pose_bc37_ui_contract.py`：检查默认按钮和日志是否与矩阵契约一致（**只是源码静态检查，不是 Windows GUI 运行测试**）。

Linux CLI：

```bash
cmake -S . -B build_offline -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build_offline --target twin_multi_pose_experiment_tests twin_newscan_bc37_axis_bounds
ctest --test-dir build_offline -R 'MULTIPOSE_EXPERIMENT|MULTIPOSE_NEW_SCAN_BC37'
python tests/gui/test_multi_pose_bc37_ui_contract.py
```

完整 Windows Qt/VTK/OCCT 编译和实际设备未在本环境验证。
