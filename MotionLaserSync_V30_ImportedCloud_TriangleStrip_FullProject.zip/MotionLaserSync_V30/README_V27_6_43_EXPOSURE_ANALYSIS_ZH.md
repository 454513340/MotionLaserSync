# MotionLaserSync V27.6.43 — 曝光分析与材料曝光库

> 版本说明：本文记录 V27.6.43 当时的行为。V27.6.45 起用户材料曝光库已迁移到 `QStandardPaths::AppDataLocation/calibration/material_exposure_library.json`（Windows Roaming 路径），详见 `README_V27_6_45_MATERIAL_EXPOSURE_LOG_PATH_ZH.md`。


V27.6.43 在 V27.6.42B 基础上补齐了“传感标定 → 曝光自动测试”之后缺失的分析、保存、重载和正式扫描参数应用链路。原来的曝光扫频采集流程和正式 200 Hz 硬件同步采集/解码主路径不做结构性改写。

## 1. 新增功能

### 1.1 曝光测试完成后自动分析

当“曝光自动测试”启用了 Profile 保存并且所有异步保存任务已经真正落盘后，程序自动运行 `ExposureAnalysisEngine`。同一个 session 目录会新增：

- `exposure_analysis.csv`：逐曝光档汇总指标；
- `exposure_analysis.json`：推荐曝光、安全候选区间、首次饱和曝光、饱和平台、置信度和逐档指标。

分析模块不直接使用整条 1280 点 Profile 的全局最大值，而是先按无效点、PointIndex 间断和 Z 跳变拆分连续表面，再默认选择平均 X 最接近光学中心 X=0 的连续段作为目标 ROI。这样可避免 Natural_Sunny 数据中左右亮背景/夹具抢先饱和而把曝光判断带偏。

### 1.2 已有历史数据可直接分析/导入

“系统标定 → 传感标定 → 曝光自动测试”区域新增 **“分析/导入已有数据”** 按钮。可选择已有 `sensor_calibration_session.json` 目录，兼容当前 v4 和已上传 Natural_Sunny 数据使用的 v3 session。

### 1.3 材料曝光库持久化

分析成功后，若 session 清单包含材料、光照、传感器、测量场、分辨率、激光功率、反射选择、阈值、温度、Profile Rate 和机床 XYZBC 位姿信息，推荐结果会写入用户材料曝光库：

`QStandardPaths::AppConfigLocation/material_exposure_library.json`

写入使用 `QSaveFile` 原子提交。软件下次启动时自动加载。材料库的 canonical key 包含材料、光照、传感器、测量场、分辨率、激光功率、反射模式、阈值、温度、标定 Profile Rate 和经过适度舍入的 XYZBC 标定位姿，避免不同条件的标定结果被静默覆盖。

### 1.4 正式参数区按材料方案自动写入 Exposure / Idle

传感器参数区新增 **“材料曝光方案”** 下拉框。选择条目后：

- 软件/内部触发：恢复该标定条目的 `recommendedExposure + referenceIdle`；
- 5 ms 硬件同步：保留推荐 Exposure，但 **不会复制慢速标定 Idle**，而是根据硬件触发周期重新计算安全 Idle，并满足现有 `SyncManager` 的严格约束 `Exposure + Idle < 500`（单位均为 10 µs）。

在当前 5 ms 硬件触发周期中，推荐 Exposure=30 时得到 Idle=469，因此传感器内部周期为 4.99 ms；真正触发节拍仍由外部硬件 5 ms / 200 Hz 决定。

材料方案选择和库刷新在任何 Video/Profile/曝光标定任务运行时都会被禁用，避免采集中被程序化改写 Exposure/Idle。

## 2. Natural_Sunny / Alumina ceramic ball 1 的内置种子条目

使用用户提供的完整扫频数据验证：13 个曝光档（5~65，步长 5），每档 10 条 rich Profile，共 130 条 Profile。

V27.6.43 算法结果：

- 推荐 Exposure：**30 × 10 µs = 0.30 ms**；
- 安全候选：**25~30 × 10 µs**；
- 首次明显饱和：**35 × 10 µs**；
- 推断 Maximum 饱和平台：约 **875.5**，因此不把 UI 的 `maxIntensity=1023` 硬编码为饱和阈值；
- 30 档目标覆盖约为本 sweep 最大覆盖的 **96.5%**；
- 30 档信号约为本 sweep P90 最大信号的 **92.3%**；
- 30 档顶端平台比例约 **0.34%**，而 35 档跃升至约 **17.3%**。

该条目作为 `config/material_exposure_defaults.json` 的 bundled seed 随软件发布：

- 标定 Rate：25 Hz；
- 标定 Exposure：30；
- 标定 Idle：3970；
- 5 ms 硬件同步应用值：Exposure=30，Idle=469。

## 3. 新增源码文件

- `include/calibration/ExposureAnalysisEngine.h`
- `src/calibration/ExposureAnalysisEngine.cpp`
- `include/calibration/ExposureTimingPolicy.h`
- `src/calibration/ExposureTimingPolicy.cpp`
- `include/calibration/MaterialExposureLibrary.h`
- `src/calibration/MaterialExposureLibrary.cpp`
- `tools/exposure_analysis_cli.cpp`
- `config/material_exposure_defaults.json`

同时修改 `MainWindow`、`main.cpp`、`CMakeLists.txt` 和运行补偿面板版本显示。

## 4. Portable CLI 验证

不依赖 Qt、VTK 或厂商 SDK 的曝光分析 CLI 可独立构建：

```bash
cmake -S . -B build-exposure -DEXPOSURE_ANALYSIS_CLI_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-exposure --config Release
```

运行：

```bash
exposure_analysis_cli <sensor-calibration-session-dir> [output-dir]
```

本 release 在提供的 Natural_Sunny 数据上实际编译并运行通过，结果见 `validation/v27_6_43_exposure_analysis/`。

## 5. 重要边界

当前 v1 ROI 策略假定待分析实验件的主要目标表面位于光学中心附近（连续目标段平均 X 最接近 0）。这正好适用于本次氧化铝陶瓷球数据，也能避开两侧亮背景；若未来工件目标明显偏离中心，应该增加显式/手动 ROI 后再把结果用于自动参数应用。

材料曝光条目保存的是“在记录条件下验证过的推荐值”，不代表只凭材料名称就可以忽略光照、距离、姿态、传感器配置等条件。下拉框中会显示主要条件，完整条件和标定位姿可在 tooltip/JSON 中查看。

## 6. 构建验证状态

本运行环境不是项目要求的 Windows x64 + 用户现有 Qt/VTK + ECI3808/scanCONTROL 厂商 SDK 环境，因此无法在这里完成整个 GUI 可执行文件的 Windows 链接验证。已经完成的是：

- portable `exposure_analysis_cli` C++17 编译；
- 对用户上传 Natural_Sunny 130 条 Profile 的真实数据回放；
- `ExposureTimingPolicy` 独立 C++ 编译/断言测试；
- 源码集成点和 session v3/v4 字段静态核对。

Windows 工程仍沿用原项目的现有 GUI 构建依赖和路径。
