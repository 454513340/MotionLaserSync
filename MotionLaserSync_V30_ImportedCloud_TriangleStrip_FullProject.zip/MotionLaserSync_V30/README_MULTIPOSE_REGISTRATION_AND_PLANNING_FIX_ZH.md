# V29 多姿态实验工作流：STEP/SCAN 配准初值与规划/光学错误诊断修订

## 修订目标
针对真实用户报告的三个缺口：
1. STEP 和 `.scan` 已导入却仍显示 XYZ/RxRyRz 全零，无法直接做有效五轴扫描规划；
2. “读取 M0–M8 场景 JSON”被误解为自动配准；
3. “规划 + 多姿态光学预览”失败仅在窗口底部显示，无法区分逆解、碰撞、ROI 和光学不命中。

此次代码更新 **只修改离线研究功能**，不修改 H1/H3 电气触发、不开放机床控制、不移除 `OfflineOnly` G 代码防护。

## 新的界面工作顺序
路径规划 → 多姿态实验扫描 →

1. 导入真实 STEP；
2. 导入对应的原生 SCAN v3（保留每帧 XYZCB、Physical17、原始点索引）；
3. 点击 **① 从 STEP + .scan 提议粗配准**；
4. 检查候选 XYZ/RxRyRz、匹配样本、1mm 粗邻近比例、朝向歧义；
5. 依据三维模型/实测点云的孔位、边界和夹具情况审查，点击 **② 复核后应用候选位姿**；
6. 规划同一 CAD ROI 的多姿态 XYZCB 轨迹，并执行 M3 光学可见性检查；
7. 仅当所有指定姿态的虚拟预览帧有至少 50% 命中 CAD 工件时，允许导出 **离线** H1/H3 NC 或模拟 SCAN；
8. 独立认证仍未完成，NC 文件保留 `OfflineOnly: true`，无法直接执行。

**仅人工初值时**：可手动输入 X/Y/Z/Rx/Ry/Rz 或按需使用旧 DigitalTwinScene JSON，再点“只对手工位姿做离线预览”。

## 新增配准算法的准确范围
`include/twin/MultiPoseRegistrationAssist.h`、`src/twin/MultiPoseRegistrationAssist.cpp`：
- 从真实机床 XYZ 预览点中提取高 Z 的近水平顶面候选；
- 从已导入的 STEP 网格中确定性采样 CAD 三角面，建立 3D KD-tree；
- 在 `Rz=0, ±90°, 180°` 四种水平朝向下搜索 XY/Z 位移，并作局部坐标搜索；
- 输出候选位姿、粗匹配统计和朝向歧义提示；
- 若无足够顶面样本或匹配支持，拒绝给出位姿。

**此方法仅是自动粗配准提议**。它不支持任意装夹倾斜时的完整 Rx/Ry/Rz 联合优化；近似表面邻近分数不是工业计量误差；单个 `.scan` 分出的点也不等于独立重复测量；零件对称结构可能导致 Rz 多解。缺少独立基准验证时 `registrationVerified` 仍为 `false`。

完整生产级配准仍需逐步增加：夹具/背景分割、几何特征匹配、6DoF ICP/稳健优化、多初值与解退化检查、独立重复扫描/基准计量验收。不得将本次粗位姿当作满足机床安全运动的空间标定。

## 规划与光学分阶段诊断
- **缺位姿审查**：拒绝开始规划，明确引导先做粗配准或人工复核；
- **ROI 越界**：指向 CAD 局部 ROI 参数，而不是暗示控制器有故障；
- **Physical17 FK/IK 失败**：指出固定 C/B 姿态的逆解/标定问题；
- **轴限位拒绝**：指出机床空间与焦距/工件位姿不一致，不能扩大限位强行通过；
- **FCL 拒绝**：不能禁用碰撞检查规避；
- **光学模型初始化失败**：标明五轴轨迹可能已规划，但 M3 几何光学尚未就绪；
- **光学可见帧 <50%**：保留离线轨迹查看，阻止 NC 和模拟 SCAN 导出。

重要：这仅检查可用数字孪生模型中的轨迹和视线，未认证真实夹具/传感器外壳和实机起始位置，不具有实机安全放行能力。

## 真实输入文件验证（诊断而非工件位姿证书）
输入：上传的 `传感器连接件.STEP`、`6061_Alumina_Scan_H3.scan`。从真实 SCAN 全量 CRC 验证后，按原项目工具 `tools/m0m5_prepare_scans.py` 在离线数据副本中抽取点云，使用项目中 `examples/digital_twin/6061_reference_mesh.obj` 作为该 STEP 已有的三角参考网格。

- 原始 SCAN：4615 profiles，4,766,566 有效样本。
- 辅助粗配准候选：CAD→MCS XYZ 约 `(44.44, 10.09, -225.07) mm`、Rz 约 `-90°`、Rx/Ry 采用近水平先验 0°。
- 粗邻近距离中位数约 `0.291 mm`（取样表面代理值，**不是配准精度**）；1mm 邻近比例 99.95%（**不是置信度**）；旋转朝向仍显示可能多解，必须检查孔槽朝向。
- 在上述候选附近重放已记录的 Physical17 及首帧五轴初位姿，离线五轴路径求解：3 个独立姿态全部产生轨迹，每个姿态单条扫描 1861 个名义 profiles。
- 不加载真实 FCL 碰撞模型的 M3 几何仿真：姿态 P01/P02/P03 分别 24/24、24/24、24/24 帧命中 CAD。这里没有验证 Windows GUI、FCL 或实机行为。

原来的默认 CAD 位姿 0、0、0 与真实测量的机床 Z 区域相差 200 多 mm，因而在规划前必须先对齐。不要将该候选硬编码成软件默认值。

## 代码范围
新增：
- `include/twin/MultiPoseRegistrationAssist.h`
- `src/twin/MultiPoseRegistrationAssist.cpp`
- `tests/twin/twin_multi_pose_registration_tests.cpp`

修改：
- `CMakeLists.txt`
- `include/widgets/MultiPoseExperimentWidget.h`
- `src/widgets/MultiPoseExperimentWidget.cpp`
- `include/twin/MultiPoseExperimentQtAdapter.h`
- `src/twin/MultiPoseExperimentQtAdapter.cpp`

## 构建与测试范围
Linux CLI-only C++17 编译通过。24 项可运行的离线回归测试通过；较大的原 M6 连续运动仿真测试未包括在这一快速测试结果内。

由于当前环境缺少 Windows + Qt + OpenCASCADE + 控制器 SDK，尚不能确认 GUI 完整编译或在现场 FCL 模型下的规划是否成功。请优先使用原工程自带的 GUI Smoke 测试，并观察弹窗中具体的“逆解/限位/FCL/光学”阶段信息。

## 禁止事项
- 不得删掉 `OfflineOnly` 或 `registrationVerified=false` 就下发运动；
- 不得将旧 M0 JSON 的 `poseEstimate` 称作新文件已经配准；
- 不得将本次 1mm 粗邻近分数宣传为亚毫米计量精度；
- 不得将历史 `.scan` 的 XYZCB 当作机床**当前**位置；
- 不得将模拟 SCAN 作为真实 M3/M4 测试数据；
- 不得为了通过路径生成而绕过原有碰撞、轴限位和 H1/H3 硬件检查。
