# MotionLaserSync V27.6.46 — 分阶段硬件同步时域标定工作流

## 1. 版本目的

V27.6.46 在 V27.6.45 基础上重构“系统标定 → 硬件同步标定”，将原先偏手工的“采入当前扫描 → 分轴求 τ”改为完整、可执行、可验证的分阶段工作流：

1. 导入标准球机床坐标系点云；
2. RANSAC 球拟合并用已知半径精化球心；
3. 读取当前 XYZCB 作为实际扫描路径中心；
4. 在参数表中配置用途、XYZ 方向权重、扫描速度、移动距离和重复次数；
5. 自动生成严格成对的正向/反向空间直线路径；
6. 软件自动定位到起点，并用现有 V32.9 SINGLE-OP14 硬件同步链路逐条采集；
7. 所有标定路径完成后，用实际 REGIST(104) MPOS 速度和动态球心求一个全局 τ；
8. 使用独立 Hold-out 路径进行 RAW 与候选 τ 离线补偿对比；
9. 只有“求解质量 PASS + Hold-out 验证 PASS”后，才允许启用运行时补偿；
10. 结果可保存/加载，活动文件仍位于 AppData/Roaming/.../calibration。

本版本**不修改控制器 BASIC**，也不改变已现场确认的触发拓扑。

## 2. 固定的硬件触发拓扑

当前正式链路保持：

```text
ECI3808 V32.9 SINGLE-OP14

OP14/PWM0 -----------------> scanCONTROL External Trigger
       |
       +--------------------> ECI IN0 -> REGIST(104)
                                         |
                                         +-> X MPOS
                                         +-> Y MPOS
                                         +-> Z MPOS
                                         +-> C MPOS
                                         +-> B MPOS
```

连续触发周期仍为 5 ms（200 Hz）。

本标定只识别：

```text
τ = t_sensor_effective - t_ECI_latch
```

其中 τ>0 表示传感器有效光学测量时刻晚于当前 REGIST(104) 锁存时刻。

## 3. 为什么改为“轨迹 Pair”而不是强制 X/Y/Z 单轴

线激光安装几何决定了并非每个机床轴单独运动都能完整扫过标准球。V27.6.46 不再要求 Y-only 或 Z-only 扫完整球。

每条配置定义一个任意 XYZ 空间方向：

```text
u = normalize([wx, wy, wz])
```

例如：

- X 主扫掠：`[1, 0, 0]`
- XY 斜线：`[1, 0.2, 0]`
- XZ 斜线：`[1, 0, 0.2]`
- XYZ 斜线：`[1, 0.2, 0.2]`

软件为每一组配置自动生成一个严格正反 Pair：

```text
+ : start -> end
- : end   -> start
```

B/C 在 V27.6.46 第一阶段保持固定。B/C 动态旋转属于后续五轴全点云精化范围，不混入本版解析 Pair 求解。

## 4. 标准球参考建立

先导入已经位于 Machine frame 的标准球点云（`.scan/.ply/.csv/.txt`）。

第一步用 RANSAC 找球：

```text
||p_i - c|| ~= R
```

第二步固定已知球半径 R，仅精化球心 c：

```text
min_c Σ ρ( ||p_i-c|| - R )²
```

这样避免把动态同步畸变错误吸收到自由球半径中。

参考球心用于：

- 确认动态扫描拟合到的是同一个球，而不是背景/球座；
- Hold-out 验证中的参考几何检查；
- 3D 视图显示。

扫描路径中心使用“当前 XYZCB”，而不是直接把 Machine-frame 球心当作关节 XYZ，因为传感器存在手眼偏置。

## 5. 参数表与路径生成

参数表字段：

- 启用；
- 用途：标定 / 验证；
- 名称；
- X/Y/Z 权重；
- 速度 mm/s；
- 距离 mm；
- 重复次数；
- 说明。

以当前 XYZCB 为路径中心 q0，空间方向 u，距离 L：

```text
start.xyz = q0.xyz - 0.5 * L * u
end.xyz   = q0.xyz + 0.5 * L * u
start.cb  = end.cb = q0.cb
```

每个 repeat 都生成独立 pairId。

## 6. 自动路径采集如何复用当前 V32.9 硬件同步

每条路径由 MainWindow 按下列顺序执行：

1. 检查控制器、scanCONTROL、MachineSafety、XYZ 回零状态和 B/C 绝对位置状态；
2. 用五轴关节规划安全移动到扫描起点；
3. 预装一条精确 XYZ 空间直线，但此时不允许运动；
4. 执行 V32.9 `hwTableCommissioningPreflight`；
5. `SyncMode::Hardware`，Trigger 固定为 `EdgeRising`；
6. 启动原有 SyncManager / V32.9 硬件采集；
7. 等待 Probe 和硬件同步建立；
8. Probe 建立以后才允许 merge path 开始运动；
9. 运动过程中由现有 SINGLE-OP14 同时触发 scanCONTROL 与 IN0/REGIST(104)；
10. 运动完成后 `SyncManager::stop()`，执行原有尾部 Drain / 数量闭环；
11. 检查 Pose/Profile/Aligned/Pending/Dropped/AlignmentFault；
12. 数据通过才采入本条观测；否则停止自动流程。

标定和验证采集期间必须禁用运行时 τ 补偿，确保保存的是 RAW REGIST(104) 位姿。

## 7. 实际速度不是命令速度

每条轨迹的实际速度从 REGIST(104) 锁存的 XYZ MPOS 求得。

连续触发间隔 T=5 ms，位置增量：

```text
v_k = (q_{k+1}.xyz - q_k.xyz) / T
```

软件剔除 Probe -> 第一条连续 PWM 的特殊间隔，然后对各分量做鲁棒统计，得到：

```text
v = [vx, vy, vz]
```

同时检查：

- 速度 MAD；
- 直线 cross-track 稳定性；
- B/C 是否基本静止；
- 实际方向与规划方向余弦；
- 实际速度与请求速度是否严重不符。

因此求解使用的是**真实硬件锁存运动**，不是命令 feed。

## 8. 全局 τ 的数学模型

对于同一条空间路径的正向和反向扫描：

```text
v+ , c+
v- , c-
```

其中 c 是利用动态扫描点云拟合的 Machine-frame 球心。

定义：

```text
Δv = v+ - v-
Δc = c+ - c-
```

固定时间延迟模型为：

```text
Δc = -τ Δv
```

单 Pair 的时延估计：

```text
τ_pair = -(Δv · Δc) / ||Δv||²
```

多 Pair 的公共最小二乘解析解：

```text
τ = - Σ(Δv_i · Δc_i) / Σ||Δv_i||²
```

因此 X-only 是一般三维模型的特殊情况；XY/XZ/XYZ 空间斜线无需改公式。

## 9. 求解质量门限

V27.6.46 检查：

- 完整正反 Pair 数；
- 不同实际速度等级数；
- 三维 Pair 模型 R²；
- τ 标准差；
- 每个 Pair 的三维模型残差；
- sensor resolution / exposure / idle / 5 ms trigger 配置一致性；
- 当前运行时补偿仅接受 `0 <= τ < triggerPeriod`。

所有标定规划路径必须完成并采入通过后，“求解 τ”才可用。

## 10. Hold-out 独立验证

求解完成后可以修改参数表、重新生成新的验证路径，例如：

```text
XY 斜线
XZ 斜线
XYZ 斜线
不同速度
不同距离
```

这些路径不能参与之前 τ 的求解。

验证采集仍然保持 RAW 硬件同步。对于同一份验证数据，软件同时计算：

```text
RAW reconstruction
candidate-τ offline corrected reconstruction
```

候选 τ 的离线位姿：

```text
α = τ / T
q_corr(k) = q_k + α (q_{k+1} - q_k)
```

再通过现有 Physical17 重建球面点。

验证计算：

- RAW 等效时延；
- 校正后残余时延；
- 时延改善百分比；
- 正反 Pair 三维残差 RMS；
- 每条扫描 raw/corrected 球面 RMS。

只有 Hold-out 门限 PASS 后才允许点击“验证通过后启用补偿”。

## 11. 正式运行时补偿

正式采集时不修改 BASIC，也不改变 Profile/REGIST ordinal 配对。

对于第 k 条 Profile：

```text
Profile_k <-> Raw REGIST Pose_k
```

若 τ>0：

```text
q_corr(k) = q_k + (τ/T)*(q_{k+1}-q_k)
```

然后：

```text
q_corr -> Physical17 -> Machine-frame point
```

原始 latch pose 保留，补偿帧标记为 `PoseTiming::HardwareTemporalInterpolated`。

当前运行时实现仍只支持正时延 look-ahead：

```text
0 <= τ < 5 ms
```

如果实机标定得到负 τ，本版会拒绝启用，而不会错误地强行补偿。负 τ 需要后续增加 `q_{k-1}, q_k` 回看插值。

## 12. 保存与加载

活动文件：

```text
C:/Users/<user>/AppData/Roaming/YourCompany/MotionLaserSync/calibration/active_hardware_temporal.json
```

V27.6.46 schemaVersion=2，保存：

- 拓扑与 delay 定义；
- 参考球；
- 路径中心；
- 参数配置表；
- 标定观测；
- Hold-out 验证观测；
- sensor timing；
- τ / std / quality / validation 状态；
- runtimeEnabled。

旧 schemaVersion=1 不会自动转换成新轨迹模型，必须重新执行 V27.6.46 标定。

## 13. 推荐第一次上机顺序

1. 导入高质量静态标准球点云并拟合球心；
2. 手动把机床停在 X 能完整扫过球的中间位置，读取当前 XYZCB；
3. 保留推荐的 X 低/中/工作速度三组标定；
4. 先运行 X 三速度全部正反 Pair；
5. 求解 τ，检查符号、量级、R²、std 和 Pair 残差；
6. 再用 XY/XZ/XYZ 斜线作为 Hold-out；
7. 验证 PASS 后启用补偿；
8. 再做独立生产工况验证。

## 14. 验证说明

当前交付环境为 Linux，无法完成依赖 Windows x64 + Qt6 + VTK + ZMotion SDK + scanCONTROL SDK 的完整 GUI Release 链接。

已完成：

- 新轨迹 τ 数值单元测试；
- REGIST 实际速度向量估计测试；
- Hold-out 校正改善测试；
- P0 控制器/同步 mock 回归；
- HardwareSyncReport 回归；
- Runtime/Archive 回归；
- V27.6.44 temporal runtime/archive compatibility contract；
- V27.6.45 material-exposure path compatibility contract；
- V27.6.46 staged temporal workflow source contract；
- 两份 ECI3808 V32.9 BASIC SHA-256 不变。

正式上机前仍必须在目标 Windows 开发环境完整编译 Release，并在低速、短距离条件下先验证自动路径安全性与 τ 正负号。
