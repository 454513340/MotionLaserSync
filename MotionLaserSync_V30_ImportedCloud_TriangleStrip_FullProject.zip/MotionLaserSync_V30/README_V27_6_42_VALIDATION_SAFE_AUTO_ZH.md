# MotionLaserSync V27.6.42 — 独立验证安全工作域 + 自动独立轴移动/采集

## 1. 修改目的

V27.6.41 在 47 组 Stage-2 训练姿态上通过渐进式 trimmed screening 自动排除了 13 组高残差姿态，训练 RMS 从约 0.0703 mm 降到约 0.0361 mm。随后旧 hold-out 数据中又出现了与这些高残差 B/C 区域接近的姿态，例如 `B≈+25°, C≈+37.5°`、`B≈-25°, C≈+37.5°`、`B≈+25°, C≈-37.5°`。如果这些区域已经被 Stage-2 训练明确判定为高残差工作区，再把同一邻域自动生成成“标定可用性验证姿态”，就会把已知危险区重新混入验收范围。

V27.6.42 因此做两项修改：

1. **生成独立验证姿态时，默认避开 Stage-2 已剔除姿态的 B/C 危险邻域。**
2. **Stage-3 独立验证增加“自动移动 + 自动采集”流程，运动路径与 Stage-2 自动采样使用同一个独立轴绝对定位入口，不使用五轴插补。**

> 重要：避开危险区域后通过的 hold-out 验证，只证明“保留安全 B/C 工作域”有效；不能据此宣称被排除区域也有效。若设备最终必须覆盖这些被排除 B/C 区域，应优先解决 B/C 实际机械角反馈/补偿或扩展运动学模型，而不是仅靠验证筛选绕开。

## 2. 数据驱动的危险区域，而不是写死角度

V27.6.42 不把 `B=+20°/C=40°` 等角度硬编码到程序里，而是直接读取最终 Stage-2 Physical17 结果中的：

```cpp
m_lastResult.rejectedTrainingPoses
```

每一个被 Stage-2 渐进筛选排除的完整 XYZBC 姿态都会保留其：

- B/C 角度；
- pose RMS；
- P95；
- max；
- rejection score。

生成 hold-out 候选时，对候选姿态 `(Bv,Cv)` 与每个已剔除姿态 `(Br,Cr)` 计算：

```text
dB = Bv - Br
dC = wrapTo180(Cv - Cr)
dBC = sqrt(dB^2 + dC^2)
```

默认要求：

```text
dBC >= 10 deg
```

GUI 中可以修改“危险 B/C 排除半径”，默认 10°，范围 2°~30°。

这意味着危险区会随着当前机器本次 Stage-2 的真实筛选结果改变，不依赖固定机型经验值。

## 3. 与训练网格的独立性仍然保留

危险区排除不是替代原来的 hold-out 独立性约束。每个新验证姿态还必须继续满足：

```text
与全部训练姿态的 B/C 距离 >= validation minimum separation
```

默认仍为 4°。

因此一个验证姿态同时需要满足：

```text
A. 不落入 Stage-2 rejectedTrainingPoses 的危险 B/C 邻域
B. 不与 Stage-2 实际训练姿态过近
C. 通过 MachineSafety 目标姿态门禁
D. 通过独立轴实际速度轨迹的过渡路径门禁
E. 球在传感器可见范围内并通过静态球拟合质量门禁
```

## 4. 候选池扩大

由于危险区域会删掉一部分 D-optimal 候选，V27.6.42 将验证规划候选池从：

```cpp
max(24, wanted * 4)
```

扩大到：

```cpp
max(48, wanted * 8)
```

避免因为先过滤危险区域而无法找到足够的安全 hold-out 姿态。

## 5. Stage-3 自动移动 + 自动采集

Stage-3 新增两个按钮：

```text
自动移动 + 采集独立验证
停止自动验证采集
```

完整流程：

```text
生成安全 hold-out 计划
        ↓
启动自动验证采集
        ↓
再次检查坐标约定 / 控制器 / 回零 / B/C反馈 / 传感器
        ↓
再次检查该验证姿态是否落入 rejected B/C 危险区
        ↓
MachineSafety 目标 + 独立轴过渡路径检查
        ↓
X/Y/Z/C/B 各自 Single_MoveAbs
        ↓
全部轴 Idle
        ↓
等待新轮廓并进行 RANSAC 球弧预检查
        ↓
通过 → fresh-profile 正式采集
失败 → 整个验证姿态跳过，继续下一姿态
        ↓
保存到 hold-out 集，不进入 Physical17 训练求解器
```

## 6. 运动方式：与 Stage-2 完全同一路径

验证自动运动复用：

```cpp
requestIndependentJointMove(...)
    -> MainWindow
    -> ZmcController::moveJointAbs5DIndependent(...)
```

控制器端对每一个需要运动的轴分别设置自己的：

```text
SPEED
ACCEL
DECEL
LSPEED=0
SRAMP=0
MERGE=0
```

然后分别发送：

```cpp
ZAux_Direct_Single_MoveAbs(..., AxisX, ...)
ZAux_Direct_Single_MoveAbs(..., AxisY, ...)
ZAux_Direct_Single_MoveAbs(..., AxisZ, ...)
ZAux_Direct_Single_MoveAbs(..., AxisC, ...)
ZAux_Direct_Single_MoveAbs(..., AxisB, ...)
```

这是**五个独立单轴绝对定位命令**，没有 BASE 轴列表，没有 5-axis `MoveAbs` 插补，也不会按长轴距离比例把其他轴耦合成五轴联动轨迹。

多个活动轴可以在各自 Single_MoveAbs 下同时运动，但每个轴的速度/加速度/减速度独立。这正是 V27.6.22 之后 Stage-2 实机采样的运动语义。

## 7. 自动流程的失败策略

- MachineSafety 目标/路径拒绝：标记该姿态，继续下一姿态。
- 到位后无合格球拟合：整个位姿跳过，继续下一姿态。
- fresh-profile 质量门禁失败：整个位姿跳过，继续下一姿态。
- 坐标约定变化、控制器状态不安全、轮廓流停止、采集期间位姿漂移：自动流程停止，保留剩余姿态为待处理。
- 验证数据始终写入 `m_validationRecords`，不会加入 Stage-2 `m_records` / Physical17 求解器。

## 8. 验证 JSON 增加范围声明

独立验证 JSON 现在额外记录：

```json
{
  "avoid_rejected_training_bc_regions": true,
  "rejected_training_bc_exclusion_deg": 10.0,
  "rejected_training_pose_count": 13,
  "validation_scope": "retained_safe_bc_domain_excluding_stage2_rejected_neighborhoods"
}
```

这样以后看到“验证通过”时，可以知道它究竟验证了整个配置范围，还是明确排除了 Stage-2 已知危险区域。

## 9. 对旧 hold-out CSV 的影响

当“避开阶段2已剔除的高误差B/C区域”开启时，旧 hold-out CSV 中若含有距离 rejected B/C 姿态过近的验证点，会被认为**不属于当前安全工作域验收集**。

如果只是想离线分析旧数据，可以取消该选项再执行验证；此时验证范围会被记录为 `configured_bc_domain_with_training_grid_separation_only`，并且旧危险区造成的失败不会被隐藏。

## 10. 数值/源码验证

本版本在当前 Linux 环境完成：

- portable `single_sphere17_cli` CMake 编译：通过；
- `v20_2_single_sphere17_tests` 数值回归：通过；
- V27.6.42 源码契约检查：通过；
- 已知旧 hold-out 危险点与历史 rejected B/C 点的距离测试：通过，默认 10° 排除半径会排除这些邻域；
- 检查自动验证运动调用链确实复用 `requestIndependentJointMove -> moveJointAbs5DIndependent -> Single_MoveAbs`：通过。

当前环境没有 Windows Qt + ECI3808 + scanCONTROL 完整 SDK，因此 GUI/控制卡全工程仍需在目标 Windows 工程中重新编译，并进行空载低速、急停、限位和碰撞门禁实机确认。
