# V27.6.18 calibration review revision

基于用户最新可运行的 V27.6.17 RAR 修订。先阅读 docs/V27_6_18_CALIBRATION_REVIEW_ZH.md。

阶段二采用轮廓级精确残差信息累加和全量训练点精修，修正姿态选集、可见弧和独立验证目标设置。

已验证 Linux C++17 数值/规划/运行时测试26项通过；未在Windows VS2022 GUI和实机上验证。
保持原CMake依赖、SDK、控制器及资源不变。使用前备份当前工程与标定数据，x64-Release重新配置构建，先用实际CSV离线回归，再做冻结模型的独立验证和实机安全检查。

PATCH_FILES.zip 按相对路径覆盖到本次RAR对应的工程根目录；完整源码包可直接解压到新目录。历史MANIFEST属于原历史版本，本修订清单位于verification/v27618/revision_manifest.json。
