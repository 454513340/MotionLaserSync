# V27.6.37 阶段2门禁 / 回零使能可见性 / 轮廓视图修复

本版基于 V27.6.36，而不是回退到 V27.6.35。因此 V27.6.36 已完成的 XYZ 补偿速度与独立五轴 MachineSafety 时序一致性修复、补偿安全包络检查均保留。

## 复核结论

### 1. “生成姿态后回零/使能按钮没有了”

V27.6.34 与 V27.6.35 的 `src/widgets/SingleSphere14CalibrationWidget.cpp` SHA-256 完全相同（`8dd4cd14f5f40451d3c281582152dd37dcfae6d5d9dadeba333747b7593e2a99`），说明 XYZ 运行补偿补丁没有从阶段2 widget 中删除这些按钮。原工程的 XYZ/五轴回零、`重读 B/C 绝对位置`、B/C `人工使能` 一直由外层“控制”页统一持有。

`onGeneratePlan()` 本身也不会撤销 XYZ DATUM、B/C absolute-ready 或 B/C servo-enable。加载补偿表只会把运行补偿保持 OFF，启用补偿反而要求 XYZ 已正规 DATUM。真正会撤销引用/使能的典型事件包括：写入 XYZ 轴配置会撤销对应 XYZ reference 并关闭补偿；写入 B/C 轴配置、重建旋转坐标或控制器重连会按原安全设计撤销 B/C ready/servo，之后必须重新同步/使能。

V27.6.37 在阶段2计划区新增“真实运动准备（执行前门禁）”状态行，直接显示：XYZ DATUM、C absolute、C servo、B absolute、B servo、XYZ compensation。并新增按钮：

`打开控制页：XYZ/五轴回零、重读B/C、人工使能`

按钮只导航到原有权威控制页，不复制第二套回零/使能实现，避免两套安全状态机分叉。

### 2. 自动移动后整张表出现“已跳过：执行前门禁失败”

这是 V27.6.35/V27.6.36 阶段2自动执行逻辑中的真实缺陷。

原逻辑中 `startDirectMoveToPlanIndex()` 返回 `false` 可能代表两类完全不同的问题：

- 全局机器未就绪：控制器/坐标约定/五轴 idle 等；
- 单个姿态的 MachineSafety 目标或过渡路径门禁失败。

但 `continueAutomaticStage2Acquisition()` 不区分失败类型，会无条件把当前行覆盖为 `已跳过：执行前门禁失败`，然后继续下一行。因此一次全局状态问题可能把 48 个姿态逐个全部跳过；同时目标/路径门禁原本写入的详细原因也会被通用文字覆盖。截图中大量连续行出现同一通用状态与该缺陷完全一致。

V27.6.37 将执行前失败分为：

- `GlobalReadiness`：XYZ DATUM、B/C absolute、B/C servo、控制器、坐标约定、all-idle 等；
- `TargetSafety`：单个目标姿态碰撞/间隙门禁；
- `TransitionSafety`：当前到目标的整段扫掠路径门禁；
- `UserCancelled`。

处理规则改为：

- **GlobalReadiness**：自动流程立即暂停一次，当前及剩余姿态保持待处理，不再批量标记“已跳过”；恢复条件后可直接重新启动。
- **TargetSafety / TransitionSafety**：只跳过该姿态，并保留具体 MachineSafety 原因，然后继续下一姿态。

另外在 MainWindow 真正下发 Stage-1/Stage-2 五轴运动前也新增显式 `XYZ areLinearMposReferenced()` 门禁，避免只检查 B/C 而把 XYZ reference 问题延后到更深层才暴露。

### 3. 自动移动/采集时被迫切换二维轮廓

原 `onFitCurrentProfile()` 每次拟合成功都无条件 `emit requestProfileView()`。自动阶段2到位后每个姿态都调用拟合，因此自动流程会持续抢占主视图并切到“二维轮廓”。此外进入“运动学标定”页时，外层 `CalibrationWidget` 也会再次强制请求二维轮廓。

V27.6.37 改为：

- 自动阶段2中的拟合只更新 profile 数据和 overlay，不切换主视图；
- 进入“运动学标定”页不再自动切二维轮廓；
- 手工点击拟合、显式启动轮廓预览时仍保留原来的二维轮廓导航；
- 自动采集只要求轮廓流正在运行，**不要求二维轮廓 Tab 当前处于选中状态**。

MainWindow 的约 30 Hz latest-profile UI 更新原本就会持续向 `m_profile2DView` 写入数据，与该 Tab 是否当前显示无关，因此后台质量门禁不需要依赖视图选择。

## 测试

当前 Linux 环境完成：

- 控制器/Mock 传输回归：82/82；
- XYZ 补偿数值与真实表回归：25/25；
- V27.6.36 补偿/MachineSafety source contract：PASS；
- V27.6.37 Stage2 gate/profile source contract：16/16；
- 定向 CTest：4/4 PASS。

完整 Windows Qt6/VTK/FCL GUI 无法在当前 Linux 环境实际编译，真实机床也没有在这里执行运动，因此 V27.6.37 仍需在你的 Windows 构建环境编译并做设备侧低速验证。

## 建议实机验证顺序

1. 连接控制器，确认阶段2“真实运动准备”显示当前每个门禁状态。
2. 在“控制”页完成 XYZ/五轴正规回零；重读 B/C 绝对位置；人工使能 B/C。
3. 回到阶段2，状态应显示 XYZ DATUM=OK、B/C absolute=OK、servo=ON。
4. 生成 D-optimal 计划；确认生成动作本身不会改变这些状态。
5. 保持轮廓流运行，但把左侧主视图切到“三维点云”；启动自动移动采集，确认程序不会强制跳回二维轮廓。
6. 人为断开一个 B/C 使能后尝试启动自动采集：应只提示一次“真实运动未就绪”，计划行不应被批量标成跳过。
7. 恢复使能后重新启动，计划应可继续。
