# MotionLaserSync V27.6.16M / ECI3808 V32.9

本版建立在 V27.6.16L + V32.9 上。控制器 BASIC 协议与 V32.9 保持不变；上位机重点处理 scanCONTROL Profile 主机接收链、缺帧取证、硬件同步期间 B/C 控制界面刷新，并继续保护已验证的 Physical17 坐标约定。

## 1. Profile 接收链重构

旧路径在 LLT SDK callback 内直接执行 `ConvertProfile2Values()`、创建 X/Z 容器并随后向多个 Qt consumer 投递 200 Hz Profile。GUI 或整个进程出现调度抖动时，这会放大 callback 服务时间和事件队列压力。

V27.6.16M 改为两级 ingress：

1. LLT callback 只记录 callback-entry PC 时间、callback ordinal，并把 raw profile bytes `memcpy` 到启动前预分配的 128-slot SPSC ring；正常路径不调用 `ConvertProfile2Values()`，不进行 GUI 更新。
2. 独立 `ProfileDecodeThread` 以 `QThread::HighestPriority` 消费 raw ring，完成 SDK 转换、sensor timestamp/index 解码和 `LaserProfile` 构造。
3. raw ring 满、callback bytes 超过预分配 slot 或正式 session SDK 转换失败均 fail-closed；禁止静默覆盖。
4. ECI TABLE 读取线程由 `TimeCriticalPriority` 下调为 `HighPriority`，避免主机 TABLE drain 无必要地压过 sensor decode path。

128-slot raw ring 在 200 Hz 下可容纳约 640 ms 的短时 decoder backlog；这不是“允许系统卡 640 ms”的实时保证，只是把短时调度抖动从 LLT callback 中隔离出来。任何 ring overflow 仍直接判本段无效。

## 2. Profile gap forensic diagnostics

每条正式 `LaserProfile` 额外保存：

- `callbackOrdinal`
- `rawBytes`
- `ingressDepth`
- `callbackServiceUs`
- `decoderQueueUs`
- `decodeServiceUs`
- `decodeDonePcUs`

报告遇到 `prevIndex + 1 != currentIndex` 的前向缺口时，会输出缺口前后 callback ordinal、sensor/PC 时间间隔、raw-ring 深度、callback 服务时间、decoder 排队/执行时间以及邻域帧。

判读原则：

- `ΔIndex > 1` 但 `ΔCallback == 1`，且 raw-ring drop=0、convert fail=0：缺失 sensor index 没有形成额外 SDK callback，优先排查传感器 / Ethernet / LLT callback 之前的数据链。
- callback ordinal 同时跨越，且存在 raw-ring drop 或 conversion failure：主机 ingress/decode 链有直接参与证据。
- 其它组合只报告证据，不强行归因。

ColdPrime 收尾现在除了要求 raw callback 连续静默，还要求 raw ring 已排空，随后才重置正式 session callback ordinal/diagnostics，避免 warm-up 尾帧污染正式 forensic 边界。

## 3. GUI 与正式采集解耦

- MainWindow 不再把全部 200 Hz Profile 作为 Qt queued GUI 事件处理。`LaserSensor` 保存 latest decoded profile，GUI 用 33 ms timer（约 30 Hz）latest-only 刷新 2D Profile/History。
- SingleSphere14CalibrationWidget 不再常驻订阅 200 Hz Profile。普通“拟合当前轮廓”读取 latest snapshot；只有 fresh-profile calibration capture 期间临时建立 queued subscription，结束立即断开。
- SoftwareSyncStrategy 仅在软件同步 active 时订阅 Profile；HardwareSyncStrategy 仅在硬件 session active 时订阅。
- 硬件同步正式 Profile bookkeeping 使用 DirectConnection 在 decode thread 中完成轻量 mutex/atomic 入队和 index accounting；30 ms owner-thread timer 仍负责重的点映射/点云构造。

## 4. B/C 控制界面硬件同步刷新

硬件同步期间不再额外调用 ECI `GetMpos/GetDpos` 刷新 C/B。MainWindow 的位置 timer 直接读取 HardwareSyncStrategy 已在内存中的 latest TABLE `SamplePoint`：

- C/B：显示 `machine = TABLE raw latched MPOS + frozen software-frame offset`
- XYZ：硬件同步期间不使用 TABLE MPOS 覆盖普通控制页，因为上位机普通控制/标定坐标约定仍为 XYZ DPOS。

这样既避免了 C/B UI 卡顿时额外抢占 ECI I/O，又保持显示数据与本次 hardware-latch session 同源。

## 5. Physical17 标定模型保护

本版继续固定并静态断言：

- 普通上位机 / 静态标定 / RTCP：`XYZ = DPOS`, `C/B = software mechanical MPOS`
- hardware-sync TABLE provenance：`XYZ/C/B = REGIST(104) latched raw MPOS`

控制器 XYZ `ATYPE=4` 只表示最终光栅尺硬件结构，不能自动把现有 Physical17 的 XYZ source 从 DPOS 改成 MPOS。`readPoseSourceMask()` 直接使用 central software sampling contract：feedbackMask=24、commandMask=7。

V27.6.16K 的 post-stop Physical17 reinjection queue fix 继续保留：等 `SyncManager::stop()` 完整退出、`m_stopping=false` 后才重新注入运行时模型。

## 6. 控制器

继续使用 `ECI3808_V32_9_SINGLE_OP14_PWM_FULL_MPOS_StopFix_RAMCompact.bas`：

- 仅 OUT14/PWM0
- 200 Hz / 2% duty
- ColdPrime
- 单次 Probe
- 五轴 ATYPE=4 + REGIST(104)
- 128-slot REGIST wrap 修复
- normal stop 100% hold 6 ms + final synchronized OFF edge

本版没有改变 TABLE ABI。

## 7. 离线验证

针对本次修改执行：

- `p0_core_mock_tests`: 62/62 PASS
- `v19_report_tests`: 22/22 PASS（含新的 gap forensic 判读回归）
- `p0_unit_tests`: 31/31 PASS
- `verify_v32_9_full_mpos.py`: 9/9 PASS
- `verify_v32_9_stopfix.py`: 9/9 PASS
- `verify_v27616j_calib_dpos_restore.py`: 8/8 PASS
- `verify_v27616m_profile_ingress.py`: source-contract checks PASS

Linux tests-only harness 不链接 Micro-Epsilon LLT/Qt GUI 的 Windows 实机 DLL，因此最终仍需在目标 Windows + scanCONTROL 29xx + ECI3808 上编译和实测。重点观察报告中的 raw-ring high-water、callback/decoder 最大耗时以及 gap forensic 区段。
