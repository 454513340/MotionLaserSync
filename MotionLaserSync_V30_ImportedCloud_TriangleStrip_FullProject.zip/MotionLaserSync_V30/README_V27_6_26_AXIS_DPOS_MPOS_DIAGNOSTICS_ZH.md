# V27.6.26 — XYZ DPOS/MPOS 位移诊断采集

本版本基于 V27.6.25，增加“控制 -> 最下方 -> DPOS / MPOS 位移诊断”。
本次不修改 DATUM/SetMpos 回零算法，只增加只读诊断与 CSV 导出，避免在根因尚未确认时改变机床坐标行为。

## 目的

区分以下三类现象：

1. 固定零偏：`DPOS-MPOS` 非零，但 `ΔDPOS≈ΔMPOS`；
2. 真正的位移不一致：`ΔDPOS-ΔMPOS` 在某个位置区间出现约 0.02 mm；
3. 停止后的沉降/漂移：轴已经 IDLE，但 MPOS 在随后 2 s 内继续变化。

## 自动记录

勾选“自动记录XYZ单轴绝对/相对定位”，然后使用控制页原有 X/Y/Z 单轴绝对或相对定位。

每次运动自动记录：

- 运动前：DPOS / MPOS / FE / IDLE / DATUM_IN；
- `moveAbs/moveRel` 返回、控制器报告 IDLE 后立即：同一组数据；
- 再等待“稳定等待”时间（默认 2000 ms）后：同一组数据。

定义：

- `FE = DPOS - MPOS`
- `ΔDPOS = settled_DPOS - start_DPOS`
- `ΔMPOS = settled_MPOS - start_MPOS`
- `Δ误差 = ΔDPOS - ΔMPOS`
- `FE_change = settled_FE - start_FE`
- `post_idle_mpos_drift = settled_MPOS - idle_MPOS`

自动诊断只对 XYZ 生效。当前项目 B/C 上层 API 在 absolute-ready 后故意不暴露原始 DPOS，因此不把 B/C 混入此项诊断。

## 手工记录

“记录起点”可记录 X/Y/Z 任一轴。随后可以使用其它方式移动轴，停稳后点击“记录终点并添加”。程序会先记录一个终点立即值，再按稳定等待时间等待并记录最终值。

## CSV

“保存CSV”导出详细字段，包括：

- requested target / delta
- start DPOS / MPOS / FE
- IDLE 后立即 DPOS / MPOS / FE
- 等待后 settled DPOS / MPOS / FE
- ΔDPOS / ΔMPOS / ΔDPOS-ΔMPOS
- FE change
- post-IDLE DPOS/MPOS drift
- DATUM_IN 端口号与原始输入电平
- move result / diagnostic error

建议 Z 轴实验：回零后，稳定等待设 2000 ms，分别在 `-11 mm`、`-0.5 mm`、`+4.5 mm` 等区间做 `+5 / -5 mm` 往返重复试验，每个方向至少 5~10 次，再导出 CSV。
