# V28.9 / M8 构建与回归报告

- 基线：`MotionLaserSync_V28_PROJECT_M7_MSVC_COMPILE_FIXED.zip`。
- 新增 C++17 核心：M8 阶段计划、H1 先决条件、虚拟 M2 拒绝、验收时面积与分段来源核查、剩余 CAD 目标排序。
- GUI：把现有 M3→M4→M5→M5.1→M5.2→M6→M7 串联成一个异步可取消离线流程。用户仍必须手动设置 STEP 和导入真实 M2。
- 测试命令：`cmake -S . -B build -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF -DCMAKE_BUILD_TYPE=Release`, `cmake --build build -j4`, `ctest --test-dir build --output-on-failure -j3`。
- 测试结果：20/20 通过，包括 `V28_M8_WORKFLOW_AND_ACCEPTANCE`。
- `M6` 候选振幅 GUI 0～90°，不改变原 M6 候选函数及真实机器安全约束。
- Qt/VTK/MSVC 整体 Windows GUI 尚未编译验证；不得声称本机已通过。
- 未运行整套 200Hz 10 段重计算；已通过的是便携核心及原有较小规模的 M6 轨迹回归。
- 自动 M8 只编排当前一次多段 M6 + M7 验收：未达到目标时输出剩余特征，而非直接执行下一次或生成真实机器指令。
