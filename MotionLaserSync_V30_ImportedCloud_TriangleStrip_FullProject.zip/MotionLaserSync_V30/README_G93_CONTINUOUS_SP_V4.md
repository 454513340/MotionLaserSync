# MotionLaserSync V30 G93 continuous SP trajectory/planner repair (V4)

## Actual failure / cause

The real-machine log at 2026-10-24 16:20:37.748 shows that first G00 completed, M50/H3 started, and the first G05 failed with `G93 time infeasible under axis velocity/acceleration limits` before scan movement. STEP collision and site acceptance are not the cause.

Prior code produced each inverse-time F using `F = 60/(distance/nominal speed)`, ignoring acceleration. More importantly, real `runtime::plan` rejected blending at **all** inverse-time knots. G05 execution never set the `continuous` attribute. Thus the controller planner treated a sampled straight scan as a sequence of rest-to-rest moves, which made F300.17 (~0.199884 sec / 0.999419 mm) physically impossible at 5 mm/s, 25 mm/s².

## Source changes (not just extra validation)

1. `src/runtime/FiveAxis.cpp`, `include/runtime/FiveAxis.h`:
   - Fix zero-initialized junction lookahead that previously prevented nonzero blended velocities.
   - Allow nonzero entry/exit speed across collinear, explicitly-continuous XYZCB G05 knots.
   - STOP at non-collinear corners, group boundaries and first/final knots.
   - Solve an actual per-segment SP peak speed with G93 `60/F` time, capped by configured per-axis speeds and accelerations; reject an impossible time instead of stretching it invisibly.
   - Implement `retimeG93Polyline`: calculate feasible G93 intervals with 5% headroom on configured axis speeds, accounting for group acceleration and deceleration.
2. `src/gcode/GCodeExecutor.cpp`: G05 path points are marked `continuous` for the five-axis SP planner. Full controller motion and feedback gates remain active.
3. `src/twin/MultiPoseExperiment.cpp` and `include/twin/MultiPoseExperiment.h`: when `ExperimentOptions::enforceHardwareG93` is enabled, the multi-pose planner re-times each scan/transfer group **before NC export**, using the same physical SP timing implementation as the executor. The connected pose start/end playback timestamps are updated to match the revised NC. Synthetic optical-only experiments can retain their independent virtual-machine limits.
4. `src/widgets/MultiPoseExperimentWidget.cpp`: enable physical G93 generation for the interactive multi-pose planner, default scan/transfer requested speed to 5 mm/s matching current V30 SP software caps (the GCode real-machine preflight still checks the actual machine settings).
5. `src/twin/TwinM6NcPreview.cpp`, `include/twin/TwinM6Continuous.h`: new NC headers identify dynamically timed continuous SP paths and preserve OFFLINE ONLY markers. No direct hardware approval is granted.
6. `src/twin/NcG93MotionAudit.cpp/.h`: G93 preflight now models continuous straight knots; add `retimeNcG93Continuous` for older existing NCs. Both geometry and M50/M51 structure are checked after the transformation.
7. `src/twin/NcG93ContinuousCandidateCli.cpp`: standalone offline CLI for older NCs. The original `nc_g93_retime_candidate_cli` was retained as the former conservative exact-stop alternative.
8. New `tests/twin/twin_g93_continuous_timing_tests.cpp` plus a test in `tests/p0_core_mock_tests.cpp`: covers ramp + constant-velocity + stop, a 90-degree corner, generated/simulated NC agreement, connected S0/S1 groups, and nonzero SP knot speeds reaching simulated ECI SDK calls.

## Results on YOUR original NC

Original input SHA-256: `7936e9ab0f21a40c4412deb983122f57f2d2653dfe19b3d328bca78659105478`

Generated OFFLINE candidate SHA-256: `2dda16a0a41064d83f6ff918e72ec380eabc81b1af9b915d2ff37bf1bd05e497`

| Statistic | Original NC | Continuous-SP offline candidate |
|---|---:|---:|
| XYZCB movement segments | 8103 | 8103 |
| H3 scan groups | 37 | 37 |
| S1 scanning motion | 814.584 s | 864.487 s |
| S0 laser-OFF transfers | 398.014 s | 833.546 s |
| Total nominal motion | 1212.598 s (~20.21 min) | 1698.033 s (~28.30 min) |
| First G93 time (~0.9994 mm) | 0.199884 s | 0.305404 s |
| Typical next straight scan knot | 0.199884 s | 0.210404 s |

The original transfers require roughly twice the present software 5 mm/s X/Y/Z limit, so the continuous SP fix cannot restore those nominal transfer times without **independently verified** higher physical axis limits. Actual scanning motion stays near the original 5 mm/s, rather than being slowed to every-point rest-to-rest.

Old exact-stop conservative retiming: 3288.53 s (~54.8 min). This revision is not that workaround.

## Rebuild / offline reproduction

```
cmake -S MotionLaserSync_V30 -B build_g93 -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build_g93 --config Release --target nc_g93_continuous_candidate_cli
nc_g93_continuous_candidate_cli ORIGINAL.nc NEW_OFFLINE_ONLY.nc
```

For Visual Studio, extract the new ZIP into a fresh ASCII-only path, delete old CMake cache and reconfigure the **entire** MSVC x64 GUI. Avoid mixing files with the earlier v3 project.

## Validation and critical limits

- Portable complete source built; **35/35 CTest** passed, including added G93 end-to-end tests.
- The ZmcController implementation compiled with the bundled mock ECI SDK. **111/113** mock tests passed: two **pre-existing** stale power-session Home-mask expectations failed, unrelated to the changed SP path. New explicit check for 20 continuous G93 SP knots passed and verified nonzero `SetEndMoveSpeed` during motion and a final zero-speed stop.
- No Windows GUI/Qt/FCL full build or actual controller/servo motion timing is available in this environment. A simulated SDK tests parameter ordering, NOT the hardware's SP interpolation dynamics.
- Real ECI firmware may apply its own corner/acceleration policy and actual duration can differ from the software trapezoid. Before commissioning, use a short **single scan group** with motors unloaded/guarded as site procedures require, inspect controller DPOS/MPOS and hardware latched timestamps, validate the desired actual speed and stop behavior, then repeat the four software/field checks for the final NC SHA. Do NOT infer physical timing accuracy from the offline simulation or raise axis limits blindly.
- `OFFLINE_ONLY` is retained for the candidate, and the NC change invalidates old STEP/registration/machine-session approvals. The short trial and its setup must be authorized through the established site safety procedures. Maintain an accessible hardware E-stop.

## Why exact original G93 is impossible at a cold start

A 0.999419 mm first step cannot finish in 0.199884 s when starting at 0 speed with max v=5 mm/s and accel=25 mm/s². It takes at least about 0.3 s if it can accelerate to 5 mm/s **and preserve** that velocity into the following straight segment (rather than ~0.4 s under the erroneous exact-stop model). One must change the first-step G93 F and/or provide acceleration lead-in before the exposure; neither a longer watchdog nor skipping a time check can make an infeasible command physically achievable.
