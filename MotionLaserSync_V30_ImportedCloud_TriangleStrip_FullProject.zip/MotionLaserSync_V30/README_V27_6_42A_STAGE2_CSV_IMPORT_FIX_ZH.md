# MotionLaserSync V27.6.42A — Stage2 CSV 导入恢复修复

## 问题

V27.6.42 的 Stage3 安全 hold-out / 自动验证功能本身没有修改 `onImportSessionCsv()`，但旧的 Stage2 CSV 入口一直被定义成“仅离线入口”：

```cpp
m_btnImportSession->setEnabled(idleUi && !m_referenceTaught && m_records.empty());
```

当默认有效标定在控制器和传感器连接后自动绑定时，`tryBindPersistentCalibration()` 会设置 `m_referenceTaught=true`。因此即使当前没有任何新采集记录，Stage2 CSV 按钮也会被禁用。截图中的“已恢复有效标定并绑定实机”正好触发了这个条件。

## V27.6.42A 修复

1. Stage2 CSV 导入按钮只在“求解/运动空闲 + 当前没有实机采集记录”时允许，不再因为已有有效标定已绑定而禁用。
2. 如果当前有效标定已经绑定实机，点击导入会先明确询问是否切换到“离线 Stage2 CSV 模式”。
3. 切换后控制器和传感器保持连接，但：
   - `m_referenceTaught=false`；
   - `m_persistentCalibrationBound=false`；
   - 自动标定运动被禁止，避免把历史 CSV 当成当前实机会话。
4. 已加载的 Stage1 `hand-eye + sphere` 和坐标约定继续保留，因此旧版 Stage1+Stage2 混合 CSV 仍可可靠过滤 Stage1 profiles。
5. 已验证的当前 Physical17 在切换前保存为 fallback。
6. 导入 CSV 后仍执行原来的“训练签名复核”：若 profile/point 数和全训练集 RMS/max 与冻结结果一致，保留该 Physical17；不一致则取消当前工作结果并要求重新 Stage2 求解。
7. V27.6.42 的安全 hold-out 区域与独立轴自动验证逻辑全部保留。

## 预期操作

即使界面顶部显示控制器/传感器已连接、默认有效标定已绑定，也可以点击“导入阶段2/旧版混合 CSV”。确认切换后即可选择 CSV。导入阶段不会断开硬件，但不会允许自动运动；需要完成离线求解并重新绑定结果后才能恢复实机运动。
