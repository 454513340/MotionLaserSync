# MotionLaserSync V28.4 — M5 CAD 表面覆盖分析（完整 M0～M5 源码）

## 在何种基线上开发

在用户已验证 Windows 正常运行的 `MotionLaserSync_V28_PROJECT_M4_MSVC_LINK_FIXED.zip`（V28.3.1）基础上增加 M5，不删除原 M0/M1/M2/M3/M4 功能；不修改硬件驱动与实时采集安全协议。

用户当前的 M4 H1 全量报告：全局 F1=0.9707，IoU=0.9431；四沉孔 ROI F1=0.8853，平均 |Z| 残差为 0.4421 mm。这足以进入 CAD 面积覆盖诊断，但不意味着测量精度足以进行尺寸公差检验。M3 的相机偏置 +75 mm 仍为等效光学模型，并非出厂标定参数。

## 新增功能

1. `TwinM5Coverage`：纯 C++17、与 GUI/控制器无关的 CAD 三角面细分，按照三角面积生成有限数量的近似等面积单元，BVH 最近三角形查询，将有效点关联到细分单元；分别统计 M2 和 M3 已观测面积、仅一方观测面积和双方均无观测面积；默认排除 CAD 朝下的底面。
2. `TwinM5Adapter`：从现有 SCAN v3 原始数据 `Frame5D.sensorToMachine + ArchivePoint(x,z,index)` 重建真实采样，从 M3 虚拟 Profile 读取 `Valid` 且命中 `Workpiece` 的采样；绝不合成缺失点。与 M2/3 不匹配的帧序号或变换直接中止。
3. `DigitalTwinScanWidget` 新增 **9. M5 CAD 表面覆盖**：调整网格单元尺寸、最近表面关联距离、单元最少有效点数、排除 CAD 底面；运行、取消、清除、导出；后台运行并可取消。
4. `PointCloudWidget` 新增独立 M5 覆盖诊断图层，并同步到主窗口：青色=实测已覆盖、红色=实测未覆盖、黄色=仅 M3 虚拟覆盖。该图层不改动实时扫描/原有 M2/M3 点云；关闭编辑窗口后仍保留，点击清除 M5 时会同时删除两个视图的热图。
5. 报告：`twin_m5_coverage.json` 为统计概要；`twin_m5_coverage_cells.csv` 为每个 CAD 表面细分单元的面积/中心/法向/命中数；`twin_m5_coverage_features.csv` 为按特征统计的覆盖面积。CSV/JSON 导出在后台运行，不冻结 GUI。
6. `VirtualProfileSample` 新增内存中的 `hitObject` 诊断标志，用于避免将虚拟支承面回波错认为 CAD 工件覆盖；原有 M3 `.m3prof` 序列化格式未改变。

## 使用方法（Windows 10 + VS2022）

1. **保留旧工程备份**。新 ZIP 解压到新文件夹，VS2022 → 文件 → 打开 → 文件夹 → `MotionLaserSync_V28_PROJECT`。
2. 在 `CMakeSettings.json` 使用用户指定的 `TWIN_OCCT_PREFIX=D:/dev/vcpkg/installed/x64-windows-release`。CMake 缓存重建后确认输出 `V28.3.1 M4 GUI direct sources ... [OK]` 以及 `V28.4 M5 CAD coverage: core + GUI + CSV report registered [OK]`。
3. 选择 `x64-Release`、GUI 主程序 `MotionLaserSync.exe` 编译（非测试 CLI），运行后标题应显示 `V28.4`。
4. 路径规划 → `数字孪生 / STEP 工件放置`；导入 `传感器连接件.STEP` 或载入示例工件；按已配准值放置。
5. M2 中载入用户的 `6061_Alumina_Scan_H1.scan`。M3 虚拟模拟可选，但强烈建议先运行，以便比较真实覆盖与虚拟覆盖。M4 可以保留以前的结果，M5 不会自动修改 M4 拟合参数。
6. 滚动到第 9 部分 M5，默认：单元尺寸 `0.60mm`，最近面距离上限 `0.65mm`，每单元最少 `2` 个点，排除 CAD 底面。点击 `运行 M5 覆盖分析`，主界面出现新的彩色区域。完成后导出 JSON+CSV。
7. M5 对旧结果的依赖：CAD 位姿/支承面变化、重新运行 M3、重新导入 M2 以及清空场景都会清除已有的 M5 热图及统计，防止误用过时数据。

## 参数和定义

- 坐标：所有真实采样先使用归档 `sensorToMachine` 变换一次，再使用 CAD 估计位置的逆矩阵转换到 CAD 局部坐标；**不二次施加五轴运动学**。
- 表面：使用从 STEP/OBJ 导入的**三角网格代理**；一个网格三角形细分 `n²` 个等面积单元；模型面小于定量几何公差的误差及 B-Rep 的解析圆柱参数尚未单独保证。
- M2 有效返回点由真实 `.scan` 数据提供；M2 缺少采样返回时，原因是 **UNKNOWN**，不能单独判定为 `CameraOccluded`。
- 一块单元 `realHits >= minHitsPerCell` 才记为真实覆盖；`virtualHits` 独立计数。多个位置相近的点可能在同一单元中，不代表独立视角。
- 面积覆盖率=满足命中条件的 CAD 代理表面单元面积之和 / 选定目标单元总面积；**不是孔径测量精度、实际点云配准 RMS 或可达性保证**。
- 顶面、底面、其它 CAD 侧面适用于任意网格；当尺寸匹配本次 H1 6061 零件（30×95×10mm）时，额外启用**基于已知几何位置的分组模板**：四个沉孔上壁/台阶/下壁、中心通孔与两条弧形槽。与任意其他零件相同尺寸不代表其特征必然相同，此分组不是通用自动 CAD 特征识别。
- 默认目标是选定的 CAD 实体面，尚未区分`可见但未覆盖`和`当前机床永远无法观测`；这种可达性与 NBV 属于后续 M6。
- 默认单元数量上限 250,000。如果原始 0.60mm 间距生成的细分数量超出上限，系统会自动增大有效间距；请以 JSON 中的 `cellPitchEffectiveMm` 为准。
- 最近表面匹配距离 0.65mm 是**诊断容许关联距离**，不是制造公差和传感器精度。本次 M4 沉孔配对Z误差 0.4421mm，需谨慎分析关联过远点的风险；可以分多组阈值重复运行 M5 进行敏感性分析。
- 实测下方支承面回波可能与 CAD 底面重合，因此默认排除底面；后续需要结合实际夹具/支承真值进一步区分，不能用此默认规则证明全部侧壁都可观察。
- M3 虚拟光学几何仍未完成多姿态标定，虚拟覆盖只能作为模型预测，不代表实际后续扫描一定能够成功。

## 离线验证与限制

- `-DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF`：无需 Qt/VTK/硬件 SDK 的核心 C++17 构建；所有原有 10 项相关测试与 2 项新增 M5 测试均应通过。
- `twin_m5_tests`：已验证 CAD 表面面积守恒、细分单元命中阈值、不同观测通道、底面排除、刚性放置、内存单元上限及非法参数拒绝。
- `twin_m5_h1_real_tests`：已使用真实 H1 的 100 条原始曝光位姿及 103,973 个真实有效样本，配合 M3 近似模型进行 CAD 面积覆盖对照；只是子集验证，绝不能将其百分比当成 4,598 帧全量覆盖率。
- Windows 10 + VS2022 Qt/VTK/Open CASCADE 完整 GUI 编译、运行与全量多百万点吞吐需要用户本地验证；本环境不能代替现场测试。

## 新增源文件

- `include/twin/TwinM5Coverage.h`, `src/twin/TwinM5Coverage.cpp`
- `include/twin/TwinM5Adapter.h`, `src/twin/TwinM5Adapter.cpp`
- `tests/twin/twin_m5_tests.cpp`, `tests/twin/twin_m5_h1_real_tests.cpp`
- `include/widgets/DigitalTwinScanWidget.h`, `src/widgets/DigitalTwinScanWidget.cpp`
- `include/widgets/PointCloudWidget.h`, `src/widgets/PointCloudWidget.cpp`
- `include/twin/VirtualLaser2950.h`, `src/twin/VirtualLaser2950.cpp`
- `CMakeLists.txt`, `src/app/MainWindow.cpp`

## 下一阶段 M6

将 M5 输出的未观测 CAD 表面单元交给视角可见性分析器，搜索五轴 B/C 姿态并调用 M3 完全相同的逐帧虚拟光学模块预演候选轨迹。M6 之前，不要根据表面“未观测”就盲目生成运动指令。
