# V28 M0+M1 测试与已知限制（源码交付）

## 源项目

基线：用户上传的 `MotionLaserSync_Experiment3_ZExposure_Revised_Source_20261013.zip`；所有原有源码文件均保留。原有 C++ 控制器/传感器/同步/BASIC 文件均未修改。当前变更仅在 CMake、路径规划 UI、VTK 显示入口及独立的 `twin` 目录。

## 已实际执行（本开发环境，Linux C++17 Release，未使用 Qt/VTK/OCCT）

- `cmake -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF`：配置完成。
- `cmake --build ...`：`digital_twin_core`, `digital_twin_cli`, `twin_core_tests`, `twin_reference_tests` 编译成功。
- `ctest --output-on-failure`：3/3 通过：数学/轨迹/射线变换；参考网格几何尺寸和射线命中；OBJ 加载和坐标报告。
- `TWIN_ENABLE_OCCT=ON` 且机器未安装 OCCT 时：CMake 清楚提示 STEP 依赖不可用，但独立核心及 OBJ 测试仍可构建/运行。
- 原有 `verify_h1_h3_only_llt_basic_contract.py`：PASS。
- 原有 `verify_experiment3_hw_preview_multifield_contract.py`：PASS。
- 原有 `verify_small7_experiment3_contract.py`：62/62 PASS。
- 原有 `verify_sphere_exposure_x_only_contract.py`：15/15 PASS。

参考网格由本次用户提供的 STEP 预先转换，离线 CLI 显示：3256 triangles；CAD bbox X=-15~15, Y≈-54.978~40, Z=0~10 mm；理论机床 MCS bbox X≈-10.856~84.518, Y≈-5.504~25.776, Z≈-225.05~-215.05 mm。测试文件与导入参数均在 `examples/digital_twin/`。

## 尚未执行的测试

当前容器没有 Windows MSVC、Qt6 C++ 开发库、完整 VTK Qt 插件、Open CASCADE C++ 头文件/库及用户 SDK 二进制资源，因此未编译完整 `MotionLaserSync.exe`，未执行实机测试，不能保证没有 Windows/OCCT 版本特异性编译错误。

首次在现场 Windows 配置时请分别执行：

1. 官方 ZMC/LLT SDK、Machine5X 视觉资源补全；验证原 V27 GUI 可以正常生成。
2. 安装 OCCT（vcpkg `opencascade:x64-windows`），确认 CMake 日志出现 STEP enabled。
3. 在路径规划中打开新窗口，导入 `examples/digital_twin/6061_sensor_connector.step`；核对 95×30×10 mm。
4. 编辑 X/Y/Z/Rx/Ry/Rz，保存/加载场景 JSON，观察 VTK Actor 是否同步变化。
5. 调整支承面；验证它不触发设备 I/O。
6. 验证缺少 OCCT 或机床视觉资源时 UI 显式提示，而不默默假造 B-Rep 或碰撞模型。

## 未包含的功能

未实现 M2 `.scan` 真实逐帧回放、M3 2950 双光路遮挡、M4 数据驱动校准、M5 CAD 覆盖率、M6 NBV 五轴补扫、M7 融合闭环、M8 整体工作站功能。此次仅是 M0+M1 的工件导入和放置系统。
