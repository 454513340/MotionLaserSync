# ECI3808 V32.11 ACTIVE

当前正式控制器程序：`controller/ECI3808_5Axis_Controller.bas`。

V32.11 在 V32.10 runtime-PWM 基础上把 `TABLE[357]` 从 XYZ 三轴 Home mask 扩展为 XYZ/C/B 五轴上电会话 Home mask：

- bit0 X；bit1 Y；bit2 Z；bit3 C；bit4 B；
- `31` 表示五轴都已完成本次 ECI/BASIC 上电会话的回零流程；
- `TABLE[354]=321053` 为 V32.11 capability magic；
- BASIC 初始化仍执行 `TABLE(357)=0`；
- `TABLE[355]/[356]` 继续承担运行时 PWM 请求/ACK。

B/C persisted Home bit 只记录“本次控制器上电会话中已经成功回过机械 0°”；它不能替代上位机每次连接时从 RS485 重新建立 B/C 绝对机械坐标。硬件同步授权要求两者都有效。
