# V28.7.3 M6 SCAN 分卷与进度改动验收记录

## 已执行

- 现有 M6 离线核心源代码增加同步 Profile sink、四项独立进度计数器；便携 C++17 编译检查通过（未包含 Qt GUI）。
- `twin_m6_simulated_archive_tests`：**通过**。测试 `Archive v5` 的 1280索引范围模拟点、精确五轴模拟变换、CRC 篡改拒绝、模拟来源非零硬件掩码拒绝、硬件记录 Physical17 不一致拒绝、正确硬件 Physical17 归档恢复。
- 变更后的 `DigitalTwinScanWidget.cpp`、`TwinM6Adapter.cpp`、`TwinM6ScanArchive.cpp` 进行了字符串换行/花括号的自动静态检查，未发现不闭合字符串、意外裸换行及花括号失配。
- CMake Qt GUI 源清单中检查 `TwinM6ScanArchive.cpp` 已注册。

## 当前环境尚未完成

- **Windows 10 + VS2022 + Qt6/VTK/FCL/Open CASCADE 完整 GUI 编译与运行**：没有相应本机 SDK。
- 使用 Qt `qCompress` 写入大批量 SCAN 分卷、再通过真实 M2 读取器打开的端到端大数据测试：待 Windows 首次运行验收（源码在保存后会自行读回首/末分卷）。
- 完整 M6 参考工件的离线全套耗时回归：Debug 全轨迹以及 Release 优化构建测试超过本环境运行预算，没有计为通过。
- 压缩率与时间收益尚未从完整 H1 的 M6 仿真中实测；不能预设 SCAN 会比 float32 PLY 更小。

## Windows 建议检验

1. 编译 V28.7.3 `MotionLaserSync.exe`，加载 STEP + 真实 SCAN + M5。
2. 只运行一条 M6 连续扫描段，检查四条独立进度条。
3. 保存并检查 `_scan_manifest.json` 包含有效时间、原始 Profile 数、每卷 SHA256 与 `SIMULATED` 标记。
4. 在 M2 中逐卷导入新 `.scan`；检查绿色预览点与运动位姿，以及模拟来源提示。
5. 与 M6 JSON 对照 `virtualProfiles` 与 `archivedValidSamples`；允许后者包含支承面回波，而 CAD 覆盖只统计工件点。
6. 扩展到 3 段、9 段，记录磁盘大小、分卷数量、导出时间、最大内存、取消后是否残留本次不完整目标文件。
7. 确认任何 M6 结果都不能变成可下发机床的运动指令。
