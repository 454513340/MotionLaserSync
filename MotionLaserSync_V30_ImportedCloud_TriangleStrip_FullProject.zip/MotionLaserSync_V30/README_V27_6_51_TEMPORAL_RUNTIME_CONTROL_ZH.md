# MotionLaserSync V27.6.51 — 硬件同步时域补偿自动加载 / 参数页运行开关 / 3D 状态标识

本版本在 V27.6.50 的 **ECI3808 V32.9 SINGLE-OP14 + IN0/REGIST(104)** 硬件同步链上做上位机增量修改，控制器 BASIC 不变。

## 1. 目标

把“活动硬件时域标定”和“是否实际应用补偿”拆成两个独立状态：

- 活动标定：保存并加载 `tau / sigma / Calibration ID / sensor timing fingerprint`；
- 运行时开关：仅决定正式硬件同步重建使用原始 `q_k`，还是使用 `q(t_k+tau)`。

关闭运行时补偿 **不再清零或遗忘 tau**。

## 2. 活动标定自动保存和启动自动加载

活动文件：

```text
%APPDATA%/YourCompany/MotionLaserSync/calibration/active_hardware_temporal.json
```

V27.6.51 行为：

1. 标定求解 PASS + Hold-out PASS 后，自动把结果保存为活动标定；
2. 第一次自动保存默认 `runtimeEnabled=false`，不会未经操作员确认就改变正式测量；
3. 参数页把开关打开后，`runtimeEnabled=true` 被持久化；
4. 下次程序启动自动加载活动文件，并恢复上次 ON/OFF 状态；
5. OFF 时依然保留并显示 tau、sigma、ID 和标定 sensor timing。

恢复一个已经完成且 Hold-out PASS 的 V49/V50/V51 Session 时，也会自动把该结果提升为活动标定，但运行时默认 OFF，便于把已有 HTRUN50 实验迁移到本版本。

## 3. 参数设置页新增“硬件同步时域补偿”

显示：

- Calibration ID；
- tau (us)；
- sigma (us)；
- alpha = tau / 5 ms；
- 标定时 ResolutionIndex / Exposure / Idle / Trigger Period；
- 当前参数是否和标定配置匹配；
- 运行时 ON/OFF。

开关：

```text
[ ] 启用正式硬件同步时域补偿
```

OFF：

```text
Profile_k + REGIST(104)_k -> Physical17
```

ON：

```text
q_corr = q_k + tau/T * (q_{k+1} - q_k), T=5 ms
Profile_k + q_corr -> Physical17
```

XYZ/C/B 五轴全部在轴空间插值，然后再进入 Physical17。

## 4. 安全门

- 采集运行 / Stop-Drain 期间 `SyncManager::setHardwareTemporalCorrection()` 拒绝切换；
- 参数页开关在采集运行时自动锁定；
- 正式硬件采集启动时仍严格检查 ResolutionIndex / Exposure / Idle / 5 ms fingerprint；
- 配置不一致时即使 ON，也 Fail-Closed 拒绝硬件采集；
- 软件同步不应用此硬件时域补偿。

## 5. 三维点云显示

正式硬件同步时：

- Temporal Runtime ON：三维点云使用补偿后的 `q(t+tau)` 经过 Physical17 重建；
- Temporal Runtime OFF：三维点云使用原始同 ordinal REGIST(104) 位姿；
- 软件同步：3D 顶部显示 `Temporal Runtime: N/A / 软件同步`。

PointCloudWidget 顶部新增状态：

```text
Temporal Runtime: ON  tau=xxx us
Temporal Runtime: OFF / RAW  tau=xxx us loaded
Temporal Runtime: N/A / 软件同步
```

运行时 ON/OFF 发生变化后，程序会清空当前 PointCloudBuilder/VTK 点云和 SyncManager 已采集数据，防止同一 3D 云中混入 RAW 与 corrected 点。

注意：时域标定自动路径采集仍使用 V27.6.48 之后的 memory-safe RAW 模式，不实时向 3D 窗口扇出百万级点云。

## 6. 对 V27.6.50 已完成 Session 的迁移

如果已有完整 Session，例如：

```text
E:/Projects/CData/HardwareTemporalCalibration/HTRUN50-...
```

在 V27.6.51 的“硬件同步标定”页点击“恢复/继续已有Session”。若 Session 内已经包含：

- calibration solve PASS；
- Hold-out PASS；

则恢复后会自动生成/更新 `active_hardware_temporal.json`，运行时保持 OFF。随后可在“参数设置 -> 硬件同步时域补偿”直接打开开关。

## 7. 控制器未修改

现场拓扑保持：

```text
OP14/PWM0 -> scanCONTROL external trigger
OP14      -> ECI IN0 -> REGIST(104) -> XYZ/C/B raw MPOS
```

控制器 BASIC SHA-256：

```text
263d1f2a560120b006d25262e79fc364ebf35b4e6f2b3bf986f56013166b105a
```

## 8. 主要修改文件

- `src/core/SyncManager.cpp`
- `include/app/MainWindow.h`
- `src/app/MainWindow.cpp`
- `include/widgets/HardwareSyncCalibrationWidget.h`
- `src/widgets/HardwareSyncCalibrationWidget.cpp`
- `include/widgets/CalibrationWidget.h`
- `src/widgets/CalibrationWidget.cpp`
- `include/widgets/PointCloudWidget.h`
- `src/widgets/PointCloudWidget.cpp`
- `src/core/HardwareSyncReport.cpp`
- `src/app/main.cpp`
- `tools/verify_v27651_temporal_runtime_control.py`
