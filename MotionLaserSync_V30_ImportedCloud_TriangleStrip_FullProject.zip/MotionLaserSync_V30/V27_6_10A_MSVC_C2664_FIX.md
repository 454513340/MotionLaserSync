# V27.6.10A - MSVC C2664 compile fix

## Symptom

MSVC reports C2664 in `src/widgets/SingleSphere14CalibrationWidget.cpp` at the direct Stage-2 move signal:

- signal: `requestJointMove(const JointPose5D&, double)`
- supplied value: `const mls::calibration::JointPose5d`

## Root cause

The portable calibration/planner core deliberately defines its own dependency-free
`mls::calibration::JointPose5d`. The Qt/controller layer uses the application's
`JointPose5D` from `include/core/DataTypes.h`. Their fields are currently equivalent,
but they are distinct C++ types and cannot bind to each other's references.

V27.6.10 changed Stage-2 movement from the legacy segmented controller-side `JointPose5D`
temporary to a direct use of `CalibrationPoseInstruction::predictedJoint`. That field is
the portable `JointPose5d`, so the new direct signal exposed the type mismatch.

## Fix

An explicit boundary converter `controllerPoseFromPortable(...)` is added in the widget's
anonymous namespace. `onMoveToSelectedPose()` now converts the planner target to
`JointPose5D` before displaying/submitting the controller move.

No kinematic/calibration numerical values are changed by this fix; it is a field-for-field
copy of X/Y/Z/C/B at the portable-core / Qt-controller boundary.

## Checks performed

- `single_sphere14_cli`: builds successfully in portable C++17 mode.
- `single_sphere17_cli`: builds successfully in portable C++17 mode.
- `v20_2_single_sphere17_tests`: passes (1/1, about 3.2 s in the check environment).
- All `requestJointMove(...)` emission sites were reviewed; the Stage-2 direct emission now supplies a real `JointPose5D`.

The complete Windows Qt/VTK/vendor-SDK GUI cannot be built in the Linux check environment,
so Visual Studio x64-Release remains the final platform compile check.
