# V28 MSVC 编译修正（2026-10-14）

## 修改内容

`src/widgets/DigitalTwinScanWidget.cpp` 第 134 行：

原：`auto* addParam=[&](const QString& label,double value,double min,double max){`

修正：`auto addParam=[&](const QString& label,double value,double min,double max){`

原因：lambda 表达式的类型是闭包对象，不能通过 `auto*` 作为指针推导。第 141～145 行 C2064 错误由该声明失败引起。

这与 Open CASCADE 是否安装无关。Open CASCADE 是独立的 STEP 导入可选依赖。

当前环境已验证离线数字孪生核心 CMake 构建与测试；完整 Windows Qt/VTK GUI 需要在用户 VS2022 环境中确认。
