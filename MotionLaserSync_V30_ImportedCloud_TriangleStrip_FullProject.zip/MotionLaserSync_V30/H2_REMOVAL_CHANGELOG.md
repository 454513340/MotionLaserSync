# V32.16 / H1-H3 ONLY — H2 退役变更记录

## 主机侧
- `include/runtime/Acquisition5D.h`：仅允许拓扑 H1=1、H3=3，原 ID=2 不复用；增强 ACK 模式校验，运行时版本标志改为 321058。
- `src/core/SyncManager.cpp`：移除 H2 三阶段测试、专用 ColdPrime+CMM、外触发+CMM 复核与停止分支；保留 H1 ColdPrime、H3 内部 CMM 专用启动与 FIFO 对齐。
- `include/core/LaserSensor.h`、`src/core/LaserSensor.cpp`：移除 H2-only SDK 接口、手动 Divider 诊断和 CMM warmup 统计；保留 H3 所需的 CMM 配置/时间戳解析及 SDK gated 启停。
- `src/app/MainWindow.cpp`：删除 H2 选项，保留 H1/H3 与 R1 极性设置并更新提示。
- `src/core/ZmcController.cpp`：更新协议版本、只读预检文本及 ACK 描述；通过 `validTopologyEdge()` 在写 TABLE 之前拒绝原 ID=2。

## 控制器 BASIC
- 新唯一文件：`controller/ECI3808_V32_16_H1_H3_ONLY.bas`（旧三拓扑 BAS 已不再包含）。
- BASIC `AC()` 只接受 `rm=1`、`rm=3`；`rm=2` 返回配置错误 14，保持不启用采集。
- 保留 H1 OP14/R0 与 H3 CMM/IN1/R1 的 FIFO、Home mask、频率/拓扑双 ACK、cold-prime、STOP-DRAIN、安全停机等原有逻辑。
- TABLE 兼容布局保持，`TABLE[354]` 版本能力标记从 321057 修改为 321058，防止新版 Host 误用旧 BASIC。

## 回归与部署
- `tests/p0_core_mock_tests.cpp`：以“编号 2 被拒绝”和“旧 BASIC 被拒绝”取代 H2 成功测试；H3 的 CMM Probe/ACK 负面测试保留。
- 历史版本说明仍作为档案保留，**不能将里面的旧 H2 或旧 BAS 文件名用于现场部署**。
- 现场必须编译下载新 BASIC，重新回零并验证 H1/H3；本包不代表已在真实 ECI 控制器或 Windows 上完成联调。

- `tools/verify_h1_h3_only_llt_basic_contract.py`：以新静态协议检查替换会引用已删除三拓扑 BAS 的旧 V27.6.57 脚本。
- `tests/h1_h3_only_contract_tests.cpp`：新增独立 C++17 协议校验，纳入 CMake tests。
