# 本次文件差异与测试结果

变化/新增文件：

- `CMakeLists.txt`
- `README_SPHERE_TWO_STAGE_IMPORTED_CLOUD_ZH.md`
- `include/app/MainWindow.h`
- `include/calibration/SphereArcQualityGate.h`
- `include/calibration/SphereTwoStageFit.h`
- `include/widgets/HardwareSyncCalibrationWidget.h`
- `src/app/MainWindow.cpp`
- `src/calibration/SphereTwoStageFit.cpp`
- `src/widgets/HardwareSyncCalibrationWidget.cpp`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `tools/sphere_two_stage_quality_cli.cpp`

通过：两项 portable CLI，3/3 导入入口静态一致性；尚未 Windows GUI 编译/实机验收。
