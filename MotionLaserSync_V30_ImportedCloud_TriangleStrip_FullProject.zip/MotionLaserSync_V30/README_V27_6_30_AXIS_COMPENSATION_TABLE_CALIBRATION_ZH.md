# V27.6.30 — XYZ 位置补偿表自动标定（仅采表/建表，不启用补偿）

本版本建立在 V27.6.29 上，新增独立的 **“XYZ 位置补偿表自动标定”** 区域。

目标只有一个：先可靠测出 X/Y/Z 三条线性轴的 `DPOS -> MPOS` 实际映射，生成可审查的正向/反向候选补偿表。**V27.6.30 不会把这些表应用到任何运动命令，也不会写入控制器坐标或 Physical17。**

## 1. 使用前提

1. 控制器已经连接；
2. 需要采表的 X/Y/Z 已经完成项目当前的正规 DATUM 回零，并建立本次连接有效的 MPOS 机床零点；
3. 机床没有 GCode、同步采集、五轴定位、自动球研究或其他运动任务；
4. 先读取/确认 XYZ 的真实软限位；
5. 全程有人监护急停。

PRE_HOME 数据只用于诊断，不允许生成正式补偿表。

## 2. UI

控制页面底部新增：

- 标定轴：`X / Y / Z / XYZ依次`
- X/Y/Z 各自独立的：
  - 起始 DPOS
  - 终止 DPOS
  - 步长
- 重复扫描次数（默认 3）
- IDLE 后稳定等待（默认 2000 ms）
- 换向预加载距离（默认 2 mm）
- `按当前软限位填充安全范围`
- 保存目录
- `开始XYZ补偿表采集`
- `停止采集`
- `保存当前采表结果`
- 进度条与候选补偿表摘要

默认行程仅为 `-20 .. +20 mm / 0.5 mm` 的占位值；正式实验必须按现场 X/Y/Z 有效行程修改。

## 3. 为什么需要“换向预加载”

为了让正向表和反向表真正对应一致的机械接近方向：

正向扫描：

```text
start - preload
      -> start -> start+step -> ... -> end
```

反向扫描：

```text
end + preload
      -> end -> end-step -> ... -> start
```

因此采表范围必须同时满足：

```text
start - preload >= 负软限位
end   + preload <= 正软限位
```

不满足时程序拒绝启动。

## 4. 一次重复循环的测量过程

对每条轴、每个循环：

1. 正向预加载；
2. 正向逐点扫描全部 DPOS 网格；
3. 每点等待控制器 IDLE；
4. 立即记录 DPOS / MPOS / ENCODER；
5. 再等待设定的稳定时间；
6. 再记录稳定后的 DPOS / MPOS / ENCODER；
7. 正向完成后做反向预加载；
8. 反向逐点扫描同一组网格；
9. 完成所有重复后恢复该轴开始采表时的 DPOS；
10. `XYZ依次` 模式再进入下一轴。

采表期间程序不会调用 `SetMpos()`。如果检测到 `SetMpos generation` 发生变化，采表立即中止，防止不同坐标基准的数据混入同一张表。

## 5. 输出文件

默认目录：

```text
<程序目录>/calibration/axis_compensation/
```

每次运行建立独立时间戳目录，例如：

```text
axis_comp_candidate_20260922_123456_789/
```

内部包含：

```text
raw_axis_compensation_samples.csv
X_compensation_candidate.csv
Y_compensation_candidate.csv
Z_compensation_candidate.csv
axis_compensation_manifest.json
```

只生成本次实际采集过的轴文件。

### raw_axis_compensation_samples.csv

保存每一个原始采样点，包括：

- 轴 / 正反方向 / 循环 / 点号
- 请求 DPOS
- IDLE 后 DPOS / MPOS / ENCODER
- 稳定等待后的 DPOS / MPOS / ENCODER
- `DPOS - MPOS`
- IDLE 后 MPOS 漂移
- MPOS reference 状态
- SetMpos generation
- DATUM_IN 状态
- 运动状态 / 错误

这是后续重新分析最重要的原始文件，请保留。

### X/Y/Z_compensation_candidate.csv

同一 DPOS 网格点、同一方向的多次重复会自动平均，生成：

```text
axis
direction
nominal_command_dpos_mm
desired_mpos_mm
required_dpos_mm
correction_required_dpos_minus_desired_mpos_mm
correction_stddev_mm
mpos_stddev_mm
mean_post_idle_mpos_drift_mm
samples
```

其中候选运行映射为：

```text
desired_mpos_mm -> required_dpos_mm
```

正向与反向分别保存，后续运行补偿不能混成一张方向无关表。

### axis_compensation_manifest.json

明确标记：

```text
status = CANDIDATE_UNVALIDATED
runtime_compensation_enabled = false
```

并保存采样范围、步长、重复次数、稳定时间、预加载距离以及每个方向的节点数量/单调性/补偿范围。

## 6. 建议现场第一次怎么采

不要一开始 XYZ 全行程一起跑。建议：

### Z 轴

由于已知丝杠导程 = 10 mm/rev，建议：

```text
step = 0.5 mm
repeats = 3
settle = 2000 ms
preload = 2 mm
```

范围使用实际标定/扫描会用到的 Z 有效区域，而不是机械极限本身。

### X / Y 轴

第一轮可以先：

```text
step = 1.0 mm
repeats = 3
```

如果发现明显短周期结构，再缩小到 0.5 mm 重采。

## 7. 时间估算

例如 Z 有效范围 100 mm，步长 0.5 mm：

```text
201 点 × 正反2方向 × 3次 = 1206 个测量样本
```

仅 2 秒稳定等待就约 40 分钟，再加运动时间。因此 UI 会在开始前显示样本数和最低等待时间估算。

## 8. 本版本明确没有做什么

V27.6.30 **没有**：

- 修改 Jog；
- 修改单轴绝对/相对定位；
- 修改标定自动姿态运动；
- 修改 GCode / RTCP / 连续轨迹；
- 修改控制器 DPOS/MPOS；
- 修改 Physical17；
- 自动启用任何补偿。

先采表、分析、验证。下一阶段才会把经过验证的表接入 `ideal MPOS target -> compensated DPOS command` 的运动命令层。

## 9. 离线回归

本版本未修改 Physical14 / Physical17 / profile-block 数学求解代码。便携测试重新构建并通过：

```text
v20_single_sphere14_tests     PASS
v20_2_single_sphere17_tests   PASS
v27618_profile_block_tests    PASS
```

完整 GUI 仍需在现场 Windows x64 + Qt6 + ZMotion/scanCONTROL/FCL 环境编译和实机验证。
