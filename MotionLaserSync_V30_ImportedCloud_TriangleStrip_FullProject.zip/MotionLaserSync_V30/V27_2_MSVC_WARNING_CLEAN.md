# V27.2 MSVC warning-clean update

This revision keeps the V27.1 Arc namespace fix and additionally removes the
three warnings seen in Visual Studio:

1. `C4005 WIN32_LEAN_AND_MEAN macro redefinition`
   - CMake no longer defines `WIN32_LEAN_AND_MEAN` globally.
   - the bundled scanCONTROL `stdafx.h` now guards its local definition.
2. `Translations will not be available ...` from `windeployqt`
   - normal IDE builds no longer run `windeployqt` automatically.
   - an explicit CMake target named `deploy_qt` is provided.
   - for release packaging, configure with `-DAUTO_DEPLOY_QT=ON` if desired.

The translation message is a deployment-tool warning, not a C++ compile error.
The application itself contains no `.ts/.qm` translation deployment requirement
in this project, and `--no-translations` remains intentional.

After replacing the source tree, delete the old Visual Studio/CMake cache (`out`
and `.vs`, or use **Delete Cache and Reconfigure**) so the changed CMake rules
are regenerated.
