# V27.6.20 — 运动学标定离线路径生成修正

## 1. 问题现象

在控制器、传感器均未连接的离线状态下：

1. 可以自动载入/手动载入已验证 Physical17 标定；
2. 可以导入标准球点云；
3. 3-D RANSAC 能正确拟合固定球心；
4. 但“生成质量约束 + D-optimal 标定姿态”仍不可用，或进入生成函数后提示控制器未连接。

这不是球点云或 RANSAC 失败，而是 GUI/规划器把“路径设计”与“真实机床运动会话”绑定在了一起。

## 2. 原因

原 V27.6.19 有两层在线门禁：

- `updateCalibrationReadiness()` 只有 `m_referenceTaught == true` 时才允许阶段2生成按钮；从磁盘恢复的标定故意保持 `m_referenceTaught == false`。
- `onGeneratePlan()` 又强制调用 `readStableState()` 获取控制器当前 XYZCB；控制器未连接时直接退出。

因此即使导入点云已经更新 `m_sphereCenterGuessMachine`，也无法离线生成 D-optimal 路径。

## 3. V27.6.20 行为

路径生成与真实运动授权分离。

### 离线允许

- 载入阶段1/已验证 Physical17 模型；
- 导入球点云并执行 3-D RANSAC；
- 用拟合后的机床坐标系固定球心生成质量约束 + D-optimal 阶段2姿态；
- 运行 V27.6.19 已加入的五轴数字孪生 + 激光梯形 FOV + 球截圆/有效圆弧仿真；
- 导入已有阶段2 CSV 后执行离线求解/分析。

### 离线仍禁止

- 真实移动到计划姿态；
- 自动移动/采集；
- 实时采集；
- 需要实时设备坐标约定确认的扫描/RTCP 运行。

这些功能仍要求真实控制器/传感器连接和会话绑定。

## 4. 离线起点的安全处理

离线状态不存在可信的“当前机床姿态”。因此 V27.6.20 不会把零姿态、旧历史姿态或未初始化姿态当成真实起点。

- 第一个 D-optimal 姿态：只检查目标姿态 MachineSafety/FCL 和光学可见性；
- 第1个规划姿态 -> 第2个规划姿态，以及之后所有相邻姿态：继续做 MachineSafety 扫掠过渡检查；
- 真正连接机床执行时：仍必须从执行当时的真实 MPOS 到首姿态重新通过在线安全门禁。

## 5. 离线规划限位

原 `PosePlannerConfig` 的 XYZ 默认范围非常宽，只适合作为底层占位值，不能用于真实离线路径设计。

V27.6.20 在集成 GUI 中复用 MainWindow 已有的 `resolveSphereStudyPlanningLimits()`：

- 离线：读取 `models/machine5x/machine_config.json` 中的 `offline_planning_limits`，并使用现有安全裕量；
- 在线：在上述 Machine5X 边界基础上继续与控制器实时软限位求交；
- 若无法取得有限、安全的离线边界，离线规划直接拒绝，而不是退回无限 XYZ 范围。

## 6. 主要修改文件

- `include/calibration/SingleSphere14Calibration.h`
- `src/calibration/SingleSphere17Calibration.cpp`
- `include/widgets/SingleSphere14CalibrationWidget.h`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `include/widgets/CalibrationWidget.h`
- `src/widgets/CalibrationWidget.cpp`
- `src/app/MainWindow.cpp`
- `tests/v27618_profile_block_tests.cpp`

## 7. 回归验证

当前 Linux portable 验证环境已通过：

- `v27618_profile_block_tests`
  - 残差/Jacobian/信息矩阵等价性；
  - invalid-data/cancellation/gauge/pose-gate；
  - 新增 offline known-center planning 回归；
  - 验证离线规划不会把非有限/虚假 start pose 传入首段 transition gate。
- `v20_2_single_sphere17_tests`
  - Physical17/rank14 + two-stage calibration tests passed。

完整 Windows GUI 没有在当前 Linux 环境中编译，因为工程依赖 Windows Qt6/VTK/ZMC/scanCONTROL/Machine5X 运行栈。请在原 VS2022 x64-Release 环境中“删除缓存并重新配置”后全量生成。

## 8. 推荐离线工作流

1. 启动程序，保持控制器/传感器离线；
2. 自动载入或手动载入对应阶段1/Physical17 标定；
3. 导入标准球点云；
4. 执行 RANSAC 球心拟合；
5. 设置 D、gamma、eta、B、C 和姿态数量；
6. 点击“生成质量约束 + D-optimal 标定姿态”；
7. 点击“仿真运行标定姿态”，逐姿态检查数字孪生、激光 FOV 和二维/三维圆轮廓；
8. 只有确认规划正确后，再连接实机并重新做设备坐标约定/首段安全检查后执行。
