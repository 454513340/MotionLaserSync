# V28.7.3 / M6 Windows MSVC 前向声明修复

## 错误

Visual Studio 2022 在 `include/widgets/DigitalTwinScanWidget.h` 第 234 行报：
- C2039: `M6ExportProgress` 不是 `mls::twin` 成员
- C2065: 未声明的标识符
- C2923、C2955: `std::shared_ptr` 模板参数错误

## 原因与修复

`include/twin/TwinM6ScanArchive.h` 已经定义 `struct mls::twin::M6ExportProgress`，但 GUI 头文件使用 `std::shared_ptr<mls::twin::M6ExportProgress>` 时没有声明该类型。

在 `DigitalTwinScanWidget.h` 的 `namespace mls::twin` 前向声明行末增加 `struct M6ExportProgress;`。保持轻量前向声明，完整定义由 GUI `.cpp` 包含 `twin/TwinM6Adapter.h` 间接取得。

本次没有修改 `.scan` 格式、压缩、文件分卷、M6 规划/动态/碰撞、四条进度条或硬件控制。原有 Open CASCADE 前缀保持 `D:/dev/vcpkg/installed/x64-windows-release`。

## 验证

- 从原版压缩包直接抽取未修改的头文件：可复现 `M6ExportProgress is not a member of mls::twin`。
- 修复后的头文件（使用最小 Qt 类型桩，仅验证 C++ 类型/声明合法性）：GCC/Clang C++17 语法检查通过。
- `DIGITAL_TWIN_CLI_ONLY=ON` 和 `TWIN_ENABLE_OCCT=OFF` 的离线 Ninja Release 目标构建通过。
- `V28_M6_SIMULATED_ARCHIVE_ROUNDTRIP` 和 `V28_M6_CONTINUOUS_5AXIS_OFFLINE`：2/2 通过。
- 当前环境没有 Windows VS2022/Qt/VTK 全套依赖；完整 GUI 构建仍需在用户机器上验证。

## Windows VS2022 操作

1. 备份原工程。
2. 选择新 ZIP 完整解压，或只替换 `include/widgets/DigitalTwinScanWidget.h`。
3. 关闭旧的 Visual Studio 文件夹、重新打开新工程，清除 CMake 缓存并重新配置。
4. 选择 `MotionLaserSync.exe` 目标编译，而不是 `exposure_analysis_cli.exe`。
5. 导入 STEP / M2，运行单段 M6，测试进度条和 `.scan` 分卷导出。

注意：本修复解决了截图中这四条编译错误；若重新编译后另有错误，请提供新的完整编译/链接日志。
