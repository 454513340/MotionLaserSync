> **V28.2 勘误：** 本文记载的是之前 M3 复审时的历史默认值。当前版本依据 H1 方向核对，虚拟相机默认已由 -75 mm 调整为 **+75 mm**；Profile 索引与 Sensor-X 的方向也已反转。详见 `README_V28_M3_DIRECTION_FIX_ZH.md`。

# MotionLaserSync V28 M3 源码复审与修复说明

审查基线：`MotionLaserSync_V28_PROJECT_M3_COMPLETE.zip`（用户前一轮收到的版本）。

## 复审核对范围

- 数字孪生核心：`TwinTypes`、`TwinScene`、`CadGeometryAdapter`、`VirtualLaser2950`、`TwinSimulationAdapter`、`ScanReplayAdapter`。
- UI/渲染集成：`DigitalTwinScanWidget`、`PointCloudWidget`、`PathPlanningWidget`。
- 构建与测试：`CMakeLists.txt`、`tests/twin`、参考 H1 曝光位姿子集。

## 本版已修正的确定问题

1. `src/widgets/DigitalTwinScanWidget.cpp`: 之前在 `updateSupport()` 中，主视图的支承面刷新受到 `scene.hasWorkpiece()` 的错误限制。先清除 CAD 再清除支承面时，主界面可能保留旧支承面 Actor。现已去掉该条件；即使没有 CAD，也会向主视图同步支持面的启用/禁用状态。
2. `include/twin/VirtualLaser2950.h`: 之前光学引擎默认相机 Y 偏置 `-35 mm`，而 GUI 默认 `-75 mm`；离线 CLI 与 GUI 默认不一致。统一为 `-75 mm`。这些仍是**假设的等效光学参数，未经厂家标定**。
3. `src/twin/VirtualLaser2950.cpp`: 原来仅检查曝光变换的数值有限性和最后一行，没有检查旋转矩阵是否为正交的刚性变换。由于使用 `inverseRigid()`，错误的尺度/剪切矩阵可产生失真的 M3 光路。现在拒绝此类矩阵并生成 `BadPose` 状态。
4. `src/twin/VirtualLaser2950.cpp`: 增加 Sensor-Z 边界、测量宽度、容差和追踪距离的 NaN/Inf 验证，并防止直接调用 `simulate()` 时根据非法的 `sampleCount` 申请超大内存。
5. `src/widgets/DigitalTwinScanWidget.cpp`: 清除 M3 时停止旧进度定时器，禁止旧后台任务继续覆盖“已清除”状态文案；在 QtConcurrent 工作函数中捕获异常并返回可显示错误。
6. `CMakeLists.txt`: 当前 4 个断言型测试在 Release 下原先可能因 `NDEBUG` 使 `assert()` 不执行。现对测试目标强制取消 `NDEBUG`，Debug/Release 均保留断言。
7. `tests/twin/twin_virtual_laser_tests.cpp`: 增加非刚性位姿、NaN/Inf 光学参数、无效采样数、默认基线一致性验证；遮挡壁位置随默认基线调整。

## 已完成的验证

- Linux 便携 C++17 核心：Debug 编译（GCC + AddressSanitizer/UndefinedBehaviorSanitizer），CTest **7/7 通过**。
- Linux Release 便携 C++17 核心：CTest **7/7 通过**；测试断言仍启用。
- 参考场景和采样的 100 帧 H1 曝光位姿 CLI 测试通过。
- 这不等于已经在 Windows 10/Visual Studio 2022 下完成 Qt6/VTK/Open CASCADE 的 GUI 编译和运行。请在本机确认完整 `MotionLaserSync` 主程序目标；请勿只编译 CLI。

## 仍需进一步验证的限制（未宣称已经解决）

- `VirtualLaser2950` 的发射器/接收器光心为近似光学模型，不能直接据此判定多角度实际扫孔的可见性。M4 应与真实 `.scan` 索引掩码及孔壁覆盖面积进行逐帧比较。
- M3 使用了理想针孔投射和固定二次光路，不包含材料反射率、曝光、激光线实际三角测量标定及强度质量模型。
- `.m3prof` 目前只有导出代码、尚无独立读回和二进制回归校验测试；应在 M4 增加读回器及端到端校验。
- 当前 GUI 的线程/导出路径还缺少真实 Windows 压力测试。正在写出磁盘的后台导出会持有自己的数据快照；单击“清空”不会立刻终止已有磁盘写出，也不会删除先前保存的文件。
- 为防止对实机发生错误控制，本版本仅执行离线光学仿真，未引入新的轴运动指令。

## Windows VS2022 验收步骤

1. 以新的目录解压，保留你本机可工作的厂商 SDK、Qt/VTK/FCL 等依赖；TWIN_OCCT_PREFIX 继续为 `D:/dev/vcpkg/installed/x64-windows-release`。
2. 删除旧 CMake 缓存并重新配置，选择 `MotionLaserSync.exe` 主程序，执行 `x64-Release` 构建。
3. 载入 STEP + 启用支承面；清除 CAD，再清除支承面，确认弹窗和主界面均不残留支承面。
4. 导入 SCAN，运行 M3，切换相机 Y 偏置，检查 Valid/CameraOccluded 计数变化；默认值应为 `-75 mm`。
5. 在 M3 进行中尝试“清除 M3”，确认旧进度不会覆盖已清除状态，完成时不会重建旧点云。
6. 导出 PLY、m3prof、JSON。所有三份文件应存在。注意 m3prof 尚缺读回测试，不建议直接作为生产数据协议。
