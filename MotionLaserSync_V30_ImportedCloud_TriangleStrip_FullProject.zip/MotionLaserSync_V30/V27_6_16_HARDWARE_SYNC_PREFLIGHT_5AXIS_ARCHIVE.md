# MotionLaserSync V27.6.16：硬件同步只读预检 + 五轴点云归档加固

## 1. 本版本定位

V27.6.16 基于已经验证通过的 V27.6.15 标定/hold-out 工作流继续审计 ECI3808 硬件同步链和五轴点云保存链。

本交付版**不直接授权物理硬件同步执行**。上位机仍在 `SyncManager::start()`、MainWindow 和 G-code 三层保留物理触发锁；随包的 `ECI3808_5Axis_Controller.bas` 也设置 `HWALLOW=0`，即使外部误写采集 enable，也会关 PWM、关输出并返回故障码 9。

新增的“硬件同步只读预检”只读取 TABLE 协议头，不写 TABLE、不启动 PWM、不产生传感器外部触发、不下发运动。

## 2. 对实际 ECI3808_5Axis_Controller.bas 的审计结论

### 2.1 REGIST(104) 与传感器边沿必须一致

控制器代码使用：

```text
REGCONT=104
REGIST(REGCONT, ..., RWORDS)
```

正运动手册对 `100+mode` 的连续锁存定义中，mode=4 为 R0 下降沿，因此 104 表示 R0 下降沿连续锁存。旧 UI 默认 `EdgeRising`，而 LaserSensor 对 `EdgeRising`/`EdgeFalling` 会实际配置不同的输入极性，这会造成“传感器轮廓触发沿”和“控制器位置锁存沿”不是同一逻辑边沿。

V27.6.16：

- TABLE[349] 不再只写模糊的 `4`，而是发布实际 `REGCONT=104`；
- Host `Table5D::latchMode` 也固定为 104；
- 候选硬件触发类型显示为下降沿；
- 未来物理硬件路径即使解除外层授权，也会拒绝上升沿/脉冲模式。

### 2.2 连续 REGIST 原始 FIFO 的计数/槽位逻辑修正

旧 BASIC 把 `TABLE(XB)` 等五个 FIFO 的首字既当累计锁存数量，又按 `RWORDS=129` 做回绕：

```text
d=x-gr
IF d<0 THEN d=d+RWORDS
s=(gseq MOD RCAP)+1
```

这样把“累计锁存计数”和“循环数据区槽号”混在了一起。V27.6.16 改为：

- `d=x-gr` 小于 0：直接故障；
- `d>RCAP`：说明 raw FIFO 在 BASIC 搬运前已经覆盖旧样本，直接故障；
- 读取槽号按 raw 已消费计数 `((gr+i-1) MOD RCAP)+1` 计算，不再依赖 Host 发布序号；
- 新故障码 8 表示 raw FIFO 计数回退/积压超过容量、锁存证据已经丢失。

### 2.3 H_TRIG 不是独立物理触发计数器

BASIC 中 `H_PUB` 和 `H_TRIG` 都由同一个 `gseq` 发布，因此它们只能证明“Host 可见的已发布锁存 ordinal 数量”。它们不是两套独立硬件证据，不能单独证明 PWM 边沿、R0 锁存边沿和传感器曝光属于同一个物理事件。

报告和源码注释已经明确这一点。

## 3. 新增只读协议预检

`ZmcController::hwTableCommissioningPreflight()` 会检查：

- ECI3808 已连接；
- 没有 Host 五轴运动任务；
- B/C 机械绝对坐标已经建立；
- TABLE magic = 270916；
- recordWords=6、period=5 ms、capacity=96；
- feedbackMask/commandMask 合法且覆盖 XYZCB；
- timing=HardwareLatched；
- latchMask=31；
- latchInput=0；
- triggerOutput=14；
- REGIST mode=104；
- BASIC 当前 fault=0、enable=0。

该函数只调用 GetTable 类读取接口；当前源码契约专门检查预检函数内部不存在 `ZAux_Direct_SetTable`。

## 4. 五轴点云重建检查

当前硬件同步点云链本身已经使用冻结的、经过 hold-out 验证的 Physical17 模型：

1. 每个 ECI 锁存记录解码为 XYZCB `Frame5D`；
2. `calibratedFrame()` 调用 `completeFrame()`，把同一套 17 参数写入该 profile 的不可变 frame；
3. `completeFrame()` 计算该 XYZCB 姿态下的 `sensorToMachine`；
4. 每个激光点通过 `mapProfilePoint(frame, sensorX, sensorZ)` 生成机床坐标系 XYZ；
5. `AlignedPoint` 持有该 profile 的 frame，因此显示、保存和离线重建使用同一份五轴来源证据。

V27.6.16 没有退回三轴平移模型。

## 5. 五轴 .scan 保存/压缩加固

`.scan` v3 本来已经按 profile 保存：

- XYZCB joints；
- command/raw 轴来源；
- C/B 机械绝对偏置；
- 完整 Physical17[17]；
- 每 profile 的 `sensorToMachine`；
- session/ordinal/timestamp；
- feedback/latch/command masks；
- 原始传感器 X/Z 与 point index。

因此 `.scan` 是五轴源数据归档；CSV/PLY 只是派生 XYZ 点云，不能恢复完整的五轴/Physical17 来源。

V27.6.16 新增：

- 一个 `.scan` 文件禁止混入不同 session；
- 禁止混入不同 Physical17；
- 禁止混入不同 C/B offset、timing 或 XYZCB source mask；
- 点 XYZ 必须能由保存的 frame + 原始 X/Z 重新算出，否则拒绝保存；
- 采集还在运行时拒绝导出，必须等停止收尾、计数/队列收敛后再保存；
- 保存对话框的 1..9 压缩级别现在真正传到异步保存线程；V27.6.15 中这个 UI 值没有进入 SaveTask；
- `.scan` 外层名义 sample interval 使用本次采集记录的周期；v3 仍以每 profile 的实际 timestamp 为权威时间。

现有 v3 archive 仍保留 512 MiB 未压缩安全上限，避免一次性解压/编码造成失控的内存分配。长扫描需要后续单独设计 chunked/streaming v4，不能靠简单提高上限解决。

## 6. 物理硬件执行为什么仍锁定

软件能验证协议一致性和计数完整性，但以下项目必须由具备设备操作资质的人员在受控条件下完成实机验收，不能由源码静态检查替代：

- PWM 输出与 R0 锁存输入之间的真实电气路径；
- 同一物理边沿是否同时进入传感器触发输入；
- 输入电平/极性是否符合目标设备；
- 传感器曝光相位相对锁存时刻的偏差；
- 五轴运动状态下的最大抖动、漏触发和故障停机行为。

因此本交付版只提供 read-only preflight，并在 BASIC/Host 两侧都保持物理启动 fail-closed。

## 7. 回归测试

- V27.6.16 当前源码契约：24/24 通过；
- 可移植核心/Mock ECI、SingleSphere14/Physical17、同步报告、五轴 runtime archive、轨迹解析、RTCP 数值与锁存仿真等当前相关测试：20/20 通过；
- 完整 CTest 共 28 项，其中 8 项历史“源码字符串契约”仍失败，因为它们要求 V27/V20/V27.6.5/.../V27.6.15 的旧版本号、旧 magic 或旧 UI 文本；当前 V27.6.16 契约通过。

Linux 环境不能替代 Windows x64 + Qt/VTK + ZMotion/scanCONTROL 厂商 SDK 的最终 MSVC 链接验证，也不能替代实机电气/时序验收。
