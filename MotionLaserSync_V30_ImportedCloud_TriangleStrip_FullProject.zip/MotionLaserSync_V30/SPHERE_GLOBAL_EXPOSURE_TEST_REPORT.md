# 标准球全扫描曝光测试：本次源码检查记录

## 可在当前环境重现的通过项

1. 使用 `cmake -DSPHERE_EXPOSURE_CLI_ONLY=ON`，C++17 编译新增 `SphereExposureSweep` 和 `sphere_exposure_cli`，自检通过：二维圆弧、RMS、峰值半径、多个曝光比较、采样过粗或数据不足时拒绝排名。
2. 新增 `.sxraw` v1 离线读取工具的 Python 语法检查通过，利用两帧测试点进行了二进制格式的读取往返检查。
3. 旧版 `-DEXPOSURE_ANALYSIS_CLI_ONLY=ON` 构建通过，保留原 ExposureAnalysisEngine 与原固定位置自动曝光测试代码。
4. 新旧版本的 `controller/ECI3808_V32_16_H1_H3_ONLY.bas` SHA256 完全相同；H1/H3 控制器协议没有发生修改。
5. CMake APP_SOURCES 已包含 `src/app/MainWindowSphereExposure.cpp` 和 `src/calibration/SphereExposureSweep.cpp`；头文件包含全部新增状态/槽声明。

## 尚未通过或尚未执行

- **未执行 Windows Qt6/VTK/ZAux/LLT 完整应用构建**：当前 Linux 环境没有相关厂商 SDK 和 Qt 图形依赖。需在用户的 Windows/Visual Studio 环境核对实际 C++ 类型和 Qt 信号槽连接。
- **未进行实机运动测试**：尚未验证实际的 X 轴行程、设备物理安全、软件急停、信号失联、真实采样频率、丰富辅助 LLT 通道的运行开销。
- 旧工程的大量 `P0_TESTS_ONLY` 历史 Mock 目标曾尝试编译，但受当前环境编译时间限制，在构建未完成前停止，不可声称整套 Mock 通过。历史静态约束检查部分依赖原压缩包未带的工具脚本。
- 软件预检查无法代替真实物理限位和独立硬件急停。正式自动扫描前必须用无工件、低速、短曝光集合验证全过程。

## 版本兼容

基于用户前一次 `MotionLaserSync_H1_H3_H3_TEMPORAL_PATH_UI_LOG_FIX_FULL_SOURCE.zip`。如在另一个名为 `MotionLaserSync_V27_6_57_FULL_PROJECT` 的旧源码目录中进行局部覆盖，必须确认实际已更新到同一份 H1/H3 头文件/实现；不能跨版本直接覆盖。
