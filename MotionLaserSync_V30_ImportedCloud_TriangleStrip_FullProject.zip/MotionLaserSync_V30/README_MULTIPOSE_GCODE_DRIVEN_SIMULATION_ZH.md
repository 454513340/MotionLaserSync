# V29 多姿态实验扫描：以最终 G 代码为输入的离线数字孪生执行仿真

## 本次修正的主要问题

之前的动画读取 `ExperimentPlan::path`，即使导出的 NC 文本中某段 XYZCB、F 或 M50/M51 有错，动画仍可能按照正确规划轨迹继续播放，因此不能称为“G 代码验证”。

本版在原界面“路径规划 → 多姿态实验扫描”内，将**NC 文本变为仿真唯一运动指令来源**。

```
STEP + .scan -> 粗配准候选（仍需人工复核） -> 多姿态 XYZCB 规划
    -> makeM6NcPreview() 生成 H1/H3 离线 NC
    -> simulateMultiPoseNc() 读取 NC 文本 + 复用 runtime::parseNcBlock
       -> G05/G93 逆时间逐段插补 / M50-M51 开关 / 名义 profile 触发时钟
       -> 逐点与原规划 XYZCB、采集段/转场段、段时间核对
          -> NC 执行级验证通过（只代表实现的 NC 子集）
             -> Physical17 正运动学 + 五轴机床和激光扇面逐帧动画
             -> 虚拟激光采样 -> simulated .scan + float64 PLY
             -> manifest 保存实际使用的 NC 文件 SHA-256
             -> 同姿态真实 .scan 对比
```

## 操作说明

1. 在“路径规划”内打开“多姿态实验扫描”。导入 CAD STEP 和原始真实 `.scan`，提议粗配准，检查叠加后人工确认。粗配准不能替代完整 6DoF 精配准与现场安全验收。
2. 设置同一 CAD ROI 和 P01/P02/P03 等 C/B 姿态，点击“规划五轴轨迹 + 逐姿态光学检查”。该操作如今会先创建**H3 离线 NC 并对其逐段解释执行**，再生成光学预览。
3. 选择 H1/H3。系统为各姿态重新生成 NC 并逐点验证运动目标、G93 进给时间和 S0/S1/M50/M51 同步状态。只有通过后才可播放、导出或仿真。
4. “查看所选姿态 NC”显示当前已解析执行的程序前后片段及 SHA256。完整内容参与仿真，不因文本编辑器截断而省略。
5. 如要校验已保存的 NC，选定**一个具体姿态**，点击“导入 NC 文件并逐段校验”。此入口将**实际读取磁盘 NC 字节**，拒绝不符合原规划、错误拓扑、未知指令或错误时间的程序。通过后，动画与点云生成改用这份加载的文本。
6. “按已解析 G代码播放五轴+传感器”可播放、暂停、单步、拖动，显示当前 XYZCB、激光开关、已触发 Profile 数量及最后 M 指令和 NC 行号。P01/P02/P03 是独立离线程序，切换间不伪造未经规划的连贯机床转场。
7. “执行 G代码并导出模拟 .scan + PLY”按 NC 解释器计算的**全部理想曝光时刻**产生模拟轮廓，不再读规划器原始 `view.exposures`；保存每个姿态的 `SIMULATION_INPUT_H*.nc`、模拟 SCAN v3、有效点无损 XYZ PLY，并在 manifest 中记录该 NC 的 SHA256、H1/H3、M50/M51 组数及名义运动时间。
8. 用相同 P01/P02/P03 实机采集的新 `.scan` 可与对应仿真 PLY 做固定机床坐标系近邻对比。原扫描中的 `PoseTiming::Simulated` 不得作为真实数据。

## 目前实现的解释器边界

- 使用与原 `GCodeParser` 相同的底层 `runtime::parseNcBlock` 语法/模态解析，但**不调用任何机床执行器**。
- 本次只支持生成器输出的 `MACHINE_JOINTS_XYZCB`、绝对 `G90`、`G05` 连续五轴点、`G93` 每段逆时间进给、`M50/M51/M60/M61/M63/M30`、H1/H3 的离线子集。遇到 `G43.4`、`G92`、`G91`、不支持的直线/圆弧、错误的 S/G93/触发顺序等，明确拒绝，**不会自动猜测其意义**。旧硬件 H2 不支持。
- 含有 `OfflineOnly: true` 才能进入模拟器；不得改成可实机执行程序。G 代码实际控制器速度规划/加速度/jerk、插补缓冲区、硬件电气触发相位、传感器响应延迟都不等价于这里的**名义 G93 理想插补**。
- 第一条 `G00` 被识别为**未知实际起点的定位参考**，仅将虚拟机床放在其终点，不动画臆造的入场轨迹。各姿态之间未规划的 C/B 连续转场也不被模拟成已验证的安全动作。
- M3 激光扇面/遮挡模型尚未完成各姿态的独立光学标定；粗配准及局部 FCL 覆盖不足以证明真实夹具/传感器外壳无碰撞；离线 NC 校验结果**不构成机床运行许可**。
- `M63` 的保存等待视为逻辑同步屏障，未模拟真实磁盘 IO/外设异步响应时间。

## 主要源码

- `include/twin/MultiPoseNcSimulation.h` + `src/twin/MultiPoseNcSimulation.cpp`：离线 NC 逐行解析执行、名义曝光序列、严格匹配规划及时间回放采样。
- `src/twin/MultiPosePlayback.cpp`：新增使用 NC 输出而非原规划轨迹构造多姿态播放时间轴。
- `src/twin/MultiPoseExperimentQtAdapter.cpp`：实际 NC 解析后驱动光学预览和全部模拟轮廓，导出时回读已保存的 NC 重新验证。
- `src/widgets/MultiPoseExperimentWidget.cpp`：NC 导入与验证、H1/H3 切换、控制动画、对比及输出。
- `tests/twin/twin_multi_pose_nc_simulation_tests.cpp`：改写 XYZCB/G93、移除 M50/M51/M63、修改触发 S 标志、切换非法模态等负测试。
- `tests/twin/twin_multi_pose_experiment_tests.cpp`：三个角度的 NC 逐段解释、从 NC 触发位姿生成虚拟激光命中。

## 测试和 Windows 联调

这里已在 Linux portable CLI 模式下编译，并运行 `ctest -E V28_M6_CONTINUOUS_5AXIS_OFFLINE` 的 26 项测试（26 通过）；大型 M6 长时测试被单独排除，上传原项目缺失的 `sensor_calibration_timing_tests.cpp` 不计入通过数。Qt/VTK/Windows 版**尚未实际编译启动或操作 GUI**。

Windows 上请以原 Visual Studio + Qt + VTK + OCCT + FCL 开发环境重新生成并编译，先执行项目 `tools/RunGuiSmokeTest.ps1`，再从 P01 单姿态开始验证 NC、播放、模拟点云与 SHA256。不得在未补齐完整现场验收前进行实机运动。
