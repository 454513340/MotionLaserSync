# MotionLaserSync V28.7.3 — M6 无损模拟 SCAN 分卷与分阶段进度条

> 此版本由 V28.7.2 源码修改。**数字孪生离线仿真，不向真实机床下发运动指令。**

## 一、改动概览

M6 不再以大型 PLY 为默认输出，而是在正式的五轴连续扫描过程中，直接将每帧 **完整 1280 原始索引范围中的有效回波**连同 `XYZCB / sensorToMachine / Simulated 时间 / 源序号` 记录到现有 `.scan` v3 / Archive v5 归档结构。

- 同一个仿真段的有效 Profile 保持原始顺序；超过容量阈值（默认保守估算的约 48 MiB 未压缩负载）后分卷。正常按扫描段边界分卷。
- 使用程序现有 `CompactScanIO::save` / Qt zlib (`qCompress`)；**并非 LZ4 或 Zstandard**。
- **不对有效 Profile 降采样**；CAD 表面覆盖率继续采用全部模拟点。分卷包含有效的工件和支承面回波，原始采样索引保留；无效采样没有坐标，但索引缺口仍保留。
- 标记 `PoseTiming::Simulated`，五轴硬件 `feedbackMask/latchMask/commandMask` 均为 0，不能冒充测量记录。原 H1/H3 的 Physical17 一致性校验保持不变。
- 每卷是独立可由现有 M2 单文件读取器打开的 v3 `.scan`；主程序目前**不支持一次点击自动合并全部分卷**。使用 `*_scan_manifest.json` 的文件列表可按顺序识别各卷。
- 输出 JSON 报告和只读离线五轴轨迹 CSV。PLY 为额外可选输出，默认关闭；如勾选则可指定每 N 点抽样输出，仅用于显示。

## 二、界面与进度

数字孪生工作台 M6 区新增 **四条可见进度条**：

1. **候选搜索**：展示粗筛/精评的当前阶段进度，而不是将候选 Profile 算作正式扫描结果；
2. **已完成扫描段数**：完成数量/用户设置的上限（NBV 可能提前结束，所以上限不是保证执行段数）；
3. **当前扫描段**：在当前段逐帧 `n / N` 的进度百分比，包含扫描段序号；
4. **无损归档/导出**：扫描时显示暂存 Profile 和卷数；导出时显示复制压缩 `.scan` 文件的已完成字节及文件数量。

仿真和导出均可取消。导出使用 `QSaveFile` 原子写入单文件；导出出错/取消后删除本次已经成功创建的输出文件。扫描中途清除也会先请求取消，不清理用户之前的磁盘文件。

## 三、导出产物

例如用户输入 `twin_m6_continuous_5axis.json`（请选**新的文件名**，为避免覆写已有分卷，程序会拒绝复用已有文件名），会得到：

```
twin_m6_continuous_5axis.json                  M6 覆盖面积、阶段结果及安全标记
twin_m6_continuous_5axis_trajectory_offline.csv   包含 SCAN/TRANSFER 的 XYZCB + 4×4 姿态摘录，绝不可当真实运动命令
twin_m6_continuous_5axis_scan_manifest.json      分卷次序、每卷 Profile/采样数量、SHA256、来源和格式
twin_m6_continuous_5axis_seg01_part0001.scan     Qt zlib 压缩的完整模拟 Profile
twin_m6_continuous_5axis_seg01_part0002.scan     该段超阈值时继续分卷
...
```

如果勾选“另存抽样 PLY”，还会追加 `_simulated_sampled.ply` 或 `_simulated_full.ply`。不勾选时不会构造以前的 `.xyzfloat` PLY 缓存，因此降低临时磁盘占用，但新的无损 `.scan` 暂存文件在本次 M6 数据对象存在期间仍需要磁盘空间。

**大小提示：** SCAN 保留 `float32` PLY 没有的采样索引、时间、五轴位姿及 `binary64` X/Z，因此文件最终大小由真实压缩率决定，不能承诺一定比 PLY 更小。压缩会增加部分 CPU 耗时。

## 四、重要数据分离

- `Frame5D::sensorToMachine` 是 **M6 每帧模拟曝光时刻的刚性变换**，由 Physical17/离线锚定模型计算，不可再次施加五轴变换。
- `PoseTiming::Simulated` 携带零硬件来源掩码；严格硬件记录仍必须与保存的 Physical17 计算结果一致。此扩展不修改 `.scan` v3 或 Archive v5 的磁盘二进制布局。
- M2 可以按卷查看 M6 的模拟 SCAN，并显示 SIMULATED 来源提示；**M6 不接受 M6 生成的虚拟 SCAN 作为下一轮“真实初扫”**。
- M3 多姿态光学模型仍未经真实多角度标定，整机工件/夹具/传感器外壳完整碰撞检查也未经授权。本阶段不能导出实际机床可执行轨迹。

## 五、Windows 10 / VS2022 验证建议

1. 在独立目录解压完整工程并使用 VS2022 `x64-Release` 打开。
2. `TWIN_OCCT_PREFIX` 保持为 `D:/dev/vcpkg/installed/x64-windows-release`。
3. 删除 CMake 缓存，重新配置，确认：
   `V28.7.3 M6 streaming simulated SCAN v3 + segmented progress bars [OK]`
4. 编译 `MotionLaserSync.exe`。之前的 SDK/VTK/Qt/FCL 环境及可视化资源仍需要与项目一致。
5. 导入 STEP、真实 H1 `.scan`，运行 M5；先用一个连续五轴段检查四条进度条。
6. 点击保存，检查 JSON/CSV/分卷 `.scan` 与 manifest。用 M2 **单独读取其中一卷**，核对点云和 SIMULATED 标记，再运行多段。
7. 对已保存的磁盘文件，清空 GUI 图层不会删除它们。

## 六、测试范围与限制

- 便携 C++17 算法层的测试已扩展同步 Profile sink 和单段进度读取。
- 新增 Archive v5 模拟来源/位姿索引/CRC 的正反回归测试，也验证了正确的硬件 Physical17 记录仍可通过校验，伪造硬件来源的模拟变换不能通过。
- 本环境没有 MSVC/Qt6/VTK，因此 Windows GUI 和 `CompactScanIO::save()` 的 Qt 压缩/读取往返需要你的本机首次构建验收；不得将离线回归通过等同于已验证 Windows GUI。
- 当前模拟分卷采用 `uint32` 的原始采样索引与保守的单卷大小限制；下一阶段如需对整个多卷数据进行自动恢复与合并，应另建有内存/流式保护的 reader，而不是一次载入全部数千万点。
