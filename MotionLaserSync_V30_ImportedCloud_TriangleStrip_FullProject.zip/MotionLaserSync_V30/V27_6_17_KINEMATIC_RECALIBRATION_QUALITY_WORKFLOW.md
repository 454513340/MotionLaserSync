# V27.6.17 — Kinematic Re-calibration / Quality-Constrained Stage-2 Workflow

This change set addresses the System Calibration → Kinematic Calibration Stage-2 workflow.

## 1. Re-calibration after restart

A persisted, independently validated Physical17 result is no longer treated as a terminal state that disables Stage-2 pose generation. After the live controller/sensor coordinate convention is bound, the existing accepted model may be used as:

- the navigation / planning seed for a new Stage-2 calibration,
- the runtime fallback model while the new training set is being acquired and solved.

The old accepted model remains available to scan/RTCP until a newly solved model passes the independent hold-out validation gate.

## 2. Sphere point-cloud import on the kinematic page

Stage-2 now provides **Import sphere point cloud** and **RANSAC fit sphere center** actions. The implementation reuses `SphereDistanceAngleStudy::fitMachineSphereRansac()` and updates the machine-frame fixed sphere center used by the kinematic planner. The fitted sphere is also forwarded to the MachineSafety / 3-D safety visualization.

Importing/refitting a sphere does not overwrite the currently accepted production calibration.

## 3. D–gamma–eta quality-constrained candidate geometry

The portable Physical17 pose planner gains an optional quality-study geometry mode. The integrated GUI enables it by default:

- D: 92 … 100 mm, default step 4 mm
- gamma: 0 … 50 deg, default step 25 deg
- eta: -7.5 … +7.5 deg, default step 7.5 deg

Candidate sphere-center geometry follows the same definitions as the sensor study:

- `Xc = D sin(eta)`
- `Zc = D cos(eta)`
- `|Ys| = R sin(gamma)`

These quality constraints are candidate gates only. The existing Physical17 information matrix and greedy D-optimal selection still determine which candidates are recorded, preserving the rank/observability objective.

## 4. Optical simulation and collision preflight

After D-optimal selection, the GUI generates a reserve pool and filters it with the same physical scan simulation principles used by the sphere-study workflow:

- scanCONTROL trapezoidal X-Z measuring field,
- Flip-Z-aware FOV orientation,
- end-effector-facing visible sphere arc,
- minimum plane-intersection margin,
- minimum visible arc angle / arc length.

When MainWindow supplies MachineSafety callbacks, every retained pose also passes:

- target-pose collision / clearance validation,
- complete transition sweep validation from the previous accepted pose.

The same safety checks are repeated immediately before every real machine move (fail closed).

## 5. Quality-controlled Stage-2 acquisition

Each fresh profile is processed as follows before it can enter the Physical17 solver:

1. coarse ROI filtering,
2. robust circle RANSAC,
3. reject if RANSAC inlier ratio is below the configured threshold,
4. unwrap the measured circle arc and trim both arc ends,
5. keep only the trimmed RANSAC inliers,
6. compute radial RMS and absolute-residual P95 on the kept points,
7. reject the frame if RMS/P95 fail,
8. reject the entire pose if too few fresh frames pass.

Default Stage-2 gates:

- minimum RANSAC inlier ratio: 0.80
- trimmed RMS <= 0.010 mm
- trimmed P95 <= 0.020 mm
- trim 5% of measured arc span from each end
- at least 80% of requested fresh frames must pass

Only the surviving trimmed RANSAC inliers are written into `SphereProfileObservation.points`, therefore background/outliers and low-quality arc-edge points do not enter the Physical17 optimization.

## 6. Automatic Stage-2 move + acquisition

A new **Automatic move and acquire Stage-2 plan** workflow executes the training plan sequentially:

1. execution-time MachineSafety target + transition check,
2. move to full XYZCB target,
3. arrival sphere-fit check,
4. fresh-profile acquisition,
5. strict per-frame / per-pose quality gate,
6. accept or skip pose,
7. continue to the next pending pose.

A dedicated stop action interrupts the automated sequence. Controller/sensor state failures and capture drift stop automation rather than silently continuing.

## 7. Portable regression tests

`tests/v20_2_single_sphere17_tests.cpp` adds tests that verify:

- generated target centers stay inside the configured D/gamma/eta region,
- a D=92…100 quality-constrained D-optimal plan still reaches Physical17 target rank >=14 and full-state rank >=17 in the synthetic reference problem.

## Build-validation note

The portable Physical17 CLI and numerical tests compile on the provided Linux environment. The complete GUI cannot be linked here because this project intentionally requires the Windows x64 Qt/VTK/vendor SDK/FCL deployment. The modified GUI sources therefore still require the normal Windows x64 Release build on the project machine before hardware use.
