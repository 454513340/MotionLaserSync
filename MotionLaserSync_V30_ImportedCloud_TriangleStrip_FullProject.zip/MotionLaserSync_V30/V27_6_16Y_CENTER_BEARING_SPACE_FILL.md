# V27.6.16Y — Center-Bearing-Aware Space-Filling Sphere Study

This release extends V27.6.16X without changing controller BASIC.

## Geometry

The sphere-section circle center is no longer assumed to lie on sensor +Z.
For configured optical reference `(X0,0,Z0)` and target/observed circle center `(Xc,0,Zc)`:

- `D = sqrt((Xc-X0)^2 + (Zc-Z0)^2)`
- `eta = atan2(Xc-X0, Zc-Z0)` (from +Z toward +X)
- `Xc = X0 + D*sin(eta)`
- `Zc = Z0 + D*cos(eta)`
- `gamma = asin(h/R)`, where `h` is the unsigned known-sphere-center to actual profile-plane distance.
- `theta` remains the point-level local sphere-normal / optical-viewing-ray angle.

`eta=0` is now explicitly only a special case.

## Path planning

The planner:

1. searches reachable C/B orientations inside the real software limits;
2. retains a compact diverse family of laser-profile plane normals;
3. builds all machine/sensor-feasible `(D,gamma,eta,plane)` candidates;
4. rejects candidates whose theoretical full section circle leaves guarded scanCONTROL X/Z FOV or whose RTCP-equivalent XYZ inverse violates machine limits;
5. uses deterministic maximin selection in normalized `(D,gamma,eta,unoriented plane-normal)` space;
6. keeps at most the requested number of study poses (default 120);
7. orders the selected set by nearest-neighbor XYZBC travel for automatic execution.

This avoids the old Cartesian explosion while keeping B/C variation as a natural way to realize diverse section planes.

## Acquisition and analysis

- one independent acquisition batch per pose, default 20 Rich Profiles;
- RANSAC locates the circle/ROI but does not erase dropout/outlier samples;
- actual `D/gamma/eta` are recomputed from acquired data and actual MPOS;
- exports include eta at plan, visit, profile, and point levels;
- the baseline empirical quality surface is now `D/gamma/eta`, not only `D/gamma`.

## Compatibility

- Existing `eta=0` APIs remain as wrappers for portable tools/tests.
- V27.6.16V geometry/quality regression remains passing.
- No `.bas` file is modified by X -> Y.
