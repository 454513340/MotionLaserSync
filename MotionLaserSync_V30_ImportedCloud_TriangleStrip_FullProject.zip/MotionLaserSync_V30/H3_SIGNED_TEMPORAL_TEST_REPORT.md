# H3 专属有符号时域校正修改：测试与限制记录

- 基础：原 `MotionLaserSync_H1_H3_ONLY_FULL_PROJECT`，控制器 BASIC 完全保持不变，V32.16 协议魔数 `321058`。
- 平台：Linux portable C++ tests only（没有 Qt6/VTK/Windows 驱动运行时）。
- `cmake -S . -B build-h3-tests -G Ninja -DP0_TESTS_ONLY=ON -DCMAKE_BUILD_TYPE=Release`
- `cmake --build build-h3-tests --target h1_h3_only_contract_tests p0_unit_tests p0_core_mock_tests v27644_hardware_temporal_tests v27650_drift_radius_temporal_tests h3_signed_temporal_tests`
- `ctest --test-dir build-h3-tests -R '^(h3_temporal_extension_contract|h3_signed_temporal|v27644_hardware_temporal|v27650_drift_radius_temporal|h1_h3_only_contract|p0_portable_unit)$' --output-on-failure`：**6/6 PASS**。
- `p0_core_mock_tests`：**109/112 PASS**，其余三项分别是旧工程存在的 `stale HOME restore`、`axis compensation reconnect revocation` 和 `stale XYZ Home bits downgraded`；并非本次引入，但需要后续单独追查。
- 旧合同脚本对缺失的历史 BASIC 依赖会发生 `FileNotFoundError`，不能作为目前 BASIC 的正确性证明。
- 目前未验证 Windows 端 Qt GUI/CMake 全量构建、29xx/LLT SDK 版本适配或 V32.16 的实机 H3 signed-τ 标定；请完成后再将该功能用于正式运动测量。
