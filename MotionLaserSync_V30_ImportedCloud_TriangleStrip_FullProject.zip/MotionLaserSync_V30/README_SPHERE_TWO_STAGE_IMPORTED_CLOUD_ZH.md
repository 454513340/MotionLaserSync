# 标准球导入点云两阶段拟合（诊断增强）

## 本次修改针对的三个入口

1. 主界面「球面测距 / 截面角 / 圆心视场偏角」：`MainWindow::onSphereStudyImportCloud()` → `onSphereStudyFitSphere()`，包括全标准球曝光扫描的参考球路径规划。
2. 单球 Physical17「运动学标定」阶段 2：`SingleSphere14CalibrationWidget::onImportStage2SphereCloud()` → `onFitStage2SphereCloud()`。
3. 「硬件同步时域标定」H1/H3 的参考球：`HardwareSyncCalibrationWidget::importReferenceCloud()` → `fitReferenceSphere()`。

这三个入口均改用相同 `SphereTwoStageFit::fitImportedSphere()` 及 `SphereArcQualityGate.h` 质量判据。原有全点 3D RANSAC 函数不删除，作为对照同时计算。**运动中的时域动态球重建，不属于“导入点云参考球拟合”入口，此版不改变其原有时域模型、锁存或运动流程。**

## 两阶段方法

- 使用 `.scan` v3 保留的逐帧 X/Z（二进制 double）和当次保存的 `sensorToMachine`，不重写/重新估计 Physical17。
- 同时以同一批双精度机床点进行旧全点 3D RANSAC 参考拟合，旧方法的半径、RMS、内点数均输出用于对照。
- 将旧拟合球心通过 `sensorToMachine` 逆变换，得到每帧传感器 X/Z 中的球心预计投影，用作圆弧 ROI 的定位初值，而**不是**用理论半径强制决定三维拟合球直径。
- 使用原有 `SphereExposureSweep::fitArc()`，按弧覆盖角 >=120°、RMS <=0.010mm、圆弧拟合内点 >=80、半径在物理合理区间内，筛选合格 Profile；随后将这些 Profile 的双精度点用于 3D RANSAC，第二阶段阈值 **0.020mm**。
- 二阶段候选球心与旧球心差距 >1mm、二阶段 RANSAC 失败、合格 Profile <20 时，均拒绝应用新参考球；传统结果继续展示作诊断，**不会静默回退并驱动自动路径**。
- `.ply/.csv/.txt` 或缺少原始逐帧 X/Z 的旧 `.scan` 只能走原 RANSAC，明确在界面与日志标记“未执行圆弧筛选”。不能从无来源的 XYZ 点云伪造 Profile 归属。 

### 如何调整初始诊断阈值

在 `include/calibration/SphereArcQualityGate.h` 中修改 `SphereTwoStageQuality`：

```cpp
minimumArcSpanDeg = 120.0;      // 单帧可见圆弧覆盖角
maximumArcRmsMm = 0.010;        // 单帧圆弧RMS，10µm
minimumArcInliers = 80;        // 单帧拟合内点数
minimumAcceptedProfiles = 20;  // 合格截面下限
refinedRansacThresholdMm = 0.020; // 后续3D球拟合阈值，20µm
```

这里的默认值是本轮数据的研究起点，不是厂家宣称的整体测量精度。不能为了“刚好得到19.05mm”倒过来调整筛选阈值。界面原来的 3D 阈值保留，用于**旧算法对照**；新的 20µm 阈值由此处单独控制。

## 对 sphere_calibration12(1).scan 的实测离线复算

基于该文件先前已解码的 1768 帧 X/Z 和机床双精度点；用本次源码复用的 `SphereExposureSweep::fitArc` 筛选：

| 指标 | 结果 |
| --- | ---: |
| 原始 Profile | 1768 |
| 符合新圆弧判据 Profile | 1195 |
| 通过判据的三维点 | 503830 |
| 原全点 C++ RANSAC（0.120mm） | 直径约19.09762mm |
| 新两阶段 C++ RANSAC（0.020mm） | 直径约19.05915mm |
| 新二阶段内点 RMS | 约0.00893mm |
| 奇偶 Profile 独立拟合直径 | 19.05759 / 19.05663mm |

本版与旧离线分析脚本得到的 19.05033mm **不完全一致**，原因是圆弧识别和质量筛选的具体实现不同。这证明质量筛选确实改变了球径估计，但尚不代表能实现亚微米绝对球径测量精度。奇偶组只是同一次扫描的内部稳定性检查，不是另一份数据的独立验收。

## 代码与部署

- 全部上位机源码、模型资源、原控制器 `ECI3808_V32_16_H1_H3_ONLY.bas` 都在完整 ZIP 中；**BASIC 完全未改动**。
- 原工程没有新增机床运动权限。旧 H1/H3/LLT/STOP 联锁及原有活动标定 JSON 都不覆盖。
- 原始 `.scan` 不写回；显示点云仍可使用 `QVector3D`，数值拟合采用 .scan 保存的 binary64 坐标以避免界面单精度量化。
- 建议先用 `.scan` 离线复测，核对系统日志 `两阶段参考球` 的两组直径/RMS，再确认新球心是否适合实际机床路径规划。不要直接凭一次球径一致性改写当前已验证的 17 项标定。

### 在你的 Visual Studio/CMake 中

解压完整工程，或使用替换包在上一版 `SPHERE_EXPOSURE_XONLY_PATH_FIXED` 工程中按目录覆盖。因为新增 `SphereTwoStageFit.cpp`，务必同时覆盖 **CMakeLists.txt**，再“删除缓存并重新配置 CMake → 重新生成 MotionLaserSync.exe”。

如果你曾手动修改 X 轴安全速度、模型资源路径或其它源文件，建议先备份，使用 PATCH 核对冲突；这份工程基于**上一次提供的 XONLY PATH FIX 归档**，不能推断已经包含你电脑上后续自行修改的代码。

### 已做与未做的测试

- 便携式 CMake 测试 `-DSPHERE_TWO_STAGE_QUALITY_CLI_ONLY=ON`：通过（圆弧质量门控、数值 RANSAC）。
- 旧 `-DSPHERE_EXPOSURE_CLI_ONLY=ON`：通过（圆弧曝光分析回归）。
- 用户 sphere12 RAW 导出点的离线 RANSAC 复算、奇偶 Profile 对照：完成。
- 三个导入入口静态一致性与 CMake 新源码登记检查：通过。
- **Windows Qt/VTK GUI 完整编译及实机测试：尚未执行**。新增两阶段候选必须先在 Windows 上离线拟合另一条独立球扫描验证，不能直接认定已有 Physical17 精度通过。
