# MotionLaserSync V27.6.45 — 材料曝光方案日志化与 Roaming 标定目录

## 修改目标

本版本基于 V27.6.44，**不改变当前控制器硬件触发方案**。ECI3808 V32.9 仍为：

`OP14/PWM0 -> scanCONTROL External Trigger`

`OP14/PWM0 -> ECI IN0 -> REGIST(104) -> XYZ/C/B MPOS`

本次只修改“传感器参数 / 材料曝光方案”的界面提示与材料曝光库持久化路径。

## 1. 删除材料曝光方案下方的小提示

原界面在材料曝光方案下方放置 `m_lblMaterialExposureStatus`，会显示“材料曝光库已加载”“材料曝光方案已应用”等提示。V27.6.45 删除该 QLabel，避免占用参数区空间。

以下动态信息统一进入底部系统日志，日志前缀为 `[材料曝光方案]`：

- 材料曝光库启动加载成功/失败；
- 点击“刷新”的成功/失败；
- 切换到手动 Exposure/Idle；
- 方案 key 不存在；
- 方案与当前同步模式不兼容；
- 方案应用后的 Exp、Idle、内部时序、标定参考 Rate/Idle、置信度；
- 当前激光功率/反射选择/阈值与标定条目不一致；
- 曝光分析推荐值写入材料库成功/失败；
- session 缺材料/光照、缺有效 Profile Rate/Idle、清单无效或缺失。

材料条目的静态 tooltip 仍保留，用于查看条目条件；它不是运行状态提示。

## 2. 用户材料曝光库路径

V27.6.44 使用 `QStandardPaths::AppConfigLocation`，现场 Windows 机器表现为：

`C:/Users/<user>/AppData/Local/YourCompany/MotionLaserSync/material_exposure_library.json`

V27.6.45 改为：

`QStandardPaths::AppDataLocation/calibration/material_exposure_library.json`

Windows 下即：

`C:/Users/<user>/AppData/Roaming/YourCompany/MotionLaserSync/calibration/material_exposure_library.json`

在当前用户 45451 的机器上对应：

`C:/Users/45451/AppData/Roaming/YourCompany/MotionLaserSync/calibration/material_exposure_library.json`

这与 `active_single_sphere17.json`、`active_hardware_temporal.json` 所在的持久化标定根目录保持一致。

## 3. 旧库迁移

为避免升级后已有材料曝光条目消失：

1. 如果新 Roaming/calibration 路径已经有库文件，直接加载新文件；
2. 如果新文件不存在，则检查旧 `AppConfigLocation/material_exposure_library.json`；
3. 旧文件存在时先读取，并把合并结果保存到新 Roaming/calibration 路径；
4. 后续启动以新路径为准。

## 4. 与曝光分析联动

传感标定曝光扫频分析得到推荐值后，写入材料曝光库的目标同样是新的 Roaming/calibration 文件。`sensor_calibration_session.json` 中的 `analysisPlan.materialLibraryPersistence` 也同步改为：

`QStandardPaths::AppDataLocation/calibration/material_exposure_library.json`

## 5. 不变项

- 控制器 BASIC 未修改；
- OP14、IN0、REGIST(104) 硬件同步拓扑未修改；
- V27.6.44 的硬件同步时域标定、Pose 时域补偿、Physical17 均未改变；
- 材料曝光推荐值算法及硬件同步下 5 ms 周期 Idle 重算策略未改变。
