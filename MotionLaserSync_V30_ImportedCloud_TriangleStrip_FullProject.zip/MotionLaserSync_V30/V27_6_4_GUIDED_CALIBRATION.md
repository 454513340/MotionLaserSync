# V27.6.4 Guided Calibration changes

基于 V27.6.3 Release-only 稳定版本，重构单球17物理参数/rank14第一次标定流程。

核心修正：

1. 参考示教锁定 Flip X/Z、ATYPE 对应的 DPOS/MPOS 数据源和手眼平移规范锚点。
2. 当前 XYZ=ATYPE1 时标定自动使用 XYZ DPOS + C/B MPOS；以后 XYZ=ATYPE4 时自动切五轴 MPOS。
3. 参考姿态要求 B/C≈0 且 |Y_S| 小；第一次粗球心种子强制 Y_S=0，降低 ±Y 导航分支敏感性。
4. 首次计划自动限制 B±20°、C±30°、5°网格、最多24姿态、单侧Y_S。
5. 规划表 XYZ 明确为 seed，绝不直接执行；运动只按 B/C≤5°小步推进。
6. 每次 B/C 小步后必须重新拟合；球靠近安全视场边缘时，必须先用 XYZ 小步只把 X/Z 拉回中央，途中不跨 ±Y_S。
7. B/C 最终到位后才闭环到该 D-optimal 目标球心并允许静态采集。
8. 首次 rank14/17 求解后，复标规划直接使用已求解固定机床球心，不再依赖参考轮廓 ±Y_S 分支。
9. 增加二阶段状态：首次求解 -> 全范围复标 -> 最终求解 -> 独立验证/保存。
10. 修正参考/采集删除状态，并禁止会话中混用不同 Flip、ATYPE/位置数据源、规范锚点。
11. Core planner 增加 `PosePlannerSeed::hasSphereCenterMachine`，复标计划的参考距离也使用已求解球心反算的传感器中心。
12. 新增回归测试：首次单侧安全计划达到 physical rank14/full rank17；已知固定球心后计划不再依赖 taught ±Y。

详细操作见 `docs/V27_6_4_GUIDED_SINGLE_SPHERE_CALIBRATION.md`。
