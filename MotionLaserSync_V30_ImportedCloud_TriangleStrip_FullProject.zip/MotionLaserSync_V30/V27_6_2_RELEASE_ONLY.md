# V27.6.2 — Release-only CMake

基于 V27.6.1，只调整构建配置，不改设备、运动、标定或采集逻辑。

- Visual Studio `CMakeSettings.json` 只保留 `x64-Release`。
- 单配置生成器未指定 `CMAKE_BUILD_TYPE` 时默认 `Release`。
- Qt 平台插件只检查/复制 Release 的 `qwindows.dll`，不再配置 `qwindowsd.dll`。
- 两个单球 CLI 工具标记为 `EXCLUDE_FROM_ALL`，普通 GUI 生成不参与。
- 推荐删除旧 `.vs` 和 `out` 后重新打开工程，以免 VS 保留旧的 x64-Debug 配置。
