# MotionLaserSync V27.6.16A：MSVC/CMake 长路径构建修复

## 问题

V27.6.16 源码包的工程目录名较长，同时 `CMakeSettings.json` 把 Ninja 构建目录设置在：

`<projectDir>\\out\\build\\x64-Release`

如果用户又把 ZIP 解压到同名外层目录，CMake 的 `CMakeScratch/TryCompile-*` 临时对象路径可能超过传统 Win32/MSVC 路径边界。此时甚至会在项目源码尚未参与编译前，由 `cl.exe` 对 `testCXXCompiler.cxx` 报：

`fatal error C1083: 无法打开编译器生成的文件: "": Invalid argument`

## 修复

V27.6.16A 不改变 V27.6.16 的运动学、同步协议、点云归档或 BASIC 逻辑，只修复 Windows 构建布局：

- ZIP 内工程根目录缩短为 `MotionLaserSync_v27_6_16A`；
- Visual Studio `CMakeSettings.json` 的 `buildRoot` 改为：

  `${env.USERPROFILE}\\CMakeBuilds\\MotionLaserSync\\${workspaceHash}\\build\\${name}`

- `installRoot` 同样移出源码目录；
- 额外传入 `-DCMAKE_OBJECT_PATH_MAX=200`，让 CMake 更早对过长对象路径采用缩短策略；
- 应用显示版本改为 V27.6.16A，便于区分构建修复包。

## 使用注意

从 V27.6.16 切换到本版本时，不要复用原工程目录中的 `out/build`、`.vs` 或旧 `CMakeCache.txt`。Visual Studio 会在新的 USERPROFILE/CMakeBuilds 路径重新生成缓存。

本修复只处理构建路径，不代表硬件同步物理链路已经完成实机验收。
