# V29 多姿态研究扫描：离线机床/传感器回放、完整模拟点云和真实对比

## 范围与安全状态

本次只在「路径规划 → 多姿态实验扫描」的原有独立研究对话框内追加功能。M0–M8 数字孪生、H1/H3 硬件同步与原 G 代码执行保持原有职责；没有使 `OfflineOnly` 程序变成可执行实机 NC，没有控制器/传感器 API 调用。

**Windows Qt + VTK GUI 的编译和实际窗口操作必须在用户 Windows 环境验证；Linux CLI 编译通过不等于 GUI 已通过。** 工件当前仍是 `registrationVerified=false` 的人工审核粗配准候选，无法作为现场安全证明。机床五轴关节运动回放只是显示；两组不同姿态被定义为两个独立的程序会话，期间不添加未经规划的 C/B 联接运动。

## 图形界面操作

1. 在「路径规划」打开「多姿态实验扫描」。导入 STEP 与历史真实 SCAN v3，用粗配准建议或人工位姿做离线场景。确认零件与点云方向后，规划 P01/P02/P03。须确认光学命中与碰撞检查状态；实机检查仍未完成。
2. 在窗口下部「5 离线轨迹执行回放 / 仿真点云 / 实测对比」点击 **播放五轴+传感器仿真**：共享三维视图中的整机 XYZCB 模型跟随规划路线，红色线框为理想激光扇面，绿色点逐渐累积为模拟命中点。转场段激光 OFF；点击「暂停/继续」「单步」「停止」或拖动进度条，速度为 1×/5×/20×。下拉框选择「显示全部姿态」可连续观看分离的 P01/P02/P03 会话；选某一个姿态，只播放它的独立轨迹。
3. **规划后立即播放是稀疏预览**，只有每个姿态最多约 24 个已预计算的真实光线命中轮廓，用于快速看运动与轮廓方向。
4. 点击 **生成完整模拟 .scan + 无损 PLY + 回放缓存**，后台严格按每一条计划轮廓的传感器姿态重新执行 M3 CAD BVH 光线投射；能取消，进度按轮廓数更新。完成后再次播放，会根据按实际模拟得到的最多约 240 个显示帧/姿态进行更密的累积；**保存到 PLY 的有效 CAD 命中点是不抽稀的**。
5. 在上面的姿态下拉框选择 P01（或 P02/P03），点击 **导入所选姿态实测 .scan 并对比**，选择相同角度完成的新实测扫描文件。系统拒绝 Simulated 扫描伪装成实测，核实每一轮廓记录的 C/B 与所选姿态在 0.5° 以内。按 CAD 共同 ROI 裁剪实测显示点，计算两个方向的近邻距离中位数、P95、给定阈值内比例，并在三维视图显示实测残差着色与 JSON 报告。这个最近邻分析不是强制配准，不可直接称为计量误差、缺陷真值或绝对精度。

## 输出文件

选择导出目录后按每个姿态生成：

```text
M3M4_SIM_<时间>/
  M3M4_SIMULATED_ONLY_manifest.json
  ALL_POSES_SIMULATION_ONLY_UNFUSED.ply  # 仅按姿态串接顶点，未融合/未消除重复
  P01/
    SIMULATION_ONLY_workpiece.ply        # binary little endian double64 XYZ，全部有效工作件命中点
    [已有 M6ScanVolumeWriter 写入的压缩 SCAN-v3 体文件]
  P02/
    SIMULATION_ONLY_workpiece.ply
    [仿真 SCAN 体文件]
  P03/
    SIMULATION_ONLY_workpiece.ply
    [仿真 SCAN 体文件]
  comparison_P01.json                     # 对应 P01 真实独立扫描对比后才生成
```

所有模拟 SCAN 仍使用 `PoseTiming::Simulated`，并保存 XYZCB、相应 Frame、Physical17、1280 原始轮廓索引与无效点；不准将其作为独立真实测量证据。PLY 导出仅含 M3 判定为 `Valid` 且 `hitObject=Workpiece` 的点，不含插补或凭空补全点，缺失形态和每点溯源应使用模拟 SCAN 阅读。工作台/夹具可能影响完整光线可见性，但本次没有完成材料反射率、真实光学校准与全外壳运动碰撞认证。

## 源码变更

- 新增 `include/src/twin/MultiPosePlayback.*`：多姿态时间轴、XYZCB 插补、激光扫描段识别、Physical17 正运动学回放接口。
- 新增 `include/src/twin/MultiPoseCloudComparison.*`：固定坐标系内 KD-tree 双向最近邻诊断，不自动 ICP，不把配准候选变为 verified。
- 扩展 `MultiPoseExperimentQtAdapter.*`：保存每个预览轮廓的点集；完整模拟 SCAN+二进制 PLY+按姿态回放缓存+全姿态未融合 PLY；独立实测 SCAN/C-B 身份核验、ROI 裁剪、误差 JSON。
- 扩展 `MultiPoseExperimentWidget.*`：播放/暂停/单步/拖动/倍速、按姿态回放、全数据后台生成、实时日志和未来实测文件比较。
- 扩展 `PointCloudWidget.*`：仅图形层的五轴模型姿态切换、激光线框、模拟点逐渐积累、实测-仿真最近邻距离着色（不改变真实机床轴值）。
- `src/app/main.cpp`：新增窗口控件启动冒烟检查，以防 UI 初始化空指针回归。
- `CMakeLists.txt`：链接上述两个可移植算法模块、新增无 Qt 的测试。

## 测试与验证边界

- Linux 下 `DIGITAL_TWIN_CLI_ONLY=ON` 编译成功；离线可执行的 25 项回归测试通过（排除耗时很长的 `V28_M6_CONTINUOUS_5AXIS_OFFLINE`，不能计作通过）。
- 新增 `MULTIPOSE_OFFLINE_XYZCB_PLAYBACK_AND_REAL_SIM_GEOMETRY` 检验时间插补、非采集区关闭激光、各姿态时间分离、KD-tree 距离统计与异常输入。
- `tests/gui/test_multi_pose_simulation_ui_contract.py` 对 Qt 界面接线做静态检查，但**不是 GUI 编译或运行**。
- 用户 Windows 机器上需运行：

```powershell
powershell -ExecutionPolicy Bypass -File tools/RunGuiSmokeTest.ps1 -ExePath "D:\<build>\Release\MotionLaserSync.exe"
```

该脚本只验证 GUI 可见、实验窗口能打开、播放/暂停/单步/对比按钮存在，不联网、不触发机床。还需现场核对模型运动轴方向、传感器 STL 与 Physical17、PLY/SCAN 读取、一帧几何可视结果与原 M3 行为一致。

## 后续必须解决的认证门槛

粗配准是近水平放置的**候选**，不是独立六自由度精配准；现实扫描如果转动 C/B，现有传感器光学模型、表面可见性、夹具与外壳、加减速、触发时间、路径起点及机器轴限位必须另行验证。尽管 UI 预览轨迹和 H1/H3 离线 NC 可以保存，`registrationVerified=false` 与 `hardwareAuthorized=false` 状态保持原样，不执行真实 G 代码。

注意：正式导出 PLY 的每点 XYZ 使用 IEEE-754 float64，避免因大幅值机床 Z 坐标使用 float32 引入量化。回放与近邻快速诊断当前使用有界的 QVector3D(float32) 显示样本，仅用于可视分析，不能作为高精度计量结果。
