# V27.6.16Z — Optical Intersection / Actual-FOV / Arrival-Probe Sphere Study

## Purpose

V27.6.16Z fixes a field failure observed in V27.6.16Y: a generated XYZBC study pose could be kinematically reachable yet the real scanCONTROL Profile contained no usable sphere arc. The autonomous study must not treat joint reachability as optical reachability.

This release therefore adds two independent gates:

1. **Planning-time forward optical simulation** after the XYZBC inverse is solved.
2. **Arrival-time real Profile Probe** before the formal 20-profile acquisition.

If the real Probe cannot find the sphere, the program performs a small fixed-C/B local reacquisition in the laser-plane-normal direction and probes again.

## 1. Actual scanCONTROL field used by the program

The study planner now takes its measuring limits from the same `Constants` used by the running Profile widgets/acquisition code:

- Sensor X: `-25 .. +25 mm`
- Sensor Z: `70 .. 120 mm`

The planner adds a default 1 mm safety margin on each boundary. It no longer uses the old study-only `X=-42..+42 mm` assumption.

## 2. Planning-time sphere/laser-plane intersection

For every solved five-axis pose, the known RANSAC machine-frame sphere center is forward transformed into the sensor frame:

`O_s = [Xs, Ys, Zs]`.

The actual laser Profile plane is `Ys=0`. Therefore a physical sphere-plane intersection requires

`|Ys| < R`.

V27.6.16Z additionally requires a configurable positive intersection margin:

`R - |Ys| > 0.50 mm` by default.

If the plane misses the sphere, or is too close to tangency, that pose never enters the autonomous queue.

## 3. Predicted section circle and visible-arc gate

If the plane intersects the sphere, the forward simulation computes:

- section-circle center in Sensor frame: `[Xs, 0, Zs]`
- section radius: `sqrt(R^2 - Ys^2)`

The circle is sampled densely (default 720 angular samples). A sample counts as predicted visible only when:

- X is inside the guarded program X range,
- Z is inside the guarded program Z range,
- it belongs to the front-facing sphere arc relative to the configured optical reference center.

The longest contiguous predicted visible arc is calculated. The default study gate requires at least **75°**. The predicted visible arc and sphere-plane intersection margin are shown in the study plan table.

This is intentionally stricter than “joint target is legal”, but it remains a model-based prediction. The same Physical17/machine model is used for inverse and forward simulation, so it cannot remove residual real-machine/model errors. That is why the real Profile Probe below is mandatory.

## 4. Arrival-time real Profile Probe

The autonomous sequence is now:

`Move -> settle -> Probe -> (optional reacquisition) -> formal 20 Rich Profiles -> next pose`.

Default Probe settings:

- 5 Probe Profiles
- at least 3 Profiles must produce a valid sphere circle
- Circle RANSAC + adaptive refinement is used
- Rich signal fields (`Maximum/Width/M0/M1/...`) are NOT used to pre-filter the Probe geometry

A Probe timeout with fewer than the requested circle quorum is a failure. The quorum is never silently reduced because fewer frames arrived.

Only after Probe succeeds does the formal one-batch 20-profile study acquisition begin.

## 5. Local automatic sphere reacquisition

If Probe fails, the program keeps C/B fixed and changes the target sphere center Sensor-Y coordinate, which is equivalent (at fixed orientation) to translating the sensor/laser plane along its normal relative to the sphere. It uses the existing Physical17 RTCP-equivalent 3x3 XYZ inverse.

Default search sequence:

`+0.5, -0.5, +1.0, -1.0, +1.5, -1.5, +2.0, -2.0 mm`

After every successful local move, the machine settles and Probe is repeated. Formal acquisition starts only if a real circle is detected.

The search step and maximum range are configurable. Failed inverse/limit/optical candidates are skipped and the next offset is tried.

Important: this local recovery primarily handles laser-plane-normal miss caused by current calibration/model residuals. If a future dataset demonstrates large X/Z model errors as well, the same framework can be extended to a compact Sensor-X/Z reacquisition pattern. Formal analysis already uses the actual fitted circle and actual MPOS, so a successful local correction does not pretend the nominal D/gamma/eta was achieved.

## 6. Provenance retained

`visits.csv` now records, in addition to planned/actual geometry:

- predicted visible arc
- predicted plane-intersection margin
- number of Probe frames
- number of Probe frames with a circle
- whether reacquisition was used
- reacquisition attempt count
- final normal offset

The formal analysis still uses fitted/actual `D`, `SectionAngle gamma`, `CenterBearing eta`, and point-level `LocalSurfaceAngle theta` rather than planned targets.

## 7. BASIC controller files

No `.bas` file is modified by this release. Keep the machine's field-tuned XYZ encoder-ratio settings.

## 8. Validation

Portable numerical/source validation covers:

- actual program X/Z field propagation into the study planner
- forward sphere/laser-plane intersection rejection
- off-field circle rejection
- minimum predicted visible-arc gate
- real Profile Circle-RANSAC Probe
- Probe quorum on partial/timeout input
- fixed-C/B Sensor-Y reacquisition inverse
- previous V/Y sphere geometry and center-bearing regressions
- controller Mock-ZAux core regression

The full Qt/VTK Windows application still requires the machine PC's MSVC + ZMotion + scanCONTROL SDK environment for the final GUI link/build.
