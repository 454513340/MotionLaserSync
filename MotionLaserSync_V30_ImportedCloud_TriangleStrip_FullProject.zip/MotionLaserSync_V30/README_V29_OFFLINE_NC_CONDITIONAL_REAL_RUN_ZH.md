# MotionLaserSync V29 — 多姿态 OfflineOnly NC 条件实机放行补丁

## 核心变化

`OfflineOnly: true` 仍然保留在数字孪生导出的 NC 中，表示这是一份尚未取得现场执行许可的**候选程序**，但它不再构成不可变的永久拒绝规则。G 代码页可以点击“开始执行”申请准入：在下发任何五轴运动或开启正式扫描之前，`GCodeExecutor::start()` 调用现场准入检查，只有所有真实证据满足条件才会进入运行状态。

**注意：当前交付不是可直接在现场运行的 EXE。** 已接入 NC 全量几何复核结果、硬件同步试采证据、当前生效标定和现场验证调用链，但项目未提供安全 PLC、急停保护回路、真实夹具锁紧、现场工件姿态及实测光学覆盖的完整可信读取接口。新增 `MainWindow::installSiteSafetyReader(...)` 必须由设备集成方按实际接线、独立安全回路、测量数据完成接入。本工程默认没有安装该读取器，因此即使其他检查通过，也**不会**为真实五轴运动生成放行结果。严禁用 `return true`、手工勾选或 NC 注释冒充 PLC/光学现场验收结果。

## 条件放行顺序

1. 从多姿态实验生成 `OfflineOnly: true` 的 H1/H3 NC，仍需先在 G 代码模块通过解析和离线 G05/G93/M50/M51 逐段验证。硬件候选必须声明 `SyncMode: Hardware`、`ProgramFrame: MACHINE_JOINTS_XYZCB`、H1/H3、有效 Hz 和 `EdgeRising`。
2. 保留当前真实 STEP/SCAN、工件放置及多姿态规划场景，运行“整条NC FCL+光学复核”。必须逐段通过 FCL 与全部 Profile 理论光学覆盖检查；结果仅绑定这份 NC 的规范化文本摘要和当前有效 Physical17 数值。场景重新规划、文本变化或标定变化必须重检。
3. 连接控制器和传感器、完成五轴回零。按 NC 要求做真实硬件同步试采，启动→实际触发→Stop/FIFO drain→轮廓与五轴锁存姿态对齐、无丢帧/故障、频率与硬件读回验证。**零 Profile 不算通过**。按 H1/H3 的真实电气约定，静止试采可能无法产生 H3 触发，此时不能自动放行。
4. 现场安全系统必须提供**可信且新鲜的**安全 PLC、安全门/保护回路、急停状态、夹具锁紧、真实夹具与 FCL 模型匹配、实物工件姿态确认、实际光学覆盖合格，以及硬件独立保护停机有效。软件 `AxisStatus`、Qt UI 参数相等和试采计数都不能代替这些物理状态。`MainWindow::installSiteSafetyReader` 的读取器由现场集成方编写并验收；默认缺失时拒绝运行。
5. 操作员点击“开始执行”时，再次读取实际 NC 磁盘原文、重新解析并与执行器内部运动段及参数逐段比对；两份复核证据必须与待执行 NC 的文本一致。几何证据有效窗口为 20 分钟，硬件试采为 5 分钟；设备重连、场景变化、标定变化或验证超时使准入失效。
6. 再次确认控制器、传感器、五轴真实回零与健康状态、TABLE 合同和现场安全 IO；执行器实时读取最新 MPOS，验证 MPOS→首 G00 路径的 FCL 安全条件，然后才能真正开始。运行中硬件安全回路必须**独立于 Windows/Qt 程序**执行保护停机，不能仅靠这次启动前的读取。

## 修改位置

- `src/gcode/GCodeExecutor.cpp`：把 `OfflineOnly` 的无条件阻断改为明确 H1/H3 多姿态候选的**有条件申请**。与实际磁盘 NC 逐段比对后，继续调用 `SiteHardwareNcVerifier` 与现场首 G00 FCL 验证器；默认无验证器时拒绝。
- `src/widgets/GCodeWidget.cpp`：符合条件的 OfflineOnly 候选可以点击“开始执行”提出申请，不再因为单一文件头标志禁用按钮；未验证时仅弹出明确阻断原因，不向控制器下发运动。试采请求传递同一份 NC 的原文。
- `include/app/MainWindow.h` 与 `src/app/MainWindow.cpp`：记录真实试采和整条几何复核的易失性证据，绑定 NC、有效 Physical17、H1/H3/Hz/R1、传感器参数、设备连接代次和场景。注册 `SiteHardwareNcVerifier`，合并验证条件；接入 `SiteSafetyReader` 实际安全状态源（现场供应商必须提供）。
- `tests/gcode/test_offline_nc_conditional_release_contract.py`：验证源码中无条件硬禁止已经改为条件准入，且没有跳过真正的 PLC、完整轨迹、实际试采、NC 一致性、首 G00 检查。

## 现场集成接口合同

`include/app/MainWindow.h`：

```cpp
struct MainWindow::SiteSafetyInputs {
    bool safetyPlcOnline;
    bool protectiveCircuitHealthy;
    bool eStopCircuitHealthy;
    bool fixtureActuallyLocked;
    bool actualFixtureMatchesFclModel;
    bool workpiecePoseConfirmed;
    bool realOpticalCoverageQualified;
    bool independentlyWiredProtectiveStop;
    int sampleAgeMs;
};

using SiteSafetyReader = std::function<bool(SiteSafetyInputs&, QString*)>;
void installSiteSafetyReader(SiteSafetyReader reader);
```

必须由实际机器上**独立安全 PLC、夹具传感器和实测光学复核**取得数据，且安装到 MainWindow 实例。不接受靠 NC 注释、磁盘试采 JSON、UI 复选框、过期缓存或硬编码成功制造许可。`sampleAgeMs` 最大 250 毫秒。若工件位置/光学覆盖现场判断并不能由实际可靠传感器提供，必须先完成该硬件测量和验收流程，不能填 `true`。

## 重要解释：哈希并没有被用来替代现场验证

- **NC 文件摘要**仅用于证实“刚刚验证的是这份文件，马上将执行的仍然是同一份程序”。文件变了必须重新做相应验证。
- **启动已生效的 Physical17 标定**直接读取 17 个数值，不会因 `active_single_sphere17.json` 的名称或 NC 注释中的旧模型哈希不同而直接拒绝。但正在生效的 17 个参数如果与当前规划复核的数值不同，就必须重新规划及复核。

## 测试状态

已经在无 Qt6/MSVC、无真实机床的环境运行源码合同测试和纯 C++ 同步试采判据测试。它们只能证明此补丁的条件分支、证据关联和默认拒绝策略没有被意外删除，**不能证明 Windows 工程已编译、实体 PLC 读取正确、FCL 模型与现场一致或五轴运动安全**。

当前交付没有现场 I/O 点表、有效电平、PLC 型号、实际接线和经过现场验收的独立保护停机证明，所以 `SiteSafetyReader` 仍未安装。只有这些完成后，工程才能在满足全部条件时真正进入实机执行；不应更改为无条件许可。
