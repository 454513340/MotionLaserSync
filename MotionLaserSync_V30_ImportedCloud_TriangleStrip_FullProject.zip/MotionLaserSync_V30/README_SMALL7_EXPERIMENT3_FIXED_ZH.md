> **2026-10-13 版本更新：** 本文件包含较早版本的描述。最新第三实验的真实行为、曝光独立参数及扫描 X 速度计算请以 [README_EXPERIMENT3_MACHINE_Z_EXPOSURE_20261013_ZH.md](README_EXPERIMENT3_MACHINE_Z_EXPOSURE_20261013_ZH.md) 为准。

# 第三实验 Small7：多机床Z × 最大圆截面静态曝光（源码修订版）

## 交付范围和版本适配

这是基于用户提供的 `MotionLaserSync_H1_H3_TWO_STAGE_DYNAMIC_HOLDOUT_LINK_FIXED_FULL_SOURCE.zip` **完整源码**派生的独立修订版，而不是已生成的 Windows `.exe`。
原始 ZIP 与截图虽然共享 `V27.6.55` 窗口标题，但不存在截图中“第三实验：Small7 不同测量高度 × 固定最大圆截面曝光”的 C++ UI / 执行入口，因此**无法对截图中原有实验3的首次卡住作因果复现**。本版重新新增 `MainWindowSmall7Experiment.cpp`，接入原有 UI、控制器、传感器、Physical17 与 MachineSafety，且原有全测量场 X 轴扫描保留。

本包**未通过 Windows Qt/VTK/MSVC、ECI3808、scanCONTROL 或机械急停实机验收**，因此不能直接作为生产/无人值守机床程序。必须在正式执行前，完成现场联锁、单轴限位、机床数字孪生碰撞包络、传感器视场、标定、控制器固件、性能与位置反馈逐项验收。禁止通过修改 `verified` 或关闭保护绕过这些检查。

## 参数逻辑（界面已实现）

- 机床 Z 起点、终点、间隔：机床 MPOS，逐层移动，所有中间运动点也通过 MachineSafety。
- Small7 有效光学 X/Z 视场：不再在实验页重复人工输入上下限；从**已验证** `config/small7_verified_roi.json` 读取、冻结本次计划。文件必须 `verified=true`、有非空 `verificationId`、`measuringFieldIndex=7`、经真实 Small7 原始轮廓/厂商工具确认 `xMinMm/xMaxMm/zMinMm/zMaxMm` 和 FlipX/FlipZ 的**reported sensor**坐标定义。默认附带的是 `small7_verified_roi.example.json`，`verified=false`、无有效边界，专门用于阻止无证据自动运动。
- 单独定位速度：可选 1/2/3/4/5 mm/s，Z 定位、X 扫描起点定位和7点静态换位均使用选定值；原有全测量场曝光扫描模块也新增起点定位速度，取消了 `轴速度×0.2` 与 `加速度×0.2` 限制。
- **更新：** X 扫描速度不再固定为1mm/s，而由轮廓采样频率量化后与相邻轮廓目标间距相乘得出，默认200Hz×0.005mm=1mm/s；独立定位速度1～5mm/s。
- **更新：** 先整球X扫描，用已定位的圆弧半径拟合扫描最大圆，再在**实测扫描峰位**周围 ±3×0.20mm 静态七点验证。采集稳态丢弃帧数可设置，单点默认需30有效轮廓。
- **更新：** 实验3界面独立提供曝光起/止/增量、每档采集轮廓数默认20、重复2次、可选Video、稳态丢弃帧数默认3。曝光失败帧也保存用于实验对比；保存原始`.s7raw`、每帧拟合`.csv`、跨Z对比CSV与JSON。

## 实验3具体执行状态

`FAST_Z_POSITION -> FAST_X_POSITION -> SCAN_WARMUP -> SCAN_X_DERIVED_FEED -> FIT_SCANNED_PEAK -> 7×(PROBE_POSITION + PROBE_CAPTURE) -> EXPOSURE_POSITION -> 多组EXPOSURE_CAPTURE [-> 可选VIDEO_CAPTURE] -> SAVE -> NEXT_Z`。

X扫描前需软件触发连续帧预热成功，所有单轴移动的实际MPOS/DPOS、IDLE与误差通过底层每秒日志记录，GUI另提供约每秒位置心跳。出现丢帧、卡在起点、超时、到位失败、限速、失联、碰撞等情况时中止后续步骤，发出X/Z停轴请求，保留数据并写出原因。**软件停止不等于物理急停**，Windows厂商DLL阻塞时不保证立即响应，现场仍需真实急停。

## 使用顺序

1. Windows 原工程工具链（MSVC x64、Qt6、VTK、FCL、ECI3808及LLT厂家SDK）配置并编译，确认 UI 出现新增的“第三实验：Small7 多机床Z”。
2. 先通过真实设备与多段原始轮廓，确认 Small7 field=7 的有效 X/Z 范围、安全边界及报告坐标 FlipX/FlipZ；复制示例为 `config/small7_verified_roi.json` 并填入**实测数值和可追溯 verificationId**，最后由现场设备负责人标记验证。不要把整场的70～120mm和±25mm常量直接复制到Small7。
3. 已启用机床机械软限位、XYZ MPOS 回零认证、B/C 绝对位置/使能、MachineSafety FCL 模型；导入球云并拟合球心，完成Physical17并显示已验证。
4. 在传感器标定区域找到新增第三实验面板，设置Z起点/终点/间隔、定位速度1～5、Small7采样频率、参考曝光和每档有效帧。**本实验独有的曝光起止值/步长**用于静态曝光系列。设置归档根目录。
5. 点击“生成/检查第三实验Z×X路径”并人工复核每高度的预测球心、X扫球范围和弧可见性。再点击“开始第三实验”，确认对话框后逐层执行。首层建议先使用很短且无碰撞的Z行程和经过认证的1mm/s定位速度调试。
6. 遇故障导出系统日志，提供前后时段的阶段名、目标MPOS、实际MPOS/DPOS、IDLE、传感器回读、Profile索引与SDK错误码；本代码不会自动跳过失败步骤。

## 验证

在 Linux/macOS 无 Qt 和硬件的环境可验证核心：

```bash
cmake -S . -B build-small7 -DSMALL7_EXPERIMENT3_CLI_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-small7 --parallel
ctest --test-dir build-small7 --output-on-failure
python tools/verify_small7_experiment3_contract.py
```

保留整球曝光便携版回归：

```bash
cmake -S . -B build-sphere -DSPHERE_EXPOSURE_CLI_ONLY=ON
cmake --build build-sphere --parallel
./build-sphere/sphere_exposure_cli
python tools/verify_sphere_exposure_x_only_contract.py
```

GUI 主程序只允许在 Windows x64（厂家DLL/库存在）构建；本次交付环境没有原 Windows 设备/Qt/FCL 工具链，无法声称 Windows GUI 已编译或实机运行。

## 修改的主要文件

- 新增 `include/calibration/Small7HeightPlan.h`、`src/calibration/Small7HeightPlan.cpp`（纯C++可测路径与时间预算）
- 新增 `src/app/MainWindowSmall7Experiment.cpp`（UI、执行状态机、软件扫描与采集/停止）
- 修改 `include/app/MainWindow.h`、`src/app/MainWindow.cpp`（GUI接线、运行互锁、断开设备/停止保护）
- 修改 `src/core/ZmcController.cpp`、`include/core/ZmcController.h`（超时估算、位置状态记录和请求停轴、限速错误）
- 修改 `src/app/MainWindowSphereExposure.cpp`（旧整球扫描起点独立定位速度）
- 修改 `CMakeLists.txt`（完整项目/portable test 源码编译列表）
- 新增 `tools/small7_experiment3_cli.cpp`、`tools/verify_small7_experiment3_contract.py`、`config/small7_verified_roi.example.json`

## 仍需现场验收的边界

本版按真实“Reported Sensor-Z”窗口对理论球弧做数值可见性检查，未伪造 field=7 的任何测量界限，也没有伪造它与机床Z的线性关系。静态7点找到的是**7个离散候选点中的最大中位圆半径**，不是连续最优化的绝对最大圆；其空间不确定度与测得弧质量必须单独评价。原始扫球轮廓保存了时间戳和索引，未假定非硬件同步的PC时间戳可直接推算精确机床X位置。

由于未提供与截图一致的原实验3源码/首次故障日志，也未实机测试，**这不是对截图版本现场故障已彻底排除的认证声明**。要确证首点具体故障根因仍需将新版本 Windows 编译运行后的日志与控制器/传感器实际回读对齐排查。

## 本次追加的执行质量与互斥修订

- `Small7HeightPlan.cpp` 已列入正式 `ALGORITHM_SOURCES`，用于 Windows GUI 主程序链接（而不仅仅是单独 CLI 测试）；其他独立CLI目标不意外引入它。
- 新旧两种自动球曝光实验互斥，不能在 Small7 运行期间再启动原来的全场曝光扫描。
- 从规划到完成，每个新的单轴目标发出前均验证 Physical17 数值、拟合球心与标准球直径未变。逐曝光阶段逐次检查 **五轴 IDLE、Y/C/B 不漂移、机床Z不漂移、X精确锁定到7点候选峰位**。
- 轮廓流监测：扫描/预热期间超过约1.5秒未收到 Profile 信号，或静止采集期间超过约3秒没有新轮廓，即终止采集并请求停轴，明确报告数据流中断。时限受 Windows/Qt 事件循环调度延迟影响，不是硬实时安全联锁。
- 扫描合格轮廓独立统计在 `XScan` **运动工作线程仍活动**时收到的样本；不允许用扫描前预热帧凑够扫球数量。并保留原始 `.s7raw` 文件用于离线追溯。

### `.s7raw` 文件结构（V1）

二进制为**Little Endian**：四字节 ASCII `S7P1`；接着 5 个 `int32`，分别为 `version=1`、`exposure10us`、`rateHz`、`heightIndexZeroBased`、`isScan(0/1)`；然后每个轮廓帧为 `uint32 profileIndex`、`int64 pcTimestampUs`、`uint32 pointCount`、重复 `pointCount` 组 `float32 reportedSensorXmm` 和 `float32 reportedSensorZmm`。XYZCB 实际轴反馈不在本文件逐帧编码；不要误用 PC 时间戳做硬件同步轨迹重建。
