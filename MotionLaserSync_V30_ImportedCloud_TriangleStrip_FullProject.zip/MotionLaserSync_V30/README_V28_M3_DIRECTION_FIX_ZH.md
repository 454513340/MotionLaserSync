# MotionLaserSync V28.2 — M3 沉孔观察方向与 Profile 索引修复

基线：`MotionLaserSync_V28_PROJECT_M3_AUDITED_FIXED.zip`。只修改数字孪生代码和测试，真实五轴运动控制、H1/H3 采集及原 `.scan` 文件格式保持不变。

## 为什么改

- 之前 M3 虚拟相机的 `Sensor-Y=-75 mm` 默认值预测的沉孔台阶可见侧，与实测 H1 的可见侧相反。
- 原虚拟 `sampleXAtZ()` 以索引递增得到递增的 `Sensor-X`，但真实 H1 SCAN 中 `Sensor-X` 随原始采样索引增加而**下降**（约 -0.036 mm/索引，取决于深度）。
- M3 从 M2 直接使用每条 Profile 的 `Frame5D.sensorToMachine`，本次**没有修改或反转 X 轴轨迹**，也没有改变记录的关节数据。

## 源码更改

1. `include/twin/VirtualLaser2950.h`：默认相机光心更改为 `cameraOriginSensor={0,+75,251.25}`，仍是**未标定的等效光学参数**。
2. `src/twin/VirtualLaser2950.cpp`：在 `sampleXAtZ()` 中使用 `return -t*widthAtZ(z);`，与实测索引方向一致；保留深度相关 58/50/42 mm 视场模型。
3. `src/widgets/DigitalTwinScanWidget.cpp`：GUI 默认相机偏置从 `Sensor2950Geometry` 读取，避免 GUI/CLI 再次出现不同的默认值。
4. `tests/twin/twin_virtual_laser_tests.cpp`：修改遮挡墙的光路侧，并断言索引斜率为负。
5. `tests/twin/twin_m3_direction_tests.cpp`：新增 H1 100 条实测曝光位姿的 CAD 沉孔可见侧回归测试（使用项目自带的参考 OBJ 和位姿子集）；CMake/CTest 已接入。
6. `src/twin/TwinSimulationAdapter.cpp`：仅在仿真参数 JSON 中增加索引方向及未标定光学基线的注记（非真实 SCAN 格式）。
7. `src/app/MainWindow.cpp`：窗口版本文字改为 V28.2，便于辨别是否启动了新程序。

## 已验证的方向性结果（H1 100 帧参考子集，不是完整 M4 标定）

以参考 STEP 的四个沉孔台阶的 CAD 局部 `+Y` 可见点比例计：

| 等效相机位置 | 台阶有效点数量 | CAD 局部 +Y 侧比例 |
|---|---:|---:|
| Sensor-Y = +75 mm（新默认） | 1303 | 95.70% |
| Sensor-Y = -75 mm（旧默认） | 1212 | 11.14% |

注意：这是按点数计的**可见侧方向性测试**，不是台阶面的完整面积覆盖率、标定精度或多姿态预测精度。旋转 B/C 后的真实光学预测仍需 M4 多姿态实测检验。

## Windows 10 / VS2022 使用方法

1. 解压完整工程到新的目录；使用你已经验证能工作的 Qt6/VTK/SDK 环境。
2. Open CASCADE 路径继续为 `D:/dev/vcpkg/installed/x64-windows-release`，不需改变。删除旧 CMake 缓存、重新配置并编译 **MotionLaserSync 主 GUI 程序**。
3. 打开“路径规划 → 数字孪生 STEP 工作台”，导入工件 STEP 及 M2 真实 `.scan`。
4. 清除旧 M3 虚拟点云；确认 GUI 的“模拟相机 Y 偏置”默认显示 `+75.00 mm`。
5. 运行 M3；对比四个沉孔的缺失侧，并按需导出 `.ply` / `.m3prof` / `.m3.json`。
6. 如果仍出现反向，提供当前 M2/M3 分层截图、CAD 放置参数和导出的 `.m3.json`，以排查加载了旧 `.exe`、镜像几何或传感器坐标约定等问题。

## 离线独立测试命令

```powershell
cmake -S . -B build-twin -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF
cmake --build build-twin --config Debug
ctest --test-dir build-twin -C Debug --output-on-failure
```

完整 GUI 仍需要在用户本机 VS2022 实际编译运行验证；本修复包不能视为已经完成 M4 的物理标定。
