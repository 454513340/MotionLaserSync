# MotionLaserSync V27.6.16W — Auto Sphere Geometry/Quality Study

V27.6.16W is based directly on V27.6.16V. It does **not** change the sphere-study geometry/quality definitions introduced by V; it fixes the cramped study UI and adds an automatic five-axis experiment runner.

## 1. UI layout change

The old optical-center / D-gamma / C-B rows used long horizontal layouts and were clipped on the narrow right-hand panel. V27.6.16W replaces them with a multi-row `QGridLayout` group:

- optical reference center X0/Z0;
- Measurement Distance D: start / end / step;
- SectionAngle gamma: start / end / step;
- C-axis samples: start / end / step;
- B-axis samples: start / end / step.

The acquisition settings are also split into a second multi-row group, so group/profile counts, stabilization wait, timeout and retry controls remain visible without horizontal compression.

## 2. Automatic experiment workflow

After fitting the sphere and generating a valid D-gamma-C/B path, `自动采集剩余路径` runs the valid path rows automatically:

1. select the next five-axis target;
2. plan and execute the existing synchronized XYZCB point-to-point move;
3. wait the configured post-arrival stabilization time;
4. start/keep the scanCONTROL Profile stream and Rich Profile channels;
5. discard the configured warm-up frames;
6. collect the configured groups x profiles;
7. write each complete group immediately to disk;
8. advance to the next target.

C and B remain real varying path degrees of freedom. The automatic runner does not replace them with fixed rotary angles.

## 3. Controls and safety behavior

The automatic workflow provides:

- Start: `自动采集剩余路径`;
- cooperative Pause/Resume;
- Stop Auto;
- post-arrival settle time;
- per-group callback timeout;
- configurable retry count;
- skip already-completed poses;
- continue-to-next-pose or abort after retries are exhausted.

While the workflow is active, manual X/Y/Z/C/B motion, P4 joint moves, merge/capture starts and G-code controls are locked. This lock remains active during settle and Profile acquisition, not just during controller motion.

Automatic execution requires:

- controller connected;
- XYZ grating MPOS references established by normal homing;
- B/C absolute mechanical frames ready;
- B/C manually servo-enabled;
- scanCONTROL connected;
- all axes idle;
- no conflicting synchronized scan, video/exposure test or G-code task.

## 4. Partial-data handling

A sensor callback timeout must not make a large unattended experiment hang forever. In automatic mode, every group has a watchdog. If it expires:

- already received Profile frames are written as a **partial** group;
- the record is marked `complete=0`;
- the automatic retry/continue policy is applied.

Raw group schema is therefore `SphereDistanceAngleStudy.RawRichProfile.v3` and includes:

- `GroupComplete`;
- `CapturedProfiles`;
- every original sample slot, including coordinate-invalid/dropout slots.

Only complete groups count toward the configured groups-per-pose target. With `跳过已完成位姿` enabled, a partially completed pose is resumed by collecting only the missing complete groups rather than silently collecting another full set.

## 5. Pause semantics

Pause is deliberately cooperative:

- if requested during a five-axis move, the move is allowed to finish and the workflow pauses before acquisition;
- if requested during a pose capture, the whole current pose acquisition is allowed to finish and then pauses;
- if requested during the stabilization wait, the pending timer is invalidated and the workflow pauses immediately at the reached pose.

Resume from an already reached pose restarts the stabilization wait and then captures without moving away and back unnecessarily.

## 6. Sensor stream lifetime

When V27.6.16W itself starts Profile preview for an automatic run, it keeps the Profile stream and Rich channels alive between successfully completed poses. The direct study callback is disconnected during motion, so no moving frames are recorded. This avoids repeatedly stopping/restarting the sensor for hundreds of path rows.

At normal completion, Stop Auto, sensor/controller disconnect or application shutdown, ownership is released and the preview is stopped if it was started by the automatic workflow.

## 7. Data/model semantics unchanged from V

V27.6.16W keeps the V27.6.16V definitions:

- D = Euclidean distance from the refined section-circle center to the configured sensor optical reference center;
- SectionAngle gamma = unsigned `asin(h/R)` from the known machine-frame sphere center to the transformed laser Profile plane;
- LocalSurfaceAngle theta = point-level unsigned angle between the local sphere normal and the optical viewing ray;
- Circle RANSAC identifies geometry/ROI only; signal quality channels are not used to pre-filter;
- once EvaluationROI is known, Good, geometric Outlier and Dropout sample slots all remain part of the measurement-quality denominator;
- Rich Profile X/Z/Width/Maximum/Threshold/Moment0/Moment1 remain losslessly retained for later uncertainty modelling.

Analysis remains a separate explicit step after acquisition. V27.6.16W does not yet modify Physical17/kinematic calibration or introduce a final GP/GAM/boosted uncertainty model.

## 8. BASIC deployment warning

No `.bas` file is changed from V27.6.16V. In particular, the active BASIC copy in this source package still has SHA-256:

`263d1f2a560120b006d25262e79fc364ebf35b4e6f2b3bf986f56013166b105a`

The field machine has separately tuned XYZ encoder ratios. Do **not** overwrite the field BASIC with the source-package copy. Prefer the V->W patch for the PC application update.

## 9. Offline verification

Linux/offline validation performed for this source tree:

- V27.6.16W source contract: 22/22 PASS;
- selected portable controller/scheduler/sphere/Physical17/runtime/RTCP regression set: 14/14 PASS;
- delimiter/static source sanity check: PASS;
- three BASIC hashes: unchanged from V.

The complete Qt/VTK GUI is intentionally Windows-x64/vendor-SDK-only in this project and was not linked in the Linux validation environment. A final Windows/MSVC Release build is required before machine deployment.
