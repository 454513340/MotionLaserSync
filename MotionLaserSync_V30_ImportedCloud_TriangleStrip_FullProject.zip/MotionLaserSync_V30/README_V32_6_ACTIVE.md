# 当前活动版本：V27.6.16H / V32.6 SINGLE-OP14 ATYPE4-MIXED-DPOS

现场只接 OP14。不要连接或依赖 OP0。

- scanCONTROL: OP14 / EdgeRising
- ECI IN0: OP14 / REGIST(104)
- XYZ: 控制器 `ATYPE=4`，但当前上位机数据仍使用 TIMER0 内的 DPOS 快照
- C/B: REGIST(104) raw MPOS + 冻结的 RS485 software-frame offset
- 正式采集前：同一 OP14 ColdPrime，至少 8 个成功转换 Profile 后再建立新 session

详细说明见 `V27_6_16H_V32_6_SINGLE_OP14_MIXED_DPOS.md`。
