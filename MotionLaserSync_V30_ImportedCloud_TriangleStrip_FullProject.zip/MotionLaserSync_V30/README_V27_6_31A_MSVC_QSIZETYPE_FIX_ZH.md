# V27.6.31A — MSVC / Qt6 `qsizetype` 编译修复

本修订仅修复 V27.6.31 A/B 补偿验证模块在 MSVC + Qt6 下的类型推导编译错误，不改变补偿验证算法、Physical17、运动逻辑或 CSV 格式。

## 问题

Qt6 中 `QVector::size()` 返回 `qsizetype`，而 A/B 验证点数量和索引使用 `int`。V27.6.31 中以下表达式混用了两种类型：

- `std::min(pointCount, candidates.size())`
- `std::min(lastIndex + 1, candidates.size() - 1)`

MSVC 无法为 `std::min` 推导统一模板参数，因此产生 `C2672`；`const int n` 的初始化随之失败，产生连带的 `C2737`。

## 修复

先显式建立：

```cpp
const int candidateCount = static_cast<int>(candidates.size());
```

之后 `std::min` / `std::clamp` 全部使用 `int`：

```cpp
const int n = std::min(pointCount, candidateCount);
index = std::clamp(index, 0, candidateCount - 1);
if (index <= lastIndex)
    index = std::min(lastIndex + 1, candidateCount - 1);
```

当前验证候选规模远小于 `INT_MAX`，因此此转换在本模块的业务范围内是安全的。

## 回归

portable 数值回归重新执行：

- `v20_single_sphere14_tests` — PASS
- `v20_2_single_sphere17_tests` — PASS
- `v27618_profile_block_tests` — PASS

完整 Windows GUI 仍需在现场 MSVC + Qt + ZMotion SDK 环境完成最终编译验证。
