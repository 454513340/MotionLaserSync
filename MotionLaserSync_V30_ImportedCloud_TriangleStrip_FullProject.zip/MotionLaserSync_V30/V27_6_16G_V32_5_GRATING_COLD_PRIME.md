# V27.6.16G / ECI3808 V32.5 — WITH-GRATING + COLD-PRIME

## Scope

This build deliberately removes the NoGrating acquisition contract from the active hardware-sync path.
The only accepted controller profile is:

- XYZ/C/B: `ATYPE=4`
- five-axis continuous latch: `REGIST(103)` / R0 logic rising edge
- scanCONTROL trigger: `OP0`, external `EdgeFalling`
- latch bridge: `OP14 -> IN0`
- record: `[ordinal, X, Y, Z, C, B]`
- `feedbackMask=31`, `latchMask=31`, `commandMask=0`, `timing=HardwareLatched`

XYZ gratings may be physically absent during commissioning. In that case XYZ MPOS values are diagnostic only; the program must not be treated as a valid five-axis measurement system until the gratings, direction and encoder ratios are commissioned.

## Why cold-prime was added

Field evidence showed a repeatable cold-power pattern:

1. sensor trigger configuration readback succeeds;
2. `TransferProfiles(..., true)` succeeds;
3. the controller receives the first trigger and publishes Pose=1;
4. scanCONTROL produces no usable callback for the single startup Probe;
5. without power-cycling the controller or sensor, a later application run receives profiles normally.

That pattern is consistent with a cold-start readiness race in the sensor/SDK/Ethernet profile data path. A single one-shot Probe is therefore too brittle: if that first profile is lost, the host intentionally refuses to enter continuous triggering and the session deadlocks at Probe.

## V32.5 startup sequence

1. Configure scanCONTROL external `EdgeFalling` and verify DIGITAL_IO/TRIGGER readback.
2. Start `TransferProfiles` and register callback.
3. Enter BASIC `enable=3` cold-prime mode.
   - TIMER0 period remains 5 ms.
   - Only OP0 is pulsed.
   - OP14 stays OFF.
   - No REGIST pose is generated.
   - Buffer-B and published-latch counters do not advance.
4. Host suppresses all prime profiles from the acquisition strategy and waits until at least 8 converted profiles arrive.
5. Stop cold-prime, wait for callback tail to become quiet, log `TABLE[352]` prime-pulse count, then reset callback diagnostics.
6. Keep `TransferProfiles` running.
7. Create a fresh TABLE session and arm five `REGIST(103)` channels.
8. Send one formal dual-output Probe: OP0 + OP14.
9. Require exactly 1 formal Profile + 1 formal five-axis Pose.
10. Switch to continuous 5 ms dual-output triggering.

The prime frames are not part of the saved scan and do not consume pose ordinals.

## TABLE header

`TABLE[330..351]`:

```
96 0 0 0 0 0 0 270909 6 5 0 0 1 31 4 31 0 0 0 103 14 1
```

Key fields:

- `342 = 1`: execution authorization
- `343 = 31`: feedback mask XYZCB
- `344 = 4`: HardwareLatched
- `345 = 31`: latch mask XYZCB
- `346 = 0`: command-position mask
- `347 = 0`: R0/IN0 latch input
- `348 = 0`: scanCONTROL trigger output OP0
- `349 = 103`: continuous R0 rising-edge latch
- `350 = 14`: OP14 latch bridge output
- `351 = 1`: cold-prime capability
- `352`: runtime prime pulse count (not part of static header)

`TABLE[334]` modes:

- `0`: idle
- `1`: continuous acquisition
- `2`: one-shot formal Probe
- `3`: sensor cold-prime, OP0 only

## B/C coordinate rule

No change was made to the established B/C coordinate frame:

1. RS485 absolute encoder counts are converted using the existing mechanical zero count, direction and reduction ratio.
2. At controller connection, `softwareFrameOffset = machineAbsoluteAngle - rawControllerMPOS`.
3. At hardware capture start the C/B offsets are frozen.
4. Each latched C/B record is converted as `machine = rawLatchedMPOS + frozenOffset`.

The controller MPOS/DPOS is not rewritten.
