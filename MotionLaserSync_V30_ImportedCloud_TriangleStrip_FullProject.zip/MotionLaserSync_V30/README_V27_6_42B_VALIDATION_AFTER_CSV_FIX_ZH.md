# MotionLaserSync V27.6.42B — Stage2 CSV 求解后独立验证姿态恢复修复

## 问题现象

V27.6.42A 中，为了允许在“已绑定有效标定”的程序状态下导入历史 Stage2 CSV，导入函数会主动退出当前实机标定运动会话：

- `m_referenceTaught = false`
- `m_persistentCalibrationBound = false`

这个动作本身是正确的：离线 CSV 不能和当前实机运动会话混在一起。

但 `updateCalibrationReadiness()` 仍把“生成独立验证姿态”错误地绑定到：

```cpp
liveMotionSession = m_referenceTaught && controllerOnline;
```

所以 CSV 导入 -> Stage2 最终求解成功以后，即使 Physical17 已经成功、训练 CSV 也仍在内存里，“生成独立验证姿态”按钮仍会灰掉。

此外，V27.6.42A 的 `onGenerateValidationPlan()` 还无条件读取当前实机五轴状态，这使得独立验证姿态“设计”与真实运动授权耦合在一起。

## V27.6.42B 修复原则

把三个状态彻底分开：

1. **离线训练/求解**：允许 Stage2 CSV 自举 + Physical17 求解；
2. **离线 hold-out 姿态设计**：只要有冻结后的 Physical17 + 对应训练数据，就允许生成独立验证姿态；
3. **真实自动运动/采集**：执行前必须重新核对当前实机 FlipX/FlipZ、XYZCB DPOS/MPOS 来源、回零/绝对坐标和 MachineSafety。

## 1. 独立验证姿态允许离线生成

V27.6.42B 中：

```cpp
m_btnGenerateValidation->setEnabled(
    m_hasResult && idleUi && !stage2TrainingObservations().empty());
```

不再要求 `m_referenceTaught == true`。

生成验证姿态时：

- 若当前存在已认证实机起点：使用当前实机 XYZCB，并检查“当前点 -> 首个验证姿态”的过渡路径；
- 若当前是 CSV 离线状态：不伪造 `(0,0,0,0,0)` 起点，首姿态只做目标安全检查，后续验证姿态之间仍做完整 MachineSafety 过渡检查；
- 真正执行自动验证时，会从当时的实机 MPOS 重新检查“当前点 -> 首姿态”。

离线验证姿态规划也复用 Machine5X 有限规划边界，不允许使用无限/占位 XYZ 范围。

## 2. 自动验证采集可以安全重新绑定新 Stage2 结果

如果 Stage2 CSV 是在此前已经绑定过的有效标定/阶段1坐标约定基础上导入的，那么导入时会保留：

- Stage1/默认标定的 `FlipX / FlipZ`；
- XYZCB DPOS/MPOS feedback mask；
- Stage1 bootstrap 来源。

点击“自动移动 + 采集独立验证”时，如果当前处于离线状态，V27.6.42B 会调用：

```cpp
tryBindCurrentSolvedResultForCalibrationMotion(...)
```

它会重新读取当前实机并严格比较：

- 当前 XYZCB DPOS/MPOS 来源 == 训练来源；
- 当前 FlipX / FlipZ == 训练来源；
- 当前五轴状态可稳定读取；
- 当前 Stage2 Physical17 的 translation gauge 未被破坏。

通过以后只恢复 **标定/验证运动权限**，不会恢复旧 hold-out 结论，也不会直接开放 RTCP/扫描。

## 3. 修正 V27.6.39+ 的 translation-gauge 绑定规则

V27.6.39 以后，Stage2 使用当前训练数据自行求：

- hand-eye rotation；
- hand-eye translation；
- sphere center。

因此 Stage2 的 `Tx/Ty/Tz` 不再要求等于旧 Stage1 的 `Tx/Ty/Tz`。

V27.6.42B 在重新绑定时，对新结果检查的是：

```text
最终 Physical17 Tx/Ty/Tz
        ==
initialization_bootstrap 中保存的 Stage2 self-bootstrap Tx/Ty/Tz
```

而不是错误地强制：

```text
Stage2 Tx/Ty/Tz == Stage1 Tx/Ty/Tz
```

旧版结果仍维持 Stage1 translation-gauge 一致性检查。

## 4. 防止旧独立验证结论误绑定到新求解结果

V27.6.42A 还有一个隐藏风险：

- 启动时加载了旧“默认有效标定”；
- 导入新的 Stage2 CSV；
- 新 Stage2 结果求解完成；
- 设备状态刷新时，旧 `m_persistentCalibrationLoaded` 仍可能触发默认标定自动绑定逻辑。

如果不处理，存在把旧 hold-out 通过结论错误附着到新参数向量的风险。

V27.6.42B 在进入 CSV 重标定模式时明确清除内存中的“当前 persistent model”授权：

```cpp
m_persistentCalibrationLoaded = false;
m_persistentCalibrationBound = false;
m_persistedValidationSummary = ValidationSummary{};
```

旧生产模型仍由 `m_fallbackResult` 保留，并且磁盘文件不删除。

因此：

- 旧模型不会被丢失；
- 旧验证结论不会污染新模型；
- 新模型必须重新做本次 hold-out 才能获得运行授权。

## 5. 正确工作流

```text
启动程序 / 已有有效标定可已绑定
        ↓
导入 Stage2 CSV
        ↓
退出当前实机标定运动会话（设备连接保持）
        ↓
Stage2 data self-bootstrap
        ↓
progressive trim
        ↓
Physical17 求解成功
        ↓
直接点击“生成独立验证姿态”
        ↓
离线生成 safe hold-out 计划
（避开 Stage2 rejected B/C 危险区）
        ↓
点击“自动移动 + 采集独立验证”
        ↓
重新核对 Flip / feedback mask / 当前五轴状态
        ↓
仅绑定本次新模型用于验证运动
        ↓
从当前 MPOS -> 首验证姿态做 MachineSafety
        ↓
X/Y/Z/C/B 独立 Single_MoveAbs
        ↓
自动采集 fresh hold-out profiles
        ↓
执行独立验证
        ↓
通过后才允许保存为新的默认有效标定 / RTCP / 扫描
```

## 验证重点

建议 Windows 实机重点验证：

1. 启动后已有有效标定自动绑定；
2. 导入 Stage2 CSV；
3. Stage2 最终求解成功；
4. “生成独立验证姿态”应立即可点击，不需要先清空会话；
5. 生成后“自动移动 + 采集独立验证”在设备在线、Stage1/坐标约定来源存在时可点击；
6. 第一次启动自动验证时日志应出现“当前阶段2求解结果已重新绑定到实机，仅用于标定/独立验证运动”；
7. 此时旧 validation passed 不应自动恢复；
8. 本次 hold-out 真正通过后，才允许新的 Physical17 成为运行标定。
