# V27.6.16O — Sensor Calibration Tab / Full-Field Auto-Idle / XYZCB

基于 V27.6.16N + V32.9。控制器 BASIC/TABLE ABI 不变，本版只调整 Qt 上位机的传感标定界面与传感器标定参数管理。

## UI 结构

- 原“控制”Tab中的 `传感器调试` 面板已移除。
- `系统标定` 的第一个内层 Tab 新增 `传感标定`，原 Video、轮廓预览、曝光自动测试整体迁入此页。
- 左侧原调试显示页改名为 `传感预览`，仅承担 Video/轮廓可视化，不再承载控制参数。

## 最大测量区域与采样周期

scanCONTROL 29xx 操作手册定义预设测量区域 `Large=0 / Standard=2 / Small=7`，并说明最大可实现测量速度随测量区域变化。项目既有 scanCONTROL 2950 官方 Quick Reference 表将 `Large(0)` 映射为 144 Hz。

传感标定页临时强制 `ROI1_PRESET=0 (Large)`。进入前保存用户正式采集所选测量区域；Video/轮廓预览/曝光测试结束或中止后自动恢复，因此不会破坏 V32.9 正式硬件同步通常使用的 `Small(7)` 设置。

曝光和 Idle 的 UI 单位均为 10 us。标定页将 Idle 设为只读并自动计算：

```text
ratedCycleUnits = ceil(100000 / fullFieldHz)
autoIdle        = max(0, ratedCycleUnits - exposureUnits)
```

对当前 2950 Large(0) / 144 Hz：

```text
ratedCycleUnits = ceil(100000 / 144) = 695
```

因此曝光 100（1.00 ms）时，自动 Idle=595（5.95 ms），总周期 6.95 ms，理论约 143.9 Hz，不超过 Large(0) 上限。若曝光本身超过 6.95 ms，则 Idle 自动变为 0，采样率随曝光主动下降，不会为了追求 144 Hz 而违反曝光时间约束。

曝光输入范围已统一到 1..4000（0.01..40.00 ms）。

## 五轴实验位姿

原 `XYZ + 入射角` 元数据改为当前机床 `XYZCB`：

- X/Y/Z：读取 `readJointSample5D()` 中既有 DPOS 语义；
- C/B：读取同一接口恢复后的软件机械 MPOS；
- 不从 ATYPE 推断标定坐标来源。

CSV 元数据明确保存：

```text
Position_X_DPOS
Position_Y_DPOS
Position_Z_DPOS
Position_C_MechanicalMPOS
Position_B_MechanicalMPOS
MeasuringField: Large (ROI1_PRESET=0)
Exposure
Idle_Auto
EstimatedProfileRate
```

这与已验证 Physical17 的坐标契约保持一致：`XYZ=DPOS, C/B=mechanical MPOS`。V32.9 硬件同步 TABLE 仍是真实五轴锁存 MPOS，两条数据来源语义不混用。

## 曝光自动测试

每个曝光档位启动 Video/Profile 前都会重新计算对应 Idle。Profile 保存直接读取 `LaserSensor::latestProfile()`，不依赖约 30 Hz GUI 预览刷新，避免曝光测试保存到旧的 UI 缓存帧。

## 不变项

- V32.9 SINGLE-OP14 / PWM0 / FULL-MPOS / ColdPrime / 128-slot wrap / synchronized stop-tail 不变。
- V27.6.16M ProfileIngress / DecodeThread / GapForensics / TABLE B/C UI 不变。
- V27.6.16N 自动硬件同步只读预检不变。
- Physical17 17参数、扫描重建和 RTCP 的坐标来源不变。
