# MotionLaserSync V27.6.53：运行时硬件同步频率 + XYZ/C/B 五轴上电会话回零状态

V27.6.53 是对 V27.6.52 的安全修正。V27.6.52 的 `TABLE[357]` 只保存了 X/Y/Z 三轴 Home 状态，不能满足“XYZBC 五轴均完成回零后，重启上位机仍能恢复五轴已回零状态”的机床工作流。

本版本保留 V27.6.52 的运行时 PWM 频率功能，同时将 Home 状态统一扩展为五轴。

> 上位机 V27.6.53 必须与 ECI3808 V32.11 BASIC 配套使用。协议能力标志为 `TABLE[354]=321053`；旧 V32.10/V32.9 会 fail-closed，不作为五轴 Home 状态来源。

## 1. 五轴 Home mask

`TABLE[357]` 定义为控制器/BASIC“本次上电会话”的五轴 Home bitmask：

```text
bit0 = X 已完成正规 DATUM，并建立光栅 MPOS 机床零点
bit1 = Y 已完成正规 DATUM，并建立光栅 MPOS 机床零点
bit2 = Z 已完成正规 DATUM，并建立光栅 MPOS 机床零点
bit3 = C 已在绝对机械坐标 ready 后成功回到机械 0°
bit4 = B 已在绝对机械坐标 ready 后成功回到机械 0°
```

因此：

```text
TABLE[357] = 31  <=>  X/Y/Z/C/B 五轴都完成过本次控制器上电会话的回零流程
```

B/C 的 Home bit **不能替代 RS485 绝对坐标同步**。上位机重新连接后，会先从 `TABLE[357]` 恢复 B/C 的“本次控制器上电会话已经完成过回零”的历史状态；只有本次上位机会话重新从禾川伺服读取绝对位置并成功建立 `absolute-ready` 后，B/C 的 Home 状态才被认为有效。

也就是说：

```text
B/C 可用于硬件同步 = persisted Home bit + 当前连接的 RS485 absolute-ready
```

## 2. XYZ 的回零提交规则

X/Y/Z 仍使用原点开关/DATUM。开始回零前先清对应 bit；只有以下链路全部成功后才最后提交 bit：

```text
DATUM 成功
-> HOME_STATUS == 1
-> 光栅 MPOS 稳定
-> SetMpos(axis, 0)
-> DPOS/MPOS 零点复核
-> 原软限位恢复成功
-> TABLE[357] 对应 bit = 1
```

这样即使上位机在回零中途异常退出，下次启动也不会错误恢复成“已回零”。

## 3. B/C 的回零提交规则

B/C 没有使用 XYZ 那样的原点开关。项目当前的“B/C 回零”定义保持不变：

```text
RS485 绝对机械坐标已建立
+ 操作员人工使能旋转轴
+ 绝对定位到机械 0°
```

V27.6.53 新增 `ZmcController::homeRotaryAxisToZero()`，流程为：

```text
先清 TABLE[357] 对应 C/B bit
-> 执行 moveAbs(axis, 0°)
-> 运动结束
-> 读取机械坐标 DPOS/MPOS
-> 验证 IDLE 且 0°误差在容差内
-> 最后提交 C/B Home bit
```

所以如果运动失败、被停止、上位机异常退出或 0°复核失败，C/B bit 保持清零。

## 4. 上位机退出再启动

只要 ECI3808 控制器与 BASIC 没有重启：

1. 新上位机连接后读取 `TABLE[354..357]`；
2. X/Y/Z 对置位 bit 再检查 `HOME_STATUS` 和 MPOS，过期 bit 自动降级；
3. C/B 保存其 Home-session bit；
4. 上位机重新完成 RS485 绝对坐标初始化后，C/B persisted Home bit 才生效；
5. 五轴 `isAxisHomed()` 均为 true 时，`areAllAxesHomed()` 才为 true；
6. 正式硬件同步只读预检要求 `TABLE[357] == 31`。

因此正常场景为：

```text
XYZBC 五轴已经回零
-> 仅退出上位机
-> 控制器/机床持续上电
-> 再启动上位机并连接 ECI
-> 自动重新建立 B/C 绝对坐标
-> 恢复 XYZBC 五轴 Home 状态
-> 不要求重复执行五轴回零
```

出于原有安全策略，B/C 伺服“人工使能”状态不会跨上位机进程自动恢复；重新启动上位机后仍需按既有策略人工使能。这与 Home/reference 状态是两个不同概念。

## 5. 控制器/BASIC 重启时清零

V32.11 BASIC 初始化执行：

```basic
TABLE(357)=0
```

所以 ECI 控制器掉电/重新上电、BASIC 被重新下载或重新运行后，五轴 Home mask 都从 0 开始，必须重新执行相应回零流程。

### 重要边界

这里的“上电会话”是 **ECI/BASIC 的上电会话**。如果实际电气系统存在“伺服/机床主动力掉电，但 ECI3808 仍由独立 24V 保持上电”的情况，那么仅靠 TABLE RAM 无法知道机床动力已经掉电，`TABLE[357]` 也不会自动清零。

若现场属于这种供电结构，应额外接入“机床主电源/伺服电源有效”数字输入，或利用现有可靠的电源/驱动状态信号，在掉电事件时由 BASIC 清 `TABLE[357]`。在没有该输入之前，V32.11 能严格保证的是“ECI/BASIC 重启清零”。

## 6. 硬件同步频率功能保持不变

V27.6.53 继续使用 V27.6.52 的运行时频率协议：

| TABLE | 含义 |
|---:|---|
| 354 | `321053`，V32.11 runtime capability magic |
| 355 | 上位机请求 PWM0 频率 Hz |
| 356 | BASIC 已应用 PWM0 频率 Hz |
| 357 | XYZ/C/B 五轴 Home mask |

频率由上位机设置，受 scanCONTROL 当前 Measuring Field 最大 profile rate 限制。活动软件按 `T=1/f` 派生周期，不再把 200 Hz / 5 ms 写死为运行时常量。

## 7. 部署文件

控制器使用：

- `controller/ECI3808_5Axis_Controller.bas`（canonical）
- 或同内容的 `controller/ECI3808_V32_11_RUNTIME_PWM_FIVE_AXIS_HOME_STATE.bas`

上位机：`MotionLaserSync V27.6.53`。

## 8. 回归验证

本版本新增/更新测试覆盖：

- C/B 0°回零前先撤销旧 persisted Home bit，成功复核后才重新提交；
- C/B 回零失败时 persisted bit 保持清零；
- `TABLE[357]=31` 的五轴 Home mask 在上位机断开/重连时保留；
- B/C persisted bit 必须等待当前连接的 RS485 absolute-ready 后才生效；
- stale XYZ bit 会降级，但保留仍有效的 C/B session bit；
- 模拟 ECI/BASIC 重启、`TABLE[357]=0` 后五轴重新要求回零；
- 正式硬件同步预检和启动均要求五轴 Home mask=31；
- 运行时 PWM 频率/Measuring Field 上限/`T=1/f` 逻辑继续通过回归。
