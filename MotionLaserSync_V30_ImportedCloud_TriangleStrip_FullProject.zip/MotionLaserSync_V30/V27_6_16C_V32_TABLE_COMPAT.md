# V27.6.16C / ECI3808 V32.1 TABLE compatibility fix

## Root cause of “BASIC protocol header mismatch”

The uploaded host project and the latest RAM-compact BASIC pair did not describe the same ABI.

Original host expected:
- `TABLE[337] magic = 270916`
- `TABLE[349] = 104` (exact continuous `REGIST(100+4)` mode)
- `TABLE[344] timing = 4` and `TABLE[345] latchMask = 31` for every hardware frame

The first V32 BASIC pair published:
- `TABLE[337] = 270909`
- `TABLE[349] = 4`, although the executed instruction is `REGIST(104,...)`
- NoGrating also published `timing=4/latchMask=31` even though only C/B are hardware latched and XYZ are DPOS snapshots.

Simply loosening the host check is unsafe: the V31 header and the first V32-NoGrating header are ambiguous, while their XYZ record semantics are different. V31 can publish zero XYZ MPOS on an ECI3808 without XYZ scales, whereas V32-NoGrating intentionally publishes XYZ DPOS snapshots.

## Corrected V32.1 header contracts

### NoGrating (current machine)

`TABLE[330..349]` at idle:

```text
96 0 0 0 0 0 0 270909 6 5 0 0 0 24 1 24 7 0 14 104
```

Meaning:
- feedbackMask=24 -> C/B from encoder feedback
- timing=1 -> ControllerSequential/Mixed
- latchMask=24 -> only C/B are hardware latched
- commandMask=7 -> XYZ from controller DPOS snapshots
- latchInput=0 -> R0 / IN0
- triggerOutput=14 -> OUT14/PWM0
- REGIST mode=104 -> continuous R0 falling-edge latch

### WithGrating

```text
96 0 0 0 0 0 0 270909 6 5 0 0 0 31 4 31 0 0 14 104
```

Meaning:
- feedbackMask=31
- timing=4 -> HardwareLatched
- latchMask=31 -> XYZCB all hardware latched
- commandMask=0
- REGIST mode=104

Both variants keep the same host ring record:

```text
[ordinal, X, Y, Z, C, B]
```

at `TABLE[370..945]`, capacity 96, six words per record.

## Host changes

- `Table5D::magic` changed from 270916 to 270909.
- Added explicit V32.1 NoGrating and WithGrating profile validation.
- The ambiguous V31/early-V32 NoGrating header is rejected with a targeted message instead of being silently accepted.
- Runtime now stores and re-checks effective timing/latch/source metadata instead of hardcoding every frame as `HardwareLatched`.
- NoGrating frames are archived as `ControllerSequential`, feedbackMask=24, latchMask=24, commandMask=7.
- WithGrating frames are archived as `HardwareLatched`, feedbackMask=31, latchMask=31, commandMask=0.
- Probe description updated to the V31/V32 one-shot implementation: 1 ms OUT14 pulse, then 200 Hz continuous mode after one record is confirmed.
- Fault-code text updated for V32-NoGrating fault 7 (more than one C/B event accumulated before XYZ DPOS snapshot can be reconstructed).
- Read-only preflight now prints the detected variant and a full TABLE[330..349] snapshot on failure.

## Safety / scope

The host build still keeps physical hardware-sync execution disabled. The “hardware sync read-only preflight” only reads the TABLE header. It does not write TABLE, start PWM, or command motion.

This change fixes the host/BASIC ABI and provenance semantics. It does not prove sensor exposure phase, electrical level compatibility, or dynamic synchronization accuracy.

## Verification performed

Focused portable tests after the change:
- `p0_core_mock_tests`: 57/57 passed
- `v21_runtime_tests`: 47/47 passed
- `v19_report_tests`: 19/19 passed

The tests include:
- NoGrating preflight pass with no `SetTable`
- WithGrating preflight pass
- exact TABLE[349] mismatch diagnostics
- rejection of the ambiguous V31/early-V32 NoGrating header
- one-shot probe / 200 Hz transition contract
- ring record/provenance decoding for the mixed NoGrating profile
