# V27.6.16V — Sphere Geometry / Profile Quality Study

This release replaces the V27.6.16T/U sphere distance-angle prototype with a geometry/quality study intended to produce data that can later guide Physical17 hand-eye and machine-geometry recalibration. It **does not change the formal kinematic calibration solver yet**.

## 1. Reference sphere

The workflow starts from a hardware-synchronized reconstructed machine-frame sphere cloud. 3-D sphere RANSAC rejects fixture/background points and refines the sphere center `O_M`. The certified/entered sphere radius `R` is used as the study reference.

The old Physical17 calibration remains usable as a navigation seed. It is not treated as new ground truth and legacy provenance remains preserved.

## 2. Study geometry

### MeasurementDistance D

After Circle RANSAC identifies the sphere arc, the geometrically reliable points are refined to a 2-D section circle in scanCONTROL coordinates:

`C_S = (Xc, 0, Zc)`.

The configured optical reference center is `O_opt=(X0,0,Z0)`. The study distance is

`D = ||C_S - O_opt|| = sqrt((Xc-X0)^2 + (Zc-Z0)^2)`.

The UI exposes X0/Z0 explicitly; the current calibrated scanCONTROL convention defaults to zero. `Zc` is still exported separately because the sensor working-Z range remains important.

### SectionAngle gamma

The current laser Profile is the sensor X-Z plane. Through the actual XYZCB MPOS and the available Physical17/machine model this plane is mapped to the machine frame. Let `n_pi` be its unit normal and `C_M` the fitted section-circle center mapped to machine coordinates.

`h = | n_pi dot (O_M-C_M) |`

`gamma = asin(h/R)`, with `0 <= gamma <= 90 deg`.

No sign is used: which side of the laser plane contains the sphere center is not a sensor-quality variable. The theoretical section radius is

`r_ref = R cos(gamma) = sqrt(R^2-h^2)`.

The difference `r_fit-r_ref` is exported as `RadiusBias`; this prevents a very circular but incorrectly scaled Profile from being ranked as high quality merely because Circle RMS is small.

### LocalSurfaceAngle theta

`gamma` belongs to a whole Profile. `theta` belongs to each expected sphere sample slot. For a reference sphere point `P_i`, local outward normal `n_i` and ray from that point to the configured optical reference center `v_i`,

`theta_i = acos(|n_i dot v_i|)`.

The EvaluationROI reference circle supplies an expected point and theta even when a slot is a dropout and has no valid measured Z. This allows later models to learn `P(dropout | D,gamma,theta)` instead of silently losing failed measurements.

## 3. Five-axis path coverage

V27.6.16V does **not** hold C/B fixed. The UI defines D, gamma, C and B ranges. For every explicit C/B sample, the planner uses the available Physical17 + identified machine geometry to solve XYZ for the requested sensor-space sphere geometry.

Thus a nominal D/gamma condition may be revisited under multiple rotary poses. C/B are preserved in the experimental record, while the primary sensor-quality coordinates remain the **actual fitted** D/gamma/theta.

Target values are navigation goals only; they are never substituted for measured values in analysis.

## 4. Lossless Rich Profile semantics

The acquisition stores one record for every original scanCONTROL sample index: X, Z, Width, Maximum, Threshold, Moment0 and Moment1 when available. No point is rejected because a Rich channel looks bad.

Circle RANSAC sees only coordinate-valid X/Z and serves two purposes: locate the actual circle and create a stable multi-frame EvaluationROI. If the approximate calibration predicts the sphere in the wrong window, RANSAC retries the full coordinate-valid Profile.

After a common ROI is established, every original sample slot in `[start,end]` is an experiment observation:

- `Good`: coordinate valid and geometrically consistent with the refined circle;
- `GeometricOutlier`: coordinate valid but inconsistent with the reference circle;
- `Dropout`: expected circle slot with invalid/no coordinate.

Only Good/RANSAC geometry is used to refine a circle. **All ROI slots** remain in quality statistics. A bad Profile therefore cannot improve its Valid ratio by shrinking its own ROI.

## 5. Profile quality outputs

For every Profile the analyzer exports:

- fitted circle center Xc/Zc and actual MeasurementDistance D;
- actual SectionAngle gamma and plane offset h;
- fitted radius, theoretical radius, RadiusBias;
- Circle RMS/MAD/P95/max shape residual;
- absolute section residual mean/RMS/P95/max relative to `r_ref`;
- Good/Dropout/Outlier ratios;
- longest dropout/outlier runs and dropout run count;
- robust Maximum/Width/Moment0/Moment1/Threshold statistics for all coordinate-valid points and for Good geometry separately.

`point_samples.csv` exports every EvaluationROI slot, including dropouts, with expected X/Z and LocalSurfaceAngle theta where inferable.

## 6. First empirical quality map

The release exports `quality_map_kernel.csv`, an interpretable Gaussian-kernel regression over actual `(D,gamma)` observations. It predicts local Profile P95 absolute section error, RadiusBias, Dropout ratio, Outlier ratio, Good ratio, local spread and support. Low-support/extrapolated cells are explicitly flagged.

This map is deliberately a baseline rather than a black-box model. The lossless Profile and point exports are intended for the next analysis stage, where GAM/LOESS or heteroscedastic Gaussian Process can model Profile-level uncertainty and grouped gradient-boosted models can model point-level quality using `(D,gamma,theta,Maximum,Width,M0,M1,...)`. Training/validation must be grouped by Visit/Pass rather than randomly splitting neighboring points.

## 7. What this release does not do

V27.6.16V does not yet alter Physical17 parameter identification, the machine geometric-error optimizer, or formal calibration weighting. The intended next step is to use the quality surface as a prior/weight while still selecting kinematically informative XYZBC poses.

## 8. Controller code

No `.bas` file is modified by this release. V27.6.16U Home-All hardware-sync unlock behavior and V27.6.16S XYZ grating MPOS homing/reference behavior are retained.
