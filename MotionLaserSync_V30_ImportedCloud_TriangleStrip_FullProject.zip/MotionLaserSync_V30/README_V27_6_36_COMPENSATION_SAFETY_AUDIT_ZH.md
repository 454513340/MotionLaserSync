# V27.6.36 XYZ补偿 + MachineSafety 复核修正版

本版从 V27.6.35 继续，专门修复补偿与原有碰撞安全模型之间的耦合问题。

## 修复

1. Stage-2 独立五轴：MachineSafety 现在使用与实际控制器完全一致的XYZ补偿限速后参数，避免XYZ被precision speed限制后与C/B的相对时序改变而导致预测轨迹失真。
2. 启用XYZ补偿时，同步/独立五轴的MachineSafety过渡检查对每一个采样姿态都执行静态间隙检查，而不再只在首尾检查间隙。
3. 从已加载XYZ表计算保守L1补偿路径包络。当前随包数据最大节点修正约X=0.02000014 mm、Y=0.01300017 mm、Z=0.027333577 mm，总包络约0.060334 mm。只有machine_config.json中的minimum_static_clearance_mm严格大于该包络才允许现有MachineSafety受保护的补偿五轴运动。当前配置为1.0 mm。
4. FCL STL、机床运动学、ignored collision pairs、3 mm直线关节规划裕量、3°旋转裕量和2 mm研究球间隙本身未改动。

## 重要边界

原V27.6.34的FCL碰撞门禁并不是全局运动门面：球面研究/Stage-2等路径有MachineSafety门禁，但普通单轴手动、持续JOG、普通G-code/通用merge等并非全部经过FCL碰撞模型。V27.6.36没有把这一历史行为伪装成“全局碰撞保护”。控制器软限位、AXISSTATUS、B/C absolute-ready/servo interlock仍由各运动门面继续执行。

因此，本版解决的是“补偿不能使原本受MachineSafety保护的轨迹与实际运动不一致”。若目标是让所有生产运动（包括G-code、merge、单轴手动）统一经过FCL，应另做一次全局MotionSafety门面重构。
