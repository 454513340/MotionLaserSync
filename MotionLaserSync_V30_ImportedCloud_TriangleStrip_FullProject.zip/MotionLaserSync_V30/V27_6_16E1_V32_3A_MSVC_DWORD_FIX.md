# V27.6.16E1 / V32.3A MSVC DWORD build fix

## Problem

MSVC C2664 in `LaserSensor.cpp` at the two `CInterfaceLLT::GetFeature(DWORD, DWORD*)` calls.
The vendor API requires the second argument to be `DWORD*`, while V32.3 used `unsigned int*`. On MSVC/Windows `DWORD` is a distinct type from `unsigned int` for overload/type checking.

## Fix

- Changed `Trigger`, `MultiPort`, `ioReadback`, `triggerReadback`, and verification masks to `DWORD`.
- Kept the public diagnostics/atomics as `unsigned int`; explicit casts are used when storing vendor values.
- Cast values to `qulonglong` when formatting hexadecimal diagnostics with `QString::arg`, avoiding overload ambiguity.
- No change to trigger polarity, TABLE protocol, B/C software-frame offsets, REGIST(104), or V32.3 runtime logic.

## Affected source

- `src/core/LaserSensor.cpp`

This is a compile-only compatibility correction for the scanCONTROL vendor C++ API.
