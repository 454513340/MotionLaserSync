# V27.6.16AD 离线球面截平面族“卡死”修复

## 1. 根因确认

V27.6.16AC 的离线规划入口虽然不再要求控制器连接，但路径生成仍把 `m_axisParams[AxisX..AxisB].softLimitNeg/Pos` 直接写入 `SphereStudyPathOptions`。

`AxisParams{}` 在控制器尚未连接/尚未读取轴参数时的明确占位值是：

- `softLimitNeg = -999999`
- `softLimitPos = +999999`

自动截平面族选择器按 `rotaryCandidateStepDeg`（界面默认 10 deg）遍历 C/B。AC 因而会把离线 C/B 搜索域错误扩展到接近 `[-999999,+999999] x [-999999,+999999]`。这是一个极大的双重循环，所以 GUI 线程表现为点击“生成球面截平面族路径”后长时间无响应。

这不是球面 RANSAC、球-平面求交或可见圆弧公式本身的死循环。

## 2. AD 的限位来源

`models/machine5x/machine_config.json` 新增 `offline_planning_limits`，数值来自工程现有 `config/eci3808_trajectory_limits.example.json` / ECI3808 V32.9 现场 BASIC：

| Axis | raw planning range |
|---|---:|
| X | -150 .. +117 mm |
| Y | -119 .. +137 mm |
| Z | -35 .. +56 mm |
| C | -90 .. +90 deg |
| B | -90 .. +90 deg |

随后仍应用 Machine5X 的规划安全裕量：XYZ 各缩 3 mm，B/C 各缩 3 deg，因此默认离线自动搜索实际使用 C/B `[-87,+87] deg`。

在线状态下不是忽略控制器：AD 使用 `Machine5X offline_planning_limits ∩ 控制器实时软限位`，然后再扣安全裕量。

如果 Machine5X 没有配置离线限位，离线规划现在会明确报错，绝不会再次退回 ±999999。

## 3. 数值核心增加独立防挂保护

`SphereStudyPathOptions` 新增：

```text
maxAutomaticRotaryCandidateCount = 2048
```

自动 C/B 搜索在进入双重循环以前先计算候选格点总数。若限位非有限、上下界错误、或者候选数超过硬上限，立即返回：

```text
Automatic C/B search grid is too large/invalid ... Refuse to enumerate
```

C/B 搜索也由浮点 `for (angle += step)` 改成了预先计数后的整数索引循环，使终止次数完全确定。

因此即使未来另一个调用入口错误传入 ±999999，核心库也会 fail-fast，而不是依赖 MainWindow 恰好传对参数。

## 4. FCL 阶段不是无限循环，但改善了界面反馈

最终空间填充路径最多保留界面要求的目标姿态数（默认 120）。这些姿态仍必须通过：

1. Machine5X 目标姿态碰撞/静态间隙；
2. 相邻 XYZCB 整段扫掠碰撞检查；
3. 单段扫掠采样仍受 `transition_max_samples=4000` 硬上限约束。

这一阶段计算量可能明显高于纯几何规划。AD 在安全筛选过程中定期处理 Qt repaint/event，并在状态栏显示 `正在执行Machine5X路径安全检查 n/N...`。因此重计算时窗口仍能刷新，不再表现为完全冻结。

## 5. 复现测试

新增 portable regression `v27616ad_offline_planner_guard_tests`：

- 显式传入 AC 离线状态的 C/B `[-999996,+999996]` + 10 deg 步长；
- 要求 1 秒以内 fail-fast；
- 要求错误信息包含 oversized-grid 诊断；
- 再用 AD 的 Machine5X 有限范围和截图中的 D/gamma/eta 参数组合验证正常生成；
- 默认 120 个目标姿态的纯数值规划在当前 Linux portable 测试环境约 0.5 秒完成（FCL GUI 安全筛选不在该 portable 数值计时内）。

## 6. 不变项

- 球面点云 RANSAC 逻辑不变；
- scanCONTROL X/Z FOV、球-激光平面相交、可见弧角度/物理弧长门禁不放宽；
- Machine5X PLY/STL 几何文件不修改；
- ECI3808 V32.9 BASIC 不修改；
- `SphereDistanceAngleStudy.v9` 数据 schema 不变，本次仅更新应用版本为 V27.6.16AD。
