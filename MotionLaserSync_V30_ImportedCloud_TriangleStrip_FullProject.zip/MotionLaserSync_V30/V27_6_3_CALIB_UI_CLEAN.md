# V27.6.3 — 单球17参标定页面彻底移除重复详情栏

基于 V27.6.2 Release-only。

问题：
- V27.6.1 已删除 CalibrationWidget 最外层“标定日志”；
- 但 SingleSphere14CalibrationWidget（实际承载 17 参数 rank14 标定）内部还保留了一个
  `m_details` QTextEdit，用来显示 gauge / message / sphere center / singular values。
- 标定前该 QTextEdit 为空，因此右侧出现一个很大的空白白框，看起来像“旧日志残留”。

修改：
- 删除 SingleSphere14CalibrationWidget 内部 `m_details` QTextEdit。
- 删除对应 QTextEdit include、前置声明和成员。
- 求解详情（translation gauge、message、sphere center、hand-eye translation anchor、
  17 个物理奇异值、20 状态奇异值）统一通过 `logMessage` 进入底部系统日志。
- 右侧只保留：
  - 标定状态
  - 17 参数结果表
  - 保存/加载/导入/导出按钮
- 保持 V27.6.2 Release-only CMake。
- 未修改 ECI3808/PWM/REGIST/RTCP/TABLE/传感器协议。
