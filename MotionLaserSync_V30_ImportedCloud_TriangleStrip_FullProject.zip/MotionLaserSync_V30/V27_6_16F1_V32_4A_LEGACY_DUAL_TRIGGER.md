# V27.6.16F1 / ECI3808 V32.4A LegacyDualTrigger

## Why this version exists

The V32.3 field test proved that the scanCONTROL trigger path itself is working:

- Probe passed with exactly 1 Profile + 1 Pose.
- 129 SDK callbacks were received and all 129 profiles converted successfully.
- Profile indices were continuous.
- Apart from the intentional Probe -> continuous handshake gap, the measured profile interval was essentially 5 ms.

The capture was invalidated for a different reason:

`V32-NG一次轮询积压超过1个C/B锁存，XYZ历史DPOS快照无法可靠恢复`

V32.3 NoGrating only sampled XYZ DPOS when its foreground BASIC loop noticed a new C/B REGIST record. At 200 Hz it is normal for more than one controller event to accumulate between foreground/PC polls, so past XYZ DPOS could not be reconstructed safely.

## V32.4A controller-side fix

V32.4A returns to the timing architecture of the proven legacy BASIC program:

- TIMER0 is the acquisition clock at 5 ms.
- OP0 remains the proven scanCONTROL trigger output.
- OP14 is a separate latch-bridge output physically looped to ECI IN0.
- The same TIMER0 ISR asserts OP0 and OP14 together.
- scanCONTROL uses `EdgeFalling` on the legacy OP0 path.
- C/B use `REGIST(103)` (continuous R0 logical rising edge) on OP14 -> IN0.
- NoGrating XYZ DPOS are captured in that same ISR into a 128-deep software FIFO.
- C/B hardware REGIST data and XYZ software FIFO records are later drained in batches into Buffer-B.
- Therefore host polling no longer has to run at 200 Hz and a batch containing multiple records is valid.

The public Buffer-B record remains:

`[ordinal, X, Y, Z, C, B]`

For NoGrating:
- X/Y/Z = TIMER0 ISR DPOS snapshots.
- C/B = hardware-latched raw MPOS.
- Host restores mechanical C/B as `raw MPOS + frozen software-frame offset`.

For WithGrating:
- XYZ/C/B = hardware-latched MPOS using `REGIST(103)`.

## Protocol header

V32.4A extends the header to TABLE[330..350]:

- TABLE[337] = 270909
- TABLE[338] = 6
- TABLE[339] = 5 ms
- TABLE[342] = 1 execution authorization
- TABLE[348] = 0 sensor trigger output (OP0)
- TABLE[349] = 103 continuous REGIST mode
- TABLE[350] = 14 latch bridge output (OP14 -> IN0)

NoGrating provenance:
- feedbackMask = 24
- timing = 1
- latchMask = 24
- commandMask = 7

WithGrating provenance:
- feedbackMask = 31
- timing = 4
- latchMask = 31
- commandMask = 0

## Host changes

- Manual hardware sync now explicitly selects `EdgeFalling`, matching the legacy OP0 path.
- Preflight requires the V32.4A 21-word header, OP0 sensor output, OP14 latch bridge, and REGIST(103).
- Sensor readback diagnostics remain enabled.
- Probe is one TIMER0 LegacyDualTrigger event, not a 1 ms software pulse.
- The intentional Probe -> continuous handshake interval is excluded from steady-state 5 ms timing statistics.
- B/C absolute-coordinate logic is unchanged.

## Field-test target

For the first V32.4A NoGrating run, the expected final invariants after stop are:

- Profile == Pose == TABLE[336]
- Aligned == Profile
- Dropped == 0
- TABLE read failures == 0
- Buffer overflow == 0
- Profile index has no gap/duplicate/backward step
- Continuous-stage exposure intervals are approximately 5 ms

The Z-axis hardware-limit warning seen in the prior log is independent of the sync fix and should be cleared before testing trajectories that move Z.
