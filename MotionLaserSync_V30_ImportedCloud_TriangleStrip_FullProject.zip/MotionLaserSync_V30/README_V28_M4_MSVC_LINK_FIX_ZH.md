# MotionLaserSync V28.3.1：M4 / VS2022 LNK2019 链接修复

本版以此前交付的 `MotionLaserSync_V28_PROJECT_M4_COMPLETE.zip` 为唯一基线修订，完整保留 M0、M1、M2、M3 及 M4 功能。

## 问题与根因

VS2022 截图显示 11 项链接错误（主要是 LNK2019、最终 LNK1120），缺失：

- `M4Metrics::f1/iou/meanAbsX/meanAbsZ/rmseZ` 等；
- `M4FloorCoverage::intersectionOverUnion/realPositiveRatio/simulatedPositiveRatio` 等；
- `TwinM4Adapter::compare/fitEquivalentCameraY/exportComparison/exportFit` 等。

这些成员函数的定义存在于工程源码中，并非缺少 Open CASCADE、函数声明或 VS2022 语法支持。直接原因是当前生成的 Windows 主程序链接配置**没有解析到**相关 M4 `.cpp` 的目标文件（可能还伴随旧工程/旧缓存）。截图的工程路径含 `MotionLaserSync_V28_PROJECT_M3_COMPLETE`，尤其应核查是否仍在构建以前的目录。

## 本版变更

- `CMakeLists.txt`：将 M4 核心的 `TwinM4Comparison.cpp` 和 `TwinM4Calibration.cpp` 以及 Qt 桥接 `TwinM4Adapter.cpp` **直接编译进 `MotionLaserSync.exe`**，而不是指望从 GUI 的 `digital_twin_core.lib` 中间接解析 M4 符号。CLI-only 离线测试时 M4 核心仍编入 `digital_twin_core`。两种模式不会把同一个 M4 实现同时链接两次。
- `CMakeLists.txt`：增加配置期源码缺失检查，检查三份 M4 实现文件是否存在且注册到 GUI 的 `WIDGET_SOURCES`；若缺少则在 CMake 配置时明确报错。
- `MainWindow.cpp`：标题更新为 `MotionLaserSync V28.3.1`，便于识别是否启动了新编译的程序。
- `tests/twin/verify_m4_gui_cmake.py`：新增纯源码链接结构检查，无需 Qt、VTK 或厂商 DLL。
- 保留 Open CASCADE 路径 `D:/dev/vcpkg/installed/x64-windows-release`，未更改机床控制器、采集协议、M2/M3 光学模型或已有 M4 比较公式。

## Windows 10 + VS2022 使用方式（重要）

1. 不要在旧 `M3_COMPLETE` 工程里只替换 `DigitalTwinScanWidget.cpp`；**解压整个修复 ZIP 到全新目录**，如 `E:\Projects\MotionLaserSync_V28_PROJECT_M4_MSVC_LINK_FIXED\`。内层工程目录名仍为 `MotionLaserSync_V28_PROJECT`。
2. Visual Studio 2022：`文件 -> 打开 -> 文件夹...`，选择新目录中的 `MotionLaserSync_V28_PROJECT`（应能在此层看到 `CMakeLists.txt`）。
3. 选择 `x64-Release`，使用 `项目 -> 删除缓存并重新配置`，重新生成 CMake（菜单措辞可能随 VS 版本不同）。**仅“生成解决方案”并不保证旧 CMake 缓存已更新。**
4. 查看 CMake 输出，应包含：

   ```text
   V28.3.1 M4 GUI direct sources: Comparison + Calibration + Adapter [OK]
   ```

   如果没有这行，请先检查是否打开了新工程，以及是否真正清除并重新配置缓存。
5. 在启动项中选择 `MotionLaserSync.exe` 并重新构建。正常情况下构建输出会编译 `TwinM4Comparison.cpp`、`TwinM4Calibration.cpp`、`TwinM4Adapter.cpp` 到 `MotionLaserSync` 主程序目标。
6. 运行后标题应显示 `MotionLaserSync V28.3.1`。然后依次尝试 M2 `.scan` 导入、M3 虚拟扫描以及 M4 全量对比。

如果仍出现 LNK2019，请提供 **“输出 -> 生成”** 窗口中完整的链接命令/构建输出与 `CMakeCache.txt` 中 `CMAKE_HOME_DIRECTORY` 项。CMakeCache.txt 应指向新的工程目录，而不应是原先的 `M3_COMPLETE` 路径。

## 本地可执行检查

如果安装了 Python 3，可在工程根目录运行：

```powershell
python tests\twin\verify_m4_gui_cmake.py
```

结果应为：

```text
M4 GUI source wiring verified: Comparison, Calibration, Qt Adapter
```

## 本次已完成的验证与限制

- Linux C++17 离线 Debug 构建和 CTest：**10/10 通过**。
- Linux C++17 离线 Release 构建和 CTest：**10/10 通过**。
- CMake GUI 注册源码静态检查：**通过**。
- **无法在本环境安装或运行你的 Windows VS2022 + Qt6 + VTK + 厂商 SDK GUI 全量构建**。请以 Windows 机上的构建结果为准，若有 MSVC 特有的后续错误再处理。

本次修复不触碰真实硬件运动控制、不改变测量场与扫描位姿变换，仍是数字孪生离线诊断工作流。
