# V27.6.16E / V32.3 SENSOR-TRIGGER-DIAG

## 现场故障依据

V32.2 实机 Probe 得到 `Pose=1, Profile=0`。ECI3808 的 REGIST/Buffer-B/TABLE 链已产生一条位姿，但 scanCONTROL 没有形成可用 Profile。

## V32.3 修改

1. **传感器边沿改为 EdgeRising**：控制器继续 `REGIST(104)`。现场已验证 OUT14 关闭时 ECI IN0 为 1->0；对于当前 24V/NPN 触发链，scanCONTROL 使用线路回高的 EdgeRising，使传感器和 ECI 锁存落在同一 OUT14 关闭时刻。
2. **DIGITAL_IO 先配置，TRIGGER 后配置**，避免数字输入配置覆盖/重置触发设置。
3. **配置后立即 GetFeature 回读** `FEATURE_FUNCTION_DIGITAL_IO` 与 `FEATURE_FUNCTION_TRIGGER`；关键位不一致即拒绝采集。
4. **新增 SDK Profile 回调诊断**：raw callback、转换成功、转换失败、最后转换返回值、buffer 字节数、resolution。
5. **Probe 超时错误直接携带诊断**：可一次区分“完全没有传感器回调”与“收到回调但 ConvertProfile2Values 失败”。
6. **硬件模式不再提前打印“采集启动成功”**；开始时显示“已 Arm，等待 Probe”。只有 Probe 1 Profile + 1 Pose 成立后才由同步层记录切换 200 Hz。
7. **数据分析报告新增传感器触发/回调诊断区**。

## BASIC

V32.3 BASIC 的运行逻辑、TABLE 地址和 V32.2 HW-EXEC 完全兼容；仍使用 `TABLE[342]=1`、`TABLE[349]=104`，单次 Probe 为 `OUT14 ON -> DELAY(1) -> OUT14 OFF`。本次根本修改在上位机 scanCONTROL 边沿和诊断链。

## 第一次复测重点

启动后应看到：

- `V32.3外部触发配置回读通过`
- `V32.3传感器触发回读缓存: valid=1`
- `V32.3硬件同步已Arm，正在等待1ms单脉冲Probe...`
- 成功时：`V32.3单脉冲Probe对齐通过...切换200Hz`

若仍失败，超时日志里的判读：

- `sensorRawCallback=0`：优先检查 scanCONTROL In1 / GND-In1 接线、电平与真实边沿。
- `sensorRawCallback>0` 但 `convertedProfile=0`：优先检查 LLT SDK Profile 格式、resolution/ConvertProfile2Values。

B/C 增量编码器的机械绝对坐标算法没有修改：TABLE 内仍是 raw MPOS，上位机使用启动时经 RS485 绝对编码器、机械零点、方向和减速比计算出的 software-frame offset，按 `machine = rawMPOS + frozenOffset` 恢复。
