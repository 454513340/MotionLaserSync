# V27.6.16Q — 传感标定 Rich Profile 数据保存

本版基于 V27.6.16P。**只修改 `系统标定 -> 传感标定` 的轮廓获取与保存路径；硬件同步采集、HardwareSyncStrategy、TABLE、GapForensics 报告、点云归档和 ECI3808 V32.9 BASIC 均保持原逻辑。**

## 1. 设计目标

V27.6.16P 的曝光测试每个曝光点只保存一条最新轮廓的 `X,Z`。V27.6.16Q 在同一静态传感标定流程中额外保存 LLT SDK `ConvertProfile2Values()` 可直接提供的辅助通道，同时避免给 200 Hz 硬件同步增加额外数组分配和转换负担。

实现方式：

- `LaserSensor::m_sensorCalibrationRichProfileEnabled` 默认 `false`。
- 只有曝光测试进入 `StartProfile` 时临时置 `true`。
- 此时 DecodeThread 除 X/Z 外，还向 LLT 请求：
  - `pWidth`
  - `pMaximum`
  - `pThreshold`
  - `pM0`
  - `pM1`
- `StopProfile`、人工停止和测试完成都会恢复 `false`。
- HardwareSync 代码没有调用此开关，因此正式硬件同步仍走 V27.6.16P 的 X/Z-only 解码路径。

## 2. 一次实验只保存一次的 Session 清单

每次曝光测试目录新增：

` sensor_calibration_session.json `

内容包括：

### 2.1 传感器身份

- sensor type name
- device name（SDK 可读时）
- serial number（SDK 可读时）
- sensor IP
- active resolution

名称/序列号读取失败不会阻止实验，只会留下 note。

### 2.2 Measuring Field / 时序

- `MEASURINGFIELD preset index = 0`
- 明确说明本流程没有自定义 row/column ROI
- 进入传感标定前的实际 field index（结束时恢复）
- 目标 Profile Rate
- Exposure sweep start/end/step
- capture delay
- Idle 自动计算语义

### 2.3 环境和机床姿态

- Material：原始输入和安全文件名
- Lighting：显示名和内部代码
- Temperature
- X/Y/Z：DPOS，mm
- C/B：software mechanical MPOS，deg

保持 Physical17 坐标来源契约不变。

### 2.4 高级参数

保存两份：

1. `configuredAdvancedSettings`：当前 MotionLaserSync UI / 写入意图
2. `deviceReadbackAdvancedSettings`：实验开始时能可靠回读的设备值

记录：

- Measuring Field index
- Resolution
- Laser power
- Threshold %
- Reflection Selection（含名称）
- FlipX / FlipZ
- Auto Exposure / mode
- Shutter Alignment
- High Resolution
- Calibration
- Ambient Light Suppression
- Video Filter

### 2.5 Valid Reflection / Peak Filter

`MinWidth / MaxWidth / MinIntensity / MaxIntensity` 不再反复从当前 2950 + SDK/固件组合读取。

Session JSON 将它们保存为：

- 当前 UI / 写入意图值
- provenance = `UI/write-intent; reliable device readback intentionally not used on current 2950/SDK`

这避免把“默认/UI 值”伪装成设备回读真值。

## 3. 每个曝光点的 Profile 文件

### 3.1 `*_profile.csv`

头部增加：

- Session manifest 文件名
- UTC capture time
- Material / Lighting / Temperature
- Measuring Field
- Exposure / Auto Idle
- Target / realized Profile Rate
- XYZ DPOS / C/B mechanical MPOS
- Profile Index
- Sensor open / close timestamp
- Sensor exposure duration
- PC callback entry timestamp
- Decode done timestamp
- Callback ordinal
- Raw bytes
- Ingress depth
- Callback service time
- Decoder queue time
- Decode service time
- LLT convert flags
- 各辅助通道是否可用

点级列固定为：

```text
PointIndex,X_mm,Z_mm,Width,Maximum,Threshold,Moment0,Moment1
```

其中 `Maximum` 是 LLT SDK 的 `pMaximum` 输出，保存时明确标注为 peak maximum / intensity-like value，避免和 Peak Filter 的 `MinIntensity/MaxIntensity` 配置混淆。

如果某辅助通道没有对应 `CONVERT_*` 标志，CSV 中该列留空，而不是填 0 冒充有效数据。

### 3.2 `*_profile_meta.json`

每条保存轮廓另生成一个轻量 JSON，包含：

- 动态曝光/Idle/频率
- 机床 XYZBC 姿态
- Profile index 和传感器时间戳
- Profile ingress / decoder 诊断
- convert flags
- 可用通道表
- point count

稳定的传感器设置不重复写入这里，而引用 `sensor_calibration_session.json`。

### 3.3 `*_profile.png`

保持原有轮廓显示截图。

## 4. Video 数据

原有：

- `*_video.png`
- `*_video_raw.csv`

继续保留；`video_raw.csv` 增加 `SessionManifest` 引用。

## 5. 本版明确不做的事情

- 不修改硬件同步 Profile 保存格式。
- 不修改 `HardwareSyncStrategy`。
- 不修改 Profile Gap Forensics 报告。
- 不修改 ECI3808 TABLE / BASIC。
- 不保存整块 LLT raw profile buffer 到磁盘。
- 不在本版展开四路多反射 full-set；仍保存当前 PROFILE 解码所对应的反射输出及其辅助值。
- 不把 Peak Filter 的 Width/Intensity 配置值当作设备回读值。

## 6. 关键文件

- `include/core/LaserSensor.h`
- `src/core/LaserSensor.cpp`
- `include/app/MainWindow.h`
- `src/app/MainWindow.cpp`
- `tools/verify_v27616q_sensor_calib_rich_data.py`

