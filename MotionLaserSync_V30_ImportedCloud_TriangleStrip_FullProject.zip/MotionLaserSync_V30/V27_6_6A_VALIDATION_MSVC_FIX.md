# V27.6.6a — Independent validation MSVC type fix

V27.6.6 added an independent hold-out validation plan. `CalibrationPoseInstruction::predictedJoint`
uses the portable calibration-core type `mls::calibration::JointPose5d`, while the Qt/controller UI
formatter `poseText()` originally accepted only the GUI type `JointPose5D`.

MSVC therefore reported C2664 at the confirmation dialog:
`poseText(finalTarget)` could not convert `const mls::calibration::JointPose5d`
to `const JointPose5D&`.

Fix:
- keep both data types distinct;
- add one shared templated formatting implementation;
- provide explicit overloads for both `JointPose5D` and
  `mls::calibration::JointPose5d`.

No calibration mathematics, validation thresholds, hold-out separation logic, motion planning,
ECI3808/PWM/REGIST/TABLE protocol, or Release-only build policy was changed.
