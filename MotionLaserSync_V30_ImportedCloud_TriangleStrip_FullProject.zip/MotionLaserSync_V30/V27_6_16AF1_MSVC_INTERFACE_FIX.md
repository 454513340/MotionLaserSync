# V27.6.16AF1 — MSVC CalibrationWidget interface forwarding fix

## Symptom

MSVC reported C2039 in `src/app/MainWindow.cpp` near the offline sphere-study planning model refresh:

`'sphereStudySensorCoordinateConvention': is not a member of 'CalibrationWidget'`.

## Root cause

V27.6.16AF added `SingleSphere14CalibrationWidget::sphereStudySensorCoordinateConvention(...)`, but `MainWindow` owns the outer `CalibrationWidget*`. The outer wrapper already forwarded `sphereStudyPlanningCalibration(...)` but did not forward the new sensor-coordinate-convention query. The numerical implementation existed, but it was unreachable through the static type used by `MainWindow`.

## Fix

`CalibrationWidget` now declares and implements:

`bool sphereStudySensorCoordinateConvention(bool& flipX, bool& flipZ, QString& source) const;`

The implementation forwards to `m_singleSphere14Widget->sphereStudySensorCoordinateConvention(...)` and returns a deterministic error/fallback state if the inner widget is unavailable.

No optical geometry, Machine5X model, FOV orientation, path planning, controller BASIC, or hardware command path was changed in AF1.

## Validation

- Checked every `m_calibrationWidget->...` call in `MainWindow.cpp` against the public `CalibrationWidget` API. The only missing project-defined method in AF was `sphereStudySensorCoordinateConvention`; AF1 now exposes it.
- Checked declaration/definition/call signatures for the new forwarding method.
- Existing portable CMake test configuration succeeds; the full GUI target cannot be built in the Linux validation environment because this project intentionally requires bundled Windows x64 vendor SDKs for GUI builds.
