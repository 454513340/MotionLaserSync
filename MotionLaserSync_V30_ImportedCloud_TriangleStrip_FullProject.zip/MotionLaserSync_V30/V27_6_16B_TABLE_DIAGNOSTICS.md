# V27.6.16B TABLE 只读逐字段诊断

## 背景
现场 V27.6.16A 返回 `TABLE V27 PWM/5-latch schema, timing or provenance mismatch`，但实际提供的 `ECI3808_5Axis_Controller.bas` 静态写出的 330..349 关键字段与主机契约一致。因此必须检查控制器运行时实际 TABLE 值，而不能继续从源码猜测。

## 修改
- `hwTableCommissioningPreflight()` 仍只执行一次 `ZAux_Direct_GetTable`。
- 失败时逐项报告 capacity/magic/recordWords/period/timing/latchMask/latchInput/triggerOutput/REGIST mode。
- 单独检查 feedbackMask/commandMask 是否互斥且并集为 XYZCB 全轴掩码 31。
- 附带同一次读取获得的 TABLE[330..349] 完整快照。
- 没有增加任何 `SetTable`、PWM、运动或传感器触发动作。

## 当前 BASIC 源码按静态分析应发布
`330=96, 337=270916, 338=6, 339=5, 342=0, 343=24, 344=4, 345=31, 346=7, 347=0, 348=14, 349=104`（XYZ ATYPE=1、C/B ATYPE=4 时）。如果现场快照不同，优先调查控制器实际运行任务/版本与 TABLE 覆盖，而不是修改主机期望值去迁就未知状态。
