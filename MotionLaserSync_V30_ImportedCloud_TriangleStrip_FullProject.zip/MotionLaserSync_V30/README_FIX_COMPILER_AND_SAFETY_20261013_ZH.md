# MotionLaserSync Experiment3 源码修复与验证记录（2026-10-13）

## 修改范围

1. `src/core/ZmcController.cpp`：修复 `moveRelImpl()` 将 Lambda 内的 `compensate`、`effective` 在 Lambda 外引用的问题。在外层记录实际速度、加速度、减速度以及位移后计算超时；若没有可用的有效运动参数，则保留原来的最大等待预算。
2. `src/core/ZmcController.cpp`：启用 XYZ 轴位置补偿时，按实际将发出的控制器 DPOS 指令与当前位置的差值估计运动超时，而不只是按请求的 MPOS 增量估计；原有轴限位验证、任务互斥和超时停止行为不变。
3. `src/core/ZmcController.cpp`：断开/重新连接控制器时，除关闭 XYZ 运行时补偿外，还撤销该连接中的补偿表“已安装”授权 (`m_axisCompLoaded=false`)。再次启用前必须重新安装、确认数据。这是故障安全改进，意味着重新连接后的操作流程多一个手动确认步骤。
4. `tests/CMakeLists.txt`：给 `p0_core_mock_tests` 添加 `src/calibration/Small7HeightPlan.cpp`，修复实际控制器模拟编译目标在链接 `motionTimeoutMs(...)` 时的 undefined reference。

## 实际完成的验证（Linux/GCC，可移植路径）

- `SMALL7_EXPERIMENT3_CLI_ONLY=ON`：编译和链接成功，CTest **1/1 通过**。
- `tools/verify_small7_experiment3_contract.py`：**52/52** 静态检查通过。
- `tools/verify_experiment3_hw_preview_multifield_contract.py`：完整执行通过；包括多测量场频率表交叉检查和未验证 ROI 拒绝规则。
- `V21_TESTS_ONLY=ON`：项目的实际 `ZmcController.cpp` 连同模拟 SDK 和 `Small7HeightPlan.cpp` **成功编译、链接**；没有原来显示的变量作用域或超时函数未定义链接错误。
- 从可移植数值、标定、通信/时域算法、H1/H3 合同中选取的 **18 项 CTest 全部通过**。
- `p0_core_mock_tests` 内部共有 112 项断言，**110 项通过，2 项未通过**；未通过项均涉及旧版 V32.13 “重连时根据 HOME_STATUS 清除/降级 Home mask” 的测试预期，而当前 V32.16 代码将控制器 `TABLE[357]` 作为本次上电会话提交标志，并且不会仅因 HOME_STATUS 差异自动改写。此处需要硬件/协议负责人决定测试如何迁移，本修复**没有擅自修改或放宽**控制器回零认证策略。

## 未通过的其他历史测试与项目交付限制

`V21_TESTS_ONLY=ON` 的完整 75 项 CTest 跑完后，记录为 **34 项通过、21 项跳过、20 项失败**（在最终断连授权修复前执行；这一修改使模拟测试内部又多 1 项断言通过，但仍有旧版测试失败）。多数失败与以下问题有关：

- 旧版本协议校验仍断言 V32.9、V32.12、V32.13 的 BASIC 标志；当前项目明确只部署 **H1/H3 V32.16** (`TABLE[354]=321058`)。
- 多个历史测试脚本引用未随本包交付的旧 BASIC 文件，例如 `controller/ECI3808_5Axis_Controller.bas`，但当前唯一正式文件是 `controller/ECI3808_V32_16_H1_H3_ONLY.bas`。**不要复制/改名假装旧固件存在，更不要下载旧固件。**
- 校准回放测试需要 `calibration/runtime_xyz/{X,Y,Z}/*_compensation_candidate.csv` 等原现场标定 CSV，本源码包不包含。这些数据不能以人造测试数据替代现场标定。
- 还有少数历史版本号、界面源文本匹配测试与当前代码变更不同，需要按新协议和新功能更新测试规范后再重跑；本次没有为了“全绿”修改安全判定或造假测试结果。

**Windows GUI 完整构建未在当前环境执行**：缺少可用的 Visual Studio/MSVC、Qt6/VTK/Machine5X FCL Windows 环境及正式厂商 `zauxdll.lib`、`LLT.lib` 等，原包的部分 `third_party/*/lib/x64` 与 `bin/x64` 是零字节占位文件。修复了能复现的 C++ 编译/链接问题，但不能据此宣称整套 Windows GUI 已通过 MSVC 或真实硬件验证。

## Visual Studio 验证流程

1. 完整解压修复版压缩包，**不要把两个源码文件只拷贝到旧版本的其他源码树**。
2. 按工程 `README.md` 配齐 Qt6、VTK、Machine5X/FCL、ZMC 与 LLT 对应 x64 Release SDK，并配置工程 `CMakeSettings.json` 中的路径（请以你的实际安装路径为准）。
3. 使用 VS 的 **x64-Release**，删除旧 CMake 缓存并重新配置，然后执行“全部重新生成”。优先查看“生成”输出窗口，区分真实编译器错误与 IntelliSense 错误。
4. 如仍出现错误，把完整首个编译器错误信息及相关文件/行号反馈，以便定位新发现的 Windows 平台问题。
5. **真实运动前**，进行轴基准/机械限位、XYZ 光栅基准、B/C 绝对位置与伺服使能、硬件急停、采集触发和超时停止功能验收。不得仅凭上述离线测试直接运行设备。

## 可移植验证命令

```bash
cmake -S . -B build-e3 -DSMALL7_EXPERIMENT3_CLI_ONLY=ON
cmake --build build-e3 --parallel
ctest --test-dir build-e3 --output-on-failure
python tools/verify_small7_experiment3_contract.py
python tools/verify_experiment3_hw_preview_multifield_contract.py

cmake -S . -B build-portable -DV21_TESTS_ONLY=ON
cmake --build build-portable --parallel
# 此项会运行包含上述历史失配/缺数据项的全部测试，当前并非全绿：
ctest --test-dir build-portable --output-on-failure
```

## 文件完整性

修复只修改了 `src/core/ZmcController.cpp` 与 `tests/CMakeLists.txt`，另新增本说明文档和修复文件 SHA256 清单。原始归档中的历史完整性报表保留作旧版本追溯，**不得将其视为本修复版的校验和**。同目录 `PATCHED_FILES_SHA256_20261013.tsv` 记录本次修改文件的 SHA256。
