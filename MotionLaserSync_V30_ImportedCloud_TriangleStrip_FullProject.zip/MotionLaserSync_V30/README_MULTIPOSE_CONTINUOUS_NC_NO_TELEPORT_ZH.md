# V29 BC37 多姿态 G代码数字孪生：禁止瞬移与显式非采集转场

版本：2026-10-23 | **仅离线** | 不改变控制器授权与 H1/H3 硬件执行闸门

## 发现的根因

旧版本中每个姿态（P01～P37）有独立 `.nc`：首条 `G00 XYZCB` 仅表示离线未知起点。`makeNcDrivenPlaybackTimeline()` 将这些彼此独立、未接续的 NC 以短暂视觉间隔排列；`sampleNcDrivenPlayback()` 下一姿态立即使用其初始 XYZCB，从而出现五轴机床/传感器瞬间跳跃。这是**数字孪生动画的错误**，不能解释为设备已经走过转场。

同一姿态的不同扫描带不同：其规划本来就有 `M51 / M60 / M61 → G05 S0 [XYZCB F...] → M50 → G05 S1`，非采集转场具有非零时间、离散轴位和轴限位/碰撞检查；多倍速播放也可能让用户误认为跳跃。

## 本版行为

- 新增 `planConnectedExperimentSession()`：使用所有独立姿态的 NC 轨迹及结束/开始点，**额外**为相邻姿态计算激光关闭的五轴线性关节插补，使用规定的转场速度并根据轴最大速度加长时间；每个中间采样都检查 XYZCB 上/下限及传入的 FCL 回调。
- **不自动抬起 Z 轴**，不假设已有历史 `.scan` 位置等于机床实时 MPOS；首个 `G00` 仍未知，始终无实机执行权限。转场路径若被 FCL 否决，不能强制连续播放或导出未验证的全姿态程序。
- 连续会话生成一份独立 `MP_ALL_POSES_CONNECTED_OFFLINE_ONLY_H3.nc`（或当前选中的 H1），同时保留原来逐姿态独立 H1/H3 NC。
- 全姿态 NC 重新走 `simulateMultiPoseNc()` 真正解析 G05/G93/XYZCB/M50/M51/M60/M61/M63，再与包含转场的规划时间轴**逐点一致性比较**，实际播放根据**这份已解析 NC**的时间与中间关节坐标驱动机床/传感器模型。
- 只要姿态间转场校验失败，界面在“显示全部姿态”状态下点击播放或单步会拒绝执行并提示原因；仍可选择 P01 等独立姿态逐个回放。
- 选择“显示全部姿态”后，“查看 NC”“导入 NC 并校验”使用整组连续文件；选择具体 Pxx 时继续使用单姿态文件。任何导入文件的坐标、时间或扫描开关变化都会在重放比较中被拒绝。
- 连续 NC 的 SHA256、姿态时间段与激光关闭转场时段写入导出 manifest。模拟点云继续按姿态使用已验证的单姿态 NC 计算，转场不触发轮廓；同姿态光学点位与连续 NC 中对应扫描段相同。

## 使用说明

1. 导入 STEP 与真实预扫描 `.scan`，完成位姿复核，规划 B/C 37 组。
2. 如果已载入有效 FCL 机床模型且**所有姿态间转场全部验证通过**，日志出现“已生成并逐段核验连续实验 NC”。
3. 在姿态下拉框选择“显示全部姿态”，点击“按已解析 G代码播放五轴+传感器”，以 **1×** 速度观察 P01→P02 的非采集移动；转场时状态栏出现“姿态间连续转场（激光 OFF）”。
4. 选择“显示全部姿态”后点击“查看所选姿态 / 连续会话 NC”，检查 `M51 → M60/M61 → G05 S0 ... XYZCB ... → M50`。
5. 导出 H1/H3 NC。文件夹里保留每姿态单独 NC，如果连续连接已验证还包含 `MP_ALL_POSES_CONNECTED_OFFLINE_ONLY_H*.nc` 及 JSON 的 `continuousNcSession` 字段。
6. 若出现“连续姿态转场未验证”，禁止认为不同 NC 之间可以直接在真实机床移动。查看失败位置、机床/夹具碰撞与轴限位，必要时重新设计转场；不能直接取消 FCL 或放宽限位。

## 仍未完成的设备级验收

- Windows Qt/VTK/MSVC GUI 的实际编译、启动与运行需在原机测试。
- FCL 是**离散采样的模型检查**，不是所有夹具/线缆/传感器外壳和真实加减速的完整认证。转场为关节线性插补，尚不实现通用无碰撞绕障规划。
- 首条 G00 的真实当前位置、姿态和机床联锁并未确认；所有 NC 为 `OfflineOnly: true`。
- H1/H3 的真实硬件周期、延迟、锁存/握手行为未由离线仿真替代。
- 工件 CAD 配准仍属于未完成的精密六自由度验收，B/C 跨姿态测量仍需现场实验支持。

## 源码和测试

主改动：`include/twin/MultiPoseExperiment.h`、`src/twin/MultiPoseExperiment.cpp`、`MultiPosePlayback.*`、`MultiPoseExperimentQtAdapter.*`、`MultiPoseExperimentWidget.*`、`tests/twin/twin_multi_pose_experiment_tests.cpp`。

示例：`examples/multi_pose_experiment/connected_nc/SYNTHETIC_CONNECTED_P01_P03_OFFLINE_ONLY_H3.nc`，**合成测试模型，并非实际零件坐标**。

使用 `-DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF` 编译后，29 个现有注册测试中本次运行 28 项全部通过，长时间 M6 测试未计入。另执行了 3 项 GUI 静态源码检查；没有声称 Windows GUI 编译通过。
