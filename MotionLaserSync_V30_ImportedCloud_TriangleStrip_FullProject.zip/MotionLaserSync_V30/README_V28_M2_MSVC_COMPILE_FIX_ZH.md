# V28 M2 MSVC 编译修复说明（2026-10-14）

## 本次修复的错误

用户在 Visual Studio 2022 x64-Release 中报告：
- `ScanReplayAdapter.cpp` 第 72 行 C2466、C2086；
- 后续第 74～83 行 C2679、C2672、C2665 等共 12 个连锁错误。

根本原因是旧代码：

```cpp
const QVector3D xyz(float(q[0]),float(q[1]),float(q[2]));
```

被 MSVC 按“函数声明”而不是 `QVector3D` 对象构造来解析（Most Vexing Parse）。

已修复为 C++17 安全写法：

```cpp
const QVector3D xyz{
    static_cast<float>(q[0]),
    static_cast<float>(q[1]),
    static_cast<float>(q[2])
};
```

后续 `setX/setY/setZ`、`std::min/std::max` 和 `append` 的报错都是由此产生的连锁错误，不应通过额外改动 STL、Qt 或 Open CASCADE 来“修复”。

## 兼容性与验证

- 以 `MotionLaserSync_V28_PROJECT_M0M1_FIXED_M2.zip` 为基线，只修改 `src/twin/ScanReplayAdapter.cpp` 的这一处初始化语法，并添加本说明。
- `CMakeSettings.json` 中的 `TWIN_OCCT_PREFIX` 仍为 `D:/dev/vcpkg/installed/x64-windows-release`。
- 原 M0/M1 主视图同步、M2 `.scan` 回放、完整 PLY 导出源码都予以保留。
- `DIGITAL_TWIN_CLI_ONLY=ON` / `TWIN_ENABLE_OCCT=OFF` 离线核心 CMake 构建成功，`ctest` 4/4 通过。
- **未在此环境完成 Qt/VTK/Windows/MSVC 完整 GUI 构建**；请在本机 VS2022 x64-Release 下验证剩余 Windows 专用接口。

## VS2022 验证顺序

1. 关闭旧的运行程序，解压本压缩包到新目录；工程根目录仍为 `MotionLaserSync_V28_PROJECT`。
2. Visual Studio 2022 → 文件 → 打开 → 文件夹，选择根目录。
3. 等待 CMake 配置完成。必要时选择“项目 → 删除缓存并重新配置”。
4. 使用 x64-Release 构建 **GUI 主程序目标**（注意不要只构建 `exposure_analysis_cli.exe`）。
5. 如果编译成功，在“路径规划”点击“数字孪生 / STEP 工件放置”，核验主视图工件同步；然后导入实际 `.scan` 回放。
6. 如果还有编译错误，复制 **第一条** 编译器错误的完整文本与对应的文件、行号。不要仅根据后续连锁错误修改其他模块。

Open CASCADE 配置与这次 C++ 初始化语法错误无关。
