# V27.1 Windows/MSVC build fix + compact ECI3808 BASIC

## 1. Visual Studio `Arc` compilation failure

On Windows, the Win32/GDI headers expose a global function named `Arc`.  The
G-code executor also used `using namespace mls::runtime;`, where the project has
its own `mls::runtime::Arc` type.  GCC/Linux accepted the original source, but
MSVC name lookup reported `C2872: 'Arc': ambiguous symbol`.  The subsequent
`arc undeclared`, `appendArc used before initialization`, and parser errors were
cascades from those two declarations.

The two declarations in `src/gcode/GCodeExecutor.cpp` are now explicitly
qualified:

```cpp
mls::runtime::Arc arc;
```

and their plane enumerators are also explicitly qualified with
`mls::runtime::Plane::...`.

No G-code/RTCP geometry algorithm was changed by this fix.

## 2. Controller BASIC in this package

The packaged controller file is the compact ECI3808 version that avoids the
old firmware's observed constraints:

- no parameterized custom `SUB`;
- no custom identifier longer than 18 characters;
- no `ONTIMER` sampling;
- XYZ remain `ATYPE=1` for commissioning;
- C/B remain `ATYPE=4`;
- five continuous REGIST FIFOs on IN0/R0;
- OUT14/PWM0 probe/continuous trigger;
- Buffer A raw latch FIFOs plus Buffer B host ring;
- V27 host TABLE ABI remains `330..349`, data starts at 370, capacity 96,
  record `[ordinal,X,Y,Z,C,B]`, magic 270909.

The host protocol therefore remains compatible with the V27 C++ acquisition
code even though the controller source itself is the compact revision.

## 3. Verification in this package

Portable/mock Linux verification after this fix:

- CMake test-only build succeeds;
- `ctest`: 21/21 passed;
- V27 source contract: 23/23 passed;
- source contract explicitly checks that the two MSVC-sensitive `Arc`
  declarations are namespace-qualified.

This cannot replace an actual MSVC/Qt/vendor-SDK build on Windows, but it
removes the exact Windows name collision shown by Visual Studio.
