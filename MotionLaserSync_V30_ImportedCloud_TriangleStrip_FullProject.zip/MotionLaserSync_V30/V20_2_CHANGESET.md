# V20.2 变更摘要：Physical 17 / Data Rank 14

本版本是在用户提供的 V20.1 工程上针对“五轴机床 + 机床基线激光传感器单球标定”做的数学复核与实现修订。

## 核心修订

1. 保留完整 17 个物理参数：11 个机床几何参数 + 6DoF 手眼。
2. 标定球心在机床坐标系中作为未知 3D nuisance variable，不向求解器提供真值。
3. 明确结构可辨识性：full `[physical17, sphereCenter3]` 为 rank 17/20；消去球心后 physical 为 rank 14/17。
4. 三个不可辨识方向是严格的全局平移 gauge，混合手眼平移、B/C 轴线位置和未知球心。
5. 手眼平移 Tx/Ty/Tz 作为显式 3D gauge/external anchor；结果仍保存完整 `^E T_S`，但不把这 3 项声称为单球数据辨识值。
6. 联合标定残差固定为 `||p_M-c_M||-R`。球的 `+Y/-Y` 只用于单条 XZ 轮廓恢复三维中心时的初始化/找球，不进入联合标定方程。
7. 初始化时自动尝试 `+Y/-Y` 两支并比较全数据残差。
8. 增加 `handEyeTransform()` / `sensorToMachineTransform()` / Qt adapter，供后续运动学规划直接复用同一套坐标约定。

## 仿真验证

仿真严格使用：带误差五轴模型 -> 给定完整手眼 -> 传感器 XZ 面平行扫描线 -> 变换到机床系 -> 与固定球求交 -> 逆变换回传感器二维 `(x,z)` -> 标定。

默认 42 姿态 x 25 扫描线 = 1050 点：

- 无噪声 RMS: `7.12e-14 mm` (Python)，项目 C++ 独立复算 `1.64e-10 mm`；
- `x sigma=1 um, z sigma=3 um` 时 RMS: `0.00231036 mm`；
- physical rank: `14/17`；
- full data-state rank: `17/20`；
- sensor->machine->sensor 最大回代误差: `2.84e-14 mm`；
- 3D gauge 平移后的残差变化: `4.26e-14 mm`。

详见 `docs/V20_2_Physical17_Rank14_Review.md` 和 `simulation/v20_2_physical17_rank14/`。

## 仍未自动改动的实机同步缺口

V20.1 的在线点云同步路径仍只使用 XYZ，且控制器 TABLE/P5 当前没有为每个 profile 锁存同步 B/C。因此，本版本没有把新的 17 参数变换强行接入实时五轴点云；在没有可靠的逐帧 B/C 同步姿态前，这样做反而会产生错误点云。下一步应先扩展硬件同步协议，再接入 `SingleSphere17Model::sensorToMachineTransform()`。

## 回归说明

- `v20_2_single_sphere17`: PASS
- legacy `v20_single_sphere14`: PASS
- `v20_gui_source_contract`: PASS
- `v19_source_contract`: 12/13；唯一 FIX1 manifest/package 项在用户原始、未修改 V20.1 ZIP 上同样失败，确认不是本次修改引入。

完整 Qt/VTK Windows GUI 由于当前 Linux 容器没有 Qt6/VTK/厂商 SDK，未在这里进行最终链接编译；可移植数值核心、CLI、回归测试和源代码接线检查已完成。
