# MotionLaserSync V27.6.38 — Stage-2 速度、Y 门禁和手/自动采集状态机修复

本版本基于 V27.6.37，并保留 V27.6.36 的 XYZ 补偿 / MachineSafety 加固。此次修改针对实机日志暴露的四类问题。

## 1. 标定速度不再要求修改全局轴参数

Stage-2 页面新增两个独立的本地速度倍率：

- XYZ 标定运动倍率（默认 0.15 × 各轴已配置参数）
- B/C 标定运动倍率（默认 0.15 × 各轴已配置参数）

两者只对本次运动学标定的独立五轴定位生效。MainWindow 复制当前 AxisParams 后在内存中缩放 SPEED/ACCEL/DECEL，再用同一份有效参数同时进行 MachineSafety 独立轴时间轨迹预测和真实下发；不会写 UNITS 或软限位，也不会撤销 XYZ DATUM / B/C absolute-ready。

同时修复全局参数页的过度失效逻辑：

- 仅 SPEED/ACCEL/DECEL/LSPEED/SRAMP/CREEP 改变时，XYZ DATUM 保持有效；
- 只有 XYZ UNITS 真正改变时才撤销对应 XYZ MPOS reference；
- B/C 只有 UNITS 或机械软限位坐标框架改变时才撤销 absolute-ready/servo；
- speed-only 写入不会重复 SetUnits。

注意：如果修改了 UNITS、机械坐标软限位等真正改变坐标语义的参数，重新建立基准仍然是必须的。

## 2. 修复自动采集中错误的 Y 球心门禁

单条激光轮廓位于传感器 XZ 平面。由球截面圆半径可以得到球心到该平面的距离 `|Y_S|`，但单帧轮廓不能判断 Y 的正负号。源码中的 `fitSphereCenterInSensor(..., +1, ...)` 因此给出的是 `+|Y_S|` 分支；该符号不用于最终球面点联合标定方程。

V27.6.37 的自动采集窗口却直接做：

`abs(measuredY - signedTargetY)`

当 D-optimal 目标位于负 Y_S 支路时，即使实际圆形轮廓非常好，也会得到约 `2*|Y_S|` 的伪差。因此实机日志中出现 X/Z 只有 0.0~0.5 mm，而所谓 `|dY|` 却达到 5~15 mm 的大量丢弃。

V27.6.38 改为只检查可观测量：

`abs(abs(measuredY) - abs(targetY))`

日志也改为 `|d|Y_S||`，明确说明“单帧轮廓不观测 Y 符号”。X/Z 窗口和正式轮廓质量门限保持原逻辑。

## 3. 手动移动 / 手动采集 / 自动采集状态机整理

- 手动“移动到选中计划姿态”完成并完成 300 ms 后的新轮廓拟合后，强制重新计算按钮 readiness；“采集当前姿态”不再因为运动期间曾被禁用而保持灰色。
- 自动采集遇到某姿态真实运动失败时，该姿态标记为“移动失败”，本轮不再自动重试；继续下一个待处理姿态。
- `selectNextPendingPlanRow()` 明确排除“移动失败”和“安全门禁失败”，避免失败姿态被循环选回。
- 自动流程结束后，失败/跳过的行仍保留，可人工选中、重新移动、确认轮廓后手动采集。

## 4. 48 个姿态不是求解的硬性数量

当前最终 Physical17 求解的硬下限仍为：

- 至少 8 个有差异的 Stage-2 训练姿态；
- 至少 8 个有效 observation/profile；
- 至少 80 个有效球面点；
- 代表优化集至少 8 个 observation。

但“达到 8 个”只表示允许启动求解，不代表结果合格。最终仍需同时满足：

- physical target rank >= expectedTargetRank（当前正常为至少 14/17）；
- full-state rank >= expectedFullStateRank（当前正常为至少 17/20）；
- 全量训练残差 RMS <= 0.050 mm；
- condition number <= 1e9；
- solver success。

所以 48 是用于提高姿态覆盖和可观测性的计划数量，不是“必须 48/48 全部成功”。少量姿态失败可以正常标定；是否足够应以界面“阶段2快速可观测性”的 rank/condition 和最终求解质量为准。

## 5. 本次实机日志对应的问题

该次 48 姿态运行中，按日志统计：27 个姿态被接受；20 个姿态被旧的球心窗口门禁丢弃；1 个姿态（#18）因 Y 轴实际控制器目标 -72.249828 mm 超过软限位 [-72, 96] mm 而真实移动失败。之后 #18 被旧状态机连续重试 68 次，直到人工停止。

V27.6.38 修复了后两类软件问题：Y 门禁改为 |Y_S|，失败姿态本轮只尝试一次。#18 的软限位本身是真实安全约束，不会绕过；它应被一次性标记失败，其他姿态继续执行，随后可调整计划范围/机械软限位配置后人工重试或重新规划。

## 6. 验证

- `p0_core_mock_tests`: 85/85 通过；新增检查 speed-only 写参数不撤销 XYZ DATUM / B/C absolute-ready，且 UNITS 改变仍正确失效。
- `v27635_axis_compensation_tests`: 25/25 通过。
- `verify_v27638_stage2_workflow_fix.py`: 13/13 通过。
- CTest 定向回归：3/3 通过。

当前 Linux 环境没有完整 Windows Qt6/VTK/FCL + ECI3808 实机链路，因此完整 GUI 编译和设备行为仍需在你的 Windows/机台环境复验。
