# MotionLaserSync V27.6.54 + ECI3808 V32.12

## 本次修正的范围

基于上位机 V27.6.53 + ECI BASIC V32.11，保持 XYZCB 五轴 Home bit、五轴 REGIST(104)、单 OP14 触发、Probe、ColdPrime、Pump 和双缓冲不变；重构运行时频率/实际停止握手。尚未引入 RS422 CMM 模式。

已恢复原始 V27.6.51 完整归档中 V27.6.53 漏包的校准数据、模型、厂商库、历史日志及 VS 工作区缓存；CMakeLists.txt 与原始包逐字节一致。仅测试的 CMakeLists 和相关上位机源码有修改。

## 必须配套的版本

- **上位机 V27.6.54 与 BASIC V32.12 必须一起更新**：`controller/ECI3808_5Axis_Controller.bas` 为新版正式部署入口，与 `controller/ECI3808_V32_12_PWM_HANDSHAKE_FIVE_AXIS_HOME.bas` 内容一致。
- `TABLE[354] = 321054` 为硬版本隔离；V32.11 (`321053`) 不允许匹配新版上位机。
- 历史 V32.9/V32.10/V32.11 `.bas` 文件留在压缩包里只为溯源，**不要下载到设备**。
- 更换 BASIC 将重新初始化 `TABLE[357]=0`，所以 **XYZCB 必须重新回零**。不要在正式工作、伺服运动中热更新。

## TABLE 协议

| 绝对索引 | 读写方 | 说明 |
|---:|---|---|
| 334 | PC 写 / BASIC 读 | EN：0 停止；1 正式运行；2 one-shot Probe；3 ColdPrime |
| 333 | BASIC | 原来的采集故障码（不和频率配置错误混用） |
| 354 | BASIC | 能力标志 321054 |
| 355 | PC | 请求 PWM 频率整数 Hz |
| 356 | BASIC | 已应用 Hz，只读状态镜像 |
| 357 | PC 维护/BASIC 启动清零 | Home bit：X=1,Y=2,Z=4,C=8,B=16；31=五轴完成 |
| 358 | BASIC | 实际状态：0 IdleReady；1 Running；2 Probe；3 ColdPrime；4 Stopping；5 ConfigError；6 Fault |
| 359 | PC | 新配置请求序号，必须 **最后写入**，相当于提交标志 |
| 360 | BASIC | 最后成功应用配置的 ACK 序号 |
| 361 | BASIC | 配置错误：0 无；10 频率非法；12 请求序号非法 |

`TABLE[356]` 和 `TABLE[360]` 是控制器状态镜像，不允许上位机或 ZDevelop 人为修改。BASIC 使用内部 `gf` 和 `ga` 作为实际运行值及最后应用序号。

## 安全频率配置

1. 先写 EN=0，等待实际状态 TABLE[358]=0，并确认采集故障 TABLE[333]=0，configError=0。
2. 将新频率写到 TABLE[355]。
3. 将新的序号写到 TABLE[359]，最后提交请求。
4. BASIC 只有在完成 StopPwmSync(old gf)、raw FIFO Pump 且实际空闲时才会接受新配置，执行 PWM_FREQ(0)=newHz。
5. BASIC 依次更新 gf、TABLE[356]、ACK TABLE[360]；PC 同时确认 355=356=期望频率，359=360=本次序号，358=IdleReady，361=0。
6. Host 还会检查当前 measuring field 和曝光周期允许该频率，随后才能启动 ColdPrime、正式 Session、Probe 和 Run。

`TABLE[334]=0` **只是停止命令，不是停止完成**。收尾时 Sensor profile ingress、BASIC Pump 和最终状态确认都必须完成。

## 出错行为

- 运行时被外部改写频率/序号，BASIC 按原 Fault 途径停止采样，并设置采集故障码 11。不能继续将这一段测量当有效数据。
- 空闲时频率非法：TABLE[361]=10，TABLE[358]=5，PWM 保持关闭；不会不断调用 Bad/RAPIDSTOP。由新、合法、递增配置请求清除配置错误。
- ACK 超时：PC 拒绝采集，不会把写入 TABLE[355] 当成已应用。若请求序号悬而未决，应诊断链路/BASIC，而不是强行置 EN=1。
- 原始采集 Fault/急停继续遵守原有故障处理，禁止自动解除采集故障继续测量。

## 性能与实机验证

- 传感器当前 measuring field 最大 Profile Hz、曝光/空闲周期仍按原 V27.6.53 上位机限制。
- **25..2000 Hz 是协议允许范围，不是这套 ECI-Pump-Ethernet 数据链已通过实测的上限。** 请分频率验证 2% duty 实际脉宽、REGIST 丢沿、Buffer-B 占用、Ethernet/Qt 数据吞吐及 Profile-Pose 严格 1:1。建议先在现有 200 Hz 配置验证，再逐步提高，不要直接上 2000 Hz。
- 这份环境没有 Windows Qt/VTK/厂商 SDK 完整 GUI 链接器和 ECI3808 设备，也没有 ZDevelop BASIC 编译器，所以 **Windows Release 全量编译 / ZBasic 编译 / 实机 PWM、Home、紧停需在现场完成**。

## 现场部署顺序（断使能／无人处于危险区）

1. 备份原工作目录和 ECI 中的 V32.11，校验新 ZIP 中厂商 DLL/LIB、`calibration/runtime_xyz` 与 models 路径完备。
2. 新建独立构建目录，使用原 Windows x64 Qt/VTK SDK 编译 V27.6.54。
3. 断开所有运动任务、关闭伺服使能并确保机械安全，使用 ZDevelop 编译 V32.12，再下载运行 BASIC。
4. 注意 BASIC 重启会清 `TABLE[357]`：按既有流程重新建立 XYZCB 五轴 Home。
5. 在无扫描运动条件下配置 200 Hz，观察 TABLE 354..361；检查 359/360 相同、358=0、356=200；确认 stop 后 358=0。
6. 用示波器确认 OP14 对 scanCONTROL 输入和 IN0 的边沿与 2% 有效脉宽，执行 ColdPrime/Probe/Run/Stop，核对全部 Profile/Pose 计数与采样数据。
7. 模拟非法配置、停止中改频、Probe 阶段改频、上位机重启保留 Home、ECI 重启清 Home。任何异常都应 fail-closed。

## 代码/测试结果

`cmake -S <源码> -B <单独build> -DV21_TESTS_ONLY=ON -DCMAKE_BUILD_TYPE=Release`

针对修改后的真实 `ZmcController.cpp`、`SyncManager.cpp` 和 Mock SDK 构建成功；核心 Mock 97/97 通过；精选 8 个 CTest 通过。测试模拟的是通信协议的请求/ACK 和状态，不是 ECI ZBasic 的真正实时执行或光学曝光。
