# MotionLaserSync V29 — G代码实机准入流程重构（源码修改版）

## 交付状态

本次交付是基于用户提供的 `MotionLaserSync_V29_Q.zip` 做出的**完整工程源码修改**，不是只读审查报告，也不是经过现场签收的实机发布版。修改了 15 个已有源码/测试文件，增加 3 个源码/测试文件及本说明。工程保留所有原有代码和项目配置，可按原 Windows / Qt6 / MSVC 构建方法构建。此环境没有完整 Windows 控制器 SDK、Qt6/MSVC 和真实五轴设备，**未进行 GUI 编译、H1/H3 真实触发或机床运动测试，不提供已验证 EXE**。

## 主要修改

### A. 按 NC 声明开展真实硬件同步试采，而不是只比较界面参数

- `src/widgets/GCodeWidget.cpp`：增加“**按NC硬件同步试采（有触发/无轴运动）**”“**停止试采**”按钮，启动前明确告知试采会真实 Arm PWM/传感器触发；与“**实机状态诊断（只读）**”区分。
- `src/app/MainWindow.cpp`：从解析后的 `GCodeProgram` 读取 `SyncMode: Hardware`、H1/H3、`HardwareTriggerHz` 和 H3 R1 边沿；调用已实现的 `SyncManager` 硬件启动、停止及 `analyzeHardwareSyncData()`，计划试采约 3 秒。其间**不执行任何 G00/G05**；用户可主动提前停止（标记为未完成，不计通过）。检查控制器五轴真实回零、静止、故障、TABLE 授权和激光传感器连接，不抢占其他运动/采集任务。
- `include/gcode/HardwareNcProbeLogic.h`：新增与 UI 无关、可用普通 C++ 测试的“硬件事实证据”判据。停止后要求确实收到轮廓与五轴锁存姿态、发布触发计数、配对记录；拒绝丢帧、重复、乱序、溢出、TABLE 读取错误、传感器触发模式读回不一致，以及实际传感器时间戳频率和 NC 要求严重不匹配（允许 10% 偏差；至少两个稳定周期）。不把“没有报错但采集到 0 帧”当作通过。
- 报告写入程序用户数据目录 `gcode_preflight/hardware_nc_probe_*.json`，其中 `runAuthorized: false`。当前版本的真实试采**不自动解锁执行按钮或生成运行许可证**。
- 重要限制：若 H1 必须外部 Probe、H3 必须实际 CMM 连续采集窗口，固定五轴不运动的 3 秒试采可能没有触发数据。这种情况应报告**证据不足**，而不是虚报硬件异常，也不能当成功。要验证真实频率，必须依照现场电气合同在安全环境下提供有效触发。

### B. 第一条 G00 是起点定位动作，但不得跳过运动安全

- `src/gcode/GCodeExecutor.cpp`：“只读诊断”不要求实际 MPOS 已经等于首个 G00 起点；首个 G00 作为真正需要执行的定位动作。
- 首段动作进入运动执行器之前，重新读取控制器 MPOS，按照当前五轴模型检查 `MPOS -> G00目标` 的完整 FCL 路径；**即使起点差值小于 0.05 mm，也不得跳过路径校验**。启用独立的 `SiteEntryMoveVerifier`，复用工程已有 `checkSphereStudyTransitionSafety()` 进行 FCL/限位评估。
- 硬件采集 NC 拒绝首 G00 前的 G91/G92，从源头避免“检查的绝对目标 ≠ 实际派发的相对/偏移目标”问题。未将“允许起点定位”理解为“任何起点运动都可以直接执行”。

### C. 完整 NC 的 FCL、CAD 光学覆盖验证，不信任 NC 注释

- G代码界面新增“**整条NC FCL+光学复核**”。需要多姿态窗口保留**对应的已加载 STEP/SCAN、正确工件放置、规划报告**，并确保当前导入的 NC 原文与本次规划生成的对应 H1/H3 每姿态或连续 NC 完全一致。无可信场景则返回阻断，不从 `SimulationVerified`、`RegistrationVerified` 等文本判断合格。
- `MainWindow::onGCodeFullNcGeometryAuditRequested()` 使用 `simulateMultiPoseNc` 逐段解释完整 NC，并对**每段**调用 `MachineSafetyModel::checkTransition` 做轨迹 FCL，逐个 NC 触发点使用 `VirtualLaser2950` 重算虚拟光学轮廓，再按照扫描组评价工件命中、ROI/边界覆盖。任何组不满足门槛都显示失败，不会自动静默跳过。
- 这是**离线数学/当前 CAD 模型检验**，尚不能证明未知夹具、实物工件公差、机床安全门及光学现场质量。不是独立的硬件运行授权。

### D. 使用实际应用的标定数值，不强制 NC 注释哈希一致

- `GCodeExecutor.cpp`：读取正在生效的 `SyncManager::currentKinematicModel()` 的 17 个实际数值，检查可读取、数值有限，**不再因为它们与 NC 的注释 `Physical17SHA256` 不同而直接阻断**。自动恢复的 `active_single_sphere17.json` 只要真正加载并应用，就可作为模型来源。
- 整条 NC 光学复核还要求当前生效的 17 参数数值与对应 STEP/SCAN 规划使用的一致；若发生变化必须基于当前参数**重新规划**，而不是靠取消检查略过几何失配。
- **保留磁盘 NC 的 SHA-256 用于程序文件版本绑定**（防止检查的是 A、执行的是被换过的 B）；它与**标定模型哈希**完全不是一回事，不应删除文件版本完整性检查。

### E. 修复 G 代码运动参数的来源判断

- `include/gcode/GCodeTypes.h` 和 `src/gcode/GCodeParser.cpp` 为 `Feed/Rapid/Accel/Decel` 增加“NC 是否显式声明”的元数据。
- `GCodeWidget.cpp` 不再用“当前数值是否等于 GUI 写死的默认值”来猜测 NC 有没有设置参数；尤其硬件采集 NC 不允许用参数页默认值无提示覆盖实际规划运动参数。
- 保留 GCodeParser/G05/G93/M50/M51 的原始协议；在多姿态 NC 导出前及写盘回读后用同一个 GCodeParser 交叉验证。

## 使用顺序

1. 在原软件启动后确认设备连接、五轴回零、当前 17 参数恢复确实已**应用**，并加载真实 STEP、SCAN 和配准数据完成多姿态规划。
2. 从多姿态模块导出新的 H1/H3 NC；在 G 代码模块“加载文件”，点击“解析验证”“多姿态NC离线逐段验证”。
3. 点击“整条NC FCL+光学复核”。请保持本次多姿态规划窗口打开，原文一致，否则报告中说明缺少对应的几何证据。先审查机器人/机床行程、CAD 夹具和光学结果。
4. 设备联机、保护设施就绪时，点击“实机状态诊断（只读）”查看控制器 TABLE/MPOS/回零状态。此操作不触发 PWM。
5. 在具备硬件激光和外部触发防护条件下，点击“按NC硬件同步试采”，确认警告，观察真实 Arm→约 3 秒→Stop→硬件数据分析；核对原控制页详细报告和 JSON，确认真实触发和传感器频率，必要时从控制页人工调查失败项。
6. **上述步骤不自动授权真实五轴 NC**：数字孪生导出的 `OfflineOnly: true` 保留硬禁止。要现场自动执行，仍需要由设备厂/现场负责人实现和签署 `SiteHardwareNcVerifier`，包含夹具、安全回路、实物轨迹、传感器和具体机台工艺验收。严禁仅为“点击开始”而删除 `OfflineOnly` 或把验证器改为始终成功。

## 测试及已知限制

以下测试已在本环境运行通过：

```text
python tests/gcode/test_nc_probe_fcl_new_flow.py
python tests/gcode/test_gcode_settings_live_entry_contract.py
python tests/gcode/test_imported_model_provenance_contract.py
python tests/gcode/test_real_run_preflight_audit.py
python tests/test_live_nc_deployment_contract.py
g++ -std=c++17 -Wall -Wextra -Werror -Iinclude tests/gcode/test_hardware_nc_probe_policy.cpp -o policy_test
./policy_test
```

它们是**源码合同/纯 C++ 逻辑回归检查**，不等于 Qt GUI 编译通过、FCL 真实模型算例通过、传感器外部试采验证通过或现场安全验收。`Qt6Core` 头文件/构建工具链在此环境不可用。完整 NC 的 FCL 和虚拟光学逐段全量回放可能很慢；需要合理控制规划段数与触发点数，实机运行仍须现场独立审核。Qt UI 新增按钮可能需要现场调整窗口宽度/换行布局。

## 主要修改文件

```text
include/app/MainWindow.h
src/app/MainWindow.cpp
include/gcode/GCodeExecutor.h
src/gcode/GCodeExecutor.cpp
include/gcode/GCodeTypes.h
src/gcode/GCodeParser.cpp
include/gcode/HardwareNcProbeLogic.h [NEW]
include/widgets/GCodeWidget.h
src/widgets/GCodeWidget.cpp
include/widgets/MultiPoseExperimentWidget.h
src/widgets/MultiPoseExperimentWidget.cpp
include/widgets/PathPlanningWidget.h
src/widgets/PathPlanningWidget.cpp
src/twin/MultiPoseExperimentQtAdapter.cpp
tests/gcode/test_hardware_nc_probe_policy.cpp [NEW]
tests/gcode/test_nc_probe_fcl_new_flow.py [NEW]
tests/gcode/test_gcode_settings_live_entry_contract.py
tests/gcode/test_imported_model_provenance_contract.py
```

## 重要区分

“硬件试采结果良好”只证明当前 **H1/H3、频率、传感器与锁存链路** 在该试采窗口表现正常；“全 NC 数字孪生 FCL/光学通过”只证明当前 CAD 和假设的几何模型通过。两者均不足以证明真实运行时的安全门、夹具、工件摆放和精确控制器路径全部被认证。现场实机放行不能由单项自动采集成功替代。
