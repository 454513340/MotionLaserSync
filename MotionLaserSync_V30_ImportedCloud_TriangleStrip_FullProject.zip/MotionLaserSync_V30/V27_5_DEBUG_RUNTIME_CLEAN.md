# V27.5 Debug runtime clean

This revision is based on V27.3, because V27.3 RelWithDebInfo runs correctly.

## Why RelWithDebInfo shows 42 steps

MotionLaserSync itself has 39 normal `.cpp` translation units:
- app/core/runtime/gcode/calibration/algorithm/widget/util/vendor sources

CMake/Ninja then adds:
- 1 Automatic MOC step
- 1 generated `mocs_compilation.cpp.obj`
- 1 link step

That produces the observed 42-step build. It is the complete GUI executable,
not a partial build.

The extra Debug build steps came from auxiliary CLI targets and generated
autogen work. V27.5 marks the two calibration CLI executables
`EXCLUDE_FROM_ALL`, so normal Visual Studio Build All no longer builds those
tools unless explicitly selected.

## Why only Debug aborts

The observed dialog is a Qt Debug `Q_ASSERT` in Windows bitmap/pixmap code:
`bm.format() == QImage::Format_Mono`.

Qt assertions are active in Debug and normally compiled out when
`QT_NO_DEBUG` is defined, which explains why RelWithDebInfo can continue.

V27.5 does not suppress the assertion. Instead it removes two plausible
startup triggers:
1. installs the VTK-required `QSurfaceFormat` before QApplication;
2. forces QVTK to a standard Arrow cursor and disables
   `vtkOrientationMarkerWidget` interactivity before enabling it.

If the same assertion remains, press Retry and capture the Visual Studio
Call Stack above `qpixmap_win.cpp`. That stack is required to identify the
actual caller; Release success alone does not prove the underlying Debug
invariant is fixed.
