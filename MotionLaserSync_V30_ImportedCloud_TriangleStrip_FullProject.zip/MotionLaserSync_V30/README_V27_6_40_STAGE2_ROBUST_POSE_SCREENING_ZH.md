# V27.6.40：Stage2 鲁棒姿态筛选 + 重新自举 + Physical17 Rank-14

## 目的

V27.6.39 已经解决了“阶段2直接从全零17参数开始”的问题：当前 Stage2 训练数据先在名义机床模型下求 9 状态 hand-eye 6DoF + 固定球心，再将 hand-eye 平移作为单球 rank-14 模型的三维 translation gauge anchor。

V27.6.40 进一步处理一个实际采集问题：同一批 Stage2 数据中，少数 XYZBC 姿态可能因为球弧质量、局部遮挡、同步误差、振动或其它采集异常而产生明显更大的球面残差。如果把这些姿态与正常姿态等价地送入最终求解，会显著抬高全局 RMS，并可能拉偏 hand-eye 自举和几何参数。

因此本版增加“**完整姿态组级别的鲁棒筛选**”。注意：程序不会物理删除原始 CSV/采集数据，只是在当前训练求解中排除被判为异常的姿态组，所有剔除姿态都会记录到日志和结果 JSON。

## 新的阶段2流程

```text
全部 Stage2 训练姿态
        │
        ▼
9-state nominal-machine bootstrap
(hand-eye 6DoF + sphere center)
        │
        ▼
初步 Physical17 / Rank-14
        │
        ▼
按完整 XYZBC 姿态统计残差
RMS / MAE / |residual| P95 / max
        │
        ▼
median + MAD 自适应筛选
        │
        ├─ 无明显异常 ───────────────┐
        │                           │
        └─ 有异常姿态               │
              │                     │
              ▼                     │
       排除异常姿态组               │
       （原始数据仍保留）           │
              │                     │
              ▼                     │
       用保留姿态重新做9-state自举  │
              │                     │
              ▼                     │
       重新求 Physical17 / Rank-14  │
              │                     │
       最多进行2轮姿态筛选           │
              └──────────────┬──────┘
                             ▼
                  保留姿态的全量点精修
                             │
                             ▼
                       独立 hold-out 验证
```

## 姿态分组

所有 profile 先按 XYZBC 进行姿态分组。当前容差与原 Stage2 姿态计数一致：

- X/Y/Z：±0.03 mm
- B/C：±0.03°

一个姿态组中的所有 profiles 都作为一个整体评价。筛选的最小单位是“姿态”，不是单点，也不是单条 profile。

## 每个姿态的误差统计

在当前冻结的 Physical17 模型和当前球心下，对每一个原始球面点计算：

```text
r = || p_machine - center_machine || - sphere_radius
```

每个姿态得到：

- `RMS`
- `MAE`
- `|residual| P95`
- `max |residual|`

异常检测主要使用 RMS 和 P95。

## 鲁棒阈值

首先在全部姿态上计算 RMS / P95 的 median 和 MAD：

```text
sigma_robust = max(0.003 mm, 1.4826 * MAD)
```

默认 RMS 门限：

```text
max(
    0.080 mm,
    1.45 * median_RMS,
    median_RMS + 3.5 * sigma_robust_RMS
)
```

默认 P95 门限：

```text
max(
    0.150 mm,
    1.45 * median_P95,
    median_P95 + 3.5 * sigma_robust_P95
)
```

P95 只作为辅助判据；为了防止单个坏点导致整组姿态被删除，P95 超限时还要求该姿态 RMS 本身也明显高于正常中位水平。

这意味着：如果整个数据集都存在系统性模型误差，程序不会因为整体 RMS 较高就机械地删除大量姿态；只有相对其它姿态显著异常的组才会成为候选。

## 防止“把有信息的极限姿态全删掉”

硬剔除带有以下保护：

1. 一轮最多剔除总姿态数的 25%。
2. 至少保留 12 个独立姿态（底层最低仍不允许低于 8）。
3. 如果原始数据具有 B 正/负覆盖，筛选后仍至少保留 2 个正 B 和 2 个负 B 姿态。
4. C 轴同样保护正/负覆盖。
5. B、C 的保留角度跨度不得低于原始跨度的 65%。
6. 筛选后重新做 9-state bootstrap；如果 rank/condition 不合格，本轮筛选自动回滚。
7. 筛选后重新做代表集 Physical17；如果 physical rank < 14 或 full-state rank < 17，本轮筛选自动回滚。

因此算法不是简单地“按 RMS 排序后删最差若干组”，而是在误差质量和可观测性之间做约束筛选。

## 为什么筛选后必须重新求 hand-eye

V27.6.40 不仅从最终 Physical17 中删除坏姿态，还会在每次筛选成功后重新求：

```text
hand-eye Rx/Ry/Rz
hand-eye Tx/Ty/Tz
sphere center
```

也就是说，被异常姿态污染的 hand-eye translation 不会继续作为后续的 gauge anchor。新的保留姿态集会重新产生 Tx/Ty/Tz，再固定这组三维平移进行 rank-14 Physical17 求解。

## 收敛判据调整

V27.6.39 实机日志中出现了 cost 已经进入明显平台，但 `1e-12` 相对 cost 阈值仍判定“stationarity 未确认”的情况。V27.6.40 的 GUI Stage2 工作流将数值停止阈值调整为：

```text
convergenceStep     >= 1e-7
convergenceCost     >= 1e-8
convergenceGradient >= 1e-7
```

这不会放宽最终 RMS / rank / condition 的质量门禁，只避免有限差分 Jacobian + Huber IRLS 在数值平台上无意义地耗尽迭代预算。

## 结果 JSON

新增：

```json
"pose_screening": {
  "rounds_applied": 1,
  "input_pose_count": 47,
  "retained_pose_count": 43,
  "rejected_pose_count": 4,
  "last_rms_threshold_mm": 0.09,
  "last_p95_threshold_mm": 0.16,
  "rejected_poses": [
    {
      "x_mm": 0,
      "y_mm": 0,
      "z_mm": 0,
      "c_deg": 30,
      "b_deg": -20,
      "profile_count": 10,
      "point_count": 2500,
      "rms_mm": 0.14,
      "p95_abs_mm": 0.23,
      "max_abs_mm": 0.36,
      "score": 1.55
    }
  ]
}
```

因此后续可以完整追溯到底剔除了哪些姿态，以及为什么剔除。

## CLI

`single_sphere17_cli calibrate` 默认也启用相同的姿态筛选。可使用：

```text
--pose-screening
--no-pose-screening
```

进行显式控制。

## 验证原则

姿态筛选属于训练集内部的 robust fitting，**不能代替独立 hold-out 验证**。删除高残差训练姿态一定会降低训练 RMS，因此最终能否接受模型仍必须看未参与训练/筛选的 hold-out 数据。
