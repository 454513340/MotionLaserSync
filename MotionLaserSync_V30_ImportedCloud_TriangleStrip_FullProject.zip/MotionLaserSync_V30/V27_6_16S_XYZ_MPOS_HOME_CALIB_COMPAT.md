# V27.6.16S — XYZ Grating MPOS Homing + Calibration Compatibility

V27.6.16S converts the upper-PC measured-position path to the commissioned XYZ incremental linear gratings while preserving DPOS as the controller demand/command coordinate. The ECI3808 V32.9 BASIC hardware-latch path was already full five-axis MPOS and is intentionally not modified in this release.

## 1. Position semantics

- **Measured/actual machine pose:** XYZ = homed grating MPOS; C/B = software mechanical MPOS.
- **Controller demand/command:** XYZ DPOS remains available and is still used where the code is explicitly constructing a controller command-space trajectory.
- **Following-error diagnostics:** retain both DPOS and MPOS; do not collapse them into one value.
- **Software acquisition:** `feedbackMask=31`, `latchMask=0`, `commandMask=0`, `SoftwareInterpolated`.
- **Hardware acquisition:** unchanged V32.9 TABLE contract, `feedbackMask=31`, `latchMask=31`, `commandMask=0`, `HardwareLatched`, `REGIST(104)`.

## 2. Incremental-grating homing

An incremental scale has no absolute machine coordinate after power-up. V27.6.16S therefore treats XYZ MPOS as unreferenced after connect/reconnect and at the beginning of every re-home.

For X/Y/Z, a successful `homeAxis()` now requires the complete sequence:

1. execute DATUM and wait for motion to stop;
2. reject manual stop/abort;
3. require `ZAux_Direct_GetHomeStatus(...) == 1`;
4. read MPOS repeatedly and require a short stability window;
5. call `ZAux_Direct_SetMpos(axis, 0)`;
6. verify both DPOS and MPOS are near zero;
7. restore the original soft limits successfully;
8. only then mark that axis' grating MPOS reference valid for the current connection.

A failed DATUM, failed MPOS alignment, or failed soft-limit restoration leaves the axis reference invalid. B/C are never zeroed by this path.

## 3. Runtime gates

Five-axis measured-state consumers require all three XYZ MPOS references to be valid. This includes measured five-axis state, software sampling, Physical17 calibration/RTCP paths and V32.9 hardware-sync preflight/start.

The automatic V32.9 preflight is quietly deferred while XYZ are not yet homed. After the third linear axis establishes its MPOS reference, the UI automatically retries preflight when the B/C absolute mechanical frame is also ready.

## 4. Physical17 legacy compatibility

Changing the live machine to XYZ MPOS does **not** automatically invalidate old accepted Physical17 results.

A legacy result with saved `feedback_mask=24` (XYZ DPOS + C/B MPOS) may be bound to the current mask-31 machine as a compatibility model. The program:

- warns that recalibration is recommended;
- continues to allow the old independently validated model as an approximate scan/RTCP fallback;
- uses the old Physical17 parameters and saved machine sphere center as initialization for a new calibration;
- uses that sphere-center/model seed to reduce search/path-planning effort during the new Stage-1/Stage-2 workflow;
- keeps the previously accepted calibration available while new training/hold-out data are being collected;
- only replaces it transactionally after a new result passes validation and is successfully persisted.

The live machine source and model provenance are stored separately. A legacy model remains marked `feedback_mask=24` when re-saved/bundled for compatibility even though the current runtime binding uses mask 31. A newly solved full-MPOS model is saved as 31.

The one rule that remains strict is that old and new observations are not silently mixed into one solve: an old model can seed the new solve, but new measurement records are captured in the current full-MPOS frame.

## 5. G-code / RTCP boundary

Measured physical pose, G92 physical-reference construction, RTCP current pose and final completion checks use XYZ MPOS.

The ordinary non-RTCP SP command queue retains XYZ DPOS as its demand-space start. This is deliberate: measured feedback error must not be blindly re-injected into a command trajectory.

## 6. Sensor-calibration metadata

Sensor-calibration pose provenance now labels XYZ as grating MPOS. Exported schemas were advanced where the position-field meaning changed (`Position_X/Y/Z_MPOS`, `x/y/z_MPOS_mm`).

## 7. BASIC deployment note

No `.bas` file is modified by this release. Keep the field-commissioned ECI3808 BASIC that already contains the machine-specific XYZ encoder ratios/directions. For the machine described with this release, the field settings are:

```basic
ENCODER_RATIO(2,1) AXIS(1)
ENCODER_RATIO(2,1) AXIS(2)
ENCODER_RATIO(2,-1) AXIS(3)
```

Those values are commissioning data and are intentionally outside this upper-PC patch.

## 8. Verification

The Linux/offline build supports the portable/core test configuration only (`-DV21_TESTS_ONLY=ON`); the full GUI is intentionally blocked there because the project bundles Windows x64 vendor SDKs. V27.6.16S therefore verifies the real `ZmcController.cpp` against Mock ZAux, numerical runtime/RTCP tests, plus a release-specific source-contract checker. Historical source-contract scripts from older releases may still assert the old XYZ-DPOS contract and are retained as historical records rather than rewritten into proof of the new behavior.
