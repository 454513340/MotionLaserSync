# Machine5X model integration notice

Source package supplied by user: `machine5x_vtk_fcl_outline_complete`.

The visual PLY and collision STL assets in `models/machine5x/` are byte-identical copies of the supplied assets. MotionLaserSync uses the supplied Machine5X kinematic convention directly; no mesh re-origin or hidden model offset is applied.

The original collision-model report is retained under `models/machine5x/reports/`. In particular, review `componentaware_simplification_report.csv` and `componentaware_model_notes.txt` before unattended operation: the simplified STL collision surface is not a formally conservative CAD envelope.
