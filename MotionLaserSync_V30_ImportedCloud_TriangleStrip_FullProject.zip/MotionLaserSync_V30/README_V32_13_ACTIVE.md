# ECI3808 BASIC V32.13 — 本版本唯一正式下载入口（待现场验证）

- 上位机版本：**MotionLaserSync V27.6.55**。
- 唯一正式 BASIC：`controller/ECI3808_5Axis_Controller.bas`。
- 核对副本：`controller/ECI3808_V32_13_PWM_HANDSHAKE_FIVE_AXIS_HOME.bas` 和根目录同名文件，必须与正式文件逐字节相同。
- 历史版本只用于对照：`controller/ARCHIVE_NOT_FOR_FLASH/`，禁止以其文件名推断版本。
- 硬协议标识 `TABLE[354]=321055`，不接受旧 `321054`；同包上位机与 BASIC 必须配套。
- `TABLE[357]=X(1)|Y(2)|Z(4)|C(8)|B(16)`；BASIC 启动清零。Run `en=1`、Probe `en=2`、ColdPrime `en=3` 三种输出模式均检测 `TABLE[357]==31`，否则 `TABLE[333]=12`、故障关闭 OP14。
- 频率配置继续使用 `355/359` 请求频率与提交序号，`356/360` 已应用频率与 ACK 序号；`358` 真正状态，`361` 配置错误。先完成旧 PWM 的停止/收尾，再应用新频率。
- 保留现场参数：X/Y/Z `ENCODER_RATIO(2,1)/(2,1)/(2,-1)`、软限位不主动修改。

**仅完成源码和模拟 SDK 检查；尚未用 ZDevelop BASIC 编译器检查，尚未通过机床、光栅、伺服、OP14/IN0/scanCONTROL 示波器测试。下载前备份原固件，确认激光不可发射/各轴安全，必要时先断开执行器输出；下载后强制五轴重新回零。**
