# MotionLaserSync V27.6.15：独立验证数据持久化与离线 hold-out 验证

## 1. 版本定位

V27.6.15 基于 V27.6.14 PRECOMMISSION_GUARD_FIXED，解决一个明确的工作流缺口：Stage2/Physical17 训练数据和独立 hold-out 验证数据以前只能在内存中分开，验证原始数据没有独立、可安全重载的持久格式，因此重新启动以后即使已经恢复 Stage1/Stage2，也无法用磁盘上的原始验证观测重新计算验证。

本版只扩展“验证数据管理和离线计算”链路。V27.6.14 的硬件同步预验收锁保持不变：UI、G-code 和 SyncManager 仍不允许启动 Hardware 同步路径。离线测试通过不等于真实电气/触发/曝光时序已验收。

## 2. 新的数据角色

V27.6.15 明确区分两类 CSV：

1. **Stage2 training CSV**：参与 Physical17 求解的数据。它用于恢复训练来源、重新求解和检查验证姿态是否与训练网格独立；不能作为 hold-out 验证数据。
2. **hold-out validation CSV**：Physical17 参数冻结后另外采集、且没有进入求解器的数据。它只用于验证，不参与参数求解。

普通 `single_sphere17_profiles.csv`/Stage2 训练 CSV 不会被“导入独立验证 CSV”入口接受。

## 3. 新增 UI 能力

独立验证区域增加：

- `导入独立验证 CSV（离线）`
- `导出独立验证 CSV`

“执行独立验证”的计算条件现在是：

- 已有成功的冻结 Physical17 结果；
- 已恢复与该结果对应的 Stage2 training CSV，用于独立性复核；
- hold-out 验证姿态数量达到当前设置；
- 每个验证姿态与训练 B/C 网格满足最小间隔。

**执行验证本身不要求控制器或 2950 在线。** 只有在线采集新的 hold-out 数据时才需要实机会话。

## 4. hold-out CSV 的绑定与防误用

V27.6.15 的验证 CSV 不只是普通点列表。每行都包含：

- `dataset_role=holdout_validation`
- `format_version=1`
- 当前 Physical17 模型 SHA-256 指纹
- 当前 Stage2 训练姿态集合 SHA-256 指纹
- `validation_pose_id`
- 原 profile ID 和导出 profile ID
- XYZCB、sensor X/Z、weight

导入时会同时检查：

- 文件角色和版本；
- Physical17 模型指纹必须与当前冻结结果一致；
- 训练姿态指纹必须与当前导入的 Stage2 training CSV 一致；
- profile 到 validation pose 的映射必须一致；
- 同一 validation pose 的 XYZCB 必须一致；
- 保存的球面点必须能重新建立代表球心拟合；
- 每个验证姿态必须重新通过与训练网格的 B/C 独立性检查。

因此不能通过简单改文件名把训练 CSV 冒充验证 CSV。

## 5. 修复：导入 training CSV 不再无条件清除已恢复 Stage2

V27.6.14 中，启动自动恢复 Stage2 JSON 后再导入 `single_sphere17_profiles.csv`，会把已经加载的17参数结果清掉。这与“恢复旧模型 -> 恢复训练来源 -> 导入 hold-out -> 离线验证”的目标流程冲突。

V27.6.15 改为：如果当前已有离线冻结 Stage2 结果，导入 training CSV 后先用下列签名复核它是否确实是该模型的训练数据：

- profile 数；
- point 数；
- 用冻结17参数对整个 training CSV 重新计算得到的 RMS；
- 同一重算得到的最大绝对残差。

全部匹配才保留冻结的 Stage2 结果；任何一项不匹配都拒绝绑定，并取消当前冻结结果，避免把另一批训练数据错误绑定到当前17参数。

## 6. 在线 hold-out 原始数据自动保存

每次成功加入新的独立验证姿态后，软件会尝试把当前完整验证原始观测保存为模型专属文件：

`single_sphere17_holdout_<模型指纹前12位>.csv`

目标位置：

- AppData 下的 `calibration/`
- `MotionLaserSync.exe` 同级的 `calibration/`

至少一个位置写成功即可。也可以用“导出独立验证 CSV”手工保存到指定位置。

这解决了“validation JSON 丢失后只能重新采集”的问题：只要原始 hold-out CSV、对应 Stage2 JSON 和对应 training CSV 都还在，就可以重新离线计算验证。

## 7. 离线 PASS 与运行授权严格分离

离线 hold-out PASS 只说明冻结 Physical17 模型通过了当前独立验证阈值；它**不会**直接授权扫描或 RTCP。

运行时 `scanCalibration()` 仍要求：

- Physical17 成功；
- hold-out 验证 PASS；
- 当前进程已经绑定实机坐标约定；
- 当前 FlipX/FlipZ 与保存/绑定约定一致；
- XYZCB DPOS/MPOS 来源与绑定约定一致。

因此：

`离线验证通过 != 当前设备已授权运行`

连接设备后仍必须完成现有的坐标约定绑定/复核，之后才允许把同一套17参数投入扫描/RTCP。

## 8. 推荐恢复流程

对于已经保存 Stage1、Stage2 和 training CSV，但没有 validation JSON 的旧项目：

1. 启动后自动恢复 Stage1 + Stage2；
2. 导入与该 Stage2 对应的 Stage2 training CSV；软件会用 profile/point/RMS/max 签名确认并保留冻结模型；
3. 如果以前已经用 V27.6.15 保存过独立验证 CSV，则直接导入；
4. 满足验证姿态数量后执行离线独立验证；
5. 如果旧项目从来没有保存过真正独立的 hold-out 原始数据，则不能用 training CSV 代替，仍需以后在受控实机验收中获得一套新的独立验证数据；
6. 独立验证通过后，只有在实机坐标约定再次核对成功时才生成/更新默认有效标定授权。

## 9. 回归状态

本版本新增 `tools/verify_v27615_offline_holdout.py` 并注册为 CTest：

- V27.6.15 当前离线 hold-out 源码契约：**35/35 通过**；
- 当前版本相关的可移植核心、Mock 传输、SingleSphere14/Physical17 数值、运行时归档、轨迹解析、RTCP 数值/锁存仿真以及 V27.6.15 契约：**19/19 通过**；
- 完整 CTest 当前为 27 项，其中 8 项历史版本源码字符串契约失败。它们检查 V19/V20/V27/V27.6.5/V27.6.6/V27.6.12/V27.6.13/V27.6.14 的历史版本号或旧实现字符串；V27.6.15 当前契约单独通过。

Linux 可移植测试无法替代 Windows x64 + Qt/VTK + 厂商 SDK 的最终编译链接，也不能替代真实硬件验收。
