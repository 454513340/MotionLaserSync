# V27.6.16J — Calibration XYZ DPOS Restore

## Fix

The Physical17/single-sphere calibration source convention is restored and fixed to:

- X/Y/Z: DPOS
- C/B: machine-frame MPOS

This convention no longer changes merely because X/Y/Z are configured as `ATYPE=4` in the controller BASIC.

The previous V32.7 upper-PC code inferred the calibration source mask from `ATYPE`.  Once XYZ were changed from ATYPE=1 to ATYPE=4 for future grating hardware latch, the calibration UI inferred `X/Y/Z=MPOS`, so saved Physical17 results with the historical `X/Y/Z=DPOS, C/B=MPOS` convention were rejected.

The controller/hardware-sync TABLE contract remains separate:

- V32.8A BASIC: X/Y/Z/C/B are all REGIST(104) MPOS records in hardware-sync TABLE data.
- Ordinary motion/status/software-sync and Physical17 calibration: X/Y/Z DPOS, C/B machine-frame MPOS.

This patch intentionally does not relabel hardware-latched TABLE MPOS as DPOS.
