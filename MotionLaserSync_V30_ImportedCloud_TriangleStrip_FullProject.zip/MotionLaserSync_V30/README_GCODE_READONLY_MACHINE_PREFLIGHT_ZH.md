# V29 连续多姿态 H3 NC：实机执行准备检查（只读版）

## 版本用途和禁止事项

这次是在 `MotionLaserSync_V29_BC37_多姿态无瞬移_G代码连续转场_完整源码_仅离线.zip` 的完整源码基础上新增**现场准入诊断**，不替换原 M0–M8、BC37 路径规划、H1/H3 采集及已验证的普通 G 代码执行功能。

**没有把当前 `MP_ALL_POSES_CONNECTED_OFFLINE_ONLY_H3.nc` 改成实机可执行，也没有放开 `OfflineOnly` 与 G 代码硬件采集预验证闸门。** 该 NC 在缺少独立现场验收前不应被下发控制器。

不要通过手工删除 `OfflineOnly`、修改 `SimulationVerified`/`RegistrationVerified` 注释或关闭软件限位来绕过检查。注释内容和 SHA-256 的自述本身不能证明外部现场安全验收。

## 已具体实现

1. `GCodeExecutor::inspectRealRunReadOnly()`：仅读取原 NC 文件、哈希、当前现场同步配置、五轴回零与实际 MPOS、运动健康/空闲状态；不调用轴运动、同步采集和 PWM 控制指令。
2. `GCodeWidget` 的 G 代码工具栏增加**“实机准入检查（只读）”**，显示每一项阻断原因和第一条 G00 的 XYZCB 当前值/目标值差异。
3. 自动保存结构化 JSON 至 `%APPDATA%/…/gcode_preflight/preflight_YYYYMMDD_HHMMSS_fff.json`（Qt `QStandardPaths::AppDataLocation`），含 UTC 时间、原始 NC SHA-256、当前 H1/H3 条件、各项拦截。
4. 加强编辑器内容与磁盘原始 NC 的一致性检查，防止保存/编辑后仍错误地将旧磁盘哈希视为当前程序。
5. 独立离线 `tools/audit_multi_pose_nc_for_real_run.py`，可核对 NC 与项目 `multi_pose_experiment_manifest.json` 的 SHA-256、M50/M51/M60/M61 等数量、已验收标志、首条 G00。该脚本永远不会向机器发送命令。
6. 新增 `tests/gcode/test_real_run_preflight_audit.py`，包含拒绝伪哈希的负测试及确保安全闸门未解除的静态回归。

## 对用户现有 NC 的检测结果

文件：`MP_ALL_POSES_CONNECTED_OFFLINE_ONLY_H3.nc`；校验值：`09f32d4b679c56d9f2c2f9f27e15d9593c820723192ef0a25c3c8493670e1cda`。与实验清单一致。

- 共 37 组 M50/M51/M60/M61，36 组姿态间激光关闭的 G05 S0；末尾 M63/M30。
- 第一个位置参考为 XYZCB ≈ `(43.775047, -2.926050, -7.792464, -10°, -10°)`。
- 程序 `OfflineOnly: true`；`RegistrationVerified: false`；`SimulationVerified: false`；`InitialJointAnchored: false`。
- 清单 `hardwareAuthorized: false`、`registrationVerified: false`、`opticsAcrossAnglesVerified: false`、`firstG00StartUnverified: true`。
- H3 名义 200 Hz、R1 edge 114；**尚须通过现场设备的独立电气和动态验收**。

文件完整与 NC 语法可解析，不等于实机运行准入。

## Windows 工程操作

在原 VS + Qt + VTK + OCCT + FCL + 控制器 SDK 环境重新编译。连接真实设备后，**先不按“开始执行”**，在 G 代码界面加载整组 NC，点击“实机准入检查（只读）”。将生成的 JSON 及控制器现场配置交由熟悉机械安全和 H3 接线的工程师完成评审。

严格的实机分阶段验收还需要：

- 五轴本次上电回零、现场五轴 MPOS 与首条 G00 的差异及独立安全进场路径；不可以将历史 `.scan` 位姿当成当前 MPOS。
- STEP/CAD 与零件实际装夹六自由度配准、夹具及机床各运动部件的全路径防碰撞、硬限位与软件安全余量。
- 17 参数运动学模型、H3 触发源/频率/R1锁存沿/轮廓计数、M50/M51 多次开关与每个 M60/M61/M63 归档的真实一致性。
- NC G93/G05 的运动动态、加减速、SP 缓冲、激光关闭转场和暂停/急停策略。
- 由现场合格人员对一份**不可再编辑的、SHA-256 锚定的程序版本**完成独立审批、按姿态分段的低风险现场验证，再讨论自动连续运行。

**只读检查报告不是授权凭证。** 本版不包含外部有资质的硬件验收系统签署及将其可信绑定至 GCodeExecutor 的逻辑，因此没有真正打通最终实机运行授权。

## 测试范围

- 本环境：便携 C++ 的多姿态 NC 核心、光学和回放 4 项回归测试全部通过；新增只读工具脚本及反篡改/保留闸门静态测试通过。
- 无 Windows Qt 和物理 ECI3808/scanCONTROL：GUI 真实构建、实时 MPOS 读取、H3 启停握手及真实五轴执行都**未在此环境验证**。
- 原项目耗时很长的 M6 长时测试不计入以上结果。
