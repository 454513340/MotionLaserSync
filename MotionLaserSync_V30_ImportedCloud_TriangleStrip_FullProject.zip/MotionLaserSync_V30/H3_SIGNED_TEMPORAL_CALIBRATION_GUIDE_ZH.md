# V32.16 H1/H3 专属硬件同步时域标定——H3 有符号延迟扩展

## 一、用途和本次修改范围

本包在已经完成 H2 删除的 `MotionLaserSync_H1_H3_ONLY_FULL_PROJECT` 上增量修改。保留现有 **H1: OP14→scanCONTROL 外触发 + ECI IN0/R0 (REGIST 104)** 和 **H3: scanCONTROL 内部时钟→CMM/RS422→ECI IN1/R1 (REGIST 114/115)** 采集方案。控制器 `controller/ECI3808_V32_16_H1_H3_ONLY.bas` **二进制内容未改变**，协议魔数仍为 `321058`，没有重新启用 H2（拓扑2仍为非法）。不需要因本次上位机标定功能更新而改写已通过验证的同版本 BASIC。

时间差的**统一定义**：`τ = t_sensor,effective − t_ECI,latch`。H1 沿用原校验限制 `0 ≤ τ < T`。H3 允许 `−T < τ < T`：正 τ 使用当前与下一条锁存，负 τ 使用上一条与当前锁存。仅允许连续、同会话、完整的五轴 MPOS 锁存帧参与校正，Probe 帧永不参与相邻插值。

**这些是代码能力，不是实机标定结果。** H3 的实际 τ（包括正负号）必须由新的正反标准球实验求解，不能把以前的 H1 `+239.18µs` 复制过去。H3 即使显示 Profile 时间戳间隔为 5.000ms，也不表示 `τ=0`。

## 二、操作顺序

1. 在设备完全停止、机械坐标/限位/急停有效的条件下备份现有 EXE、应用数据目录及 H1 JSON。保留原有全 MPOS/Physical17 几何标定。将本包在相同 Windows + Qt6 + VTK + ZAux/LLT 环境编译为新 EXE；沿用 V32.16 BASIC，重新执行只读预检。切勿用未配齐的厂商 DLL 替代正式 SDK。
2. 在**系统标定 → 硬件同步时域标定**页选择「**H3 传感器主触发：CMM → IN1/R1**」。这与主采集区的 H1/H3 选择**相互独立**，每次自动标定实际使用本页选择的拓扑，而不再强制切换 H1。
3. 在主界面设置 `200 Hz`、分辨率 `1280`（对应所用分辨率索引）、`Measuring Field=7`、固定曝光 `15×10µs=0.15ms`、自动曝光关闭；H3 内部 `Idle=485×10µs` 由程序按 200Hz 自动求得。勿在同一个 H3 标定 session 混用 0.15ms 与 1ms 曝光。CMM Divider=1、Ratio=1:1、Skew=0，实际 R1 上升或下降锁存边沿需按现场验证选择 114 或 115。
4. H3 RAW 标定第一次采集成功后自动锁定 R1 边沿；如主界面边沿被改动，后续采集会拒绝执行。**每条路径独立开关采集与 FIFO 会话**，必须通过 H3 CMM 连续窗校验和 STOP/Drain，并保证 `Profile=Pose=Aligned`、`Fault=0`，有索引缺口、丢帧、TABLE 停顿均需作废当前路径。
5. 导入已经过检验的标准球参考点云，确定固定半径球心；示教安全的扫描中点，按原 V27.6.50 流程生成正反向多速度 Pair。先选择低风险速度，确认运动范围、离线碰撞规划、跟随误差和重复球心精度后再扩展速度。**实时校正必须 OFF/RAW**。
6. 使用同一 H3 R1 硬件锁存 MPOS、正反球心、实测速度与时间漂移模型辨识有符号 `τ_H3`；评估 Pair 数量、多个速度等级、R²、有效半径正反差、延迟不确定度和实际 `|τ|<T`。不要把真实 τ 很小、不可辨识的情况强行解释为某个确定值。
7. 使用**未参与求解的独立 Hold-out 路径**，离线分别重建 RAW 和 signed-τ 修正结果。正 τ 使用后一帧，负 τ 使用前一帧。按照原有几何验证阈值判定是否真正改善。没有 PASS 时禁止启用运行时补偿。
8. 独立验证 PASS 时保存一个**默认 OFF** 的活动 JSON。仅在确认对应主界面 H3 配置（拓扑3、R1 114/115、频率、曝光、有效 Idle、Measuring Field、CMM Divider/Skew/Ratio 等）一致并确认点云已清空后，才启用 H3 runtime correction；ON/OFF 切换禁止在采集中进行。可以随时回到 RAW，不可混合 RAW 与已校正的点云。

## 三、保存路径与兼容性

| 内容 | 路径/说明 |
|---|---|
| H1 新格式活动标定 | 用户 AppData/MotionLaserSync/calibration/`active_hardware_temporal_H1.json` |
| H3 新格式活动标定 | 用户 AppData/MotionLaserSync/calibration/`active_hardware_temporal_H3.json` |
| H1 旧格式标定（只读兼容） | `active_hardware_temporal.json`；只允许作为 H1 载入，不自动迁移成 H3 |
| 标定日志/RAW/检查点 | 用户选择的归档目录；每条 `.scan` 对应独立 `.json` 元数据，session 检查点包含 topologyId、latchEdge 和 CMM 指纹 |

新格式活动 JSON `schemaVersion=4`，H3 必须绑定 `topologyId=3`、`latchEdge=114/115`、Divider=1、Skew=0、Ratio=1。H1/H3 的断点会话与活动标定禁止跨拓扑导入；没有 H3 身份标记的 V48 旧会话只能恢复到 H1。

## 四、源代码变动概览

- `MainWindow.cpp`：自动标定按标定页 H1/H3 模式与选定锁存沿采集 RAW；运行时 ON 控件检查 H3 的**有效** Idle（而不是主界面输入框中原有的 H1 Idle）。
- `HardwareSyncCalibrationWidget.{h,cpp}`、`CalibrationWidget.{h,cpp}`：增加标定拓扑选择、锁存沿冻结，H3 专属 JSON、断点隔离与签名；离线 Hold-out 支持负延迟。
- `HardwareTemporalCalibration.{h,cpp}`：H3 有符号 τ 求解质量门限；H1 非负限制保留。
- `SyncManager.{h,cpp}`：绑定 H1/H3 指纹，运行时正 τ 用后帧/负 τ 用前帧；不改变五轴 FIFO、BASIC、紧急停机及已测 H1/H3 采集拓扑。
- `HardwareTemporalCorrection.{h,cpp}`、`Acquisition5D.{h,cpp}`：有符号相邻位姿插值以及 `completeFrame` 所需来源/变换验证。
- `tests/h3_signed_temporal_tests.cpp`、`tools/verify_h3_temporal_extension.py`：负延迟合成实验、符号/相邻帧/会话/边界及源码接线回归检查。

## 五、测试现状与部署限制

在当前 Linux 隔离环境里，portable C++/Mock 可以编译，但**缺少 Windows Qt6/VTK/ZAux/LLT 运行环境，未完成 GUI 整体编译、控制器 BASIC 编译，也没有新的 H3 实机标定/扫描结果**。

- H3 signed temporal / old H1 temporal / V27.6.50 漂移求解 / H1H3 协议 / P0 portable / H3 路由源码合同：6/6 针对性 CTest 通过。
- 核心 Mock：109/112；3 项为旧工程已知的 HOME 认证和轴补偿重连状态失败。不得称全套通过。
- 历史 `verify_v27644_hardware_temporal.py` 和 `verify_v27650_drift_radius_temporal.py` 因缺少已经删去的旧 BASIC 文件失败，不能被算成新功能错误或 PASS。

实机部署前：确认 H1 原有 200Hz、五轴 R0 Probe/STOP 能重复通过；再确认 H3 CMM Active/Counter/R1 正常；然后在静止安全场景测试小段 RAW、重复球拟合、独立验证。**出现 H1/H3 Profile 缺口或 ECI TABLE 读取长停顿，立即判定数据无效，不得用延迟补偿绕过完整性检查。**
