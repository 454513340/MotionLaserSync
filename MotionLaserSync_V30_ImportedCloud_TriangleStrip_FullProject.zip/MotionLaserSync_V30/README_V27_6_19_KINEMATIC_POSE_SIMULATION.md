# V27.6.19 运动学标定姿态仿真

基于 V27.6.18 CALIBRATION_FAST_REVIEW 增量修改。

## 新增功能

运动学标定（单球阶段2）在“生成质量约束 + D-optimal 标定姿态”之后新增：

- `仿真运行标定姿态`
- `停止姿态仿真`
- `清除仿真显示`
- 每姿态播放间隔（默认 800 ms）

仿真只驱动 GUI 数字孪生，不调用控制器移动接口，不会向真实五轴发送运动命令。

每个生成姿态使用与阶段2规划光学门禁相同的 Physical17 / 固定球心 / FlipZ / scanCONTROL 梯形 FOV 模型，显示：

1. 五轴数字孪生姿态；
2. scanCONTROL X-Z 梯形测量场；
3. 球与激光平面的完整几何截圆；
4. FOV 内、且朝向末端执行器一侧的预测有效圆弧；
5. 全部姿态的累计预测采集圆弧点云；
6. 二维轮廓页中的预测有效圆弧 + 理论截圆圆心/半径。

因此可在真实运动/采集前检查生成姿态是否确实能够扫描到正确的圆轮廓，以及不同姿态对球面的覆盖是否合理。

## 主要修改文件

- `include/widgets/SingleSphere14CalibrationWidget.h`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `include/widgets/CalibrationWidget.h`
- `src/widgets/CalibrationWidget.cpp`
- `src/app/MainWindow.cpp`

## 验证

- portable `SINGLE_SPHERE17_CLI_ONLY` 在当前 Linux 环境编译通过。
- 完整 GUI 未在当前环境编译：当前验证容器没有 Qt6 Widgets 头文件，因此最终仍需在项目既有 VS2022 + Qt6/VTK/FCL 环境执行一次 x64-Release 全部生成。
