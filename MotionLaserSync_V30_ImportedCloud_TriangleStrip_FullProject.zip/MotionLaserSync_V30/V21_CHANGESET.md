# V21_CHANGESET

本轮基线为会话中的 V20.2 physical17/rank14 完整源码。本文件说明本轮实际修改；旧 V18/V19/V20 文档只作历史资料。

## 关键变更

- ECI3808 BASIC + PC TABLE 协议同步升至 V21；XYZCB 数据、会话单探针、错误停采集、心跳与环形缓冲保护。
- 五轴轴存在位掩码、严格 NC/CSV 解析、模态/进给/圆弧/点列；GUI 模板与已验证 NC 文件统一。
- 五轴 SP 排队、按轴限速、真实暂停恢复、五轴队列一起取消、资源占用与 UNITS 保护。
- 扫描统一完整17参数FK，关节偏移/标定/时序来源冻结；不再叠加旧三轴偏移。
- 双精度来源归档、完整关节CSV、PLY伴随位姿文件；QtZlib真实标签；保存失败不能伪装完成。
- 跨平台离线 CLI/测试、Windows构建入口、移除硬编码Qt路径，部署BASIC/模板/配置。

## 不能写成“已验收”的内容

完整Windows GUI、原生BASIC编译下载、ECI3808/传感器实机没有在本环境运行；顺序采样不是同沿锁存，关节SP插补不是RTCP；单球标定平移规范不自动解除。详见审计报告第1、8、10节与verification/test_summary.json。

## 基线追溯

- 输入 ZIP：`5Axis_project_v20_2_physical17_rank14.zip`
- SHA-256：`3be8110113d8bf76ab4ddba09bf5b83ba0e2183cdb504bddec5baa82e9048aee`

## 修改的原工程文件

- `CMakeLists.txt`
- `README.md`
- `controller/ZMC_5Axis_Controller.bas`
- `include/core/DataTypes.h`
- `include/core/SyncManager.h`
- `include/core/ZmcController.h`
- `include/gcode/GCodeExecutor.h`
- `include/gcode/GCodeParser.h`
- `include/gcode/GCodeTypes.h`
- `include/utils/CompactScanFormat.h`
- `include/utils/CsvExporter.h`
- `include/widgets/CalibrationWidget.h`
- `include/widgets/SaveFormatDialog.h`
- `include/widgets/SingleSphere14CalibrationWidget.h`
- `src/app/MainWindow.cpp`
- `src/core/SyncManager.cpp`
- `src/core/ZmcController.cpp`
- `src/gcode/GCodeExecutor.cpp`
- `src/gcode/GCodeParser.cpp`
- `src/utils/AsyncSaveManager.cpp`
- `src/utils/CompactScanFormat.cpp`
- `src/utils/CsvExporter.cpp`
- `src/widgets/CalibrationWidget.cpp`
- `src/widgets/GCodeWidget.cpp`
- `src/widgets/SingleSphere14CalibrationWidget.cpp`
- `tests/CMakeLists.txt`
- `tests/MockZaux.cpp`
- `tests/MockZaux.h`
- `tests/p0_core_mock_tests.cpp`
- `tests/shims/QtShim.h`

## 新增源码、控制器程序、脚本、示例与文档

- `cmake/V21Runtime.cmake`
- `config/eci3808_trajectory_limits.example.json`
- `controller/ECI3808_5Axis_Controller.bas`
- `docs/V21_ECI3808_Audit_and_Deployment.md`
- `docs/baseline/ECI3808_original_statements.bas.txt`
- `docs/baseline/README_before_V21.md`
- `examples/v21_5axis_capture.nc`
- `examples/v21_5axis_motion_only.nc`
- `examples/v21_g05_and_arcs.nc`
- `examples/v21_template_basic.nc`
- `examples/v21_template_continuous.nc`
- `examples/v21_template_multiregion.nc`
- `examples/v21_template_raster.nc`
- `include/runtime/Acquisition5D.h`
- `include/runtime/FiveAxis.h`
- `include/runtime/GCode5D.h`
- `include/runtime/ScanArchive5D.h`
- `scripts/build_offline.ps1`
- `scripts/build_offline.sh`
- `scripts/build_windows.ps1`
- `src/runtime/Acquisition5D.cpp`
- `src/runtime/FiveAxis.cpp`
- `src/runtime/GCode5D.cpp`
- `src/runtime/ScanArchive5D.cpp`
- `tests/v21_runtime_tests.cpp`
- `tools/v21_runtime_cli.cpp`
- `tools/verify_v21.py`

## 验证记录

`verification/` 保存原始测试输出、环境信息、示例验证和可检查的射线球面仿真输出。17个CTest测试组均通过；源码契约、模拟SDK及数值测试的覆盖层级严格区分。旧14/17参数标定回归继续保留。
