# ECI BASIC V32.15 deployed controller candidate

**唯一正式下发入口：** `controller/ECI3808_5Axis_Controller.bas`。

本文件与 `controller/ECI3808_V32_15_THREE_HARDWARE_TOPOLOGIES.bas` 一致。旧的 `ECI3808_V32_14_...bas` 和 V32.13 文件仅用于历史对比。硬件程序的能力字：TABLE[354]=321057；stop tail 标识：TABLE[362]=1316；默认 topology H1，H2/H3 需要与上位机协商并确认 R1/IN1 线路。

**未做 ZDevelop 编译/4 KB 占用和真实机器验收，不要直接用于无人值守设备。**

详细见：`README_V27_6_57_CMM_MSVC_AND_BASIC_SAFETY_ZH.md`。
