# Small7 实验3 修复包 — 离线验证报告

## 实施状态

- 新增第三实验独立执行状态机与规划器，原有标准球曝光试验仍保留。
- 已在 Windows 正式主程序目标中接入新界面、规划器源码和控制器运动诊断。
- 已解除原标准球全场曝光扫描“定位速度按轴限速0.2倍、加减速0.2倍”的设计；独立定位速度为 1、2、3、4、5 mm/s，Small7 X扫描固定1 mm/s。
- 原有机床限位与数字孪生 MachineSafety、Physical17、XYZ回零和B/C伺服互锁均保留；光学上下限通过已验证Small7 field7光学配置提供，不在第三实验界面人工重复填写。
- 运动命令与采集等待增加超时预算、MPOS/DPOS/IDLE逐秒可见日志、断流停止、位置锁定与故障后保存原始数据的处理。

## 结果

| 检查 | 结果 | 意义 |
|---|---|---|
| `SMALL7_EXPERIMENT3_CLI_ONLY` CMake Release 配置与编译 | 通过 | 独立的Small7规划及时间预算C++源码可编译 |
| `ctest --test-dir ...` | 1/1通过 | ROI未验证时拒绝、Physical17几何、机器Z端点、独立速度、10μs周期量化、超时范围 |
| Debug `-fsanitize=address,undefined` 编译+CTest | 1/1通过 | 测试路径未触发ASan/UBSan可见错误 |
| `SPHERE_EXPOSURE_CLI_ONLY` | 通过 | 旧标准球圆弧评估/峰值/排序/拒绝逻辑的可移植回归 |
| `SINGLE_SPHERE17_CLI_ONLY` | 可编译并运行 | 原Physical17核心回归程序可运行 |
| `verify_sphere_exposure_x_only_contract.py` | 15/15通过 | 原实验结构/互锁源码静态检查 |
| `verify_small7_experiment3_contract.py` | 35/35通过 | 新增执行结构、运动日志、真实扫描帧、GUI主链接、互斥/安全等静态检查 |
| 历史 `SPHERE_TWO_STAGE_QUALITY_CLI_ONLY` 回归 | **未完成** | 编译命令在环境中超时被终止，不能声称通过，也不将其记为代码错误 |
| Windows x64 Qt6/VTK/FCL/MSVC/ECI3808/scanCONTROL 编译 | **未执行** | 当前环境没有整套Windows/SDK工具链及真实设备 |
| X/Z轴真实运动、安全急停、传感器真实Field7轮廓 | **未执行** | 必须在现场先确认经验证配置、限位、硬件联锁和实际反馈 |

**判断范围：**本交付为“完整修改后的源码 + 离线测试”，不是Windows可运行EXE，更不是现场已通过机器运行的认证版本。上传的原ZIP也不含截图中的原实验3源码，因此无法断言截图现场第1步卡住的单一根因。详见 `README_SMALL7_EXPERIMENT3_FIXED_ZH.md`。
