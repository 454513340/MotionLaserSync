# Active integration: V27.6.16J + ECI3808 V32.8A

This integration restores the historical calibration/RTCP pose-source convention:

- X/Y/Z: DPOS
- C/B: machine-frame MPOS

The convention is no longer inferred from ATYPE. X/Y/Z may be ATYPE=4 in the controller so future gratings can be hardware-latched, without invalidating existing Physical17 calibration results.

Hardware-sync TABLE provenance remains truthful and separate: V32.8A stores hardware-latched X/Y/Z/C/B MPOS.
