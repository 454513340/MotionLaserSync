# V27.6.16X — Reachable Sphere-Section Plane Family Study

This release replaces the V27.6.16W blind `D × gamma × C × B` Cartesian path with a reachable sphere-section plane family and reduces each study pose to one batch of 20 Rich Profiles.

## 1. Why the W path was changed

W treated C and B as independent experiment-grid variables. With the previous defaults this produced
`6 D × 6 gamma × 3 C × 3 B = 324` poses and then `5 × 20` Profiles at every pose. That is unnecessarily large for the present goal: learning sensor measurement quality as a function of actual measurement geometry.

C/B are still important because they create different laser-plane orientations, but they should be used to obtain diverse *reachable section planes*, not blindly multiplied into every D/gamma pair.

## 2. Recommended path geometry implemented in X

Known quantities:

- machine-frame sphere center `O_M` from 3-D sphere RANSAC;
- certified sphere radius `R`;
- current Physical17 hand-eye + identified machine geometry model;
- actual C/B software limits;
- sensor optical reference center `O_opt^S`.

For target section angle `gamma`:

`h = R sin(gamma)`

is the perpendicular sphere-center-to-section-plane offset, and

`r_section = R cos(gamma)`

is the theoretical section-circle radius.

A C/B orientation determines the sensor profile plane orientation. In the calibrated transform, sensor `+Y` is the profile-plane normal in machine coordinates. X does **not** ask the operator to enumerate a C/B Cartesian grid. Instead it:

1. builds C/B candidates inside the real software limits;
2. rejects candidates that cannot realize a representative central D/gamma geometry inside XYZ limits;
3. computes each candidate's profile-plane normal;
4. uses farthest-point/maximin selection (normal sign ignored because `n` and `-n` describe the same geometric plane) to choose K well-separated reachable section-plane orientations.

For each selected plane orientation and each D/gamma target, the Physical17 inverse solves XYZ so the known sphere appears at the required sensor-frame section geometry. This is the five-axis reachable equivalent of the geometric plane-family idea; it does not pretend the machine has arbitrary 6-DoF sensor orientation.

## 3. Default experiment size

Default UI:

- D = 82, 87, 92, 97, 102, 107 mm -> 6 levels;
- gamma = 0, 10, 20, 30, 40, 50 deg -> 6 levels;
- reachable section-plane directions K = 4.

Maximum planned poses before feasibility rejection:

`6 × 6 × 4 = 144 poses`

Each pose now records one independent batch of 20 Rich Profiles:

`144 × 20 = 2880 saved Profiles`

The default 3 warm-up/discard frames are still not included in analysis.

If a smaller first experiment is desired, set K=3 for at most 108 poses.

## 4. Why 20 Profiles, not 5 × 20

Five groups collected without leaving the pose are strongly correlated and mainly repeat short-term sensor noise. X fixes the internal group count to one and exposes only `Profiles per pose`, default 20.

Independent repetition should be obtained by a later second/third path pass, possibly in another order or with another reachable section-plane family. Each visit is analyzed using its *actual* fitted D/gamma/theta, so the machine is not required to reproduce exactly the same physical pose.

## 5. Alternative designs considered

### A. Old Cartesian D × gamma × C × B

Simple but expensive and redundant. It over-samples joint coordinates rather than measurement geometry. Removed from the active UI.

### B. C=B=0 translation-first baseline

Useful as a commissioning/diagnostic baseline: keep both rotary axes at zero, move XYZ, collect many D/gamma conditions, then add a few rotated blocks. It is mechanically simple and robust, but coverage of section-plane orientation is limited and D/gamma may be correlated.

### C. Reachable section-plane family (implemented, recommended)

Uses the sphere geometry directly, but only requests orientations the actual two-rotary-axis machine can reach. It provides controlled D/gamma coverage plus diverse plane orientations with far fewer poses than the full Cartesian design.

### D. Adaptive / active-learning design (future)

After the first uncertainty map exists, use GP/GAM uncertainty and error gradients to request new D/gamma/plane orientations only where the map is uncertain or changes rapidly. This should be considered after X has produced a clean first dataset.

## 6. Analysis semantics unchanged from V

- `D`: Euclidean distance from fitted section-circle center to the declared sensor optical reference center.
- `SectionAngle gamma`: unsigned `asin(h/R)`, where h is the known sphere center's perpendicular distance to the actual profile plane.
- `LocalSurfaceAngle theta`: point-level local sphere-normal versus optical viewing-ray angle.
- Circle RANSAC identifies the circle; it does **not** delete bad measurement events.
- Every sample slot inside the consensus EvaluationROI remains in the quality denominator, including dropout and geometric outliers.
- Width, Maximum, Threshold, Moment0 and Moment1 are retained as diagnostic/model features and are not used to pre-clean the RANSAC input.

## 7. Automatic acquisition

The W automatic workflow is retained:

`move XYZBC -> settle -> discard warm-up frames -> acquire 20 Rich Profiles -> save -> next pose`

Pause/resume, stop, timeout, retry, skip-completed and continue-on-failure are retained.

## 8. MSVC C2326 fix

W used `timeoutMs` inside a `QTimer::singleShot` lambda without capturing it. X explicitly captures it:

`[this, token, visit, group, timeoutMs]`

This fixes the reported MSVC C2326 at MainWindow.cpp around the Rich Profile watchdog.

## 9. BASIC deployment

No `.bas` file is changed by W -> X. Keep the field-tuned controller BASIC, especially the XYZ ENCODER_RATIO values, and do not overwrite it with an older copy from a source archive.
