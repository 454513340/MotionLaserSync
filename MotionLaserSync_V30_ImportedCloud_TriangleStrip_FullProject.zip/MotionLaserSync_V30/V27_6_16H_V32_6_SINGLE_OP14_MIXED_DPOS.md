# V27.6.16H / ECI3808 V32.6 SINGLE-OP14 + ATYPE4-MIXED-DPOS + ColdPrime

## 现场约束

- 只使用 **OP14**，不要求 OP0 接线。
- OP14 同时接 scanCONTROL 外部触发输入和 ECI3808 IN0。
- XYZ 控制器轴类型保持 `ATYPE=4`，为后续光栅尺接入保留配置；**当前上位机正式采集仍使用 XYZ 的 DPOS**。
- C/B 继续使用 `REGIST(104)` 锁存 raw MPOS；上位机按启动时建立并冻结的 RS485 软件机械坐标 offset 恢复机械绝对角。

## 正式触发

现场已经实测 `OP14 ON -> IN0=1`、`OP14 OFF -> IN0=0`。因此正式同步采用：

- scanCONTROL: `EdgeRising`（线路回高）
- ECI3808: `REGIST(104)`（R0 逻辑下降沿）

两者都对应 OP14 关闭的边沿。

TIMER0 每 5 ms 执行一次：

1. `OP(14,ON)`
2. 将 `DPOS(1/2/3)` 分别写入 XYZ 软件 FIFO
3. `OP(14,OFF)`，同一边沿触发 scanCONTROL + C/B REGIST(104)
4. 更新 XYZ FIFO 计数头
5. 前台 `Pump()` 可批量搬运多个积压样本到 `[ordinal,X,Y,Z,C,B]`

因此旧 NoGrating 版本“一次轮询积压>1后无法恢复历史 XYZ”的问题被消除：XYZ 历史 DPOS 现在也有 128 深度 FIFO。

## ColdPrime：修复冷上电第一次 Profile 少/为 0

现场两次测试表明：冷上电第一次采集时，即使 scanCONTROL `SetFeature/GetFeature` 成功且 `TransferProfiles(true)` 已启动，也可能出现控制器已有 Pose、但 SDK `raw callback=0`；控制器/传感器不断电后第二次启动又正常。这更符合 **传感器/LLT/UDP 数据通道首次启动尚未完全 ready 的竞争条件**，而不是 TABLE 或 C/B 坐标算法错误。

V32.6 启动时：

1. 配置传感器外部触发并回读验证；
2. 启动 Profile 流；
3. 额外等待 120 ms；
4. `enable=3`，用 **同一 OP14** 以 5 ms 周期做 cold-prime；
5. 上位机要求至少 8 个已成功转换 Profile；这些预热帧全部抑制/丢弃；
6. 停止 prime，等待 callback 尾部安静；
7. 清零正式 Profile 诊断；
8. 建立全新 TABLE session，BASIC 清空 XYZ DPOS FIFO 和 C/B REGIST FIFO，再 re-arm `REGIST(104)`；
9. 执行正式 1 Profile + 1 Pose Probe；
10. Probe 成功后切换 5 ms 连续采集。

由于 prime 也使用 OP14，它可能让旧的 REGIST 状态产生原始锁存事件；这些事件在正式 session 建立时被清空并重新 arm，因此不会进入正式 ordinal。

## TABLE 头

`?*TABLE(330,22)` 应为：

```text
96 0 0 0 0 0 0 270909 6 5 0 0 1 24 1 24 7 0 14 104 14 1
```

含义：

- `342=1`: 硬件执行授权
- `343=24`: feedbackMask = C/B
- `344=1`: ControllerSequential / Mixed
- `345=24`: latchMask = C/B
- `346=7`: commandMask = XYZ
- `347=0`: latch input R0/IN0
- `348=14`: sensor trigger output OP14
- `349=104`: REGIST(104)
- `350=14`: latch bridge 同样为 OP14
- `351=1`: ColdPrime capability
- `352`: prime pulse runtime counter

## 重要语义

虽然 XYZ 已经配置 `ATYPE=4`，本版协议仍明确声明 XYZ 来源是 **DPOS**。所以当前未接 XYZ 光栅尺时，上位机不会把 0/无效 MPOS 当成 XYZ 测量值。

将来光栅尺接好后，如果仍运行本版，XYZ 仍继续使用 DPOS。要切换为五轴 MPOS 硬件锁存，应另行显式升级协议头和上位机来源语义，不能静默自动切换。

## 验证

离线 `V21_TESTS_ONLY` 构建成功。与本次改动直接相关的测试：

- `p0_real_core_mock_transport`: PASS
- `v19_sync_report`: PASS
- `v21_runtime_numerical_archive`: PASS

历史版本的 source-contract 测试包含旧版本号、旧 BASIC 结构和旧“硬件同步保持锁定”等冻结断言，不作为 V32.6 当前协议的通过标准。
