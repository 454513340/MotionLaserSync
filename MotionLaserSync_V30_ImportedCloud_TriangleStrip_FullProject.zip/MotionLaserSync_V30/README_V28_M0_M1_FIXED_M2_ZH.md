# MotionLaserSync V28.1 — M0/M1 主界面同步修复 + M2 实测 SCAN 离线回放

## 1. 本次交付的功能与限制

此完整源码在 V28 MSVC 修复版上增量修改，**不改变** H1/H3/OP14、硬件同步、五轴真实运动和激光 SDK 的控制逻辑。

### M0/M1 修复

- `PathPlanningWidget` 将 MainWindow 的 `m_pointCloudView` 显式注入数字孪生编辑器。
- 导入 STEP/OBJ 后，在**主界面「三维点云」**渲染独立的 CAD 工件网格、支承面；修改 X/Y/Z/Rx/Ry/Rz 后两个视图同步更新。
- 独立编辑器增加「**同步并聚焦【主界面】三维工件**」按钮。STEP 导入完成时也会自动在主视图中更新、聚焦。
- 加载已保存的 `.twin.json` 后，主视图使用相同的 CAD 位姿及支承面配置。
- 关闭独立窗口只会隐藏，不会立即销毁场景；主界面依然保留工件显示，重新打开编辑器仍可继续调整。
- 主界面 CAD 工件 Actor 与原机床模型及真实采集 PointCloudBuilder 分离，**不会被误写为实测数据**。

### M2 真实 SCAN 离线回放

- 支持选择 `.scan`，调用**原工程的** `CompactScanIO::load()` 加载、校验 SCAN v3 原始归档（包括外层/内层 CRC）。拒绝无真实五轴曝光位姿的旧版数据。
- 使用保存的 `Frame5D::joints` （XYZCB）驱动**虚拟机床模型**；使用该帧的 `Frame5D::sensorToMachine` 将真实 Sensor-X/Z 点**只转换一次**到机床坐标。
- 时间基准优先使用传感器 `sensorTimeSec`，对时间异常间隔用 `.scan` 标称周期作为安全回放兜底；不把主机到包时间当成测量时间。
- QtConcurrent 后台加载与后台导出，UI 的播放/暂停、第一帧重置、时间滑动条及 0.25/1/4/20 倍速。
- 同一批真实点通过单独的青绿色 VTK Actor 显示在弹窗及主界面。屏幕预览最多 250,000 点；保留所有 `.scan` 原始点用于测量回溯与全分辨率导出。
- 可导出完整、未按预览比例降采样的**二进制小端 PLY**；仅输出真实有效测量点，源 `.scan` 不修改。
- 编辑器关闭时停止回放；**所有 M2 动作均为图形显示，不下发机器或传感器指令**。

> M2 是“真实历史采样回放”，**不是**虚拟传感器生成光学 Profile，也不是孔遮挡补扫模拟。激光/相机双光路和 NBV 属于之后 M3～M7。

## 2. 安装/配置依赖

建议 VS2022 x64-Release 构建。沿用原 Qt6/VTK/扫描 SDK/机器 SDK/FCL 配置。**本版本已按用户给出的实际路径设置：**

```text
TWIN_OCCT_PREFIX = D:/dev/vcpkg/installed/x64-windows-release
```

位置：`CMakeSettings.json` 的 `x64-Release` 配置，同时也是 `CMakeLists.txt` 的默认缓存值。

源码中的 OCCT 搜索前缀会在 Qt6/VTK/FCL 等原有依赖发现后注入，以避免意外替换已有 Qt/VTK 配置。实际机器路径存在并包含 OpenCASCADEConfig.cmake 等配置时，CMake 日志应出现：

```text
V28 STEP import: Open CASCADE enabled
```

如果以前构建缓存里已有另一个 `TWIN_OCCT_PREFIX`，请清理缓存并重新配置。在 PowerShell 验证 CMake 配置所在目录：

```powershell
Get-ChildItem 'D:\dev\vcpkg\installed\x64-windows-release' -Recurse -Filter '*OpenCASCADE*Config.cmake'
```

提示：用户此前已验证 STEP 能成功导入，这次不需要为了解决“主界面不显示”而重新安装 Open CASCADE。

## 3. 操作步骤

### M0/M1：主界面 CAD 工件

1. 编译新的完整工程，进入 **路径规划 → 数字孪生 / STEP 工件放置…**。
2. 点击 **导入 STEP…**，选择 `传感器连接件.STEP`；可使用“载入测试零件”作参考。
3. 设置 CAD→MCS 六自由度位置；可点击“使用实测参考位置”。
4. 此时**主界面三维点云**会显示该 CAD 工件（橙色）以及可选支承面。点击 **同步并聚焦【主界面】三维工件**，然后关闭弹窗查看主界面。
5. 再次打开弹窗编辑 XYZ/Rx/Ry/Rz，主界面同步更新；可保存或读取 `.twin.json`。

### M2：历史扫描回放

1. 打开同一数字孪生弹窗；左侧向下滚动至 **5. M2：真实 SCAN v3 离线回放**。
2. 点击 **导入实测 .scan…**，选择现有的 `6061_Alumina_Scan_H1.scan`。此文件本身为约 33 MB 的用户测试数据，**不包含在源码压缩包里**。
3. 等待后台读取和双重 CRC 校验。导入成功后可用 **播放/暂停/回到第一帧/滑条/速度选择**。
4. 回放中的青绿色点为实测点累积预览，同时主界面机床外观跟随相应的归档 XYZCB 位姿；这不代表实时机器位置。
5. 点击 **导出完整重建 PLY…** 导出全有效点，无预览降采样。
6. 关闭编辑器后，主界面保留最后位置的 CAD 模型和 M2 点云 Actor；编辑器重新打开仍保存场景。

## 4. M2 参考数据与检查结果

用户给定 SCAN v3 的文件经本交付内 `tools/check_scan_v3_reference.py` 脚本实际检查：

- Profile 帧数：**4,598**
- 原始有效点数：**4,762,337**
- 归档 ordinal：0～4597；ProfileIndex：14～4611（不同概念）
- 名义采样周期：5,000 µs；传感器时间总跨度：约 23.0038 s
- 文件头和解压后的 Archive v5 的 CRC 均通过。

标准库脚本无需安装 Qt：

```powershell
python tools\check_scan_v3_reference.py "D:\scan_data\6061_Alumina_Scan_H1.scan"
```

M2 C++ 回放结果请在用户的 Windows 10 + VS2022 实际环境验证。这次开发环境缺少 Qt6/VTK 和 Windows 现场 SDK，**不能声称新的 Qt GUI/M2 C++ 分支已经完成 MSVC 实际编译或实机验证**。便携式 digital_twin_core 的 4 项 CTest 已在 Linux C++17 Release 下通过。

## 5. 源码修改文件

- `CMakeSettings.json`：用户指定 OCCT Release 路径。
- `CMakeLists.txt`：相同 OCCT 前缀默认值；新增 Qt M2 回放源文件；保留 CLI 模式。
- `include/widgets/PathPlanningWidget.h`, `src/widgets/PathPlanningWidget.cpp`：主三维视图的依赖注入；编辑器关闭时不清除会话。
- `src/app/MainWindow.cpp`：传入主 `PointCloudWidget`。
- `include/widgets/DigitalTwinScanWidget.h`, `src/widgets/DigitalTwinScanWidget.cpp`：场景双视图同步、M2 控件与回放计时、完整 PLY 导出。
- `include/widgets/PointCloudWidget.h`, `src/widgets/PointCloudWidget.cpp`：独立 VTK M2 追加点云 Actor 和区域聚焦接口。
- **新增** `include/twin/ScanReplayAdapter.h`、`src/twin/ScanReplayAdapter.cpp`：SCAN v3 读取、校验、预览样本和全量重建输出。
- **新增** `tools/check_scan_v3_reference.py`：参考 SCAN 结构与校验和测试，不依赖厂家硬件 SDK。

原 `third_party`、控制器、同步采集、SingleSphere17 等源码保持不变，CAD 不会自动载入硬件控制对象。

## 6. MSVC GUI 验收清单

1. 重新 CMake 配置可找到 OCCT，没有 C2064 / C3535 等 Lambda 编译错误。
2. STEP 导入后点击“同步并聚焦主界面”，关闭弹窗仍可看到橙色工件。
3. 单独更改 X +10 mm，确认主界面工件也向机床 X +10 mm 移动。
4. 保存 `.twin.json` 后重开，确认两个视图保持相同位姿。
5. 载入参考 SCAN，应看到 4598 帧、4762337 原始有效点的回放摘要。
6. 在第 500/2000/4598 帧暂停，检查五轴位置和三维点云连续性，无明显重复变换。
7. 导出 full PLY 检查头部 vertex 数、点位与原归档一致。
8. 确认不连接任何机床控制器也能完成这些动作；连接真实设备时需警惕图形回放姿态不是实时 MPOS。
