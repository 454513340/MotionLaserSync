# MotionLaserSync V28.3 — M4 真实 H1 / M3 数字孪生对比与等效光学参数拟合

> **离线诊断功能，不发出五轴运动或激光指令。**
> 基线：`MotionLaserSync_V28_PROJECT_M3_DIRECTION_FIXED.zip`（V28.2）。本包保留 M0、M1、M2、M3，新增 M4。

## 在 VS2022 中运行

1. 解压完整工程，打开项目根目录（CMake），选择 `x64-Release` 并重新配置/构建 GUI `MotionLaserSync`。
2. 确保原设备 SDK、Qt6、VTK、FCL 等依赖在当前电脑可用；此包依旧保留 Windows OCCT 路径：`D:/dev/vcpkg/installed/x64-windows-release`。
3. 主程序标题应显示 `MotionLaserSync V28.3`。
4. 进入 **路径规划 → 数字孪生 / STEP 工件放置**；导入参考 STEP（或随包 OBJ）；设置 MCS 中的工件位置，例如参考初值 X=44.3195、Y=10.2369、Z=-225.05、Rz=-89.2265°。
5. 导入你的 `6061_Alumina_Scan_H1.scan`，完成 **M2**；保持支承面参数和场景适当。
6. 在 **M3** 使用已修正的默认相机 `+75 mm` 运行虚拟扫描。
7. 在新增 **“8. M4：实测/虚拟 Profile 对比 + 等效相机偏置拟合”** 中点击 **“运行 M4 全量对比”**。显示全局/沉孔区域的混淆矩阵、IoU、F1 和共同有效点 X/Z 误差。
8. 点击“导出 M4 对比 JSON/CSV”可导出含四孔 CAD 台阶近似占据分布的 JSON，以及按原始 Frame ordinal 排序的逐帧 CSV。
9. 可选点击 **“拟合等效相机偏置”**：默认搜索 Sensor-Y 35～95 mm、步长 10 mm，最多 180 条特征相关帧；展示训练和同次扫描留出帧得分。导出候选 JSON/CSV。若训练/留出不一致或留出帧太少，“应用拟合偏置”会保持禁用。
10. 若被允许并确认应用，原 M3/M4 将自动清除。**需要重新运行 M3，再重新运行 M4 全量对比。**

## M4 所做的比较（不要混淆）

- **配对键：** `Frame5D::ordinal` 和原始采样 `ArchivePoint::index`。同时核对曝光位姿 `sensorToMachine`，不再执行额外机床坐标变换。
- **M2 仅保存有效采样索引。** 真实缺失点只标记为 `unknown`，**不能**据此识别它是相机遮挡、激光未命中还是曝光失败。M3 预测的遮挡原因仅为虚拟模型推断。
- **有效性混淆矩阵：** TP=双方都有有效点，FP=仅 M3 有点，FN=仅真实 M2 有点，TN=双方均无点；真阳性不代表坐标本身误差小。
- **X/Z 误差：** 仅对双方同索引都有点的样本统计传感器坐标残差，分别列出平均绝对误差、Z RMSE。
- **四沉孔 ROI：** 使用 supplied H1 零件的四个已知 CAD 圆心、半径，根据每条虚拟激光射线与 CAD 顶面的交点分类；不是通用 STEP 特征识别器。只有 STEP 包围盒近似 30 × 95 × 10 mm 时才启用。
- **台阶覆盖：** CAD z≈5.4mm、半径 2.5～3.78mm 区间内，按 36 个角扇区 × 3 个径向区域分箱；统计真实和虚拟点落在哪些箱中，输出粗略 Bin-IoU 和 CAD 局部 +Y 可见侧比例。**不是**三维表面检测覆盖率或尺寸公差判定。
- **搜索策略：** 用已知机械曝光位姿，改变一个等效相机 Y 坐标，重复运行 M3 局部扫描；训练子集的有效性匹配与台阶扇区 IoU 综合成得分，用另外一部分帧检查稳定性。只有一条 H1 固定姿态扫描无法分别标定激光与相机真正的光学中心。

## 新增/修改源码

```text
include/twin/TwinM4Comparison.h      可移植 M2/M3 索引对比、四孔台阶分区
src/twin/TwinM4Comparison.cpp
include/twin/TwinM4Calibration.h     单参数相机 Y 候选搜索及训练/留出验证
src/twin/TwinM4Calibration.cpp
include/twin/TwinM4Adapter.h         Qt SCAN v3 到可移植内核桥接、JSON/CSV 导出
src/twin/TwinM4Adapter.cpp
include/widgets/DigitalTwinScanWidget.h
src/widgets/DigitalTwinScanWidget.cpp  新增 M4 对比/拟合/取消/应用/导出操作
src/app/MainWindow.cpp              标题改为 V28.3
CMakeLists.txt                      将算法编入 digital_twin_core，Qt 桥接只编入 GUI

# 用于离线自动回归的测试及真实 H1 缩减样本
 tests/twin/twin_m4_tests.cpp
 tests/twin/twin_m4_h1_real_tests.cpp
 tests/twin/data/h1_real_100_profiles.bin
 tools/twin_m4_extract_h1_reference.py
```

## 测试与真实数据回归

在 Linux 上（**只测试没有 Qt/VTK/厂商 SDK 的核心，不代表已经完成你的 VS2022 GUI 编译**）：

```bash
cmake -S . -B build-twin -DDIGITAL_TWIN_CLI_ONLY=ON -DTWIN_ENABLE_OCCT=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-twin -j
ctest --test-dir build-twin --output-on-failure
```

截至本次交付：离线 Debug/Release 10/10 测试通过，包括原 M0–M3 及 M4 合成/真实样本回归。

从用户提供的 H1 原始归档无插值地提取 100 条原始 Profile，共 103,973 个有效样本；测试夹具经过 CRC 检查并可用脚本重现。固定同样的曝光位姿与参考网格，得到：

| 等效相机 Y | H1 沉孔 ROI 有效性 F1（100 帧） |
|---:|---:|
| -75 mm | 约 0.2505 |
| +75 mm | 约 0.8657 |

100 帧的小样本拟合训练集最优值并非一定被留出集支持，因此新实现**不允许**在该情形下直接一键应用。真正的全 4,598 帧拟合需要通过你的 Windows 机器在 GUI 运行后才能报告，不应编造该结果。

## 当前边界

- 没有真实光学内参/光心校准；M4 搜索的是 H1 单视角约束下的 **effective Sensor-Y**。
- 真实 SCAN 的缺失原因无法从有效点子集本身唯一确定。
- 只提供 H1 四沉孔的 ROI 模板；其他 STEP 工件 M4 可以进行全局逐索引对比，但不能用该模板自动拟合四孔。
- 用 M4 获得更好匹配并不意味着其他 B/C 倾斜姿态的预测已经通过验证；规划五轴补扫之前，仍建议采集至少一组独立姿态作为外部验证。
- Windows 10/VS2022 + Qt6/VTK/OCCT 完整图形主程序在本执行环境无法编译运行；新增 Qt 代码经过源码检查，需要你在电脑上验证并反馈 MSVC 编译错误。
- M4 只对数据进行诊断和模型拟合，**不生成五轴补扫轨迹**（这是后续 M5/M6 的目标）。
