# V27.6.25 Stage-2 分层候选 / Lazy MachineSafety 高速姿态规划

本版本建立在 V27.6.24（后台线程 + 进度/ETA + 可取消）之上，解决几十万 Stage-2 原始候选姿态生成时间达到小时级的问题。

## 问题根因

V27.6.24 虽然把规划放到了工作线程，但每一个原始候选都执行了：

1. XYZ 逆解/限位；
2. 720 sample 光学可见弧仿真；
3. 精确 MachineSafety STL/FCL 目标姿态碰撞/距离检查；
4. synthetic profile；
5. Physical17 17x17 信息矩阵。

例如 GUI 中 D=92..100/2、gamma=0..50/5、eta=-7.5..7.5/1.5、B=-30..30/5、C=-45..45/5、双侧会形成 285285 个原始组合。实际最终只需要 48 个记录姿态，因此对 28 万个姿态逐一做精确 FCL 并不经济。

## 新规划流程

V27.6.25 改为四级规划：

1. **快速原始粗筛**
   - 只做球截面基本几何、传感器矩形/梯形包围边界、XYZ 逆解和软件限位；
   - 不调用 STL/FCL MachineSafety；
   - 不构造 17x17 信息矩阵。

2. **有界 deterministic shortlist**
   - 当可达候选超过 20000 时进入 dense mode；
   - 使用固定 SplitMix64 priority 对原始候选做可重复、无随机种子的均匀 reservoir；
   - reservoir 上限 32768；
   - 在线规划额外保留最多 256 个离当前实机姿态最近的 start anchors；
   - 最终信息候选目标数 = clamp(requestedPoses*96, 2048, 8192)，48 姿态时为 4608；
   - 小于等于 20000 候选时保持历史全候选行为与原始顺序。

3. **shortlist 光学 + Physical17 信息矩阵**
   - 720 sample 光学可见弧精检只对 shortlist 执行；
   - synthetic profile / 17x17 information 只对通过 shortlist gate 的候选计算；
   - 不再为 28 万个原始组合构建信息矩阵。

4. **D-optimal + Lazy 精确 MachineSafety**
   - D-optimal 只在信息 shortlist 上评分；
   - 精确目标姿态 MachineSafety 仅在某候选真正到达当前排名顶部、准备进入采集计划时调用，并缓存允许/拒绝结果；
   - swept transition MachineSafety 只对实际采集顺序中的候选边调用；
   - 最终进入计划的每一个姿态仍必须通过精确 target MachineSafety，计划内部每一条相邻过渡仍必须通过精确 transition MachineSafety。

因此这是**改变检查时机，不取消安全检查**。

## API 变化

`Physical17PlanningChecks` 增加：

```cpp
std::function<bool(const JointPose5d&, const Vec3d&)> shortlistAllowed;
```

GUI 使用：

- `shortlistAllowed` = scanCONTROL 详细光学可见弧仿真；
- `poseAllowed` = 精确 MachineSafety target FCL；
- `transitionAllowed` = 精确 MachineSafety swept transition。

为了兼容旧 core 调用，如果只设置 `poseAllowed` 而不设置 `shortlistAllowed`，仍保持旧版 eager pose filtering 行为。

## 进度条

阶段调整为：

- 0..2%：准备；
- 2..40%：快速 XYZ/FOV 边界粗筛；
- 40..65%：shortlist 光学 + 17x17 信息矩阵；
- 65..98%：D-optimal + 延迟精确 MachineSafety；
- 98..100%：最终姿态整理。

规划完成日志额外显示：

- shortlist 光学实际检查次数 / 剔除次数；
- 精确目标 MachineSafety 实际检查次数 / 剔除次数；
- 精确过渡 MachineSafety 实际检查次数 / 拒绝次数。

这样可以直接确认 FCL 是否从“几十万次”下降到“几十/几百次”。

## 回归与性能验证

Linux `V21_TESTS_ONLY=ON` 环境重新编译并通过：

- `v27618_profile_block_tests` PASS；
- `v20_single_sphere14_tests` PASS；
- `v20_2_single_sphere17_tests` PASS。

`v27618_profile_block_tests` 新增 hierarchical planner 回归，验证 dense grid 下 exact target/transition callbacks 不再按原始网格数量调用。

使用与现场截图一致的 285285 原始组合、48 个最终姿态做 core benchmark（不含 Windows FCL STL 引擎）：

- shortlist optical/information candidates: 4608；
- exact target callback: 48 次；
- exact transition callback: 47 次；
- 本 Linux 容器约 0.9 s（包含 720-sample `simulateOpticalFeasibility`，但 target/transition callback 在 benchmark 中为轻量 stub）。

现场 Windows 的真实耗时主要取决于约 95 次精确 FCL target/transition 查询，而不再取决于 285285 次 FCL 查询。

## 安全边界

1. 规划仍在后台线程，不执行真实机械运动。
2. 最终计划姿态必须通过精确 MachineSafety target gate。
3. 计划内部实际相邻边必须通过精确 swept-transition gate。
4. 离线规划没有真实当前 MPOS，因此仍不虚构“零位到首姿态”的过渡；真实执行前继续使用现有首段实时 MachineSafety 门禁。
5. 应用关闭时仍沿用 V27.6.24 的 cancel + join 生命周期保护。

完整 Windows/Qt/ZMotion/FCL GUI 需在现场 x64 工程环境重新编译并上机验证。
