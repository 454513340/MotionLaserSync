# V27.6.24 Stage-2 异步姿态生成 + 进度/ETA

本补丁建立在 V27.6.23（密集候选网格修复）之上，解决离线/在线生成 Stage-2 D-optimal 姿态时 GUI 因候选筛选、FCL MachineSafety 和 D-optimal 信息量计算耗时而出现“卡死/无响应”的问题。

## 修改内容

1. `SingleSphere17PosePlanner::generate()` 新增线程无关的规划进度回调和取消标志：
   - Preparing
   - FilteringCandidates
   - SelectingDOptimal
   - Finalizing
2. 候选网格筛选阶段按已检查原始组合数报告进度，并报告当前可行候选数。
3. D-optimal 阶段按候选信息量评分工作量报告连续进度，并报告已选姿态数/请求姿态数。
4. Stage-2 GUI 使用 `QtConcurrent::run` 把完整的重计算部分放到工作线程：
   - XYZ 逆解/限位筛选
   - scanCONTROL 光学可行性
   - MachineSafety 目标姿态检查
   - synthetic profile / 17x17 信息矩阵
   - D-optimal 贪心选择
   - 相邻姿态 MachineSafety 过渡检查
5. 新增“姿态生成”进度条、阶段文字、累计耗时和本阶段 ETA。
6. 新增“取消姿态生成”按钮；取消在候选筛选和 D-optimal 内循环中被轮询，不需要等待整套网格跑完。
7. 生成期间禁用球心点云导入/重新拟合，防止后台安全筛选所使用的标准球障碍在规划中途被改变。
8. 应用关闭时主动取消并 join Stage-2 规划线程，确保 `MainWindow` 的 MachineSafety 对象不会在线程仍使用回调时先析构。
9. 原 V27.6.23 的 20 万理论网格误拒绝修复保留不变：20 万限制仅作用于经过 XYZ/FOV/static-safety 后的实际可行候选，原始组合仅保留 500 万防呆上限。

## 进度条含义

GUI 0..100% 是分阶段映射，不等同于绝对线性耗时：

- 0..2%：准备候选网格
- 2..70%：XYZ/FOV/MachineSafety 候选筛选
- 70..98%：D-optimal 信息量选择与过渡门禁
- 98..100%：整理最终姿态

ETA 使用“当前阶段已完成工作量 / 当前阶段耗时”估算，因此刚进入一个新阶段时会显示“计算中”，工作量积累后显示本阶段预计剩余秒数/分钟数。

## 线程安全边界

规划线程不读取可变 UI 控件；启动时会复制 `PosePlannerConfig`、球心、Physical17 当前估计、光学参数和安全回调。MachineSafety 自身的 `checkPose/checkTransition` 使用内部 mutex 串行保护。

真实运动仍不在该线程中执行。生成姿态只做只读规划；上电执行每个姿态前仍保留原有实时 MachineSafety/到位门禁。

## 离线回归

Linux tests-only 环境已重新编译并运行：

- `v27618_profile_block_tests` PASS
- `v20_single_sphere14_tests` PASS
- `v20_2_single_sphere17_tests` PASS

`v27618_profile_block_tests` 新增规划 progress/cancellation 回归；原 profile-block 数值一致性仍为：

- residual max difference = `8.52651e-14`
- Jacobian max difference = `2.18557e-07`

完整 Windows/Qt/厂商 SDK GUI 仍需要在现场 Windows x64 工程环境重新编译和实机验证。
