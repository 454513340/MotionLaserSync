# V27.6.56 / ECI3808 V32.14：H1、H2、H3 三种硬件同步拓扑（工程验证版）

本版本**只以用户上传的 V27.6.55 RAR 为基础**增加代码，保留该包的全部原始文件、SDK、DLL/LIB、calibration/runtime_xyz、模型和标定数据；不存在以前版本的“源码树重建后漏资源”的问题。

## 现场线路（本版依赖）

- H1 原方式：ECI PWM0/OP14 同时连到 scanCONTROL 2950-50BL 数字触发 IN1 和 ECI IN0。BASIC 使用五轴 `REGIST(104,...)`，即 R0/IN0 逻辑下降沿连续锁存；scanCONTROL 采用数字外部 EdgeRising（与实际光耦极性相符）。
- H2：**ECI OP14 只负责触发 Profile 节拍**，scanCONTROL RS422 CMM 经 RS422→NPN 到 **ECI IN1（CN9 PIN14）**，五轴位置由 R1/IN1 `REGIST(114)` 或 `REGIST(115)` 锁存。旧 OP14→IN0 即使仍保留，软件不使用它的锁存数据。
- H3：**scanCONTROL 内部时钟**决定 Profile 周期，RS422 CMM→NPN→ECI IN1 仍由 R1 `REGIST(114)/(115)` 锁存；ECI OP14 在正式运行过程中保持关闭。ECI PWM_FREQ 仍记录同一个请求值，但 H3 不以 PWM 产生采集事件。
- RS422+ 传感器 PIN12 → 差分模块+；RS422− 传感器 PIN11 → 差分模块−。转换模块的 NPN/open collector 输出接 ECI IN1，供电、OGND 和隔离按转换器说明接线。**不要把 RS422 的电压直接接 ECI IN1**。
- ECI IN1 是 R1 锁存通道而不是普通的“IN0 替代线”；`REG_INPUTS=16` 映射 R1 至 IN1，R0 保留 IN0。接线转换可能反相，UI 允许选择 `REGIST(114)`（R1 逻辑上升沿）或 `REGIST(115)`（下降沿）；**先断开激光/运动，用示波器和 TABLE 计数确认正确极性**。

## 上位机操作

在传感器参数区域选择“三种硬件同步拓扑”中的 H1、H2 或 H3。H2/H3 可以选择 CMM→IN1 的 R1 边沿。原硬件频率控件仍生效；频率受 Measuring Field、曝光/空闲时间和系统能力约束。

`TABLE[354]=321056` 是本版握手 magic。原 `TABLE[355..361]` 频率与状态序号协议保留，新增：

| TABLE | 用途 |
|---|---|
| 365 | 主机请求 1=H1，2=H2，3=H3 |
| 366 | 主机请求 104（H1）/114或115（H2/H3） |
| 367 | BASIC 已应用模式 ACK |
| 368 | BASIC 已应用 REGIST 边沿 ACK |
| 369 | 5轴 R0/R1 硬件锁存 FIFO 已 Arm 的确认 |

主机写 `355Hz`、`365/366`，最后写 `359` 提交序号；BASIC 只能在 Idle 时改变 `PWM_FREQ` 和锁存通道，发布 `356/360/367/368` ACK。Probe 和进入 Run 前再次核对，任何修改发生在采集过程中立即故障停止。以前 `TABLE[357]=31` 的 XYZCB 五轴回零联锁仍保留。更新 BASIC 会将 `TABLE[357]` 清零，**必须五轴重新回零**。

## 关键时序

- H1 原链路：外部触发 + ColdPrime → 清 Session/Arm → 单帧 Probe → PWM 连续。
- H2：外部触发 + ColdPrime（CMM 此时关闭）→ 激活 CMM 输出（divisor=1）→ Arm ECI IN1 → 一帧 Profile + 一帧 IN1 Pose → PWM 连续。停机先停 PWM 且排空 FIFO，再关闭 CMM。
- H3：预设 scanCONTROL Internal 并写入从 10μs 整数单位量化的周期 → CMM 端口设置（divisor先为0）→ Arm ECI IN1 并读 `369=1` → `StartTransmissionAndCmmTrigger()` 只交付 CMM 有效的 Profile → 连续至少8帧建立 pairing → 正常连续采集。停机**先停 CMM 和传输，再停 ECI/排空 FIFO**。H3 不使用 H1/H2 的单帧 One-Shot Probe 或 ECI ColdPrime。
- **H1 原 OP14 时间补偿标定不得直接应用 H2/H3**；必须单独标定 CMM 相对曝光有效时刻和 RS422→IN1 传播延迟。

SDK 使用 `FEATURE_FUNCTION_DIGITAL_IO` / `MULTI_RS422_CMM` 配置 CMM 输出，依 C++ Interface Documentation v1.3 先设置 CMM ratio、skew、port，最后设置 divisor；`Timestamp2CmmTriggerAndInCounter()` 提取计数与有效标志。CMM 在每次连接后重新配置，不依赖 sensor user mode 保存。

## 程序空间限制与验收性质

本 BASIC 在用户原始 `controller/ECI3808_V32_13_PWM_HANDSHAKE_FIVE_AXIS_HOME.bas` 压缩版上作增量修改，沿用原来所有五轴 FIFO/Buffer-B/STOP-DRAIN 逻辑，只新增两个全局变量 `hm/he` 和数个短分支，不新增中断任务、数组或大型缓存。**ZDevelop 编译后的实际程序字节数未在此环境测得。ECI3808 4KB 程序空间的合格与否，必须由你用 ZDevelop 编译结果现场确认；源 BAS 文本大小不是编译后大小。若超过 4KB，应停止下载、进一步压缩 BASIC，不得取消安全联锁换容量。**

本版测试：Portable unit **31/31**；真实核心 Mock transport **108/111**，其中新增的 H1/H2/H3 模式/ACK/Arm/错误边沿测试均通过；3 个失败项在原始未修改的 V27.6.55 **同样失败**（陈旧 HOME 复核、补偿在重连后的授权撤销、部分 XYZ HOME 降级），未将其伪称全部通过。另在本环境无法 Windows MSVC/Qt/VTK/厂商 DLL 整体 GUI 编译、ZDevelop BASIC 编译或示波器实机测试。因此本版是**工程联调候选版而非已通过 4KB/机械安全现场验收的正式版**。

## 下载说明

**唯一正式候选 BASIC**：`controller/ECI3808_5Axis_Controller.bas`（同 `controller/ECI3808_V32_14_THREE_HARDWARE_TOPOLOGIES.bas` 和工程根目录 `ECI3808_V32_14_THREE_HARDWARE_TOPOLOGIES.bas` SHA256 相同）。旧 V32.13 文件仅作历史比对，不再下发。需同时部署 V27.6.56 上位机与 V32.14 BASIC；不可与 V27.6.55 上位机混搭（magic不同）。

现场建议逐步 H1 → H2 → H3：先断运动并用低频（建议200Hz）在 `IN0/IN1` 和 CMM converter 上看示波器，确认 `REGIST(114/115)` 的单边沿锁存；检查 H2 单帧 Probe，H3 前8帧配对和正式停止 FIFO tail；最后多频率、不同 Measuring Field、正反向轨迹验收。变更现场布线或软件版本都应重新验证。
