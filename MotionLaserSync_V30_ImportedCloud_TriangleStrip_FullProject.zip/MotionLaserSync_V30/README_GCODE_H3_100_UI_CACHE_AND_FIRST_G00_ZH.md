# V29 G代码：H3/100 参数页与只读检查不一致、首段 G00 错误拦截修复

## 0. 复现输入

用户在“参数设置”选择 **H3 / 100 Hz / R1=114**，但 G 代码只读检查仍声称“现场 H1 / 200 Hz”；连续 NC 第一条完整 XYZCB G00 与现场 MPOS 略有差异；头部 `InitialJointAnchored: false`。

相关源码：`MainWindow::onGCodeRequestSensorParams()`、`GCodeExecutor::inspectRealRunReadOnly()`、`GCodeExecutor::start()`、`GCodeWidget::onRealRunPreflightClicked()`。

## 1. 确认的根因

1. `MainWindow::onGCodeRequestSensorParams()` 过去硬编码 `SyncMode::Software`，既不转发参数页 H1/H3、频率、R1 边沿，也不考虑 NC 自身显式的 `SyncMode: Hardware`。
2. `SyncManager` 的 H1/200 初值不会因为用户只修改参数页控件就自动刷新；此前“实机准入检查”仅看 `m_syncMgr->hardwareTopology()/hardwareTriggerFrequencyHz()`，把**旧内存缓存**错误叫做“当前现场配置”。
3. `InitialJointAnchored: false` 和 `start()` 中每轴位置差大于 0.05 的硬编码，错误地把“导入 NC 前必须已在第一个扫描点”作为一项普遍前提。实际上首段 G00 是一个移动指令，必须在执行前根据实时 MPOS 验证该段运动。

## 2. 修改内容

- `MainWindow::onGCodeRequestSensorParams()` 每次读取参数页最新 H1/H3、频率、R1 边沿、扫描测量场索引，并把它们作为**UI 意图**传给 GCodeWidget。不再写死 Software。
- 在 GCodeWidget 点击“实机准入检查（只读）”时先同步读取参数页 UI 值，但**不调用运动、PWM、采集或解锁命令**。审计文本、JSON 分别记录“参数页意图”和“SyncManager 内存缓存”，均不声称它们是物理硬件读回。
- 参数页 H3/100 与 NC H3/100 一致，而缓存仍是 H1/200：显示“内存缓存未同步”，不再将其误判为现场电气模式不一致。真正启动前，在空闲状态下将 UI 意图暂存到 SyncManager；仅更新本地参数，硬件在通过既有独立验收后才可能被配置。
- 单独区分“手动采集的 Software/Hardware 单选按钮”与“NC 内明确声明的 SyncMode”；不允许旧 GUI 软件模式静默覆盖硬件 NC，亦不允许 NC 规避完整的实机前置验证。
- `InitialJointAnchored` 改为导入阶段的**信息性字段**，不再仅凭 false 当作必须人工预定位的阻断。只读检查记录首段 G00 与当前 MPOS 的五轴差值与“启动前校验”动作。
- 正式开始前重新读取实时 MPOS：如相差足够大，须有经独立认证的现场进场路径验证回调，检查与当前 NC SHA-256 绑定的“实时 MPOS → 首个 G00”路径；未接入时默认拒绝执行。若实时 MPOS 已接近 G00，仍需既有 NC 签署和硬件同步验收。
- 在首 G00 真正下发前，再读一遍五轴 MPOS，如与执行准入时读取的位置不一致则拒绝使用过期批准。
- `HardwarePreflightLogic.h` 新增独立于 Qt 的纯逻辑校验，且补齐针对 H3/100 与旧缓存 H1/200 的测试。
- Python 离线审计不再把 `InitialJointAnchored: false` 等同于“导入前必须已到起点”；但仍要求正式执行时独立验证首条 G00 的真实路径。

## 3. 和用户日志的关系

用户报告的实际 MPOS：`43.6435,-4.4725,-7.8425,-9.9995,-10.0015`，首个 G00：`43.6534,-4.4676,-7.8229,-10,-10`。

最大 XYZ 差 = **0.0196 mm**；最大 BC 差 = **0.0015°**。两者均小于旧逻辑所用的 0.05 同单位比较阈值，且新的距离检查严格区分毫米与角度。

这是**运动起点诊断**，并不意味着 `OfflineOnly=true` 或当前标定、碰撞、传感器触发认证自动通过。

## 4. 验证结果及限制

- 可移植 C++ 单元测试：H3/100 UI 意图 vs H1/200 旧内存缓存、R1 边沿拒绝、首个 G00 近/远及 NaN：通过。
- 多姿态离线 NC 与 G05/G93/M50/M51 核心测试：通过。
- 源码静态测试：参数刷新、首 G00 动态验证、`OfflineOnly`、现场独立验证器及控制器预检仍保留：通过。
- 本环境缺少 Windows Qt/VTK、控制器和实际接线，因此无法宣称 GUI 在 MSVC 下已通过编译、NC 已经执行或 H3 物理链路已经通过验收。尚未解除离线 NC 硬件限制。

## 5. 在 Windows 中如何观察修复

1. 进入参数设置：选择 **H3 / 100 Hz / R1=114**；保存/确认测量场参数。
2. G 代码模块重新载入**真正声明 H3/100 Hz** 的 NC（不要改动旧 NC 文件头来伪造新同步模式）。
3. 点击“实机准入检查（只读）”。新报告应分别包含：
   - `参数设置页选择（仅UI意图，非控制器读回）：H3、100 Hz、R1=114`
   - `SyncManager当前内存缓存（非现场硬件读回）：...`
   - 如果两者不一致，会报告**本地缓存待刷新**，不再声称硬件实际就是 H1/200。
4. 首 G00 部分显示当前 MPOS 与目标轴差。若 `InitialJointAnchored=false`，不再仅因此认为“导入前需人工预定位”。
5. **仍不要删除 OfflineOnly、删掉独立验证器或把参数页值当作实际物理读回。** 只有真实首段路径、工件/夹具、NC 版本和 H3 电气同步均经过现场验收，才能通过既有正式执行门控。
