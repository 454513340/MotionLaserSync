# V27.6.16K / V32.9 PWM stop-tail + calibration-stop fix

## Fixed

1. **REGIST ring rollover remains fixed at 128 data slots.** The V32.8B correction is integrated into the active BASIC.
2. **Normal PWM stop tail:** BASIC changes PWM0 to 100% for 6 ms, then to 0%. This suppresses normal periodic OFF edges during the hold and creates one deliberate final OFF edge after scanCONTROL has cleared its exposure+idle busy interval. The same final edge is therefore eligible for both scanCONTROL and REGIST(104). Integrity checks remain strict; no pose is silently dropped.
3. **Physical17 post-stop re-injection:** `runningChanged(false)` now schedules the calibration refresh with `QTimer::singleShot(0, ...)`, after `SyncManager::stop()` returns and releases `m_stopping`.
4. **Diagnostics text:** active hardware-sync reports and errors refer to 200 Hz PWM0 rather than TIMER0.

## Intentionally unchanged

- Ordinary upper-PC coordinate convention remains XYZ=DPOS, C/B=mechanical MPOS.
- Hardware-sync TABLE records remain XYZ/C/B five-axis REGIST(104) MPOS.
- C/B control-page refresh during hardware capture is not changed in this revision.
- Full integrity requires `ControllerPublishedLatch == Pose == Profile == Aligned`; the host does not mask a residual stop mismatch.

## Suggested field checks

After download, verify `?*TABLE(330,22)`, `?PWM_FREQ(0)`, `?PWM_DUTY(0)`, and run a 5-10 s acquisition. Also inspect `?TABLE(353)` for REGIST FIFO wrap count.
